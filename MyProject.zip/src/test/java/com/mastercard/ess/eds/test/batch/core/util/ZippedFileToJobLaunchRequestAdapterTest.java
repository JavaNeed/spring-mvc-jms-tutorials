package com.mastercard.ess.eds.test.batch.core.util;

import static org.junit.Assert.*;

import java.io.File;

import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersIncrementer;
import org.springframework.batch.core.job.SimpleJob;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.integration.launch.JobLaunchRequest;

import com.mastercard.ess.eds.core.util.ZippedFileToJobLaunchRequestAdapter;

public class ZippedFileToJobLaunchRequestAdapterTest {
	
	ZippedFileToJobLaunchRequestAdapter zippedFileToJobLaunchRequestAdapter;
	Job job;
	JobParametersIncrementer jobParametersIncrementer;
	
	@Before
	public void init() {
		job = new SimpleJob("importRawRecord");
		zippedFileToJobLaunchRequestAdapter = new ZippedFileToJobLaunchRequestAdapter();
		zippedFileToJobLaunchRequestAdapter.setInputDirectory("/tmp/");
		zippedFileToJobLaunchRequestAdapter.setDataFileName("payload.csv");
		zippedFileToJobLaunchRequestAdapter.setJob(new SimpleJob("importrawrecord"));
	}
	
	@Test
	public void testInputDirectory() throws NoSuchJobException {
		assertEquals("/tmp/", zippedFileToJobLaunchRequestAdapter.getInputDirectory()); 
	}
	
	@Test
	public void testDataFileName() throws NoSuchJobException {
		assertEquals("payload.csv", zippedFileToJobLaunchRequestAdapter.getDataFileName()); 
	}
	
	@Test
	public void testFileRequest() throws NoSuchJobException {
		File file = new File("adaptorFilePath");
		zippedFileToJobLaunchRequestAdapter.adapt(file);
		
	}
}
