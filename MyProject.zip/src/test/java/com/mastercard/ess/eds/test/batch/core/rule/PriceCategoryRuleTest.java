package com.mastercard.ess.eds.test.batch.core.rule;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.core.rule.PriceCategoryRule;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.ProcessedRecord;

/**
 * @author e068303 This is to test the functionality and coverage of the easy
 *         rule class
 */
public class PriceCategoryRuleTest {
	ProcessedRecord procRecord, procRecord1;
	private EDSRecord edsRecord;

	PriceCategoryRule priceCategoryRule, priceCategoryRule1, priceCategoryRule2, priceCategoryRule3, priceCategoryRule4,
			priceCategoryRule5, priceCategoryRule6, priceCategoryRule7, priceCategoryRule8, priceCategoryRule9;
	private boolean checkretVal;
	private Logger logger = Logger.getLogger(PriceCategoryRule.class);
	Date date, date1, date2, date3;

	@Before
	public void setUp() throws Exception {
		logger.setLevel(Level.DEBUG);

		priceCategoryRule = new PriceCategoryRule("rule_0");
		priceCategoryRule.setOperator1(">=");
		priceCategoryRule.setOperator2("<=");
		priceCategoryRule.setOperand1(new BigDecimal(50));
		priceCategoryRule.setOperand2(new BigDecimal(150));
		priceCategoryRule.setExternal("Y");
		priceCategoryRule.setDerived("N");
		priceCategoryRule.setExternal("Y");
		priceCategoryRule.setExternalStatus("Y");
		priceCategoryRule.setDerivedStatus("N");
		priceCategoryRule.setAdcNotified("Y");
		priceCategoryRule.setPriceCategory(3);
		priceCategoryRule.setConfidenceScore(55);

		priceCategoryRule1 = new PriceCategoryRule("rule_1");
		priceCategoryRule1.setOperator1(">");
		priceCategoryRule1.setOperator2("=");
		priceCategoryRule1.setOperand1(new BigDecimal(50));
		priceCategoryRule1.setOperand2(new BigDecimal(150));
		priceCategoryRule1.setExternal("Y");
		priceCategoryRule1.setDerived("N");
		priceCategoryRule1.setExternal("Y");
		priceCategoryRule1.setDerived("N");
		priceCategoryRule1.setAdcNotified("N");
		priceCategoryRule1.setPriceCategory(2);
		priceCategoryRule1.setConfidenceScore(65);
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String dateInString = "07/06/2013";
		String dateInString1 = "11/11/2016";
		String dateInString2 = "11/11/2018";
		String dateInString3 = "11/11/2019";

		date = formatter.parse(dateInString);
		date1 = formatter.parse(dateInString1);
		date2 = formatter.parse(dateInString2);
		date3 = formatter.parse(dateInString3);
		priceCategoryRule1.setStartDate(date);

		priceCategoryRule1.setEndDate(date1);

		priceCategoryRule.setEndDate(date2);
		priceCategoryRule3 = new PriceCategoryRule("rule_2");

		priceCategoryRule3.setEndDate(date1);
		priceCategoryRule3.setStartDate(date2);
		priceCategoryRule3.setOperator1(">");
		priceCategoryRule3.setOperator2("=");
		priceCategoryRule3.setExternal("b");
		priceCategoryRule3.setDerived("Y");

		priceCategoryRule4 = new PriceCategoryRule("rule_3");
		priceCategoryRule4.setStartDate(date);
		priceCategoryRule4.setExternal("y");
		priceCategoryRule4.setOperator2(">");
		priceCategoryRule4.setOperand2(new BigDecimal(50));
		priceCategoryRule4.setStartDate(date);
		priceCategoryRule4.setEndDate(date2);
		priceCategoryRule4.setAdcNotified("adcNotified");
		
		priceCategoryRule4 = new PriceCategoryRule("rule_4");
		priceCategoryRule5 = new PriceCategoryRule("rule_5");
		priceCategoryRule6 = new PriceCategoryRule("rule_6");
		priceCategoryRule7 = new PriceCategoryRule("rule_7");
		priceCategoryRule7.setEndDate(date1);
		priceCategoryRule7.setStartDate(date2);
		priceCategoryRule7.setOperator1(">");

		priceCategoryRule8 = new PriceCategoryRule("rule_8");
		priceCategoryRule8.setStartDate(date2);
		priceCategoryRule8.setEndDate(date);
		priceCategoryRule5.setStartDate(date2);
		priceCategoryRule6.setOperator1("<");
		procRecord = new ProcessedRecord();
		procRecord.setDaysSinceLastActivity(150);
		procRecord.setIsAccountADCNotified("N");
		procRecord.setIsAccountActive("Y");
		procRecord.setAccountValid(true);
		procRecord.setIsAccountADCNotified("Y");
		procRecord.setConfidenceText("Very High");
		procRecord.setActivityText("Recent");

		procRecord1 = new ProcessedRecord();
		procRecord1.setDaysSinceLastActivity(150);
		procRecord1.setIsAccountADCNotified("Y");
		procRecord1.setIsAccountActive("Y");
		procRecord1.setAccountValid(true);
		procRecord1.setIsAccountADCNotified("N");
		procRecord1.setConfidenceText("Very High");
		procRecord1.setActivityText("Recent");
	}

	@Test
	public void test() {
		logger.setLevel(Level.DEBUG);
		priceCategoryRule9 = new PriceCategoryRule("rule_9");

		checkretVal = priceCategoryRule9.validateRule(priceCategoryRule9);
		assertEquals(checkretVal, true);
		checkretVal = priceCategoryRule.checkOperator(">=", 50, 150);
		assertEquals(checkretVal, false);
		checkretVal = priceCategoryRule1.checkOperator("=", 50, 150);
		assertEquals(checkretVal, false);
		checkretVal = priceCategoryRule1.checkOperator("<", 40, 150);
		assertEquals(checkretVal, false);
		checkretVal = priceCategoryRule1.checkOperator(">", 40, 150);
		assertEquals(checkretVal, true);
		checkretVal = priceCategoryRule1.checkOperator("<=", 50, 150);
		assertEquals(checkretVal, false);
		checkretVal = priceCategoryRule1.checkOperator("<=", 50, 50);
		assertEquals(checkretVal, false);
		checkretVal = priceCategoryRule1.checkOperator("<", 40, 30);
		assertEquals(checkretVal, true);
		checkretVal = priceCategoryRule1.checkOperator("=", 50, 50);
		assertEquals(checkretVal, true);
 
		priceCategoryRule1.setExternalStatus("Y");
		priceCategoryRule1.setDerivedStatus("N");
		checkretVal = priceCategoryRule1.validateRule(priceCategoryRule1);
		assertEquals(checkretVal, false);
		checkretVal = priceCategoryRule.validateRule(priceCategoryRule);
		assertEquals(checkretVal, false);
		checkretVal = priceCategoryRule3.validateRule(priceCategoryRule3);
		assertEquals(checkretVal, false);
		checkretVal = priceCategoryRule4.validateRule(priceCategoryRule4);
		assertEquals(checkretVal, true);
		checkretVal = priceCategoryRule5.validateRule(priceCategoryRule5);
		assertEquals(checkretVal, false);
		checkretVal = priceCategoryRule6.validateRule(priceCategoryRule6);
		assertEquals(checkretVal, false);
		checkretVal = priceCategoryRule7.validateRule(priceCategoryRule7);
		assertEquals(checkretVal, false);
		checkretVal = priceCategoryRule8.validateRule(priceCategoryRule8);
		assertEquals(checkretVal, false);

		checkretVal = priceCategoryRule1.evaluate();

		assertEquals(checkretVal, false);
		priceCategoryRule3.setExternalStatus("N");
		priceCategoryRule3.setDerivedStatus("N");
		priceCategoryRule3.setAdcNotified("acNotified");

		checkretVal = priceCategoryRule3.evaluate();

		assertEquals(checkretVal, false);

		priceCategoryRule4.setExternalStatus("Y");
		priceCategoryRule4.setDerivedStatus("Y");
		priceCategoryRule4.setExternal("Y");
		priceCategoryRule4.setDerived("Y");
		priceCategoryRule4.setAdcNotified("Y");


		checkretVal = priceCategoryRule4.evaluate();

		assertEquals(checkretVal, false);

		priceCategoryRule5.setExternalStatus("N");
		priceCategoryRule5.setDerivedStatus("Y");
		priceCategoryRule5.setExternal("N");
		priceCategoryRule5.setDerived("Y");
		priceCategoryRule5.setOperand2(new BigDecimal(50));
		priceCategoryRule5.setOperator2(">");
		priceCategoryRule5.setAdcNotified("N");

		checkretVal = priceCategoryRule5.evaluate();

		assertEquals(checkretVal, false);

		priceCategoryRule2 = new PriceCategoryRule();
		priceCategoryRule1.setInputToRule(procRecord);
		priceCategoryRule1.execute();
		priceCategoryRule2.setInputToRule(procRecord);
		priceCategoryRule2.execute();
		priceCategoryRule3.setInputToRule(procRecord1);
		priceCategoryRule3.execute();
		procRecord1.setConfidenceScore(0);
		priceCategoryRule4.setInputToRule(procRecord1);
		priceCategoryRule4.execute();
		priceCategoryRule5.setInputToRule(procRecord);
		priceCategoryRule5.execute();
		priceCategoryRule2.setOperand1(new BigDecimal(100));
		priceCategoryRule2.setOperator1(">");
		priceCategoryRule2.setOperand2(new BigDecimal(300));
		priceCategoryRule2.setOperator2("<");
		priceCategoryRule2.setAdcNotified("N");
		edsRecord = new EDSRecord();
		edsRecord.setProcRecord(procRecord);

		priceCategoryRule2.setExternalStatus("Y");
		priceCategoryRule2.setDerivedStatus("N");

		priceCategoryRule2.setExternal("Y");
		priceCategoryRule2.setDerived("N");
		priceCategoryRule2.setPriceCategory(3);
		priceCategoryRule2.setConfidenceScore(75);
		priceCategoryRule2.setStartDate(date);
		priceCategoryRule2.validateRule(priceCategoryRule2);
		priceCategoryRule2.evaluate();
		priceCategoryRule2.execute();

	}
	
	@Test
	public void testSetters() {
		priceCategoryRule2 = new PriceCategoryRule();
		priceCategoryRule2.setExternal("Y");
		priceCategoryRule2.setDerived("N");
		priceCategoryRule2.setPriceCategory(3);
		priceCategoryRule2.setConfidenceScore(75);
		priceCategoryRule2.setStartDate(date);
		priceCategoryRule = new PriceCategoryRule(priceCategoryRule2);
		priceCategoryRule.setActivityText("");
		assertEquals("", priceCategoryRule.getActivityText());
		priceCategoryRule.setConfidenceText("");
		assertEquals("", priceCategoryRule.getConfidenceText());
		assertEquals(3, priceCategoryRule.getPriceCategory());
	}
	
	@Test
	public void testAccountNumber() {
		priceCategoryRule2 = new PriceCategoryRule();
		PriceCategoryRule.getMaskedAccountNumber("123456789");
	}
}
