package com.mastercard.ess.eds.test.batch.core.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.core.util.DeDupeCPPUtil;
import com.mastercard.ess.eds.core.util.DeDupePan;
import com.mastercard.ess.eds.core.util.DeDupeTokens;
import com.mastercard.ess.eds.domain.AuthDebitPanDetailRecord;

public class DeDupeCPPUtilTest {
	
	private ExecutionContext executionContext = null; 
	private List<AuthDebitPanDetailRecord> authDebitlist = null;
	private DeDupePan deDupePan = null;
	
	@Before
	public void setUp() {
		deDupePan = DeDupePan.getInstance();
		executionContext = new ExecutionContext();
		executionContext.put(DeDupeTokens.DE_DUPE_PAN.getDesc(),deDupePan);
		
		authDebitlist = new ArrayList<AuthDebitPanDetailRecord>();
	}
	
	@Test
	public void testCheckDuplicate(){
		AuthDebitPanDetailRecord authDebitPanDetailRecord1=new AuthDebitPanDetailRecord();
		authDebitPanDetailRecord1.setCppRuleId(new BigDecimal(100));
		authDebitPanDetailRecord1.setdWSource("AUTH");
		authDebitPanDetailRecord1.setRawPan("123");
		authDebitlist.add(authDebitPanDetailRecord1);
		
		AuthDebitPanDetailRecord authDebitPanDetailRecord2=new AuthDebitPanDetailRecord();
		authDebitPanDetailRecord2.setCppRuleId(new BigDecimal(101));
		authDebitPanDetailRecord2.setdWSource("AUTH");
		authDebitPanDetailRecord2.setRawPan("123");
		authDebitlist.add(authDebitPanDetailRecord2);
		
		ConcurrentHashMap<String, StringBuffer> panRuleMapEx = new ConcurrentHashMap<String, StringBuffer>();
		executionContext.put(DeDupeTokens.PAN_RULE_MAP.getDesc(), panRuleMapEx);
		
		List<AuthDebitPanDetailRecord> uniqueAuthDebitlist = DeDupeCPPUtil.filterDuplicates(executionContext, authDebitlist);
		//assertEquals(uniqueAuthDebitlist.size(),1);
		
		Map<String, StringBuffer> panRuleMap = (ConcurrentHashMap<String, StringBuffer>)executionContext.get(DeDupeTokens.PAN_RULE_MAP.getDesc());
		
		//assertEquals(panRuleMap.get("123").toString(),"100,101");
	}

}
