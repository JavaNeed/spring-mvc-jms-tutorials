package com.mastercard.ess.eds.test.batch.core.util;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.core.util.DevUtil;

public class DevUtilTest {
	
	DevUtil devUtil;
	
	@Before
	public void init(){
		devUtil = new DevUtil();
		devUtil.setKeyStorePath("/tmp/keystore");
	}
	
	@Test
	public void testKeyStorePath(){
		assertEquals("/tmp/keystore",devUtil.getKeyStorePath());
	}
	
	@Test
	public void testString() {
		assertEquals("dev", devUtil.getEnv());
	}

}
