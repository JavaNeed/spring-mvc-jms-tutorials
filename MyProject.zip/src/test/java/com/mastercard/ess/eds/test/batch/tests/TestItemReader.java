package com.mastercard.ess.eds.test.batch.tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.test.MetaDataInstanceFactory;
import org.springframework.batch.test.StepScopeTestExecutionListener;
import org.springframework.batch.test.StepScopeTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import com.mastercard.ess.eds.domain.RawRecord;
import com.mastercard.ess.eds.test.batch.config.CommonConfigTest;

@RunWith(SpringJUnit4ClassRunner.class)
@TestExecutionListeners({ DependencyInjectionTestExecutionListener.class, StepScopeTestExecutionListener.class })
@ContextConfiguration(classes = CommonConfigTest.class)

public class TestItemReader {

	@Autowired
	private org.springframework.batch.item.file.ResourceAwareItemReaderItemStream<RawRecord> itemReader;

	@Test
	@Ignore
	public void testReader() {

		ClassPathResource resource = new ClassPathResource("MCI.AR.RABC.X.E1234567.D160812.T111135.C066");
		itemReader.setResource(resource);
		StepExecution execution = MetaDataInstanceFactory.createStepExecution();
		int count = 0;
		try {
			count = StepScopeTestUtils.doInStepScope(execution, () -> {
				int num = 0;
				itemReader.open(execution.getExecutionContext());
				RawRecord record;
				try {
					while ((record = itemReader.read()) != null) {
						assertNotNull(record);
						assertNotNull(record.getPayloadValue("URL"));
						assertNotNull(record.getRawPan());
						// assertNotNull(record.getRawData());
						assertNotNull(record.getStatus());
						// assertFalse(record.getEarning().equalsIgnoreCase(""));
						num++;
					}
				} finally {
					try {
						itemReader.close();
					} catch (ItemStreamException e) {
						fail(e.toString());
					}
				}
				return num;
			});
		} catch (Exception e) {
			fail(e.toString());
		}
		assertEquals(6, count);
	}
}
