package com.mastercard.ess.eds.test.batch.processor;

import static org.mockito.Mockito.mock;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.processor.AuthRecordProcessor;
import com.mastercard.ess.eds.core.service.EDSCPPRulesService;
import com.mastercard.ess.eds.domain.AuthDebitPanDetailRecord;
import com.mastercard.ess.eds.domain.CPPRuleRecord;

public class AuthRecordProcessorTest {
	private static Logger logger = Logger.getLogger(AuthRecordProcessorTest.class);

	private AuthRecordProcessor authRecordProcessor;

	private EDSCPPRulesService edsCPPRulesService;
	private ExecutionContext executionContext;
	private CPPRuleRecord cppRuleRcrd;
	List<AuthDebitPanDetailRecord> authDebitPanDetailRecordList=new ArrayList<>();

	@Before
	public void init() {
		logger.setLevel(Level.DEBUG);
		authRecordProcessor = new AuthRecordProcessor();
		edsCPPRulesService = mock(EDSCPPRulesService.class);
		authRecordProcessor.setEdsCPPRulesService(edsCPPRulesService);
		authRecordProcessor.getEdsCPPRulesService();
		authRecordProcessor.setRunCppRuleForDays("5");
		authRecordProcessor.getRunCppRuleForDays();
		authRecordProcessor.setExecutionContext(executionContext);
		authRecordProcessor.getExecutionContext();
		
		cppRuleRcrd=new CPPRuleRecord();
		cppRuleRcrd.setActiveSW("Y");
		cppRuleRcrd.setCatCD("E");
		cppRuleRcrd.setClsIssrCntry("ONEOF");
		cppRuleRcrd.setClsLocTranAmt("EQUALS");
		cppRuleRcrd.setClsMerchant("EQUALS");
		cppRuleRcrd.setCreateDate(new Date(2017, 01, 10));
		cppRuleRcrd.setCreatedBy(null);
		cppRuleRcrd.setFirstRunSW("Y");
		cppRuleRcrd.setLastUpdateDate(new Date(2017, 01, 10));
		cppRuleRcrd.setLastUpdatedBy(null);
		cppRuleRcrd.setUnitTmCount("WEEKS");
		cppRuleRcrd.setValIssrCntry("USA");
		cppRuleRcrd.setValLocTranAmt(new BigDecimal(100));
		cppRuleRcrd.setValMerchant(0);
		cppRuleRcrd.setValTmCount(90);
		cppRuleRcrd.setCppRuleId(new BigDecimal(100));

		AuthDebitPanDetailRecord authDebitPanDetailRecord=new AuthDebitPanDetailRecord();
		authDebitPanDetailRecord.setCppRuleId(new BigDecimal(100));
		authDebitPanDetailRecord.setdWSource("AUTH");
		authDebitPanDetailRecord.setRawPan("");
		authDebitPanDetailRecordList.add(authDebitPanDetailRecord);
	}

	/*We are testing authProcessor functionality where we are passing cppRuleRecord and it returns list of authDebitPanDetailRecordList after quering dw database*/
	@Test
	public void testProcess() throws Exception {
		logger.setLevel(Level.DEBUG);
		List<AuthDebitPanDetailRecord> panList=new LinkedList<AuthDebitPanDetailRecord>();
		List<String> cppRuleIdList =new ArrayList<>();
		cppRuleIdList.add("1");
		cppRuleIdList.add("2");
		cppRuleIdList.add("3");
		cppRuleIdList.add("4");
		
		executionContext=new ExecutionContext();
		executionContext.put("failedCPPRuleIds", cppRuleIdList);
		
		authRecordProcessor.setExecutionContext(executionContext);
		
		logger.setLevel(Level.DEBUG);
		authRecordProcessor.process(cppRuleRcrd);
		
	}
	
	@Test
	public void testProcessException() throws Exception {
		authRecordProcessor = new AuthRecordProcessor();
		logger.setLevel(Level.DEBUG);
		
		List<String> cppRuleIdList =new ArrayList<>();
		cppRuleIdList.add("1");
		cppRuleIdList.add("2");
		cppRuleIdList.add("3");
		cppRuleIdList.add("4");
		
		executionContext=new ExecutionContext();
		executionContext.put("failedCPPRuleIds", cppRuleIdList);
		
		authRecordProcessor.setExecutionContext(executionContext);
		
		logger.setLevel(Level.DEBUG);
		authRecordProcessor.process(cppRuleRcrd);
		
	}



}
