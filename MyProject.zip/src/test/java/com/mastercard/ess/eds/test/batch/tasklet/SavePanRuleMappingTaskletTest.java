package com.mastercard.ess.eds.test.batch.tasklet;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.tasklet.SavePanRuleMappingTasklet;
import com.mastercard.ess.eds.core.service.CPPRuleRecordService;

public class SavePanRuleMappingTaskletTest {
	SavePanRuleMappingTasklet savePanRuleMappingTasklet;
	CPPRuleRecordService cppRuleRecordService;
	ExecutionContext executionContext;
	String srcId;
	String jobInstanceName;
	StepContribution stepContribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	private static Logger logger = Logger.getLogger(SavePanRuleMappingTasklet.class);
	
	@Before
	public void init(){
		logger.setLevel(Level.DEBUG);
		savePanRuleMappingTasklet=new SavePanRuleMappingTasklet();
		cppRuleRecordService=EasyMock.createMock(CPPRuleRecordService.class);
		jobInstance = new JobInstance(new Long(123), "createCPPSource");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("createCPPSource", jobExecution);
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		stepContribution = new StepContribution(stepExecution);
		executionContext=new ExecutionContext();
		executionContext.put("edsSrcId","5");
		savePanRuleMappingTasklet.getExecutionContext();
		savePanRuleMappingTasklet.setExecutionContext(executionContext);
		savePanRuleMappingTasklet.getJobInstanceName();
		savePanRuleMappingTasklet.setJobInstanceName(jobInstanceName);
		savePanRuleMappingTasklet.setCppRuleRecordService(cppRuleRecordService);
		
		
	}
	@Test
	public void testExecute() {
		savePanRuleMappingTasklet.execute(stepContribution, chunkContext);
	}

	
}
