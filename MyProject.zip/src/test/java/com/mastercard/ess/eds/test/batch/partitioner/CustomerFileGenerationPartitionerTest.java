package com.mastercard.ess.eds.test.batch.partitioner;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.partitioner.CustomerFileGenerationPartitioner;
import com.mastercard.ess.eds.core.service.EDSRecordWriterService;
import com.mastercard.ess.eds.domain.EDSCustomer;

public class CustomerFileGenerationPartitionerTest {

	EDSRecordWriterService edsRecordWriterService;
	ExecutionContext executionContext;
@Before
public void init()
{
	CustomerFileGenerationPartitioner customerFileGenerationPartitioner=new CustomerFileGenerationPartitioner();
	List<String> icas = new ArrayList<>();
	icas.add("12345");
	executionContext=new ExecutionContext();
	executionContext.put("updateHistIcas", icas);
	customerFileGenerationPartitioner.getExecutionContext();
	customerFileGenerationPartitioner.setExecutionContext(executionContext);
	customerFileGenerationPartitioner.getFirstTimeRunLimit();
	customerFileGenerationPartitioner.setFirstTimeRunLimit(5);
	customerFileGenerationPartitioner.getSubsequentRunLimit();
	customerFileGenerationPartitioner.setSubsequentRunLimit(8);
	
}
	@Test
	public void test() {
		edsRecordWriterService = EasyMock.createMock(EDSRecordWriterService.class);
		List<EDSCustomer> records = new ArrayList<EDSCustomer>();		
		EDSCustomer edsCustomer = new EDSCustomer() ;
		edsCustomer.setHistFlag("Y");
		edsCustomer.setIca(1234);
		records.add(edsCustomer);
		EasyMock.expect(edsRecordWriterService.getICAsWithHistFlagForFileGeneration()).andReturn(records);
		EasyMock.replay(edsRecordWriterService);
		CustomerFileGenerationPartitioner customerFileGenerationPartitioner = new  CustomerFileGenerationPartitioner(edsRecordWriterService);	
		customerFileGenerationPartitioner.setExecutionContext(new ExecutionContext());
		assertNotNull(customerFileGenerationPartitioner.partition(0));
		
	}
	
}
