package com.mastercard.ess.eds.test.batch.config;

import static org.junit.Assert.*;

import javax.sql.DataSource;

import org.junit.Test;
import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
import org.springframework.batch.core.configuration.annotation.DefaultBatchConfigurer;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
/*
 * This is a common test class to initialize the test context
 * 
 */
@Configuration
@ComponentScan("com.mastercard.ess.eds.test")
@EnableBatchProcessing
@ImportResource({ "classpath:/import-raw-record-test.xml", "classpath:/context.xml", "classpath:/database-config.xml",
		"classpath:/pan-process-batch-job-test.xml", "email-integration-context-test.xml",
		"customer-file-generation-job-test.xml" })

public class CommonConfigTest {

	@Bean
	BatchConfigurer configurer(@Qualifier("testDataSource") DataSource dataSource) {
		return new DefaultBatchConfigurer(dataSource);
	}
	
	/*
	 * dummy test case for sonar compliance
	 */
	@Test
	public void sample()
	{
		int intValueToCompare = 1;
		assertEquals(1,intValueToCompare);
	}
}
