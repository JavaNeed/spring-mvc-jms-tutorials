package com.mastercard.ess.eds.test.core.util;

import static org.junit.Assert.*;

import java.io.File;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat; 
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List; 
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.easymock.EasyMock;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.test.util.ReflectionTestUtils;

import com.mastercard.ess.eds.core.service.CustomerFileReportService;
import com.mastercard.ess.eds.core.util.CustomerEnrollmentReportGenerator;
import com.mastercard.ess.eds.domain.CustomerEnrollmentReport;

public class CustomerEnrollmentReportGeneratorTest {
	private static Logger logger = Logger
			.getLogger(CustomerEnrollmentReportGeneratorTest.class);

	CustomerEnrollmentReportGenerator customerEnrollmentReportGenerator;
	CustomerEnrollmentReport customerEnrollmentReport;
	CustomerEnrollmentReport customerEnrollmentReport1;
	CustomerFileReportService customerFileReportService;
	//CustomerPanReportDao customerPanReportDao;
	List<CustomerEnrollmentReport> customerEnrollmentReportList;

	Sheet sheet;
	Workbook workbook;
	Row row;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	BigDecimal jobInstanceId;
	String jobInstanceName;
	String filePath;
	static String customerEnrollmentReportPath="..";
	private static final String MMMM_YYYY = "MMMM-yyyy";	
	@Before
	public void init() {
		logger.setLevel(Level.DEBUG);
		customerFileReportService = EasyMock
				.createMock(CustomerFileReportService.class);
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		jobParameter = new JobParameter(new Date());
		parameters.put("currentDateTime", jobParameter);
		jobParameters = new JobParameters(parameters);
		jobInstanceId = BigDecimal.valueOf(1);
		jobInstanceName = "CustomerEnrollmentReportGenerator";
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("custEnrlRpt", jobExecution);

		stepContext = new StepContext(stepExecution);
		CustomerEnrollmentReport custEnrlRept = new CustomerEnrollmentReport();
		customerEnrollmentReportList = new ArrayList<CustomerEnrollmentReport>();
		custEnrlRept.setActiveCust(1);
		custEnrlRept.setCode("test");
		custEnrlRept.setCustomerEnrollmentReportId(1);
		custEnrlRept.setDateCreated(new Date());
		custEnrlRept.setEnrolledCust(1);
		custEnrlRept.setUnEnrolledCust(1);
		customerEnrollmentReportList.add(custEnrlRept);
		Calendar currentCal = Calendar.getInstance();  
		DateFormat dateFormat = new SimpleDateFormat(MMMM_YYYY);
		String currentMonth=dateFormat.format(currentCal.getTime());
		filePath =  "..Customer_Enrollment_Report"+ "_" + currentMonth + ".xlsx";
	}

	@Test
	public void test() {

		logger.setLevel(Level.DEBUG);
		customerFileReportService = EasyMock.createMock(CustomerFileReportService.class);

		EasyMock.expect(
				customerFileReportService.createGeneratedFileRecord(filePath,
						new BigDecimal(1), jobInstanceName, 6)).andReturn(1);
		EasyMock.replay(customerFileReportService);

		customerEnrollmentReportGenerator = new CustomerEnrollmentReportGenerator();
		customerEnrollmentReportGenerator = new CustomerEnrollmentReportGenerator(customerEnrollmentReportPath, customerFileReportService);
		customerEnrollmentReportGenerator.writeToCustomerEnrollmentReport(customerEnrollmentReportList, jobInstanceId, jobInstanceName);
		File shouldExist = new File(customerEnrollmentReportPath);
		assertTrue(shouldExist.exists());
	}
	@Test
	public void testIssuerRegionandContinentBasedCustCount() {
		customerEnrollmentReportGenerator = new CustomerEnrollmentReportGenerator();
		workbook = new XSSFWorkbook();
		sheet = workbook.createSheet("US");
		row = sheet.createRow(3);
		CustomerEnrollmentReport custEnrlRept = new CustomerEnrollmentReport();
		customerEnrollmentReportList = new ArrayList<CustomerEnrollmentReport>();
		custEnrlRept.setActiveCust(1);
		custEnrlRept.setCode("test");
		custEnrlRept.setCustomerEnrollmentReportId(1);
		custEnrlRept.setDateCreated(new Date());
		custEnrlRept.setEnrolledCust(1);
		custEnrlRept.setUnEnrolledCust(1);
		customerEnrollmentReportList.add(custEnrlRept);
		ReflectionTestUtils.invokeMethod(customerEnrollmentReportGenerator,
				"mapObjectWithContinentToCustCount", customerEnrollmentReportList, "August-17", "September-17", sheet, new HashMap<Integer, Object[]>(),"test");
	}

	@Test
	public void testWriteDataInSheet() {
		customerEnrollmentReportGenerator = new CustomerEnrollmentReportGenerator();
		workbook = new XSSFWorkbook();
		sheet = workbook.createSheet("US");
		row = sheet.createRow(3);
		ReflectionTestUtils.invokeMethod(customerEnrollmentReportGenerator,
				"writeDataInSheet", workbook, sheet, 1, new HashMap<Integer, Object[]>());
	}

	@Test
	public void testSheetName() {
		customerEnrollmentReportGenerator = new CustomerEnrollmentReportGenerator();
		String sheetName1=customerEnrollmentReportGenerator.getSheetNameByContinentId("1");
		String sheetName2=customerEnrollmentReportGenerator.getSheetNameByContinentId("A");
		String sheetName3=customerEnrollmentReportGenerator.getSheetNameByContinentId("B");
		String sheetName4=customerEnrollmentReportGenerator.getSheetNameByContinentId("C");
		String sheetName5=customerEnrollmentReportGenerator.getSheetNameByContinentId("D");
		String sheetName6=customerEnrollmentReportGenerator.getSheetNameByContinentId("E");
		String sheetName7=customerEnrollmentReportGenerator.getSheetNameByContinentId("F");
		assertEquals("US",sheetName1);
		assertEquals("NAM",sheetName2);
		assertEquals("EUROPE",sheetName3);
		assertEquals("LAC",sheetName4);
		assertEquals("APAC",sheetName5);
		assertEquals("MEA",sheetName6);
		assertEquals("US",sheetName7);

	}

	@Test
	public void testCreateCellValue() {
		customerEnrollmentReportGenerator = new CustomerEnrollmentReportGenerator();
		workbook = new XSSFWorkbook();
		sheet = workbook.createSheet("US");
		row = sheet.createRow(3);
		ReflectionTestUtils.invokeMethod(customerEnrollmentReportGenerator,
				"createCellValue", workbook, row, new Object[] {
				"ICAs Type","17-August","17-July","June-17","May-17" }, 3);
		ReflectionTestUtils.invokeMethod(customerEnrollmentReportGenerator,
				"createCellValue", workbook, row, new Object[] { null }, 3);
	}

	//We will delete the customerEnrollmentReportGenerator from classpath in after block
	@AfterClass
	public static void checkFileDeletion() {
		try {
			File[] dirFiles = new File(".").listFiles();
			// Search Through the list
			for (int i = 0; i < dirFiles.length; i++) { // If the Files start
				if (dirFiles[i].getName().startsWith("Customer_Enrollment_Report_", 0) || dirFiles[i].getName().startsWith("..Customer_Enrollment_Report_", 0))
					try {
						File file = new File(customerEnrollmentReportPath+dirFiles[i].getName());

						if (file.delete()) {

						} else {
							File file1 = new File(dirFiles[i].getName());
							file1.delete();
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
			}

		} catch (Exception e) {

			e.printStackTrace();

		}
	}
}
