package com.mastercard.ess.eds.billing.util;

import static org.junit.Assert.assertEquals;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.mastercard.ess.eds.core.util.PreProcessingPANStatusManager;

public class BillDataSchedulerTest {
	@Autowired
	ApplicationContext context;
	@Autowired
	JobLauncher joLauncher;
	
	BillDataScheduler billDataScheduler = new BillDataScheduler();
	private Logger logger = Logger.getLogger(BillDataScheduler.class);
	
	@Before
	public void init(){
		context = EasyMock.createNiceMock(ApplicationContext.class);
		joLauncher = EasyMock.createNiceMock(JobLauncher.class);
		logger.setLevel(Level.DEBUG);
		logger.setLevel(Level.INFO);
		
	}
	@Test
	public void runTest(){
		logger.setLevel(Level.DEBUG);
		try {
			billDataScheduler.context=context;
			billDataScheduler.setJoLauncher(joLauncher);
			billDataScheduler.run();
		} catch (JobExecutionAlreadyRunningException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testJoLancher() {
		logger.setLevel(Level.DEBUG);
		billDataScheduler.context=context;
		billDataScheduler.setJoLauncher(joLauncher);
		assertEquals(joLauncher, billDataScheduler.getJoLauncher());
	}
	
	@Test
	public void testJoLancherTwo() throws JobExecutionAlreadyRunningException {
		logger.setLevel(Level.INFO);
		billDataScheduler.context=context;
		billDataScheduler.setJoLauncher(null);
		billDataScheduler.run();
	}
}
