package com.mastercard.ess.eds.test.batch.writer;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Test;

import com.mastercard.ess.eds.batch.writer.PanUnavailabilityEventWriter;
import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.domain.EDSCustomer;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;

public class PanUnavailabilityEventWriterTest {
	NotificationEventVO notification;
	PanUnavailabilityEventWriter panUnavailabilityEventWriter;
	List<EDSCustomer> customer;
	Map<String, String> jobParams;
	EDSCustomer eDSCustomer;
	private static Logger logger = Logger.getLogger(PanUnavailabilityEventWriter.class);

	@Test
	public void test() {
		logger.setLevel(Level.DEBUG);
		panUnavailabilityEventWriter = new PanUnavailabilityEventWriter();
		notification = new NotificationEventVO();
		customer = new ArrayList<EDSCustomer>();
		
		jobParams = new HashMap<String, String>();
		jobParams.put("customerName","ICICI BANK");
		jobParams.put("ica", "292");
		notification = new NotificationEventVO();
		notification.setEventName("NO_COMPROMISED_PANS_AVL");
		notification.setJobParams(jobParams);
		notification.setJobName("panProcessJob");
		notification.setJobID(new BigDecimal(123));
		eDSCustomer =new EDSCustomer();
		eDSCustomer.setCustomerName("ICICI");
		eDSCustomer.setIca(132);
		customer.add(eDSCustomer);
		try {
			panUnavailabilityEventWriter.write(customer);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
