package com.mastercard.ess.eds.test.billing.tasklet;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;

import com.mastercard.ess.eds.billing.dao.BillDataDAO;
import com.mastercard.ess.eds.billing.tasklet.BillDataTasklet;

public class BillDataTaskletTest {
    BillDataTasklet billDataTasklet;
    BillDataDAO billDataDAO;
    StepContribution contribution;
    ChunkContext chunkContext;
    StepExecution stepExecution;
    StepContext stepContext;
    JobParameters jobParameters;
    JobParameter jobParameter;
    JobExecution jobExecution;
    JobInstance jobInstance;
    private static Logger logger = Logger.getLogger(BillDataTasklet.class);

    @Before
    public void init() {
        logger.setLevel(Level.DEBUG);
        billDataDAO = EasyMock.createMock(BillDataDAO.class);
        EasyMock.expect(billDataDAO.getEligibleICAList()).andReturn(new ArrayList<Map<String, Object>>());
        EasyMock.replay(billDataDAO);
    }

    @Test
    public void test() {
        logger.setLevel(Level.DEBUG);
        String fileName = "file:///MCI.AR.RABC.X.E1234567.D160812.T111135.C001";
        Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
        billDataTasklet = new BillDataTasklet();
        billDataTasklet.setBillDataDao(billDataDAO);
        jobParameter = new JobParameter(fileName, true);
        parameters.put("input.file", jobParameter);
        jobParameters = new JobParameters(parameters);

        jobInstance = new JobInstance(new Long(123), "billdataFile");
        jobExecution = new JobExecution(jobInstance, jobParameters);
        stepExecution = new StepExecution("billdataFile", jobExecution);

        stepContext = new StepContext(stepExecution);
        chunkContext = new ChunkContext(stepContext);
        contribution = new StepContribution(stepExecution);

        chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(
                "listOfEligibleIca", new ArrayList<Map<String, Object>>());

        billDataTasklet.execute(contribution, chunkContext);
    }

}
