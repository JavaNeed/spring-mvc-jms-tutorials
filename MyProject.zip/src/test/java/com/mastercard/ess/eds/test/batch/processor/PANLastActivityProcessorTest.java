package com.mastercard.ess.eds.test.batch.processor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.mastercard.ess.eds.batch.processor.PANLastActivityProcessor;
import com.mastercard.ess.eds.core.dao.DWDao;
import com.mastercard.ess.eds.core.service.PANLastActivityService;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.ProcessedRecord;
import com.mastercard.ess.eds.domain.RawRecord;

public class PANLastActivityProcessorTest {
	
	private static Logger logger = Logger.getLogger(PANLastActivityProcessor.class);
	
	@InjectMocks
	private PANLastActivityProcessor panLastActivityProcessor = new PANLastActivityProcessor();
	
	@Mock
	private PANLastActivityService panLastActivityService;
	
	@Mock
	private DWDao dwDao;

	private EDSRecord edsRecord;
	private java.util.Date createDate;
	
	@Before
    public void setUp() throws Exception {
		logger.setLevel(Level.DEBUG);
		MockitoAnnotations.initMocks(this);		
		edsRecord = new EDSRecord();
		createDate = new java.util.Date();
		RawRecord rawRecord = new RawRecord();
		rawRecord.setCreateDate(createDate);
		edsRecord.setRawRecord(rawRecord);
		ProcessedRecord procRecord = new ProcessedRecord();
		procRecord.setPan(new BigDecimal("6746587485749859"));
		edsRecord.setProcRecord(procRecord);
		panLastActivityService = new PANLastActivityService(dwDao);
		
	}
	
	@Test //(expected = NullPointerException.class)
    public void testProcess() throws Exception {
		logger.setLevel(Level.DEBUG);
        EDSRecord edsrecord = panLastActivityProcessor.process(edsRecord);
        Assert.assertNotNull(edsrecord);
    }
	
	@Test
	public void testProcessInfo(){
		logger.setLevel(Level.INFO);
        EDSRecord edsrecord = panLastActivityProcessor.process(edsRecord);
        Assert.assertNotNull(edsrecord);
    }
	
	@Test
	public void testGetMostRecentDate() throws ParseException{
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
		logger.setLevel(Level.DEBUG);
		//Test for all values 
		String strAuthDate = "2016-11-02 00:00:00";
		java.sql.Date authDate = new java.sql.Date((simpleDateFormat.parse(strAuthDate)).getTime());
		String strDebitDate = "2016-11-03 00:00:00";
		java.sql.Date debitDate = new java.sql.Date((simpleDateFormat.parse(strDebitDate)).getTime());
		String strClearingDate = "2016-11-04 00:00:00";
		java.sql.Date clearingDate = new java.sql.Date((simpleDateFormat.parse(strClearingDate)).getTime());
		assertEquals(clearingDate, panLastActivityProcessor.getMostRecentDate(authDate, debitDate, clearingDate));
		
		//Test for only 2 values 
		assertEquals(clearingDate, panLastActivityProcessor.getMostRecentDate(null, debitDate, clearingDate));
		assertEquals(clearingDate, panLastActivityProcessor.getMostRecentDate(authDate, null, clearingDate));
		assertEquals(debitDate, panLastActivityProcessor.getMostRecentDate(authDate, debitDate, null));
		
		//Test for single value
		assertEquals(clearingDate, panLastActivityProcessor.getMostRecentDate(null, null, clearingDate));
		assertEquals(authDate, panLastActivityProcessor.getMostRecentDate(authDate, null, null));
		assertEquals(debitDate, panLastActivityProcessor.getMostRecentDate(null, debitDate, null));
		
		//Test for null		
		assertNull( panLastActivityProcessor.getMostRecentDate(null, null, null));
		
	}
	
	@Test
	public void testGetMostRecentDateInfo() throws ParseException{
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
		logger.setLevel(Level.INFO);
		//Test for all values 
		String strAuthDate = "2016-11-02 00:00:00";
		java.sql.Date authDate = new java.sql.Date((simpleDateFormat.parse(strAuthDate)).getTime());
		String strDebitDate = "2016-11-03 00:00:00";
		java.sql.Date debitDate = new java.sql.Date((simpleDateFormat.parse(strDebitDate)).getTime());
		String strClearingDate = "2016-11-04 00:00:00";
		java.sql.Date clearingDate = new java.sql.Date((simpleDateFormat.parse(strClearingDate)).getTime());
		assertEquals(clearingDate, panLastActivityProcessor.getMostRecentDate(authDate, debitDate, clearingDate));
		
		//Test for all values with combination
		String strAuthDateRevised = "2016-11-03 00:00:00";
		java.sql.Date authDateRevised = new java.sql.Date((simpleDateFormat.parse(strAuthDateRevised)).getTime());
		String strDebitDateRevised = "2016-11-04 00:00:00";
		java.sql.Date debitDateRevised = new java.sql.Date((simpleDateFormat.parse(strDebitDateRevised)).getTime());
		String strClearingDateRevised = "2016-11-02 00:00:00";
		java.sql.Date clearingDateRevised = new java.sql.Date((simpleDateFormat.parse(strClearingDateRevised)).getTime());
		assertEquals(debitDateRevised, panLastActivityProcessor.getMostRecentDate(authDateRevised, debitDateRevised, clearingDateRevised));
		
		//Test for all values with combination
		String strAuthDateReRevised = "2016-11-04 00:00:00";
		java.sql.Date authDateReRevised = new java.sql.Date((simpleDateFormat.parse(strAuthDateReRevised)).getTime());
		String strDebitDateReRevised = "2016-11-02 00:00:00";
		java.sql.Date debitDateReRevised = new java.sql.Date((simpleDateFormat.parse(strDebitDateReRevised)).getTime());
		String strClearingDateReRevised = "2016-11-03 00:00:00";
		java.sql.Date clearingDateReRevised = new java.sql.Date((simpleDateFormat.parse(strClearingDateReRevised)).getTime());
		assertEquals(authDateReRevised, panLastActivityProcessor.getMostRecentDate(authDateReRevised, debitDateReRevised, clearingDateReRevised));
				
		//Test for only 2 values 
		assertEquals(debitDateRevised, panLastActivityProcessor.getMostRecentDate(null, debitDateRevised, clearingDateRevised));
		assertEquals(authDateRevised, panLastActivityProcessor.getMostRecentDate(authDateRevised, null, clearingDateRevised));
		assertEquals(debitDateRevised, panLastActivityProcessor.getMostRecentDate(authDateRevised, debitDateRevised, null));
		
		//Test for only 2 values with combination
		assertEquals(clearingDateReRevised, panLastActivityProcessor.getMostRecentDate(null, debitDateReRevised, clearingDateReRevised));
		assertEquals(authDateReRevised, panLastActivityProcessor.getMostRecentDate(authDateReRevised, null, clearingDateReRevised));
		assertEquals(authDateReRevised, panLastActivityProcessor.getMostRecentDate(authDateReRevised, debitDateReRevised, null));
		
		//Test for only 2 values with combination
		assertEquals(clearingDate, panLastActivityProcessor.getMostRecentDate(null, debitDate, clearingDate));
		assertEquals(clearingDate, panLastActivityProcessor.getMostRecentDate(authDate, null, clearingDate));
		assertEquals(debitDate, panLastActivityProcessor.getMostRecentDate(authDate, debitDate, null));
		
		//Test for single value
		assertEquals(clearingDate, panLastActivityProcessor.getMostRecentDate(null, null, clearingDate));
		assertEquals(authDate, panLastActivityProcessor.getMostRecentDate(authDate, null, null));
		assertEquals(debitDate, panLastActivityProcessor.getMostRecentDate(null, debitDate, null));
		
		//Test for null		
		assertNull( panLastActivityProcessor.getMostRecentDate(null, null, null));
	}
	
	@Test
	public void testGetDaysSinceLastActivity() throws ParseException{
		logger.setLevel(Level.DEBUG);
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
		String strAuthDate = "2012-11-02 00:00:00";
		String strCreateDate = "2013-12-03 00:00:00";
		java.sql.Date authDate = new java.sql.Date((simpleDateFormat.parse(strAuthDate)).getTime());
		java.sql.Date createDate = new java.sql.Date((simpleDateFormat.parse(strCreateDate)).getTime());
		int days = panLastActivityProcessor.getDaysSinceLastActivity(authDate, createDate);
		Assert.assertTrue(days > 0);
	}
	
	@Test
	public void testGetDaysSinceLastActivityInfo() throws ParseException{
		logger.setLevel(Level.INFO);
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
		String strAuthDate = "2012-11-02 00:00:00";
		String strCreateDate = "2013-12-03 00:00:00";
		java.sql.Date authDate = new java.sql.Date((simpleDateFormat.parse(strAuthDate)).getTime());
		java.sql.Date createDate = new java.sql.Date((simpleDateFormat.parse(strCreateDate)).getTime());
		int days = panLastActivityProcessor.getDaysSinceLastActivity(authDate, createDate);
		Assert.assertTrue(days > 0);
	}
	
	
	@Test
	public void testServiceAuth(){
		logger.setLevel(Level.DEBUG);
		Date date = panLastActivityService.getAuthRecord("7847589458954594950",createDate);
		assertNull(date);
	}
	
	@Test
	public void testServiceAuthInfo(){
		logger.setLevel(Level.INFO);
		Date date = panLastActivityService.getAuthRecord("7847589458954594950",createDate);
		assertNull(date);
	}
	
	@Test
	public void testServiceDebit(){
		logger.setLevel(Level.DEBUG);
		Date date = panLastActivityService.getDebitRecord("7847589458954594950",createDate);
		assertNull(date);
	}
	
	@Test
	public void testServiceDebitInfo(){
		logger.setLevel(Level.INFO);
		Date date = panLastActivityService.getDebitRecord("7847589458954594950",createDate);
		assertNull(date);
	}
	
	@Test
	public void testServiceClearing(){
		logger.setLevel(Level.DEBUG);
		Date date = panLastActivityService.getClearingRecord("7847589458954594950",createDate);
		assertNull(date);
	}
	
	@Test
	public void testServiceClearingInfo(){
		logger.setLevel(Level.INFO);
		Date date = panLastActivityService.getClearingRecord("7847589458954594950",createDate);
		assertNull(date);
	}
	
	@Test
	public void testLessAccountNumber() {
		panLastActivityProcessor.getMaskedAccountNumber("2");
		assertEquals("2",panLastActivityProcessor.getMaskedAccountNumber("2"));
	}
	
	@Test
	public void DateCompare() throws ParseException  {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
		logger.setLevel(Level.INFO);
		//Test for all values 
		String strAuthDate = "2016-11-06 00:00:00";
		java.sql.Date authDate = new java.sql.Date((simpleDateFormat.parse(strAuthDate)).getTime());
		String strDebitDate = "2016-11-04 00:00:00";
		java.sql.Date debitDate = new java.sql.Date((simpleDateFormat.parse(strDebitDate)).getTime());
		String strClearingDate = "2016-11-07 00:00:00";
		java.sql.Date clearingDate = new java.sql.Date((simpleDateFormat.parse(strClearingDate)).getTime());
		panLastActivityProcessor.getMostRecentDate(authDate, debitDate, clearingDate);
		
	}
	
	@Test
	public void nullCheck() throws ParseException {
		logger.setLevel(Level.DEBUG);
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
		String strAuthDate = "2016-11-06 00:00:00";
		java.sql.Date authDate = new java.sql.Date((simpleDateFormat.parse(strAuthDate)).getTime());
		String strDebitDate = "2016-11-04 00:00:00";
		java.sql.Date debitDate = new java.sql.Date((simpleDateFormat.parse(strDebitDate)).getTime());
		String strClearingDate = "2016-11-07 00:00:00";
		java.sql.Date clearingDate = new java.sql.Date((simpleDateFormat.parse(strClearingDate)).getTime());

      Mockito.when(panLastActivityService.getAuthRecord("6746587485749859",createDate)).thenReturn(authDate);
      Mockito.when(panLastActivityService.getDebitRecord("6746587485749859",createDate)).thenReturn(debitDate);
      Mockito.when(panLastActivityService.getClearingRecord("6746587485749859",createDate)).thenReturn(clearingDate);
		
      panLastActivityProcessor.setService(panLastActivityService);
      logger.setLevel(Level.INFO);
		//Test for all values 
      EDSRecord edsrecord = panLastActivityProcessor.process(edsRecord);
		
	
	}
}
