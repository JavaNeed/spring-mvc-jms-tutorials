package com.mastercard.ess.eds.test.batch.tasklet;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;
import com.mastercard.ess.eds.batch.tasklet.ConsolidatedEmailTasklet;
import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.core.service.EventSubscriptionService;
import com.mastercard.ess.eds.notification.dao.NotificationDAO;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;

public class ConsolidatedEmailTaskletTest {
	ConsolidatedEmailTasklet consolidatedEmailTasklet;
	EventPublisher eventPublisher;
	EventSubscriptionService eventSubscriptionService;
	NotificationEventVO notificationEventVO;
	NotificationDAO notificationDAO;
	BigDecimal jobInstanceId;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	ExecutionContext executionContext;
	StepContribution contribution;
	List<Map<String, Object>> finl;

	private Logger logger = Logger
			.getLogger(ConsolidatedEmailTaskletTest.class);

	@Before
	public void setUp() throws Exception {
		logger.setLevel(Level.DEBUG);
		consolidatedEmailTasklet=new ConsolidatedEmailTasklet();
		Map<String,String> jobParams=new HashMap<>();
		jobParams.put("emailId", "customerName");
		String jobInstanceName="consolidatemail";
		Map<String, JobParameter> parameters = new LinkedHashMap<>();
		jobParameter = new JobParameter(jobInstanceName, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);
		jobInstance = new JobInstance(new Long(123), "eventName");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("eventName", jobExecution);
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		contribution=new StepContribution(stepExecution);
		eventPublisher=new EventPublisher();
		eventSubscriptionService=new EventSubscriptionService();		
		notificationEventVO=new NotificationEventVO();
		consolidatedEmailTasklet.getEventPublisher();
		consolidatedEmailTasklet.setEventPublisher(eventPublisher);
		consolidatedEmailTasklet.getEventSubscriptionService();
		consolidatedEmailTasklet.setEventSubscriptionService(eventSubscriptionService);
		consolidatedEmailTasklet.getJobInstanceId();
		consolidatedEmailTasklet.setJobInstanceId(new BigDecimal("111"));
		consolidatedEmailTasklet.getJobInstanceName();
		consolidatedEmailTasklet.setJobInstanceName(jobInstanceName);
		consolidatedEmailTasklet.getJobParams();
		consolidatedEmailTasklet.setJobParams(jobParams);
		consolidatedEmailTasklet.getNotificationDAO();
		executionContext=new ExecutionContext();
		Map<String, String> customerName = new HashMap<String, String>();
		customerName.put("124","abc");
		customerName.put("125","test");
		List<String> icaList = new ArrayList<>();
		icaList.add(null);
		icaList.add(null);
		executionContext.put("icas", icaList);
		executionContext.put("icaName", customerName);
		executionContext.put("eventId", "eventId");
		executionContext.put("eventName", "eventName");
		jobExecution.setExecutionContext(executionContext);
		notificationDAO=EasyMock.createMock(NotificationDAO.class);
	}

	@Test
	public void executeTest() throws Exception {
		List<Map<String, Object>> finl=new  ArrayList<Map<String, Object>>();
		Map<String, Object> map1=new HashMap<String, Object>();
		map1.put("EMAIL_ID", "ica");
		map1.put("ICA_NUM", "124");
		finl.add(map1);
		Map<String, Object> map2=new HashMap<String, Object>();
		map2.put("EMAIL_ID", "ica");
		map2.put("ICA_NUM", "124");
		finl.add(map2);
		eventSubscriptionService=EasyMock.createMock(EventSubscriptionService.class);
		EasyMock.expect(eventSubscriptionService.getEmailIdsUsingICA(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(finl).once();
		EasyMock.replay(eventSubscriptionService);
		consolidatedEmailTasklet.setEventSubscriptionService(eventSubscriptionService);
		consolidatedEmailTasklet.setNotificationDAO(notificationDAO);
		EasyMock.expect(notificationDAO.getCustomerDefaultMail(EasyMock.anyObject())).andReturn("ica").times(2);
		EasyMock.replay(notificationDAO);
		consolidatedEmailTasklet.execute(contribution, chunkContext);
	}
	@Test
	public void executeTest1() throws Exception {
		List<Map<String, Object>> finl=new  ArrayList<Map<String, Object>>();
		Map<String, Object> map1=new HashMap<String, Object>();
		map1.put("EMAIL_ID", null);
		map1.put("ICA_NUM", "124");
		finl.add(map1);
		Map<String, Object> map2=new HashMap<String, Object>();
		map2.put("EMAIL_ID", "ica");
		map2.put("ICA_NUM", "125");
		finl.add(map2);
		eventSubscriptionService=EasyMock.createMock(EventSubscriptionService.class);
		EasyMock.expect(eventSubscriptionService.getEmailIdsUsingICA(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(finl).once();
		EasyMock.replay(eventSubscriptionService);
		consolidatedEmailTasklet.setEventSubscriptionService(eventSubscriptionService);
		consolidatedEmailTasklet.setNotificationDAO(notificationDAO);
		EasyMock.expect(notificationDAO.getCustomerDefaultMail(EasyMock.anyObject())).andReturn("ica").times(2);
		EasyMock.replay(notificationDAO);
		consolidatedEmailTasklet.execute(contribution, chunkContext);
	}
}
