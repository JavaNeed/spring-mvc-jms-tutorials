package com.mastercard.ess.eds.test.batch.writer;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.writer.SimulationRecordDBWriter;
import com.mastercard.ess.eds.domain.AuthDebitPanDetailRecord;


public class SimulationRecordDBWriterTest {
	SimulationRecordDBWriter simulationRecordDBWriter;
	BigDecimal jobInstanceId;
	String jobInstanceName;
	ExecutionContext executionContext;
	List<List<AuthDebitPanDetailRecord> >authDebitPanDetailRecords=new ArrayList<>();
	Logger logger = Logger.getLogger(SimulationRecordDBWriterTest.class);

	@Before
	public void init()
	{
		logger.setLevel(Level.DEBUG);
		simulationRecordDBWriter=new SimulationRecordDBWriter();
		AuthDebitPanDetailRecord authDebitPanDetailRecord=new AuthDebitPanDetailRecord();
		authDebitPanDetailRecord.setCppRuleId(new BigDecimal(1));
		authDebitPanDetailRecord.setdWSource("DEBIT");
		authDebitPanDetailRecord.setRawPan("12345");
		List<AuthDebitPanDetailRecord> authDebitPanList=new ArrayList<>();
		authDebitPanList.add(authDebitPanDetailRecord);
		authDebitPanDetailRecords.add(authDebitPanList);
		executionContext=new ExecutionContext();
		executionContext.put("cppSimulationSet", new HashSet<>());
		simulationRecordDBWriter.setJobInstanceId(BigDecimal.valueOf(2222));
		simulationRecordDBWriter.getJobInstanceId();
		simulationRecordDBWriter.setJobInstanceName("CppSimulationSet");
		simulationRecordDBWriter.getJobInstanceName();
		simulationRecordDBWriter.setExecutionContext(executionContext);
		simulationRecordDBWriter.getExecutionContext();
	}
	@Test
	public void testWrite() throws Exception
	{
		logger.setLevel(Level.DEBUG);
		simulationRecordDBWriter.write(authDebitPanDetailRecords);
	}
}