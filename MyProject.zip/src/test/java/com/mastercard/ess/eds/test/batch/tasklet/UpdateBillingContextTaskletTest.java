package com.mastercard.ess.eds.test.batch.tasklet;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.tasklet.UpdateBillingContextTasklet;
import com.mastercard.ess.eds.batch.tasklet.UpdateCustomerContextTasklet;

public class UpdateBillingContextTaskletTest {

    UpdateBillingContextTasklet updateBillingContextTasklet;
    StepContribution stepContribution;
    ChunkContext chunkContext;
    StepExecution stepExecution;
    StepContext stepContext;
    JobParameters jobParameters;
    JobExecution jobExecution;
    JobInstance jobInstance;
    ExecutionContext executionContext;
    String billRunMode;

    private static Logger logger = Logger.getLogger(UpdateCustomerContextTasklet.class);

    @Before
    public void setUp() throws Exception {

        logger.setLevel(Level.DEBUG);
        updateBillingContextTasklet = new UpdateBillingContextTasklet();
        jobInstance = new JobInstance(new Long(123), "updateBillingContextTasklet");
        jobExecution = new JobExecution(jobInstance, jobParameters);
        stepExecution = new StepExecution("billing", jobExecution);
        stepContext = new StepContext(stepExecution);
        chunkContext = new ChunkContext(stepContext);
        stepContribution = new StepContribution(stepExecution);
        executionContext = new ExecutionContext();
        executionContext.put("billRunMode", billRunMode);
        updateBillingContextTasklet.getExecutionContext();
        updateBillingContextTasklet.setExecutionContext(executionContext);
        updateBillingContextTasklet.getBillRunMode();
        updateBillingContextTasklet.setBillRunMode(billRunMode);

    }

    @Test
    public void testExecute() throws Exception {
        updateBillingContextTasklet.execute(stepContribution, chunkContext);
    }

}
