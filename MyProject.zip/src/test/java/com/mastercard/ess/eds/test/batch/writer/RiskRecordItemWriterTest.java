package com.mastercard.ess.eds.test.batch.writer;

import java.io.File;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.commons.dbcp.BasicDataSource;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.config.FileStatus;
import com.mastercard.ess.eds.batch.writer.RiskRecordItemWriter;
import com.mastercard.ess.eds.billing.dao.BillDataDAO;
import com.mastercard.ess.eds.core.dao.CustomerPanReportDao;
import com.mastercard.ess.eds.core.dao.EDSRecordDao;
import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.core.icatopanmapping.ICAAccountRange;
import com.mastercard.ess.eds.core.rule.PriceCategoryRule;
import com.mastercard.ess.eds.core.service.CustomerFileReportService;
import com.mastercard.ess.eds.core.service.CustomerMasterService;
import com.mastercard.ess.eds.core.service.EDSRecordWriterService;
import com.mastercard.ess.eds.core.util.PriceCategoryRuleCache;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.ICAStatus;
import com.mastercard.ess.eds.domain.ProcessedRecord;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;

public class RiskRecordItemWriterTest {
	String location="..";
	String filePrefix="$Junit";
	CustomerFileReportService customerFileReportService;
	CustomerMasterService customerMasterService;
	PriceCategoryRuleCache priceCategoryRuleCache;
	NotificationEventVO notificationEventVO;
	EventPublisher eventPublisher;
	ProcessedRecord procRecord;
	EDSRecord edsRecord;
	List<EDSRecord> list;
	EDSRecordWriterService edsRecordWriterService;
	EDSRecordDao edsRecordDao;
	BillDataDAO billDataDao;
	StepExecution paramStepExecution;
	CustomerPanReportDao customerPanReportDao;
	RiskRecordItemWriter riskRecordItemWriter =  new RiskRecordItemWriter();
	JobInstance jobInstance;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	PriceCategoryRule priceCategoryRule;
	ExecutionContext executionContext;
	List<EDSRecord> listOfRecordsToWrite = new CopyOnWriteArrayList<EDSRecord>();

	Map<BigDecimal, String> procRecordToFileMap = new ConcurrentHashMap<>();


	@Before
	public void setup()
	{		

		String date = "2000-11-01 00:00:00";
		java.sql.Timestamp javaSqlDate = java.sql.Timestamp.valueOf(date);
		edsRecord= new EDSRecord();
		procRecord = new ProcessedRecord();
		procRecord.setIsAccountADCNotified("N");
		procRecord.setAccountValid(true);
		procRecord.setBin("");
		procRecord.setConfidenceScore(-1);
		procRecord.setDaysSinceLastActivity(150);
		procRecord.setIca("1234");
		procRecord.setIsAccountActive("Y");
		procRecord.setIsFraudReported("N");
		procRecord.setLastUpdatedDate(javaSqlDate);
		procRecord.setLastUpdatedUser("");
		procRecord.setPan(new BigDecimal("625421221662123727"));
		procRecord.setPriceCategory(0);
		procRecord.setProcRawRecordKey(new BigDecimal("1"));
		procRecord.setProcRecordKey(new BigDecimal("1"));
		edsRecord.setProcRecord(procRecord);
		priceCategoryRule = new PriceCategoryRule();
		priceCategoryRule.setActivityText("");
		priceCategoryRule.setConfidenceText("");
		listOfRecordsToWrite.add(edsRecord);
	}

	/**
	 * Method will return the IcaToRangeMap.
	 * @return
	 */
	private Map<String, Map<ICAAccountRange, ICAAccountRange>> getIcaToRangeMap() {
		Map<String, Map<ICAAccountRange, ICAAccountRange>> map=new HashMap<String, Map<ICAAccountRange,ICAAccountRange>>();
		ICAAccountRange icaRang1=new ICAAccountRange();
		icaRang1.setStart(new BigInteger("5322420000000000000"));
		icaRang1.setEnd(new BigInteger("5322429999999999999"));
		icaRang1.setMbrId("3986");

		ICAAccountRange icaRang2=new ICAAccountRange();
		icaRang2.setStart(new BigInteger("5322420000000000007"));
		icaRang2.setEnd(new BigInteger("5322489999999999999"));
		icaRang2.setMbrId("1234");

		ICAAccountRange icaRang3=new ICAAccountRange();
		icaRang3.setStart(new BigInteger("5822420000000000000"));
		icaRang3.setEnd(new BigInteger("5922429999999999999"));
		icaRang3.setMbrId("3986");

		Map<ICAAccountRange, ICAAccountRange> mapRange=new HashMap<ICAAccountRange, ICAAccountRange>();
		mapRange.put(icaRang1, icaRang1);
		//	mapRange.put(icaRang3, icaRang3);

		Map<ICAAccountRange, ICAAccountRange> mapRange1=new HashMap<ICAAccountRange, ICAAccountRange>();
		mapRange1.put(icaRang2, icaRang2);

		map.put("3986", mapRange);
		map.put("1234", mapRange1);
		return map;
	}

	private List<ICAStatus> getICAStatusList(){
		 List<ICAStatus>  icaStatusList = new ArrayList<ICAStatus>();
		 ICAStatus icaStatus = new ICAStatus();
		 icaStatus.setFileName("A");
		 icaStatus.setStatus(FileStatus.GFT_SUCCESS.getStatus());
		 icaStatus.setIca("123");
		 icaStatusList.add(icaStatus);
		 return icaStatusList;
	}
	@Test
	public void test() throws Exception {
		list = new ArrayList<EDSRecord>();
		list.add(edsRecord);
		billDataDao = EasyMock.createMock(BillDataDAO.class);

		customerPanReportDao = EasyMock.createMock(CustomerPanReportDao.class);
		customerFileReportService = new CustomerFileReportService(billDataDao);
		EDSRecordDao edsRecordDao = new EDSRecordDao(new BasicDataSource());
		edsRecordWriterService = new EDSRecordWriterService(edsRecordDao);
		//edsRecordWriterService.setCustomerPanReportDao(customerPanReportDao);
		customerMasterService = EasyMock.createMock(CustomerMasterService.class);
		priceCategoryRuleCache = EasyMock.createMock(PriceCategoryRuleCache.class);
		Map <String, Object> customerInfo = new HashMap<String, Object>();
		Map<Integer, PriceCategoryRule> rulesMap = new HashMap<Integer, PriceCategoryRule>();
		rulesMap.put(0, priceCategoryRule);
		customerInfo.put("EDS_CUST_MSTR_ID", "1234");
		customerInfo.put("CUST_NAM","ABCD");
		customerInfo.put("ENDPNT_ID","ABCD.");
		EasyMock.expect(customerMasterService.getCustomerInfo("1234")).andReturn(customerInfo);
		EasyMock.replay(customerMasterService);

		EasyMock.expect(priceCategoryRuleCache.getPriceCategoryMap()).andReturn(rulesMap);
		EasyMock.replay(priceCategoryRuleCache);
		riskRecordItemWriter = new	RiskRecordItemWriter(location, filePrefix, priceCategoryRuleCache, new BigDecimal(0),"ABCD");
		riskRecordItemWriter.setServices( customerFileReportService, customerMasterService, edsRecordWriterService);
		riskRecordItemWriter.beforeStep(null);
		riskRecordItemWriter.setJobInstanceName("ABC");
		riskRecordItemWriter.setJobInstanceId(new BigDecimal(0));
		executionContext=new ExecutionContext();
		executionContext.put("IcaToRangeCache", getIcaToRangeMap());
		executionContext.put("icaStatusList", getICAStatusList());
		riskRecordItemWriter.setExecutionContext(executionContext);
		riskRecordItemWriter.write(list);
		/*	String fileName = null;*/
		try{
			File[] dirFiles = new File("..").listFiles();
			//Search Through the list
			for (int i=0; i<dirFiles.length; i++)
			{          //If the Files starts with the word "$JunitABCD"

				if (dirFiles[i].getName().startsWith("$JunitABCD", 0))
					//Delete This file
					try{

						File file = new File("..\\".concat(dirFiles[i].getName()));
						//fileName = dirFiles[i].getName();
						if(file.delete()){
						}else{
							File file1 = new File("../".concat(dirFiles[i].getName()));
							file1.delete();
						}

					}catch(Exception e){

						e.printStackTrace();
					}
			}

		}catch(Exception e){

			e.printStackTrace();

		}

		Map<BigDecimal, String> procRecordToFileMap =new HashMap<BigDecimal, String>();
		procRecordToFileMap.put(new BigDecimal(0),"SomeVal");
		//riskRecordItemWriter.sendFilesToGFT(procRecordToFileMap);


	}

	@Test
	public void testAfterStep() {
		edsRecordWriterService = EasyMock.createMock(EDSRecordWriterService.class);
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		jobParameter = new JobParameter("file:///MCI.AR.RABC.X.E1234567.D160812.T111135.C001", true);
		jobParameters = new JobParameters(parameters);
		jobInstance = new JobInstance(new Long(123), "importRawRecords");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		paramStepExecution = new StepExecution("risk", jobExecution);
		paramStepExecution.setExitStatus(ExitStatus.COMPLETED);
		executionContext=new ExecutionContext();
		executionContext.put("IcaToRangeCache", getIcaToRangeMap());
		riskRecordItemWriter.setExecutionContext(executionContext);
		riskRecordItemWriter.setService(edsRecordWriterService);
		riskRecordItemWriter.setList(listOfRecordsToWrite, procRecordToFileMap);
		riskRecordItemWriter.afterStep(paramStepExecution);
	}


}