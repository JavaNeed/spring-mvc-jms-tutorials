package com.mastercard.ess.eds.test.batch.core.util;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.core.util.UniqueFileNameFetcherUtils;

public class UniqueFileNameFetcherUtilsTest {
	
	private UniqueFileNameFetcherUtils uniqueFileNameFetcherUtils ;
	private BlockingQueue<String> numbersQueue;
	
	@Before
	public void setUp() throws Exception {
		uniqueFileNameFetcherUtils = new UniqueFileNameFetcherUtils();
		uniqueFileNameFetcherUtils.setSize(10);
		numbersQueue = new ArrayBlockingQueue<>(10);
		uniqueFileNameFetcherUtils.setNumbersQueue(numbersQueue);
		uniqueFileNameFetcherUtils.initQueue();
	}

	@Test
	public void testFillQueue() {
		uniqueFileNameFetcherUtils.fillQueue(20);
	}

	@Test
	public void testGetRandomFileId() {
		Assert.assertNotNull(uniqueFileNameFetcherUtils.getRandomFileId());
	}

}
