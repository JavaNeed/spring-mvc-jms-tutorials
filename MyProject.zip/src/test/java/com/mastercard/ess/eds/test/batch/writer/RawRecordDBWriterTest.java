package com.mastercard.ess.eds.test.batch.writer;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.batch.writer.RawRecordDBWriter;
import com.mastercard.ess.eds.core.dao.RawRecordDBWriterDao;
import com.mastercard.ess.eds.core.service.RawRecordDBWriterService;
import com.mastercard.ess.eds.domain.RawRecord;

public class RawRecordDBWriterTest {
	
	RawRecordDBWriter rawRecordDBWriter;
	RawRecordDBWriterService rawRecordDBWriterService;
	RawRecordDBWriterDao rawRecordDBWriterDao;
	List<RawRecord> rawRecordList;
	RawRecord rawRecord;
	Logger logger;
	
	@Before
	public void init(){
		logger = Logger.getLogger(RawRecordDBWriter.class);
		rawRecord = new RawRecord(new HashMap<String, String>());
		rawRecord.addPayloadEntry("cwid", "cwid");
		rawRecordList = new ArrayList<RawRecord>();
		rawRecordList.add(rawRecord);
	}
	
	

	@Test
	public void testSourceName() {
		logger.setLevel(Level.DEBUG);
		rawRecordDBWriter = new RawRecordDBWriter();
		rawRecordDBWriter.setSrcName("");
	}
	
	@Test
	public void testWrite() {
		logger.setLevel(Level.DEBUG);
		try {
			rawRecordDBWriterService = EasyMock.createMock(RawRecordDBWriterService.class);			
			EasyMock.expect(rawRecordDBWriterService.getEdsSrcId("")).andReturn("");
			rawRecordDBWriterService.writeRecord(rawRecordList,"",new BigDecimal(123)); 
			EasyMock.expectLastCall();
			EasyMock.replay(rawRecordDBWriterService);
			rawRecordDBWriter = new RawRecordDBWriter(rawRecordDBWriterService);
			rawRecordDBWriter.setSrcName("");
			rawRecordDBWriter.setJobInstanceId(new BigDecimal(123));
			rawRecordDBWriter.write(rawRecordList);
		} catch (Exception e) {
			logger.error(e);
		}

	}
}
