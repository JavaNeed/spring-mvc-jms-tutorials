package com.mastercard.ess.eds.test.batch.writer;

import static org.junit.Assert.*;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;

import com.mastercard.ess.eds.batch.writer.CustomerDeliveryReportGenerationItemWriter;
import com.mastercard.ess.eds.core.util.CustomerDeliveryReportGenerator;
import com.mastercard.ess.eds.domain.CustomerDeliveryReportRecord;

public class CustomerDeliveryReportGenerationItemWriterTest {
	CustomerDeliveryReportGenerationItemWriter customerDeliveryReportGenerationItemWriter;
	StepContribution stepContribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	Map<String, Map<Integer, List<Object>>> continentMap;

	List <CustomerDeliveryReportRecord> customerDeliveryRecordList;
	CustomerDeliveryReportRecord customerDeliveryRecord;
	CustomerDeliveryReportGenerator customerDeliveryReportGenerator;
	String filePath = "..Customer_Internal_DeliveryReport_Sep-2017.xlsx";

	String customerDeliveryReportPath="..";

	@Before
	public void setUp()
	{
		String fileName = "file:///MCI.AR.RABC.X.E1234567.D160812.T111135.C001";
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		jobParameter = new JobParameter(fileName, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);
		jobInstance = new JobInstance(new Long(123), "importRawRecords");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("loadRawRecords", jobExecution);
		customerDeliveryReportGenerationItemWriter = new CustomerDeliveryReportGenerationItemWriter();
		customerDeliveryReportGenerationItemWriter.setJobInstanceId(new BigDecimal(0));
		customerDeliveryReportGenerationItemWriter.setJobInstanceName("abc");


		List<Object> panCountForMonthList1=new LinkedList<Object>();
		panCountForMonthList1.add(120);panCountForMonthList1.add(10);panCountForMonthList1.add(0);panCountForMonthList1.add(50);panCountForMonthList1.add(85);

		List<Object> panCountForMonthList2=new LinkedList<Object>();
		panCountForMonthList2.add(120);panCountForMonthList2.add(10);panCountForMonthList2.add(0);panCountForMonthList2.add(50);panCountForMonthList2.add(85);

		continentMap=new LinkedHashMap<String, Map<Integer,List<Object>>>();
		Map<Integer, List<Object>> prizingMap=new TreeMap<Integer, List<Object>>();
		prizingMap.put(1,panCountForMonthList1 );
		Map<Integer, List<Object>> prizingMap2=new TreeMap<Integer, List<Object>>();

		prizingMap2.put(2, panCountForMonthList2);
		continentMap.put("A", prizingMap);
		continentMap.put("a", prizingMap2);
	}

	@Test  
	public void testFileWrite() throws Exception {
		assertEquals(new BigDecimal(0),customerDeliveryReportGenerationItemWriter.getJobInstanceId());
		assertEquals("abc",customerDeliveryReportGenerationItemWriter.getJobInstanceName());

		customerDeliveryRecord = new CustomerDeliveryReportRecord();
		customerDeliveryRecord.setCatagoryCode("A");
		customerDeliveryRecord.setCreateDate("Aug-17");
		customerDeliveryRecord.setPANCount(1212);
		customerDeliveryRecord.setPriceCatagory(1);

		customerDeliveryRecordList = new ArrayList<CustomerDeliveryReportRecord>();
		customerDeliveryRecordList.add(customerDeliveryRecord);
		customerDeliveryReportGenerator = EasyMock.createMock(CustomerDeliveryReportGenerator.class);
		customerDeliveryReportGenerationItemWriter.setGenerator(customerDeliveryReportGenerator);
		customerDeliveryReportGenerationItemWriter.write(customerDeliveryRecordList);
		File shouldExist = new File(customerDeliveryReportPath);
		assertTrue(shouldExist.exists());
	}

	@Test
	public void testgetPANCountForMonthList() {
		customerDeliveryReportGenerator = EasyMock.createMock(CustomerDeliveryReportGenerator.class);
		assertFalse(customerDeliveryReportGenerationItemWriter.getPANCountForMonthList(1).isEmpty());
		assertFalse(customerDeliveryReportGenerationItemWriter.getPANCountForMonthList(2).isEmpty());
		assertFalse(customerDeliveryReportGenerationItemWriter.getPANCountForMonthList(3).isEmpty());
		assertFalse(customerDeliveryReportGenerationItemWriter.getPANCountForMonthList(4).isEmpty());
		assertFalse(customerDeliveryReportGenerationItemWriter.getPANCountForMonthList(5).isEmpty());
		assertFalse(customerDeliveryReportGenerationItemWriter.getPANCountForMonthList(6).isEmpty());


	}

}
