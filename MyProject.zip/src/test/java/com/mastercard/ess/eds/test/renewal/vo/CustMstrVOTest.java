package com.mastercard.ess.eds.test.renewal.vo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.Test;
import org.springframework.test.context.TestExecutionListeners;

import com.mastercard.ess.eds.renewal.vo.CustMstrVO;

public class CustMstrVOTest {
	
	CustMstrVO custMstrVO = new CustMstrVO();
	
	@Test
	public void testGetedsCustMstrId(){
		custMstrVO.setEdsCustMstrId(123);
		assertEquals(123, custMstrVO.getEdsCustMstrId());
	}
	
	@Test
	public void testGetcustTypeId(){
		custMstrVO.setCustTypeId("1234");
		assertEquals("1234", custMstrVO.getCustTypeId());
	}
	
	@Test
	public void testGetcustNam(){
		custMstrVO.setCustNam("aaa");
		assertEquals("aaa", custMstrVO.getCustNam());
	}
	
	@Test
	public void testGetisActvSw(){
		custMstrVO.setIsActvSw("Y");
		assertEquals("Y", custMstrVO.getIsActvSw());
	}
	
	@Test
	public void testGetisSilentSw(){
		custMstrVO.setIsSilentSw("Y");
		assertEquals("Y", custMstrVO.getIsSilentSw());
	}
	
	@Test
	public void testGeticaNum(){
		custMstrVO.setIcaNum(2641);
		assertEquals(2641, custMstrVO.getIcaNum());
	}
	
	@Test
	public void testGetprntIcaNum(){
		custMstrVO.setPrntIcaNum(5120);
		assertEquals(5120, custMstrVO.getPrntIcaNum());
	}
	
	@Test
	public void testGetServId(){
		custMstrVO.setServId("1234");
		assertEquals("1234", custMstrVO.getServId());
	}
	
	@Test
	public void testGetdefltNotifEmailAddr(){
		custMstrVO.setDefltNotifEmailAddr("xyz@mastercard.com");
		assertEquals("xyz@mastercard.com", custMstrVO.getDefltNotifEmailAddr());
	}
	
	@Test
	public void testGetendpntId(){
		custMstrVO.setEndpntId("0000");
		assertEquals("0000", custMstrVO.getEndpntId());
	}
	
	@Test
	public void testGetlstUpdtUserId(){
		custMstrVO.setLstUpdtUserId("BATCH_USER");
		assertEquals("BATCH_USER", custMstrVO.getLstUpdtUserId());
	}
	
	@Test
	public void testGetlstUpdtDt(){
		custMstrVO.setLstUpdtDt("9-7-17");
		assertEquals("9-7-17", custMstrVO.getLstUpdtDt());
	}
	
	@Test
	public void testGetlstUpdDt(){
		custMstrVO.setLstUpdDt(new Date(0L));
		assertEquals(new Date(0L), custMstrVO.getLstUpdDt());
	}
	
	@Test
	public void testGetendDt(){
		custMstrVO.setEndDt(new Date(0L));
		assertEquals(new Date(0L), custMstrVO.getEndDt());
	}
	
	@Test
	public void teststrtDt(){
		custMstrVO.setStrtDt(new Date(0L));
		assertEquals(new Date(0L), custMstrVO.getStrtDt());
	}
	
	@Test
	public void testcrteDt(){
		custMstrVO.setCrteDt(new Date(0L));
		assertEquals(new Date(0L), custMstrVO.getCrteDt());
	}
	
	

}
