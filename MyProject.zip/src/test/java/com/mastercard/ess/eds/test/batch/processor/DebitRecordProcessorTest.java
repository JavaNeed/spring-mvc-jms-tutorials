package com.mastercard.ess.eds.test.batch.processor;

import static org.mockito.Mockito.mock;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.processor.DebitRecordProcessor;
import com.mastercard.ess.eds.core.service.EDSCPPRulesService;
import com.mastercard.ess.eds.domain.AuthDebitPanDetailRecord;
import com.mastercard.ess.eds.domain.CPPRuleRecord;

public class DebitRecordProcessorTest {
	private static Logger logger = Logger.getLogger(DebitRecordProcessorTest.class);

	private DebitRecordProcessor debitRecordProcessor;

	private EDSCPPRulesService edsCPPRulesService;
	
	private  ExecutionContext executionContext;
	List<String> cppRuleIdList =new ArrayList<>();


	private CPPRuleRecord cppRuleRcrd;
	List<AuthDebitPanDetailRecord> authDebitPanDetailRecordList=new ArrayList<AuthDebitPanDetailRecord>();

	@Before
	public void init() {
		logger.setLevel(Level.DEBUG);
		edsCPPRulesService = mock(EDSCPPRulesService.class);
		debitRecordProcessor = new DebitRecordProcessor();
		debitRecordProcessor.setEdsCPPRulesService(edsCPPRulesService);
		debitRecordProcessor.getEdsCPPRulesService();
		debitRecordProcessor.setRunCppRuleForDays("5");
		debitRecordProcessor.getRunCppRuleForDays();
		debitRecordProcessor.setExecutionContext(executionContext);
		debitRecordProcessor.getExecutionContext();
		
		cppRuleRcrd=new CPPRuleRecord();
		cppRuleRcrd.setActiveSW("Y");
		cppRuleRcrd.setCatCD("E");
		cppRuleRcrd.setClsIssrCntry("ONEOF");
		cppRuleRcrd.setClsLocTranAmt("EQUALS");
		cppRuleRcrd.setClsMerchant("EQUALS");
		cppRuleRcrd.setCreateDate(new Date(2017, 01, 10));
		cppRuleRcrd.setCreatedBy(null);
		cppRuleRcrd.setFirstRunSW("Y");
		cppRuleRcrd.setLastUpdateDate(new Date(2017, 01, 10));
		cppRuleRcrd.setLastUpdatedBy(null);
		cppRuleRcrd.setUnitTmCount("WEEKS");
		cppRuleRcrd.setValIssrCntry("USA");
		cppRuleRcrd.setValLocTranAmt(new BigDecimal(100));
		cppRuleRcrd.setValMerchant(0);
		cppRuleRcrd.setValTmCount(90);
		cppRuleRcrd.setCppRuleId(new BigDecimal(100));

		AuthDebitPanDetailRecord authDebitPanDetailRecord=new AuthDebitPanDetailRecord();
		authDebitPanDetailRecord.setCppRuleId(new BigDecimal(100));
		authDebitPanDetailRecord.setdWSource("DEBIT");
		authDebitPanDetailRecord.setRawPan("");
		authDebitPanDetailRecordList.add(authDebitPanDetailRecord);
	}

	/*We are testing debitProcessor functionality where we are passing cppRuleRecord and it returns list of authDebitPanDetailRecordList after quering dw database*/
	@Test
	public void testProcess() throws Exception {
		
		debitRecordProcessor=new DebitRecordProcessor();
		cppRuleIdList=new ArrayList<>();
		logger.setLevel(Level.DEBUG);
		cppRuleIdList.add("1");
		cppRuleIdList.add("2");
		cppRuleIdList.add("3");
		cppRuleIdList.add("4");
		
		executionContext=new ExecutionContext();
		executionContext.put("failedCPPRuleIds", cppRuleIdList);
		
		debitRecordProcessor.setExecutionContext(executionContext);
		
		logger.setLevel(Level.DEBUG);
		debitRecordProcessor.process(cppRuleRcrd);
	}
	
	@Test
	public void testProcessCase2() throws Exception {
		
		cppRuleIdList=new ArrayList<>();
		logger.setLevel(Level.DEBUG);
		cppRuleIdList.add("1");
		cppRuleIdList.add("2");
		cppRuleIdList.add("3");
		cppRuleIdList.add("4");
		
		executionContext=new ExecutionContext();
		executionContext.put("failedCPPRuleIds", cppRuleIdList);
		
		debitRecordProcessor.setEdsCPPRulesService(edsCPPRulesService);
		debitRecordProcessor.setExecutionContext(executionContext);
		
		logger.setLevel(Level.DEBUG);
		debitRecordProcessor.process(cppRuleRcrd);
	}



}
