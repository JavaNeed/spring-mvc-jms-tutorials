package com.mastercard.ess.eds.test.batch.partitioner;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.item.ExecutionContext;
import com.mastercard.ess.eds.batch.partitioner.CppExecutePartitioner;
import com.mastercard.ess.eds.core.dao.EDSCPPRulesDao;
import com.mastercard.ess.eds.core.service.EDSCPPRulesService;

public class CppExecutePartitionerTest {

	EDSCPPRulesService edsCPPRulesService;
	CppExecutePartitioner cppExecutePartitioner;
	EDSCPPRulesDao edscppRulesDao;
	Logger logger;
	List<Integer> cppRuleIdList;
	@Before
	public void init() {
		logger = Logger.getLogger(CppExecutePartitionerTest.class);
		edscppRulesDao = EasyMock.createMock(EDSCPPRulesDao.class);
		edsCPPRulesService = new EDSCPPRulesService();
		edsCPPRulesService.setDao(edscppRulesDao);
		cppExecutePartitioner = new CppExecutePartitioner();
		cppExecutePartitioner.setEdsCPPRulesService(edsCPPRulesService);
		cppExecutePartitioner.setCppRunMode("EXECUTION");
		cppExecutePartitioner.setRecordsPerPartitionsLimit(5);
		cppRuleIdList= new ArrayList<Integer>();
		cppRuleIdList.add(1);
		cppRuleIdList.add(2);
		cppRuleIdList.add(3);
		cppRuleIdList.add(4);

		
	}

	@Test
	public void testpartition() {
		
		EasyMock.expect(edscppRulesDao.getCPPRuleIds("EXECUTION")).andReturn(cppRuleIdList);
		EasyMock.replay(edscppRulesDao);
		
		logger.setLevel(Level.DEBUG);
		ExecutionContext executionContext = new ExecutionContext();
		String cppruleIds1 = "'1','2'";
		executionContext.put("cppRuleIds", cppruleIds1);

		ExecutionContext executionContext1 = new ExecutionContext();
		String cppruleIds2 = "'3','4'";
		executionContext1.put("cppRuleIds", cppruleIds2);

		Map<String, ExecutionContext> partitionMapExpected = new LinkedHashMap<String, ExecutionContext>();
		partitionMapExpected.put("Partition = 1", executionContext);
		partitionMapExpected.put("Partition = 2", executionContext1);

		Map<String, ExecutionContext> partitionMap = cppExecutePartitioner.partition(2);
		assertEquals(1,partitionMap.size());
	}

	@Test
	public void testpartition2() {
		logger.setLevel(Level.DEBUG);
		
		EasyMock.expect(edscppRulesDao.getCPPRuleIds("EXECUTION")).andReturn(null);
		EasyMock.replay(edscppRulesDao);
		
		
		Map<String, ExecutionContext> partitionMap = cppExecutePartitioner.partition(2);
		assertEquals(0,partitionMap.size());
	}
	
	@Test
	public void testpartition3() {
		
		EasyMock.expect(edscppRulesDao.getCPPRuleIds("EXECUTION")).andReturn(cppRuleIdList);
		EasyMock.replay(edscppRulesDao);
		
		cppRuleIdList.add(5);
		cppRuleIdList.add(6);
		
		logger.setLevel(Level.DEBUG);
		ExecutionContext executionContext = new ExecutionContext();
		String cppruleIds1 = "'1','2'";
		executionContext.put("cppRuleIds", cppruleIds1);

		ExecutionContext executionContext1 = new ExecutionContext();
		String cppruleIds2 = "'3','4'";
		executionContext1.put("cppRuleIds", cppruleIds2);

		Map<String, ExecutionContext> partitionMapExpected = new LinkedHashMap<String, ExecutionContext>();
		partitionMapExpected.put("Partition = 1", executionContext);
		partitionMapExpected.put("Partition = 2", executionContext1);

		Map<String, ExecutionContext> partitionMap = cppExecutePartitioner.partition(1);
		assertEquals(1,partitionMap.size());
	}
	
}
