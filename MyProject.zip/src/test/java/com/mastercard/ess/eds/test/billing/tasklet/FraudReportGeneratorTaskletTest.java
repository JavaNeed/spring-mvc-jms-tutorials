package com.mastercard.ess.eds.test.billing.tasklet;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;

import com.mastercard.ess.eds.batch.tasklet.FraudReportGeneratorTasklet;
import com.mastercard.ess.eds.core.service.FraudReportService;
import com.mastercard.ess.eds.core.util.FraudReportGenerator;
import com.mastercard.ess.eds.domain.FraudReportRecord;

public class FraudReportGeneratorTaskletTest {
	FraudReportGeneratorTasklet fraudReportGeneratorTasklet;
	FraudReportService fraudReportService;
	FraudReportGenerator fraudReportGenerator ;
	StepContribution contribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	Logger logger = Logger
			.getLogger(FraudReportGeneratorTasklet.class);
	List<FraudReportRecord> fraudReports;

	@Before
	public void setUp()
	{
		logger.setLevel(Level.DEBUG);
		String jobInstanceName = "fraudGeneration";
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		jobParameter = new JobParameter(jobInstanceName, true);
		parameters.put("shiv", jobParameter);
		jobParameters = new JobParameters(parameters);
		jobInstance = new JobInstance(new Long(123), "fraudReports");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("fraudReports", jobExecution);
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		contribution = new StepContribution(stepExecution);
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("123","subaft");
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("2","subfft");
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("11","unsubaft");
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("12","unsubfft");
		fraudReports = new ArrayList <FraudReportRecord>();
		FraudReportRecord fraudReportRecord = new FraudReportRecord();
		fraudReportRecord.setSubscribedAfterCt(123);
		fraudReportRecord.setSubscribedBeforeCt(2);
		fraudReportRecord.setUnsubscribedAfterCt(11);
		fraudReportRecord.setUnsubscribedBeforeCt(12);
		fraudReports.add(fraudReportRecord);
		fraudReportService = EasyMock.createMock(FraudReportService.class);
		fraudReportGenerator = EasyMock.createMock(FraudReportGenerator.class);
		fraudReportGeneratorTasklet=new FraudReportGeneratorTasklet();
	}
	@Test
	public void test() throws Exception {
		logger.setLevel(Level.DEBUG);
		fraudReportGeneratorTasklet.setFraudReportGenerator(fraudReportGenerator);
		fraudReportGeneratorTasklet.setFraudReportService(fraudReportService);
		fraudReportGeneratorTasklet.execute(contribution, chunkContext);
	}
}
