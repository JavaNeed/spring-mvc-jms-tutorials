package com.mastercard.ess.eds.test.batch.processor;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Test;
import org.springframework.batch.item.validator.ValidationException;

import com.mastercard.ess.eds.batch.processor.PanDedupProcessor;
import com.mastercard.ess.eds.core.util.KnownPanCache;
import com.mastercard.ess.eds.domain.RawRecord;

public class PanDedupProcessorTest {
	PanDedupProcessor panDedupProcessor;
	KnownPanCache panCache;
	String result;
	RawRecord rawRecord;
	//String thisResult = "";
	private static Logger logger = Logger.getLogger(PanDedupProcessor.class);
	
	
	@Test (expected=ValidationException.class)
	public void testProcess() throws Exception  {
		logger.setLevel(Level.DEBUG);
		panDedupProcessor=new PanDedupProcessor();
		RawRecord rawRecord=new RawRecord();
		rawRecord.setProviderName("CPP");
		rawRecord.setRawPan("123");
		rawRecord.setCacheResult("1234");
		panCache=EasyMock.createMock(KnownPanCache.class);
		EasyMock.expect(panCache.getResult("123")).andReturn("NOTSENTVENDOR");
		EasyMock.replay(panCache);
		panDedupProcessor.setPanCache(panCache);
		panDedupProcessor.process(rawRecord);
	}
	@Test (expected=ValidationException.class)
	public void testProcess1() throws Exception{
		panDedupProcessor=new PanDedupProcessor();
		RawRecord rawRecord=new RawRecord();
		rawRecord.setProviderName("CPP");
		rawRecord.setRawPan("123");
		rawRecord.setCacheResult("1234");
		panCache=EasyMock.createMock(KnownPanCache.class);
		EasyMock.expect(panCache.getResult("123")).andReturn("NOTSENTCPP");
		EasyMock.replay(panCache);
		panDedupProcessor.setPanCache(panCache);
		panDedupProcessor.process(rawRecord);
	}
	@Test 
	public void testProcess2() throws Exception{
		panDedupProcessor=new PanDedupProcessor();
		RawRecord rawRecord=new RawRecord();
		rawRecord.setProviderName("CPP");
		rawRecord.setRawPan("123");
		rawRecord.setCacheResult("1234");
		panCache=EasyMock.createMock(KnownPanCache.class);
		EasyMock.expect(panCache.getResult("123")).andReturn("null");
		EasyMock.replay(panCache);
		panDedupProcessor.setPanCache(panCache);
		panDedupProcessor.process(rawRecord);
	}
	
	@Test 
	public void testProcess3() throws Exception{
		panDedupProcessor=new PanDedupProcessor();
		RawRecord rawRecord=new RawRecord();
		rawRecord.setProviderName("CPP");
		rawRecord.setRawPan("124");
		rawRecord.setCacheResult("1234");
		panCache=EasyMock.createMock(KnownPanCache.class);
		EasyMock.expect(panCache.getResult("124")).andReturn(null);
		EasyMock.expect(panCache.insert("124",  "NOTSENTCPP")).andReturn(true);
		EasyMock.replay(panCache);
		panDedupProcessor.setPanCache(panCache);
		panDedupProcessor.process(rawRecord);
	}
}
