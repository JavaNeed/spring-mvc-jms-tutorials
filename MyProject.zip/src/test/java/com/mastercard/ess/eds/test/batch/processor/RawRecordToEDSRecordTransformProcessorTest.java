package com.mastercard.ess.eds.test.batch.processor;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.mastercard.ess.eds.batch.processor.RawRecordToEDSRecordTransformProcessor;
import com.mastercard.ess.eds.domain.EDSRecord;

public class RawRecordToEDSRecordTransformProcessorTest {
	
	private static Logger logger = Logger.getLogger(RawRecordToEDSRecordTransformProcessor.class);

	@InjectMocks
	private RawRecordToEDSRecordTransformProcessor rawRecordToEDSRecordTransformProcessor = new RawRecordToEDSRecordTransformProcessor();
	
	private EDSRecord edsRecord;
	
	@Before
    public void setUp() throws Exception {
		
		MockitoAnnotations.initMocks(this);		
		edsRecord = new EDSRecord();
	}
	
	@Test
    public void testProcess() throws Exception {
		logger.setLevel(Level.DEBUG);
        EDSRecord edsrecord = rawRecordToEDSRecordTransformProcessor.process(edsRecord);
        Assert.assertNotNull(edsrecord);
    }
	
	@Test
    public void testProcessINFO() throws Exception {
		logger.setLevel(Level.INFO);
        EDSRecord edsrecord = rawRecordToEDSRecordTransformProcessor.process(edsRecord);
        Assert.assertNotNull(edsrecord);
    }
}
