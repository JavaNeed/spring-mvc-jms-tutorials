package com.mastercard.ess.eds.test.batch.writer;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.batch.writer.EDSRecordDBWriter;
import com.mastercard.ess.eds.core.dao.EDSRecordDao;
import com.mastercard.ess.eds.core.service.EDSRecordWriterService;
import com.mastercard.ess.eds.domain.EDSRecord;

public class EDSRecordDBWriterTest {

	
	EDSRecordDBWriter edsRecordDBWriter;
	EDSRecordWriterService edsRecordDBWriterService;
	EDSRecordDao edsRecordDao;
	List<EDSRecord> edsRecordList;
	EDSRecord edsRecord;
	Logger logger;
	
	@Before
	public void init(){
		logger = Logger.getLogger(EDSRecordDBWriter.class);
		edsRecord = new EDSRecord();
		edsRecordList = new ArrayList<EDSRecord>();
		edsRecordList.add(edsRecord);
		edsRecordDao = EasyMock.createMock(EDSRecordDao.class);
		edsRecordDBWriterService = new EDSRecordWriterService(edsRecordDao);
		edsRecordDBWriter = new EDSRecordDBWriter(edsRecordDBWriterService);
	}

	@Test
	public void testWrite() {
		logger.setLevel(Level.DEBUG);
		try {
			edsRecordDBWriter.write(edsRecordList);
		} catch (Exception e) {
			logger.error(e);
		}

	}
	
	@Test
	public void testWriteInfo() {
		logger.setLevel(Level.INFO);
		try {
			edsRecordDBWriter.write(edsRecordList);
		} catch (Exception e) {
			logger.error(e);
		}

	}
	
	@Test
	public void testBeforeWrite() {
		logger.setLevel(Level.DEBUG);
		try {
			edsRecordDBWriter.beforeWrite(edsRecordList);
		} catch (Exception e) {
			logger.error(e);
		}

	}
	
	@Test
	public void testBeforeWriteInfo() {
		logger.setLevel(Level.INFO);
		try {
			edsRecordDBWriter.beforeWrite(edsRecordList);
		} catch (Exception e) {
			logger.error(e);
		}

	}
	
	@Test
	public void testOnWrite() {
		logger.setLevel(Level.DEBUG);
		try {
			edsRecordDBWriter.onWriteError(null,edsRecordList);
		} catch (Exception e) {
			logger.error(e);
		}

	}
	
	@Test
	public void testOnWriteInfo() {
		logger.setLevel(Level.INFO);
		try {
			edsRecordDBWriter.onWriteError(null,edsRecordList);
		} catch (Exception e) {
			logger.error(e);
		}

	}
	
	
	@Test
	public void testAfterError() {
		logger.setLevel(Level.DEBUG);
		try {
			edsRecordDBWriter.afterWrite(edsRecordList);
		} catch (Exception e) {
			logger.error(e);
		}

	}
	
	@Test
	public void testAfterErrorInfo() {
		logger.setLevel(Level.INFO);
		try {
			edsRecordDBWriter.afterWrite(edsRecordList);
		} catch (Exception e) {
			logger.error(e);
		}

	}
	
	@Test
	public void testSetJobInstanceName(){
		edsRecordDBWriter.setJobInstanceName("panProcessJob");
		Assert.assertEquals(edsRecordDBWriter.getJobInstanceName(), "panProcessJob");
	}
	
	@Test
	public void testConstructor(){
		EDSRecordDBWriter edsRecordDBWriter = new EDSRecordDBWriter();
		assertNotNull(edsRecordDBWriter);
	}

}
