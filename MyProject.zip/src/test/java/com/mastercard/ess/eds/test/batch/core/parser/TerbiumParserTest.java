package com.mastercard.ess.eds.test.batch.core.parser;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.crypto.SecretKey;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.item.file.transform.FieldSet;

import com.mastercard.ess.eds.core.parser.ParserUtil;
import com.mastercard.ess.eds.core.parser.TerbiumParser;
import com.mastercard.ess.eds.core.parser.VendorPayloadTokens;
import com.mastercard.ess.eds.core.util.EnvironmentUtil;
import com.mastercard.ess.eds.core.util.SecurityUtils;
import com.mastercard.ess.eds.domain.RawRecord;

/**
 * Class to test TerbiumParser
 * @author E076119
 */
public class TerbiumParserTest{
	private static Logger logger = Logger.getLogger(TerbiumParserTest.class);

	private final String RAWDATASEPARATOR = "::";
	TerbiumParser terbiumParser;
	private static FieldSet fieldSet = null;
	private static SecretKey key ;
	private static String transform ;
	private static String fieldsToDecrypt;
	private static ParserUtil parserUtil = null;
	private static Map<String,String> decryptedData;
	private static EnvironmentUtil envUtil;
	private static SecurityUtils securityUtils;

	@Before
	public void setUp() {
		terbiumParser = new TerbiumParser();
		logger.setLevel(Level.DEBUG);
		fieldSet = EasyMock.createMock(FieldSet.class);
		parserUtil = EasyMock.createMock(ParserUtil.class);
		securityUtils = new SecurityUtils();
		envUtil = EasyMock.createMock(EnvironmentUtil.class);
		securityUtils.setEnvUtil(envUtil);

		transform = "AES/CBC/PKCS5Padding";
		decryptedData = new HashMap<String, String>();
		decryptedData.put(VendorPayloadTokens.VALUE.getDesc(), "5194950303591144::(Email)");
	}

	@Test
	public void testMapRawData() {
		String rawData = "5194950303591144::(Email)";
		RawRecord rawRecord = new RawRecord(new HashMap<String, String>());
		try {
			rawRecord = terbiumParser.mapRawData(rawData , rawRecord);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(rawRecord.getPayloadValue(VendorPayloadTokens.RAW_DATA.getDesc()), "{\"Email\":\"Y\"}");
	}

	@Test
	public void testParseAndDecrypt() {
		EasyMock.expect(envUtil.getEnv()).andReturn("Dev");
		EasyMock.expect(envUtil.getKeyStorePath()).andReturn("keystore.jks");
		EasyMock.replay(envUtil);
		key = securityUtils .getSessionKey("Db1iytCKD23q1XVEOrcBzDgvbWYuwJi35aHHLKOjApSWAU9pXTeK9jn6MTZWlnNdcr9luY5wgBP/XnGgoXhDc8qJj5gCnqRdZ68G32rrxqSwIdCRBRcFlbxw9KpeydXCp7DG+Bymky9cgPOgKgW2MrNUuDFT2FtCpVam5bicJwgLg4/w/qjGtBfGqxQRchz0UVxsiEKVx21Zl0FbCZKON2N2kYQ19oIQN13t/jgSAG80Qys0Q6N4XxXoDY7ANZNxgjiHzELPKLD4yW8Q3dBUm2XQMJ5a+5gNx5+ZWBIIBhC4yi/42ri286YRFE/SBiDmSrAwn/yAXXmyKd/Y2gVEZg==");
		EasyMock.expect(fieldSet.readString(VendorPayloadTokens.CWID.getDesc())).andReturn("5e27a1ef1904933f40d9d8a1a82c8a02");
		EasyMock.expect(fieldSet.readString(VendorPayloadTokens.URL.getDesc())).andReturn("http://cardertools.su");
		EasyMock.expect(fieldSet.readString(VendorPayloadTokens.VALUE.getDesc())).andReturn("Oh/Hc7vLlOBERpxEuMo1LZT1AG5N6Kb8WHDXotXAMlM=");
		EasyMock.expect(fieldSet.readString("iv")).andReturn("yl7DYXRHpv/fNxIbiBS58A==");
		EasyMock.expect(fieldSet.readString("iv")).andReturn("yl7DYXRHpv/fNxIbiBS58A==");
		EasyMock.expect(fieldSet.readString(VendorPayloadTokens.VALUE.getDesc())).andReturn("5194950303591144::(Email)");
		EasyMock.replay(fieldSet);

		fieldsToDecrypt = VendorPayloadTokens.VALUE.getDesc();

		try {
			terbiumParser.parseAndDecrypt(fieldSet, key, transform, fieldsToDecrypt);
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
	}

}
