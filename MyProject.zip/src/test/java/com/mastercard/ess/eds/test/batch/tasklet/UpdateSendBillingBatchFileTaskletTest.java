package com.mastercard.ess.eds.test.batch.tasklet;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;

import com.mastercard.ess.eds.batch.tasklet.UpdateCPPRulesExecutionStatus;
import com.mastercard.ess.eds.batch.tasklet.UpdateSendBillingBatchFileTasklet;

public class UpdateSendBillingBatchFileTaskletTest {
	UpdateSendBillingBatchFileTasklet updateSendBillingBatchFileTasklet;
	StepContribution contribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance; 
	;
	private Logger logger = Logger
			.getLogger(UpdateCPPRulesExecutionStatus.class);

	@Test
	public void test() {
		logger.setLevel(Level.DEBUG);
		updateSendBillingBatchFileTasklet=new UpdateSendBillingBatchFileTasklet();
		updateSendBillingBatchFileTasklet.setLocation("");
		logger.setLevel(Level.DEBUG);
		String fileName = "file:///MCI.AR.RABC.X.E1234567.D160812.T111135.C001";
		
		File file = EasyMock.createMock(File.class);
		File[] fileArray =  new File[1];
		fileArray[0] = file ;
		
		EasyMock.expect(file.listFiles()).andReturn(fileArray);
		EasyMock.replay(file);
		updateSendBillingBatchFileTasklet.setLocation("");
		
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		
		jobParameter = new JobParameter(fileName, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);
		
		jobInstance = new JobInstance(new Long(123),
				"updateSendBillingBatchFileTasklet");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("updateSendBillingBatchFileTasklet",
				jobExecution);
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		contribution = new StepContribution(stepExecution);
	}

	@Ignore
	public void executetest() throws Exception
	{
		logger.setLevel(Level.DEBUG);
		updateSendBillingBatchFileTasklet=new UpdateSendBillingBatchFileTasklet();
		updateSendBillingBatchFileTasklet.setLocation("");
		
		String statusCode = "0";
		File file = EasyMock.createMock(File.class);
		
		File[] fileArray =  new File[1];
		fileArray[0] = new File("") ;
		
		EasyMock.expect(file.listFiles()).andReturn(fileArray);
		EasyMock.replay(file);
		
		
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		
		jobParameter = new JobParameter(statusCode, true);
		parameters.put("input.status", jobParameter);
		jobParameters = new JobParameters(parameters);
		
		jobInstance = new JobInstance(new Long(123),
				"updateSendBillingBatchFileTasklet");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("updateSendBillingBatchFileTasklet",
				jobExecution);
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		contribution = new StepContribution(stepExecution);
		updateSendBillingBatchFileTasklet.afterPropertiesSet();
		updateSendBillingBatchFileTasklet.execute(contribution, chunkContext);
	}
	@Ignore
	public void test2() throws Exception
	{
		logger.setLevel(Level.DEBUG);
		updateSendBillingBatchFileTasklet=new UpdateSendBillingBatchFileTasklet();
		updateSendBillingBatchFileTasklet.setLocation("");
		logger.setLevel(Level.DEBUG);
		String statusCode = "1";
		
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		File file = EasyMock.createMock(File.class);
		File[] fileArray =  new File[1];
		fileArray[0] = file ;
		
		EasyMock.expect(file.listFiles()).andReturn(fileArray);
		EasyMock.replay(file);
		updateSendBillingBatchFileTasklet.setLocation("");
		jobParameter = new JobParameter(statusCode, true);
		parameters.put("input.status", jobParameter);
		jobParameters = new JobParameters(parameters);
		
		jobInstance = new JobInstance(new Long(123),
				"updateSendBillingBatchFileTasklet");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("updateSendBillingBatchFileTasklet",
				jobExecution);
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		contribution = new StepContribution(stepExecution);
		updateSendBillingBatchFileTasklet.afterPropertiesSet();
		updateSendBillingBatchFileTasklet.execute(contribution, chunkContext);
	}
}
