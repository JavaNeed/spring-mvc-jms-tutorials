package com.mastercard.ess.eds.test.batch.core.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.util.ReflectionTestUtils;

import com.mastercard.ess.eds.core.util.GlobalConstants;
import com.mastercard.ess.eds.core.util.PanUnavailabilityNotificationScheduler;

public class PanUnavailabilityNotificationSchedulerTest {

	@Autowired
	ApplicationContext context;
	@Autowired
	JobLauncher joLauncher;
	@Autowired
	JobExecution jobExecution;
	@Autowired
	Job job;

	PanUnavailabilityNotificationScheduler panUnavailabilityNotificationScheduler = new PanUnavailabilityNotificationScheduler();
	
	@Before
	public void init(){
		job=Mockito.mock(Job.class);
		context = Mockito.mock(ApplicationContext.class);
		joLauncher =Mockito.mock(JobLauncher.class);
	}
		
	@Before
	public void init1() throws JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException {
		job=Mockito.mock(Job.class);
		context = Mockito.mock(ApplicationContext.class);
		joLauncher =Mockito.mock(JobLauncher.class);
		
		JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
		SimpleDateFormat datetimeFormat = new SimpleDateFormat(GlobalConstants.DATE_TIME_FORMAT);
		String timestamp = datetimeFormat.format(new Date());
		jobParametersBuilder.addString("currentDateTime", timestamp);
		JobParameters jobParameters = jobParametersBuilder.toJobParameters();
		
		panUnavailabilityNotificationScheduler.setJob(job);
		panUnavailabilityNotificationScheduler.setContext(context);
		panUnavailabilityNotificationScheduler.setJoLauncher(joLauncher);
		
		Mockito.when(context.getBean("panUnavailableNotificationJob")).thenReturn(job);
		Mockito.when(joLauncher.run(job, jobParameters)).thenReturn(jobExecution);
	}
	
	@Test
	public void runTest(){
		panUnavailabilityNotificationScheduler.setJob(job);
		panUnavailabilityNotificationScheduler.setContext(context);
		panUnavailabilityNotificationScheduler.setJoLauncher(joLauncher);
		panUnavailabilityNotificationScheduler.run();
	}
	
	@Test
	public void runTest1(){
		panUnavailabilityNotificationScheduler.setJob(job);
		panUnavailabilityNotificationScheduler.setContext(context);
		panUnavailabilityNotificationScheduler.setJoLauncher(joLauncher);
		panUnavailabilityNotificationScheduler.run();
	}
	
	@Test
	public void splunkLoggerTest() {
		ReflectionTestUtils.invokeMethod(panUnavailabilityNotificationScheduler, "splunkLogger", new Exception("Error occurred in launching panUnavailableNotificationJob"));
	}
	
	
}
