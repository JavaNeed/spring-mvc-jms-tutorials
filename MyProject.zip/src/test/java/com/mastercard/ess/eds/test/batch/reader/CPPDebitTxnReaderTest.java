package com.mastercard.ess.eds.test.batch.reader;

import static org.junit.Assert.assertEquals;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.test.util.ReflectionTestUtils;

import com.mastercard.ess.eds.batch.reader.CPPDebitTxnReader;
import com.mastercard.ess.eds.domain.CPPTxnInfo;

public class CPPDebitTxnReaderTest {
	CPPDebitTxnReader cPPDebitTxnReader;
	PreparedStatementSetter preparedStatementSetter;
	String sql;
	RowMapper<CPPTxnInfo> rowMapper;
	ResultSet rs;
	protected Method m;
	protected static String METHOD_NAME = "cleanupOnClose";
	protected Class[] parameterTypes;
	protected Object[] parameters;
	private DataSource dataSource;
	private PreparedStatement statement;
	private Connection jdbcConnection;

	@Before
	public void setUp() throws Exception {
		cPPDebitTxnReader = new CPPDebitTxnReader();
		rowMapper = new RowMapper<CPPTxnInfo>() {

			@Override
			public CPPTxnInfo mapRow(ResultSet arg0, int arg1)
					throws SQLException {
				// TODO Auto-generated method stub
				return null;
			}
		};
		parameterTypes = new Class[0];
		m = cPPDebitTxnReader.getClass().getDeclaredMethod(METHOD_NAME,
				parameterTypes);
		m.setAccessible(true);
		parameters = new Object[0];

	}

	@Test
	public void test() throws Exception {
		cPPDebitTxnReader = new CPPDebitTxnReader();
		cPPDebitTxnReader.setRowMapper(rowMapper);
		cPPDebitTxnReader.setSql("");
		cPPDebitTxnReader.setPreparedStatementSetter(preparedStatementSetter);
		assertEquals("", cPPDebitTxnReader.getSql());

	}

	
	@Test
	public void testing() throws IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		cPPDebitTxnReader = new CPPDebitTxnReader();
		CPPTxnInfo result = (CPPTxnInfo) m
				.invoke(cPPDebitTxnReader, parameters);
	}
	
	@Test
	public void readCursorTest() throws Exception {
		cPPDebitTxnReader = new CPPDebitTxnReader();
		cPPDebitTxnReader.setRowMapper(rowMapper);
		cPPDebitTxnReader.setSql("select * from EDS_PRCSS_DATA");
		cPPDebitTxnReader.setDataSource(new BasicDataSource());
		cPPDebitTxnReader.setPreparedStatementSetter(preparedStatementSetter);
		cPPDebitTxnReader.afterPropertiesSet();
		ReflectionTestUtils.invokeMethod(cPPDebitTxnReader, "readCursor", rs, 2);
		
	}
	
	@Test
	public void openCursorTest() throws Exception{
		
		dataSource=Mockito.mock(DataSource.class);
		PreparedStatementSetter preparedStatementSetter=new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				
			}
		};
		cPPDebitTxnReader = new CPPDebitTxnReader();
		cPPDebitTxnReader.setPreparedStatementSetter(preparedStatementSetter);
		cPPDebitTxnReader.setUseSharedExtendedConnection(true);
		cPPDebitTxnReader.setDataSource(dataSource);
		cPPDebitTxnReader.setCurrentItemCount(1);
		cPPDebitTxnReader.setSql("select * from EDS_PRCSS_DATA");

		
		jdbcConnection = Mockito.mock(Connection.class);
		statement =Mockito.mock(PreparedStatement.class);
		rs= Mockito.mock(ResultSet.class);
		
		Mockito.when(jdbcConnection.prepareStatement("select * from EDS_PRCSS_DATA",ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY,
				ResultSet.HOLD_CURSORS_OVER_COMMIT)).thenReturn(statement);
		Mockito.when(statement.executeQuery()).thenReturn(rs);
        Mockito.when(rs.isBeforeFirst()).thenReturn(false);

		
		ReflectionTestUtils.invokeMethod(cPPDebitTxnReader, "openCursor",jdbcConnection);

		
	}
}
