package com.mastercard.ess.eds.test.constant;

import static org.junit.Assert.assertNotNull;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.junit.Test;

import com.mastercard.ess.eds.constant.SQLConstants;

public class SQLConstantsTest {
	@Test
	public void testEventConstants(){
		
		Constructor<SQLConstants> constants = null;
		SQLConstants sQLConstants = null;
		try {
			constants = SQLConstants.class.getDeclaredConstructor();
			} catch (NoSuchMethodException | SecurityException ex) {
			}
		constants.setAccessible(true);
		try {
			sQLConstants = constants.newInstance();
		} catch (InstantiationException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException e) {
		}

		assertNotNull(sQLConstants);
	}
}
