package com.mastercard.ess.eds.core.icatopanmapping;

import static org.junit.Assert.assertEquals;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.springframework.batch.item.ExecutionContext;

public class PanVerificationUsingICAToRangeMappingTest {
	
	Logger logger;
	PanVerificationUsingICAToRangeMapping panVerificationUsingICAToRangeMapping;
	BigInteger paddedPanMax;
	BigInteger paddedPanMin;
	BigInteger paddedPanNull;
	ExecutionContext executionContext;
	ICAAccountRange iCAAccountRange ;
	ICAAccountRange iCAAccountRangeInvalid ;
	List<BigInteger> panList;
	Map<String, Map<ICAAccountRange, ICAAccountRange>> icaToRangeCache;
	Map<String, Map<ICAAccountRange, ICAAccountRange>> icaToRangeCacheInvalid;
	Map<ICAAccountRange, ICAAccountRange> range;
	Map<ICAAccountRange, ICAAccountRange> rangeInvalid;
	
	@org.junit.Before
	public void init() {
		logger = Logger.getLogger(PanVerificationUsingICAToRangeMapping.class);
		panVerificationUsingICAToRangeMapping = new PanVerificationUsingICAToRangeMapping();
		iCAAccountRange = new ICAAccountRange();
		iCAAccountRange.setStart(new BigInteger("1111111111111111111"));
		iCAAccountRange.setEnd(new BigInteger("9999999999999999999"));
		iCAAccountRange.setMbrId("test");
		
		icaToRangeCache = new HashMap<String, Map<ICAAccountRange,ICAAccountRange>>();
		range = new HashMap<ICAAccountRange, ICAAccountRange>();
		range.put(iCAAccountRange, iCAAccountRange);
		icaToRangeCache.put("1234", range);
		
		
		iCAAccountRangeInvalid = new ICAAccountRange();
		iCAAccountRangeInvalid.setStart(new BigInteger("1111111111111111111"));
		iCAAccountRangeInvalid.setEnd(new BigInteger("9999999999999999999"));
		iCAAccountRangeInvalid.setMbrId("invalidRange");
		
		icaToRangeCacheInvalid = new HashMap<String, Map<ICAAccountRange,ICAAccountRange>>();
		rangeInvalid = new HashMap<ICAAccountRange, ICAAccountRange>();
		range.put(iCAAccountRangeInvalid, iCAAccountRangeInvalid);
		icaToRangeCacheInvalid.put("5678", rangeInvalid);
		
		
		
		
		paddedPanMax =  new BigInteger("1234567890123456");
		paddedPanMin =  new BigInteger("123");
		executionContext = new ExecutionContext();
		panList = new ArrayList<BigInteger>();
		panList.add(new BigInteger("1234567"));
		panList.add(new BigInteger("1234568"));
		panList.add(new BigInteger("1234569"));
		panList.add(new BigInteger("1234579"));
		

		
	}	

	@Test
	public void testGetExecutionContext() throws Exception {
		
		panVerificationUsingICAToRangeMapping.getExecutionContext();
				
	}

	@Test
	public void testSetExecutionContext() {
		panVerificationUsingICAToRangeMapping.setExecutionContext(executionContext);
		//assertEquals(true, true);
	}

	@Test
	public void testValidatePansToIcas() throws Exception {
		List<BigInteger> invalidPanList = new ArrayList<BigInteger>();
		assertEquals(invalidPanList, panVerificationUsingICAToRangeMapping.validatePansToIcas(icaToRangeCache, panList, "1234"));
		
		List<BigInteger> invalidPanList1 = new ArrayList<BigInteger>();
		invalidPanList1.add(new BigInteger("11111"));
		panList.add(new BigInteger("11111"));
		assertEquals(invalidPanList1, panVerificationUsingICAToRangeMapping.validatePansToIcas(icaToRangeCache, panList, "1234"));
		
		
		List<BigInteger> invalidPanList2 = new ArrayList<BigInteger>();
		invalidPanList1.add(new BigInteger("11111"));
		panList.add(new BigInteger("11111"));
		
		try {
			assertEquals(invalidPanList2, panVerificationUsingICAToRangeMapping.validatePansToIcas(icaToRangeCacheInvalid, panList, "1234"));
		} catch (Exception e) {
			assertEquals(true,true);
		}
	}

	@Test
	public void testGetMaskedAccountNumber() {
		String resultMax = "123456XXXXXX3456";
		String resultMin = "123";
		assertEquals(resultMax, PanVerificationUsingICAToRangeMapping.getMaskedAccountNumber(paddedPanMax));
		assertEquals(resultMin, PanVerificationUsingICAToRangeMapping.getMaskedAccountNumber(paddedPanMin));
	}

}
