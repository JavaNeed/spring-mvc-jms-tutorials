package com.mastercard.ess.eds.test.core.util;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.context.ApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import com.mastercard.ess.eds.core.service.EDSSourceService;
import com.mastercard.ess.eds.core.util.GlobalConstants;
import com.mastercard.ess.eds.core.util.PANProcessScheduler;
import com.mastercard.ess.eds.domain.EDSSource;

public class PANProcessSchedulerTest {

	private Logger logger = Logger.getLogger(PANProcessScheduler.class);
	Job job;
   JobExecution jobExecution;
	@Mock
	JdbcTemplate jdbcTemplate;

	@Mock
	PANProcessScheduler paProcessScheduler;

	@Mock
	EDSSourceService edsSourceService, edsSourceServiceOne;
	
	@Mock
	ApplicationContext context;
	
	@Mock
	JobLauncher joLauncher;

	@Before
	public void setUp() throws Exception {
		logger.setLevel(Level.DEBUG);
		MockitoAnnotations.initMocks(this);
		paProcessScheduler=new PANProcessScheduler(jdbcTemplate);
	}

	@Test
	public void should_populate_eds_source_list_from_map_when_is_purged_is_N()throws InterruptedException {
		// Given
		Map<String, Object> givenRowMap = new HashMap<String, Object>();
		givenRowMap.put("EDS_SRC_ID", new BigDecimal(23.23));
		givenRowMap.put("ERR_FILE_NAM", "SOME_ERROR_FILE");
		givenRowMap.put("ERR_FILE_LOC_TXT", "SOME_ERROR_FILE_LOCATION");
		givenRowMap.put("IS_PURGED_SW", "N");
		givenRowMap.put("LST_UPDT_DT", new Timestamp(6L));
		givenRowMap.put("LST_UPDT_USER_ID", "e056636");
		givenRowMap.put("EDS_SRC_TYPE_ID", new BigDecimal(23.23));
		givenRowMap.put("SRC_NAM", "Deepankar");

		// When
		PANProcessScheduler panProcessScheduler = new PANProcessScheduler();
		List<EDSSource> actualEDSSourceList = panProcessScheduler.populateEDSSourceInstanceList(givenRowMap);

		// Then
		assertEquals(new BigDecimal(23.23), actualEDSSourceList.get(0)
				.getSrc_ky());
		assertEquals("SOME_ERROR_FILE", actualEDSSourceList.get(0)
				.getErrorFile());
		assertEquals("SOME_ERROR_FILE_LOCATION", actualEDSSourceList.get(0)
				.getErrorFileLocation());
		assertEquals(false, actualEDSSourceList.get(0).getIsPurged());
		assertEquals("e056636", actualEDSSourceList.get(0).getLastUpdatedBy());

	}

	@Test
	public void should_populate_eds_source_list_from_map_when_is_purged_is_()
			throws InterruptedException {
		// Given
		Map<String, Object> givenRowMap = new HashMap<String, Object>();
		givenRowMap.put("EDS_SRC_ID", new BigDecimal(23.23));
		givenRowMap.put("ERR_FILE_NAM", "SOME_ERROR_FILE");
		givenRowMap.put("ERR_FILE_LOC_TXT", "SOME_ERROR_FILE_LOCATION");
		givenRowMap.put("IS_PURGED_SW", "Y");
		givenRowMap.put("LST_UPDT_DT", new Timestamp(6L));
		givenRowMap.put("LST_UPDT_USER_ID", "e056636");
		givenRowMap.put("EDS_SRC_TYPE_ID", new BigDecimal(23.23));
		givenRowMap.put("SRC_NAM", "Deepankar");
		
		// When
		PANProcessScheduler panProcessScheduler = new PANProcessScheduler();
		List<EDSSource> actualEDSSourceList = panProcessScheduler.populateEDSSourceInstanceList(givenRowMap);

		// Then
		assertEquals(new BigDecimal(23.23), actualEDSSourceList.get(0).getSrc_ky());
		assertEquals("SOME_ERROR_FILE", actualEDSSourceList.get(0).getErrorFile());
		assertEquals("SOME_ERROR_FILE_LOCATION", actualEDSSourceList.get(0).getErrorFileLocation());
		assertEquals(true, actualEDSSourceList.get(0).getIsPurged());
		assertEquals("e056636", actualEDSSourceList.get(0).getLastUpdatedBy());

	}


	@Before
	public void setUp1() throws JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException {
		Map<String, Object> givenRowMap = new HashMap<String, Object>();
		givenRowMap.put("EDS_SRC_ID", new BigDecimal(23.23));
		givenRowMap.put("ERR_FILE_NAM", "SOME_ERROR_FILE");
		givenRowMap.put("ERR_FILE_LOC_TXT", "SOME_ERROR_FILE_LOCATION");
		givenRowMap.put("IS_PURGED_SW", "Y");
		givenRowMap.put("LST_UPDT_DT", new Timestamp(6L));
		givenRowMap.put("LST_UPDT_USER_ID", "e056636");
		givenRowMap.put("EDS_SRC_TYPE_ID", new BigDecimal(23.23));
		givenRowMap.put("SRC_NAM", "Deepankar");
		List<Map<String, Object>> queuedList = new ArrayList<>();

		queuedList.add(givenRowMap);
		JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
		SimpleDateFormat datetimeFormat = new SimpleDateFormat(GlobalConstants.DATE_TIME_FORMAT);
		String timestamp = datetimeFormat.format(new Date());
		jobParametersBuilder.addString("currentDateTime", timestamp);
		JobParameters jobParameters = jobParametersBuilder.toJobParameters();
		/*JobExecution jobExecution = joLauncher.run(job, jobParameters);*/

		Mockito.when(edsSourceService.getQueuedFiles()).thenReturn(queuedList);
		Mockito.when(context.getBean("panProcessJob")).thenReturn(job);
		Mockito.when(joLauncher.run(job, jobParameters)).thenReturn(jobExecution);
		Mockito.when(edsSourceServiceOne.getQueuedFiles()).thenReturn(null);
		
	}

	@Test
	public void runTest() {
		PANProcessScheduler panProcessScheduler = new PANProcessScheduler();
		panProcessScheduler.setPanService(edsSourceService, context, joLauncher);
		new PANProcessScheduler(new BasicDataSource());
		panProcessScheduler.run();
	}
	
	@Test
	public void splunkLoggerTest() {
		PANProcessScheduler panProcessScheduler = new PANProcessScheduler();
		ReflectionTestUtils.invokeMethod(panProcessScheduler, "splunkLogger", new Exception("bad exception"));
	}
	
	@Test
	public void runTest1() {
		PANProcessScheduler panProcessScheduler = new PANProcessScheduler();
		panProcessScheduler.setPanService(edsSourceServiceOne, context, joLauncher);
		panProcessScheduler.run();
	}

}
