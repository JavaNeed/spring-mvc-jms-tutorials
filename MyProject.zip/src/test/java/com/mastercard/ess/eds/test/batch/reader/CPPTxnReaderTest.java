package com.mastercard.ess.eds.test.batch.reader;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStreamReader;
import org.springframework.test.util.ReflectionTestUtils;

import com.mastercard.ess.eds.batch.reader.CPPAuthTxnReader;
import com.mastercard.ess.eds.batch.reader.CPPTxnReader;
import com.mastercard.ess.eds.domain.CPPTxnInfo;

public class CPPTxnReaderTest {
	CPPTxnReader cPPTxnReader;
	CPPAuthTxnReader authTxnReader;
	ItemStreamReader<CPPTxnInfo>[] delegates;
	int delegateIndex;
	ItemStreamReader<CPPTxnInfo> currentDelegate;
	StepExecution stepExecution;
	ExecutionContext executionContext;
	
private static Logger logger = Logger.getLogger(CPPTxnReader.class);
	
	@Before
	public void setUp() throws Exception {
		cPPTxnReader=new CPPTxnReader();
		delegates =  new CPPAuthTxnReader[0];
		cPPTxnReader.setDelegates(delegates);
	}

	@Test
	public void readTest() {
		authTxnReader=Mockito.mock(CPPAuthTxnReader.class);
		cPPTxnReader = new CPPTxnReader();
		delegates =  new CPPAuthTxnReader[]{authTxnReader};
		cPPTxnReader.setDelegates(delegates);
		currentDelegate=new CPPAuthTxnReader();
		cPPTxnReader.setCurrentDelegate(currentDelegate);

		logger.setLevel(Level.DEBUG);
		executionContext = new ExecutionContext();
		executionContext.putInt("index", 0);
		JobExecution jobExecution = new JobExecution(new Long(1));
		jobExecution.setExecutionContext(executionContext);
		stepExecution = new StepExecution("CPPTxnReader", jobExecution, new Long(1));
		stepExecution.setExecutionContext(executionContext);
		ReflectionTestUtils.invokeMethod(cPPTxnReader, "beforeStep", stepExecution);
		cPPTxnReader.update(executionContext);
		cPPTxnReader.read();
	}
	
	@Test
	public void openTest() {
		authTxnReader=Mockito.mock(CPPAuthTxnReader.class);
		cPPTxnReader = new CPPTxnReader();
		delegates =  new CPPAuthTxnReader[]{authTxnReader};
		cPPTxnReader.setDelegates(delegates);
		currentDelegate=new CPPAuthTxnReader();
		cPPTxnReader.setCurrentDelegate(currentDelegate);
		
		executionContext=new ExecutionContext();
		executionContext.putInt("index", 0);
		JobExecution jobExecution = new JobExecution(new Long(1));
		jobExecution.setExecutionContext(executionContext);
		cPPTxnReader.open(executionContext);
		cPPTxnReader.close();

	}
	

	
}
