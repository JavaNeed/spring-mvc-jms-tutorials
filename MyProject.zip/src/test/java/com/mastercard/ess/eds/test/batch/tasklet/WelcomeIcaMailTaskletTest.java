package com.mastercard.ess.eds.test.batch.tasklet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;

import com.mastercard.ess.eds.batch.tasklet.WelcomeIcaMailTasklet;
import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.core.service.CustomerMasterService;
import com.mastercard.ess.eds.core.service.EventSubscriptionService;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;

public class WelcomeIcaMailTaskletTest {

	EventPublisher eventPublisher;
	CustomerMasterService customerMasterService;
	EventSubscriptionService eventSubscriptionService;
	NotificationEventVO notificationEventVO;
	StepContribution contribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	
	@Test
	public void testExecute() throws Exception {
		WelcomeIcaMailTasklet welcomeIcaMailTasklet=new WelcomeIcaMailTasklet();
		Map<String, List<Integer>> map = new HashMap<String, List<Integer>>();
		List<Integer> list = new ArrayList<Integer>();
		list.add(1);
		map.put("one", list);
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		jobInstance = new JobInstance(new Long(123), "welcomeEmail");
		jobParameter = new JobParameter("welcomeica", true);
		parameters.put("mail", jobParameter);
		jobParameters = new JobParameters(parameters);
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("billdataFile", jobExecution);
		
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		contribution = new StepContribution(stepExecution);
		
		customerMasterService = EasyMock.createMock(CustomerMasterService.class);
		EasyMock.expect(customerMasterService.getSubscribtionEmailWithICA()).andReturn(map);
		EasyMock.replay(customerMasterService);
		
		eventPublisher = new EventPublisher();
		WelcomeIcaMailTasklet wimt = new WelcomeIcaMailTasklet(eventPublisher, customerMasterService, null);
		wimt.execute(contribution, chunkContext);
	}

}
