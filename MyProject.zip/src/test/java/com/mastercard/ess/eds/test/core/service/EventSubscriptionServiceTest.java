package com.mastercard.ess.eds.test.core.service;

import java.util.ArrayList;

import org.easymock.EasyMock;
import org.junit.Test;

import com.mastercard.ess.eds.core.dao.EventSubscriptionDAO;
import com.mastercard.ess.eds.core.service.EventSubscriptionService;

public class EventSubscriptionServiceTest {

	@Test
	public void test() {
		EventSubscriptionDAO eventSubscriptionDAO = EasyMock.createMock(EventSubscriptionDAO.class);
		EventSubscriptionService eventSubscriptionService = new EventSubscriptionService();
		eventSubscriptionService.setEventSubscriptionDAO(eventSubscriptionDAO);
		EasyMock.expect(eventSubscriptionDAO.getEmailIdsByEventType("E",1)).andReturn(new ArrayList<String>());
		eventSubscriptionService.getEmailIdsByEventType("E",1);
	}

}
