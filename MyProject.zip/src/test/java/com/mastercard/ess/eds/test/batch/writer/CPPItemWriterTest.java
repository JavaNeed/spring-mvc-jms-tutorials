package com.mastercard.ess.eds.test.batch.writer;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Test;
import org.springframework.jdbc.core.JdbcTemplate;

import com.mastercard.ess.eds.batch.writer.CPPItemWriter;
import com.mastercard.ess.eds.core.dao.CPPItemWriterDAO;
import com.mastercard.ess.eds.core.service.CPPItemWriterService;
import com.mastercard.ess.eds.domain.CPPTxnInfo;

public class CPPItemWriterTest {
	CPPItemWriter cPPItemWriter;
	List <CPPTxnInfo> list;
	CPPItemWriterService cppItemWriterService;
	CPPItemWriterDAO cppItemWriterDAO;
	Logger logger;


	@Test
	public void test() throws Exception {
		logger = Logger.getLogger( CPPItemWriter.class);
		logger.setLevel(Level.DEBUG);
		list = new ArrayList<CPPTxnInfo>();
		cppItemWriterDAO = EasyMock.createMock(CPPItemWriterDAO.class);
		cppItemWriterService = new CPPItemWriterService(cppItemWriterDAO);
		cPPItemWriter = new CPPItemWriter(cppItemWriterService);
		cPPItemWriter.write(list);
		cPPItemWriter.setJobInstanceName("");
	}

}
