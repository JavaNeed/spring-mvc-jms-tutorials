package com.mastercard.ess.eds.test.core.service;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;

import org.easymock.EasyMock;
import org.junit.Test;

import com.mastercard.ess.eds.core.dao.RawRecordDBWriterDao;
import com.mastercard.ess.eds.core.service.RawRecordDBWriterService;
import com.mastercard.ess.eds.domain.RawRecord;

public class RawRecordDBWriterServiceTest {

	RawRecordDBWriterService rawRecordDBWriterService;
	RawRecordDBWriterDao rawRecordDBWriterDao;

	@Test
	public void test() {
		rawRecordDBWriterService = new RawRecordDBWriterService();
		
		rawRecordDBWriterDao = EasyMock.createMock(RawRecordDBWriterDao.class);
		
		rawRecordDBWriterService = new RawRecordDBWriterService(rawRecordDBWriterDao);
		rawRecordDBWriterService.writeRecord(new ArrayList<RawRecord>(),"",new BigDecimal(123));


		EasyMock.expect(rawRecordDBWriterDao.getEdsSrcId("")).andReturn("");

		assertEquals(null,rawRecordDBWriterService.getEdsSrcId(""));
	}

}
