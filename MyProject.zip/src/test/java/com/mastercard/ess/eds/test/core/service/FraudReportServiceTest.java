package com.mastercard.ess.eds.test.core.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.batch.exception.EDSCoreException;
import com.mastercard.ess.eds.core.dao.FraudReportDao;
import com.mastercard.ess.eds.core.service.FraudReportService;
import com.mastercard.ess.eds.domain.FraudReportRecord;

public class FraudReportServiceTest {
	FraudReportService fraudReportService;
	FraudReportDao fraudReportDao;
	List<FraudReportRecord> fraudReportRecords;
	 Logger logger = Logger.getLogger(FraudReportServiceTest.class);
	 
	@Before
	public void init()
	{
	
		fraudReportDao = EasyMock.createMock(FraudReportDao.class);
		fraudReportService = new FraudReportService(fraudReportDao);
		fraudReportService.setFraudReportDao(fraudReportDao);
		fraudReportRecords = new ArrayList<FraudReportRecord>();
	}
	@Test
	public void test()
	{
		
		Map<String, String> beforeCountMap = new HashMap<String, String>();
		beforeCountMap.put("subscribed", "arg1");
		beforeCountMap.put("unsubscribed", "arg2");
		beforeCountMap.put("aftersubscribed", "arg3");
		beforeCountMap.put("afterunsubscribed", "arg4");
		Map<String, Object> givenRowMap = new HashMap<String, Object>();
		givenRowMap.put("beforesubscribed", beforeCountMap);
		givenRowMap.put("beforeunsubscribed", beforeCountMap);
		givenRowMap.put("aftersubscribed", beforeCountMap);
		givenRowMap.put("afterunsubscribed", beforeCountMap);
		List<Map<String, Object>> beforeCountMaps=new ArrayList<Map<String, Object>>();
		beforeCountMaps.add(givenRowMap);
		beforeCountMaps.add(givenRowMap);
		beforeCountMaps.add(givenRowMap);
		beforeCountMaps.add(givenRowMap);
		EasyMock.expect(fraudReportDao.getBeforeCountSubscribedICA()).andReturn(beforeCountMaps);
		EasyMock.replay(fraudReportDao);
		fraudReportService.getBeforeCountSubscribedICA();
		Map<String, String> beforeSubsFraudCt= new HashMap<String, String>();
		beforeSubsFraudCt.put("nov","11");
		Map<String, String> beforeUnSubsFraudCt= new HashMap<String, String>();
		beforeUnSubsFraudCt.put("feb", "2");
		Map<String, Integer> afterSubsFraudCt = new HashMap<String, Integer>();
		afterSubsFraudCt.put("mar",3);
		Map<String, Integer> afterUnSubsFraudCt = new HashMap<String, Integer>();
		afterUnSubsFraudCt.put("jun",6);
		fraudReportService.wrapFraudReport(beforeSubsFraudCt, beforeUnSubsFraudCt, afterSubsFraudCt, afterUnSubsFraudCt);
		
	}
	@Test
	public void substest()
	{
		Map<String, String> beforeCountMap = new HashMap<String, String>();
		beforeCountMap.put("subscribed", "arg1");
		beforeCountMap.put("unsubscribed", "arg2");
		beforeCountMap.put("aftersubscribed", "arg3");
		beforeCountMap.put("afterunsubscribed", "arg4");
		Map<String, Object> givenRowMap = new HashMap<String, Object>();
		givenRowMap.put("beforesubscribed", beforeCountMap);
		givenRowMap.put("beforeunsubscribed", beforeCountMap);
		givenRowMap.put("aftersubscribed", beforeCountMap);
		givenRowMap.put("afterunsubscribed", beforeCountMap);
		List<Map<String, Object>> beforeCountMaps=new ArrayList<Map<String, Object>>();
		beforeCountMaps.add(givenRowMap);
		beforeCountMaps.add(givenRowMap);
		beforeCountMaps.add(givenRowMap);
		beforeCountMaps.add(givenRowMap);
		EasyMock.expect(fraudReportDao.getBeforeCountSubscribedICA()).andReturn(beforeCountMaps);
		EasyMock.replay(fraudReportDao);
		fraudReportService.getBeforeCountSubscribedICA();
		Map<String, String> beforeSubsFraudCt= new HashMap<String, String>();
		beforeSubsFraudCt.put("apr","4");
		Map<String, String> beforeUnSubsFraudCt= new HashMap<String, String>();
		beforeUnSubsFraudCt.put("aug", "9");
		Map<String, Integer> afterSubsFraudCt = new HashMap<String, Integer>();
		afterSubsFraudCt.put("may",6);
		Map<String, Integer> afterUnSubsFraudCt = new HashMap<String, Integer>();
		afterUnSubsFraudCt.put("oct",10);
		fraudReportService.wrapFraudReport(beforeSubsFraudCt, beforeUnSubsFraudCt, afterSubsFraudCt, afterUnSubsFraudCt);
		
	}
	@Test
	public void unsubsTest()
	{

		Map<String, String> beforeCountMap = new HashMap<String, String>();
		beforeCountMap.put("subscribed", "arg1");
		beforeCountMap.put("unsubscribed", "arg2");
		beforeCountMap.put("aftersubscribed", "arg3");
		beforeCountMap.put("afterunsubscribed", "arg4");
		Map<String, Object> givenRowMap = new HashMap<String, Object>();
		givenRowMap.put("beforesubscribed", beforeCountMap);
		givenRowMap.put("beforeunsubscribed", beforeCountMap);
		givenRowMap.put("aftersubscribed", beforeCountMap);
		givenRowMap.put("afterunsubscribed", beforeCountMap);
		List<Map<String, Object>> beforeCountMaps=new ArrayList<Map<String, Object>>();
		beforeCountMaps.add(givenRowMap);
		beforeCountMaps.add(givenRowMap);
		beforeCountMaps.add(givenRowMap);
		beforeCountMaps.add(givenRowMap);
		EasyMock.expect(fraudReportDao.getBeforeCountUnSubscribedICA()).andReturn(beforeCountMaps);
		EasyMock.replay(fraudReportDao);
		fraudReportService.getBeforeCountunSubscribedICA();
		Map<String, String> beforeSubsFraudCt= new HashMap<String, String>();
		beforeSubsFraudCt.put("dec","12");
		Map<String, String> beforeUnSubsFraudCt= new HashMap<String, String>();
		beforeUnSubsFraudCt.put("dec", "12");
		Map<String, Integer> afterSubsFraudCt = new HashMap<String, Integer>();
		afterSubsFraudCt.put("dec",12);
		Map<String, Integer> afterUnSubsFraudCt = new HashMap<String, Integer>();
		afterUnSubsFraudCt.put("dec",12);
		fraudReportService.wrapFraudReport(beforeSubsFraudCt, beforeUnSubsFraudCt, afterSubsFraudCt, afterUnSubsFraudCt);
	}
	@Test
	public void afterTest() throws EDSCoreException
	{
		Map<String, Integer> fraudReport = new LinkedHashMap<String, Integer>();
		fraudReport.put("subscribedICa", 7);
		EasyMock.expect(fraudReportDao.getAfterCountSubscribedICA()).andReturn(fraudReport);
		EasyMock.replay(fraudReportDao);
		fraudReportService.getAfterCountSubscribedICA();
	}
	@Test
	public void afterunsubTest() throws EDSCoreException
	{
		Map<String, Integer> fraudReport1 = new LinkedHashMap<String, Integer>();
		fraudReport1.put("unsubscribedICa", 7);
		EasyMock.expect(fraudReportDao.getAfterCountUnSubscribedICA()).andReturn(fraudReport1);
		EasyMock.replay(fraudReportDao);
		fraudReportService.getAfterCountUnSubscribedICA();
	}
}
