package com.mastercard.ess.eds.test.batch.core.util;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Test;

import com.mastercard.ess.eds.core.dao.BrandExclusionDAO;
import com.mastercard.ess.eds.core.util.BrandExclusionCache;

public class BrandExclusionCacheTest {
	private Logger logger;
	BrandExclusionCache brandExclusionCache;
	BrandExclusionDAO brandExclusionDAO;
	List<String> excludedBrands;
	@Test
	public void test() {
		logger = Logger.getLogger(BrandExclusionCache.class);
		logger.setLevel(Level.DEBUG);
		brandExclusionCache = new BrandExclusionCache();
		brandExclusionDAO = EasyMock.createMock(BrandExclusionDAO.class);
		brandExclusionCache.setBrandExclusionDAO(brandExclusionDAO);
		EasyMock.expect(brandExclusionDAO.getExcludedBrandList()).andReturn(excludedBrands);
		EasyMock.replay(brandExclusionDAO);
		brandExclusionCache.getListOfExcludedBrands();
		excludedBrands = new ArrayList<String>();
		brandExclusionCache.setExcludedBrands(excludedBrands);
		assertEquals(brandExclusionCache.getExcludedBrands(),excludedBrands);
	}
	
	@Test
	public void testList() {
		excludedBrands = new ArrayList<String>();
		excludedBrands.add("");
		logger = Logger.getLogger(BrandExclusionCache.class);
		logger.setLevel(Level.DEBUG);
		brandExclusionCache = new BrandExclusionCache();
		brandExclusionCache.setExcludedBrands(excludedBrands);
		brandExclusionCache.getListOfExcludedBrands();
		assertEquals(brandExclusionCache.getExcludedBrands(),excludedBrands);
	}

}
