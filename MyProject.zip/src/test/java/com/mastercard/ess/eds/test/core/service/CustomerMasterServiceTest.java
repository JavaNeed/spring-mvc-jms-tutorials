package com.mastercard.ess.eds.test.core.service;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.core.dao.CustomerMasterDAO;
import com.mastercard.ess.eds.core.service.CustomerMasterService;

public class CustomerMasterServiceTest {
	CustomerMasterService customerMasterService;
	CustomerMasterDAO customerMasterDAO;
	Map<String, Object> customterinfo;
	Map<String, Integer> customterinfo1;

	@Before
	public void init() {
		customerMasterService = new CustomerMasterService();
		customerMasterService = EasyMock
				.createMock(CustomerMasterService.class);
		customerMasterDAO = EasyMock.createMock(CustomerMasterDAO.class);

		customerMasterService = new CustomerMasterService(customerMasterDAO);
		customerMasterService.setCustomerMasterDAO(customerMasterDAO);
		customterinfo = new HashMap<String, Object>();
		customterinfo.put("123", new Object());
		customterinfo.put("ICICI", new Object());
		customterinfo.put("01", new Object());
		customterinfo1 = new LinkedHashMap<String, Integer>();
		customterinfo1.put("1234", 1);
		customterinfo1.put("SBI", 2);
		customterinfo1.put("02", 3);
	}

	@Test
	public void testCustomerInfo() {
		customerMasterService = new CustomerMasterService();
		customerMasterDAO = EasyMock.createMock(CustomerMasterDAO.class);
		EasyMock.expect(customerMasterDAO.getCustomerInfoFromICA("ica"))
		.andReturn(customterinfo);
		EasyMock.replay(customerMasterDAO);
		customerMasterService = new CustomerMasterService(customerMasterDAO);
		assertEquals(customterinfo,
				customerMasterService.getCustomerInfo("ica"));
	}

	@Test
	public void testEnroll() {
		Map<String, Object> givenRowMap = new HashMap<String, Object>();
		givenRowMap.put("enrolledcustomer", 1);
		List<Map<String, Object>> enrolcust = new ArrayList<Map<String, Object>>();
		enrolcust.add(givenRowMap);
		EasyMock.expect(customerMasterDAO.getEnrolledCustomerDetail())
		.andReturn(enrolcust);
		EasyMock.replay(customerMasterDAO);
		customerMasterService.getEnrolledCustomerDetail();

	}

	@Test
	public void testActive() {
		Map<String, Object> givenRowMap = new HashMap<String, Object>();
		givenRowMap.put("activecustomer", 1);
		List<Map<String, Object>> actcust = new ArrayList<Map<String, Object>>();
		actcust.add(givenRowMap);
		EasyMock.expect(customerMasterDAO.getActiveCustomerDetail()).andReturn(
				actcust);
		EasyMock.replay(customerMasterDAO);
		customerMasterService.getActiveCustomerDetail();
	}

	@Test
	public void afterTest() {
		Map<String, Object> custmap = new HashMap<String, Object>();
		custmap.put("CODE", "7");
		List<Map<String, Object>> uncust = new ArrayList<Map<String, Object>>();
		uncust.add(custmap);
		EasyMock.expect(customerMasterDAO.getUnEnrolledCustomerDetail())
		.andReturn(uncust);
		EasyMock.replay(customerMasterDAO);
		customerMasterService.getUnEnrolledCustomerDetail();
	}

	@Test
	public void listTest() {
		Map<String, List<Integer>> map = new HashMap<String, List<Integer>>();
		map.put("mango", new ArrayList<Integer>(Arrays.asList(0, 4, 8, 9, 12)));
		EasyMock.expect(customerMasterDAO.getSubscribtionEmailWithICA())
		.andReturn(map);
		EasyMock.replay(customerMasterDAO);
		customerMasterService.getSubscribtionEmailWithICA();
	}
}
