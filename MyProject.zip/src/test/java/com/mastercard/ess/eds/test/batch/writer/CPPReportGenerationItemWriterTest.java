package com.mastercard.ess.eds.test.batch.writer;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.test.util.ReflectionTestUtils;

import com.mastercard.ess.eds.Comparator.PercentageComparator;
import com.mastercard.ess.eds.batch.writer.CPPReportGenerationItemWriter;
import com.mastercard.ess.eds.core.service.CPPReportService;
import com.mastercard.ess.eds.core.util.CPPReportGenerator;
import com.mastercard.ess.eds.domain.CPPReportInfo;

public class CPPReportGenerationItemWriterTest {
	Logger logger=Logger.getLogger(CPPReportGenerationItemWriter.class);
	CPPReportGenerationItemWriter itemWtr;
	CPPReportGenerator cppReportGenerator;
	ExecutionContext executionContext;
	PercentageComparator percentageComparator;
	
	CPPReportInfo cPPReportInfo;
	CPPReportService cppReportService;
	List<CPPReportInfo> reportInfos;
	List<CPPReportInfo> reportInfos1;
	CPPReportInfo cPPReportInfo1;
	List<CPPReportInfo> reportInfos2;
	CPPReportInfo cPPReportInfo2;
	List<CPPReportInfo> reportInfos3;
	CPPReportInfo cPPReportInfo3;
	List<CPPReportInfo> reportInfos4;
	CPPReportInfo cPPReportInfo4;
	List<CPPReportInfo> reportInfos5;
	CPPReportInfo cPPReportInfo5;

	@Before
	public void init(){
		itemWtr = new CPPReportGenerationItemWriter();
		Map<String, String> distinctPanCountMap =new HashMap<> ();
		distinctPanCountMap.put("executionContext", "1");
		executionContext=new ExecutionContext();
		executionContext.put("distinctPanCountMap", distinctPanCountMap);
		reportInfos = new ArrayList<CPPReportInfo>();
		
		CPPReportInfo rptInfo = new CPPReportInfo();
		rptInfo.setGroupId(1);
		rptInfo.setCardsUsedCount(2L);
		rptInfo.setTransactionChannel("CP");
		rptInfo.setIssuerCountryCode("INDIA");
		rptInfo.setMerchantCountryCode("GERMANY");
		rptInfo.setMerchantName("ICICI");
		rptInfo.setCardsCountryPercentage(0.02);
		rptInfo.setLocalTransactionAmount(20000);
		
		CPPReportInfo rptInfo2 = new CPPReportInfo();
		rptInfo2.setGroupId(1);
		rptInfo2.setCardsUsedCount(4L);
		rptInfo2.setTransactionChannel("CNP");
		rptInfo2.setIssuerCountryCode("USA");
		rptInfo2.setMerchantCountryCode("BRAZIL");
		rptInfo2.setMerchantName("HDFC");
		rptInfo2.setCardsCountryPercentage(0.04);
		rptInfo2.setLocalTransactionAmount(15000);
		
		CPPReportInfo rptInfo3 = new CPPReportInfo();
		rptInfo3.setGroupId(2);
		rptInfo3.setCardsUsedCount(2L);
		rptInfo3.setTransactionChannel("CP");
		rptInfo3.setIssuerCountryCode("INDIA");
		rptInfo3.setMerchantCountryCode("GERMANY");
		rptInfo3.setMerchantName("ICICI");
		rptInfo3.setCardsCountryPercentage(0.02);
		rptInfo3.setLocalTransactionAmount(20000);
		
		CPPReportInfo rptInfo4 = new CPPReportInfo();
		rptInfo4.setGroupId(2);
		rptInfo4.setCardsUsedCount(4L);
		rptInfo4.setTransactionChannel("CNP");
		rptInfo4.setIssuerCountryCode("USA");
		rptInfo4.setMerchantCountryCode("BRAZIL");
		rptInfo4.setMerchantName("HDFC");
		rptInfo4.setCardsCountryPercentage(0.04);
		rptInfo4.setLocalTransactionAmount(15000);

		CPPReportInfo rptInfo5 = new CPPReportInfo();
		rptInfo5.setGroupId(1);
		rptInfo5.setCardsUsedCount(4L);
		rptInfo5.setTransactionChannel("CNPs");
		rptInfo5.setIssuerCountryCode("UK");
		rptInfo5.setMerchantCountryCode("SINGAPUR");
		rptInfo5.setMerchantName("AXIS");
		rptInfo5.setCardsCountryPercentage(0.03);
		rptInfo5.setLocalTransactionAmount(10000);

		reportInfos.add(rptInfo);
		reportInfos.add(rptInfo2);
		reportInfos.add(rptInfo3);
		reportInfos.add(rptInfo4);
		reportInfos.add(rptInfo5);
	}

	@Test
	public void testWrite() throws Exception{
		logger.setLevel(Level.DEBUG);
		itemWtr=EasyMock.createMock(CPPReportGenerationItemWriter.class);
		itemWtr = new CPPReportGenerationItemWriter();
		itemWtr.setExecutionContext(executionContext);
		assertEquals(executionContext,itemWtr.getExecutionContext());
		itemWtr.write(reportInfos);
	}
	
	@Test
	public void test() throws Exception{
		cPPReportInfo1 = new CPPReportInfo();
		cPPReportInfo1.setCardsCountryPercentage(0.01);
		cPPReportInfo1.getCardsCountryPercentage();
		cPPReportInfo1.setCardsUsedCount((long) 9);
		cPPReportInfo1.getCardsUsedCount();
		cPPReportInfo1.setGroupId(0);
		cPPReportInfo1.getGroupId();
		cPPReportInfo1.setIssuerCountryCode("INDIA");
		cPPReportInfo1.getIssuerCountryCode();
		cPPReportInfo1.setLocalTransactionAmount(100000);
		cPPReportInfo1.getLocalTransactionAmount();
		cPPReportInfo1.setLocationId("222");
		cPPReportInfo1.getLocationId();
		cPPReportInfo1.setMerchantCountryCode("GERMANY");
		cPPReportInfo1.getMerchantCountryCode();
		cPPReportInfo1.setMerchantName("ICICI");
		cPPReportInfo1.getMerchantName();
		cPPReportInfo1.setTransactionChannel("CP");
		cPPReportInfo1.getTransactionChannel();
		
		reportInfos1 = new ArrayList<>();
		reportInfos1.add(cPPReportInfo1);
		cppReportGenerator = EasyMock.createMock(CPPReportGenerator.class);
		itemWtr=EasyMock.createMock(CPPReportGenerationItemWriter.class);
		itemWtr = new CPPReportGenerationItemWriter();
		itemWtr.setExecutionContext(executionContext);
		assertEquals(executionContext,itemWtr.getExecutionContext());
		itemWtr.setObject(cppReportGenerator);
		itemWtr.write(reportInfos1);
	}
	
	@Test
	public void testJobInstanceName() {
		itemWtr = new CPPReportGenerationItemWriter();
		itemWtr.setJobInstanceName("CPPReportGenerator");
	}

	@Test
	public void testJobInstanceId() {
		itemWtr = new CPPReportGenerationItemWriter();
		itemWtr.setJobInstanceId(BigDecimal.valueOf(2222));
		itemWtr.setCountryCode("619");
		itemWtr.getCountryCode();
		itemWtr.setExecutionContext(executionContext);
		assertEquals(executionContext,itemWtr.getExecutionContext());
	}
	
	@Test
	public void testObject(){
		itemWtr = new CPPReportGenerationItemWriter();
		itemWtr.setObject(cppReportGenerator);
	}
	
	@Test
	public void testEmptyList() throws Exception {
		itemWtr = new CPPReportGenerationItemWriter();
		cppReportService = EasyMock.createMock(CPPReportService.class);
		cppReportGenerator = new CPPReportGenerator();
		percentageComparator = new PercentageComparator();
		cPPReportInfo1 = new CPPReportInfo();
		reportInfos1 = new ArrayList<>();
		cPPReportInfo1.setCardsCountryPercentage(5.0);
		cPPReportInfo1.setCardsUsedCount((long) 9);
		cPPReportInfo1.setGroupId(0);
		cPPReportInfo1.setIssuerCountryCode("INDIA");
		cPPReportInfo1.setLocalTransactionAmount(100000);
		cPPReportInfo1.setLocationId("222");
		cPPReportInfo1.setMerchantCountryCode("GERMANY");
		cPPReportInfo1.setMerchantName("ICICI");
		cPPReportInfo1.setTransactionChannel("CP");
		reportInfos1.add(cPPReportInfo1);
		
		cppReportGenerator = EasyMock.createMock(CPPReportGenerator.class);
		itemWtr.setJobInstanceId(BigDecimal.valueOf(123));
		itemWtr.setJobInstanceName("CPPReportGenerator");
		itemWtr.setObject(cppReportGenerator);
		itemWtr.setExecutionContext(executionContext);
		itemWtr.write(reportInfos1);
		Collections.sort(reportInfos1,new PercentageComparator());
		cppReportGenerator.writeToCPPReport(reportInfos1, "CPPReportGenerator" ,BigDecimal.valueOf(123) ,"CPPAnalysis","USA");
		itemWtr.setObject(cppReportGenerator);
		ReflectionTestUtils.invokeMethod(itemWtr, "group1ListIsEmpty", reportInfos1 , "USA");
	}

	@Test
	public void testIteratorDetails() {
		itemWtr = new CPPReportGenerationItemWriter();
		List<CPPReportInfo> tempList = new ArrayList<>();
		CPPReportInfo cPPReportInfo7 = new CPPReportInfo();
		cPPReportInfo7.setCardsUsedCount(5L);
		cPPReportInfo7.setTransactionChannel("CP");
		CPPReportInfo cPPReportInfo8 = new CPPReportInfo();
		cPPReportInfo8.setCardsUsedCount(5L);
		cPPReportInfo8.setTransactionChannel("CNP");
		tempList.add(cPPReportInfo7);
		tempList.add(cPPReportInfo8);
		ListIterator<CPPReportInfo> group1ListIterator = tempList.listIterator();
		ReflectionTestUtils.invokeMethod(itemWtr, "populateCardPercentageForDetailReport", 0L,0L,group1ListIterator);
		
	}
	
}
