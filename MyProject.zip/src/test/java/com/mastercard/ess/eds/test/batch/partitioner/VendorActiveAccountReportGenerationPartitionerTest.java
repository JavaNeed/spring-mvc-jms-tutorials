package com.mastercard.ess.eds.test.batch.partitioner;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.partitioner.VendorActiveAccountReportGenerationPartitioner;
import com.mastercard.ess.eds.core.dao.EDSSourceTypeDao;
import com.mastercard.ess.eds.core.service.EDSSourceTypeService;

public class VendorActiveAccountReportGenerationPartitionerTest {

	EDSSourceTypeService edsSourceTypeService;
	VendorActiveAccountReportGenerationPartitioner vendorActiveAccountReportGenerationPartitioner;
	EDSSourceTypeDao edsSourceTypeDao;
	
	@Before
	public void init() {
		edsSourceTypeDao = EasyMock.createMock(EDSSourceTypeDao.class);
		edsSourceTypeService = new EDSSourceTypeService();
		edsSourceTypeService.setEdsSourceTypeDao(edsSourceTypeDao);
		vendorActiveAccountReportGenerationPartitioner = new VendorActiveAccountReportGenerationPartitioner();
		vendorActiveAccountReportGenerationPartitioner.setEdsSourceTypeService(edsSourceTypeService);
	    List<String> vendorList= new ArrayList<String>();
		vendorList.add("Terbium");
		
		EasyMock.expect(edsSourceTypeDao.getVendorList()).andReturn(vendorList);
		EasyMock.replay(edsSourceTypeDao);
		
	}
	
	@Test
	public void testpartition() {
		ExecutionContext executionContext = new ExecutionContext();
		String vendorList = "Terbium";
		executionContext.put("vendor", vendorList);
		Map<String, ExecutionContext> partitionMapExpected = new HashMap<String, ExecutionContext>();
		partitionMapExpected.put("Thread -0", executionContext);
		
		Map<String, ExecutionContext> partitionMap = vendorActiveAccountReportGenerationPartitioner.partition(1);

	}

}
