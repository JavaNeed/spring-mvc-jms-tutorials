package com.mastercard.ess.eds.test.core.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.context.ApplicationContext;

import com.mastercard.ess.eds.core.service.EDSRecordWriterService;
import com.mastercard.ess.eds.core.util.GenerateFileScheduler;
import com.mastercard.ess.eds.core.util.GlobalConstants;

public class GenerateFileSchedulerTest {
	ApplicationContext context;
	JobLauncher joLauncher;
	EDSRecordWriterService edsRecordWriterService;
	GenerateFileScheduler generateFileScheduler;
	SimpleDateFormat datetimeFormat;
	Job job;
	
	private Logger logger = Logger.getLogger(GenerateFileScheduler.class);
	private JobExecution jobExecution;

	
	@Before
	public void init(){
		job=EasyMock.createMock(Job.class);
		context = EasyMock.createMock(ApplicationContext.class);
		joLauncher = EasyMock.createMock(JobLauncher.class);
		edsRecordWriterService =  EasyMock.createMock(EDSRecordWriterService.class);
		datetimeFormat = EasyMock.createMock(SimpleDateFormat.class);
	}
	
	@Before
	public void init1() throws JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException{
		job=EasyMock.createMock(Job.class);
		context = EasyMock.createMock(ApplicationContext.class);
		joLauncher = EasyMock.createMock(JobLauncher.class);
		edsRecordWriterService =  EasyMock.createMock(EDSRecordWriterService.class);
		datetimeFormat = EasyMock.createMock(SimpleDateFormat.class);
		boolean ifReportableRecordsExist = edsRecordWriterService.ifReportableRecordsExist();

		logger.info("ifReportableRecordsExist value ==" + ifReportableRecordsExist);

		if (ifReportableRecordsExist) {
				JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
				datetimeFormat = new SimpleDateFormat(GlobalConstants.DATE_TIME_FORMAT);
				String timestamp = datetimeFormat.format(new Date());
				jobParametersBuilder.addString("currentDateTime", timestamp);
				JobParameters jobParameters = jobParametersBuilder.toJobParameters();
				joLauncher.run(job, jobParameters);
				logger.info("launching customerFileGenerationJob ");
				generateFileScheduler = new GenerateFileScheduler(context,joLauncher,edsRecordWriterService);
				generateFileScheduler.setJob(job);
				generateFileScheduler.setContext(context);
				generateFileScheduler.setJoLauncher(joLauncher);
				
				Mockito.when(context.getBean("customerFileGenerationJob")).thenReturn(job);
				Mockito.when(joLauncher.run(job, jobParameters)).thenReturn(jobExecution);
		}
	}
	
	@Test
	public void runTest(){
			generateFileScheduler = new GenerateFileScheduler(context,joLauncher,edsRecordWriterService);
			generateFileScheduler.setJob(job);
			generateFileScheduler.setContext(context);
			generateFileScheduler.setJoLauncher(joLauncher);
			EasyMock.expect(edsRecordWriterService.ifReportableRecordsExist()).andReturn(true);
			EasyMock.replay(edsRecordWriterService);
			generateFileScheduler.run();
	}
	
	@Test
	public void runTest1(){
			generateFileScheduler = new GenerateFileScheduler(context,joLauncher,edsRecordWriterService);
			EasyMock.expect(edsRecordWriterService.ifReportableRecordsExist()).andReturn(true);
			EasyMock.replay(edsRecordWriterService);
			generateFileScheduler.setJob(job);
			generateFileScheduler.setContext(context);
			generateFileScheduler.setJoLauncher(joLauncher);
			generateFileScheduler.run();
	}
	
	@Test
	public void splunkLoggerTest(){
		generateFileScheduler = new GenerateFileScheduler(context,joLauncher,edsRecordWriterService);
		generateFileScheduler.setJob(job);
		generateFileScheduler.setContext(context);
		generateFileScheduler.setJoLauncher(joLauncher);
		generateFileScheduler.splunkLogger(new JobExecutionException("customerFileGenerationJob falied"));

	}

}
