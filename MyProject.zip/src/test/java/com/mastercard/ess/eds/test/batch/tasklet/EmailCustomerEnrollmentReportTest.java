package com.mastercard.ess.eds.test.batch.tasklet;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;

import com.mastercard.ess.eds.batch.tasklet.EmailCustomerEnrollmentReport;
import com.mastercard.ess.eds.core.dao.EDSSourceTypeDao;
import com.mastercard.ess.eds.core.events.EventPublisher;

public class EmailCustomerEnrollmentReportTest {
	EmailCustomerEnrollmentReport emailCustomerEnrollmentReport;
	EDSSourceTypeDao edsSourceTypeDao;
	EventPublisher eventPublisher;
	StepContribution contribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	String customerEnrollmentReportPath = "..CustomerDetailReport_";
	Logger logger = Logger.getLogger(EmailCustomerEnrollmentReport.class);

	@Before
	public void setUp()
	{
		logger.setLevel(Level.DEBUG);
		String fileName = "file:///MCI.AR.RABC.X.E1234567.D160812.T111135.C001";

		Map<String, JobParameter> parameters = new LinkedHashMap<>();

		jobParameter = new JobParameter(fileName, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);

		jobInstance = new JobInstance(new Long(123), "enrollmentReportFile");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("enrollmentReportFile", jobExecution);

		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		contribution = new StepContribution(stepExecution);

		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("tb", "");
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("tb_path", "_mastercard.xlsx");

		eventPublisher = EasyMock.createMock(EventPublisher.class);
		edsSourceTypeDao=EasyMock.createMock(EDSSourceTypeDao.class);	



	}
	@Test
	public void test() throws Exception {
		emailCustomerEnrollmentReport = new EmailCustomerEnrollmentReport(edsSourceTypeDao);
		emailCustomerEnrollmentReport.setCustomerEnrollmentReportPath(customerEnrollmentReportPath);
		emailCustomerEnrollmentReport.setEdsSourceTypeDao(edsSourceTypeDao);
		emailCustomerEnrollmentReport.setEventPublisher(eventPublisher);
		emailCustomerEnrollmentReport.execute(contribution, chunkContext);
	}

}