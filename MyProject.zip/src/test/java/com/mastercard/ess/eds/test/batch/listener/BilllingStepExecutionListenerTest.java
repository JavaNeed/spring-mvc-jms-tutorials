package com.mastercard.ess.eds.test.batch.listener;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.test.util.ReflectionTestUtils;

import com.mastercard.ess.eds.batch.listener.BilllingStepExecutionListener;
import com.mastercard.ess.eds.billing.dao.BillDataDAO;
import com.mastercard.ess.eds.billing.util.CSVWriterUtils;
import com.mastercard.ess.eds.billing.util.RenewalDateUtil;
import com.mastercard.ess.eds.domain.FileDetails;

public class BilllingStepExecutionListenerTest {

	private static final String DD_MM_YYYY = "dd/MM/yyyy";
	private BillDataDAO billDataDao;
	RenewalDateUtil renewalDateUtil;
	CSVWriterUtils csvWriterUtils;
	BilllingStepExecutionListener billingStepExecutionListener;
	StepContribution stepContribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	List<String> billableICAs;
	ExecutionContext executionContext;

	@Before
	public void setUp()
	{
		String fileName = "file:///MCI.AR.RABC.X.E1234567.D160812.T111135.C001";
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		jobParameter = new JobParameter(fileName, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);
		jobInstance = new JobInstance(new Long(123), "importRawRecords");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("loadRawRecords", jobExecution);
		billDataDao = EasyMock.createMock(BillDataDAO.class);
		billableICAs = new ArrayList<String>();
		billableICAs.add("ICA");
		billableICAs.add("ICAOne");

		List<Map<String, Object>> icaList = new ArrayList<Map<String, Object>>();
		List<FileDetails> fileDetails = new ArrayList<>();
		executionContext = new ExecutionContext();
		executionContext.put("listOfEligibleIca", icaList);
		executionContext.put("fileStatusList", fileDetails);

	}

	@Test 
	public void test() {
		EasyMock.expect(billDataDao.getBillableICAList(null)).andReturn(billableICAs);
		EasyMock.replay(billDataDao);
		renewalDateUtil = EasyMock.createMock(RenewalDateUtil.class);;
		billingStepExecutionListener=new BilllingStepExecutionListener(billDataDao , renewalDateUtil );
		billingStepExecutionListener.setExecutionContext(executionContext);
		billingStepExecutionListener.beforeStep(stepExecution);
		csvWriterUtils = EasyMock.createMock(CSVWriterUtils.class);
		billingStepExecutionListener.setCreateCsv(csvWriterUtils);
		billingStepExecutionListener.afterStep(stepExecution);  
	}

	@Test
	public void testRenewalDate() {
		Calendar updatedRenewalDate = Calendar.getInstance();
		updatedRenewalDate.setTime(new Date(0L));
		updatedRenewalDate.add(Calendar.DAY_OF_MONTH, 365);
		String renewalDateForIca="31/06/2018";
		try {
			Date date1=new SimpleDateFormat(DD_MM_YYYY).parse(renewalDateForIca);

			List<Map<String, Object>> childParentMapList = new ArrayList<Map<String,Object>>();
			Map<String, Object> map = new HashMap<String,Object>();
			map.put("CRTE_DT", new Date(0L));
			map.put("RNWL_DT", null);
			map.put("ICA_NUM", new BigDecimal(3));
			map.put("CRTE_USER_ID", "E07474");

			childParentMapList.add(map);
			billDataDao = EasyMock.createMock(BillDataDAO.class);
			renewalDateUtil = EasyMock.createMock(RenewalDateUtil.class);;
			billingStepExecutionListener=new BilllingStepExecutionListener(billDataDao , renewalDateUtil );

			ReflectionTestUtils.invokeMethod(billingStepExecutionListener, "updateRenewalDate", childParentMapList );

			List<Map<String, Object>> childParentMapListWithRenewalDate = new ArrayList<Map<String,Object>>();
			Map<String, Object> mapWithRenewalDate = new HashMap<String,Object>();
			mapWithRenewalDate.put("CRTE_DT", new Date(0L));
			mapWithRenewalDate.put("RNWL_DT", date1);
			mapWithRenewalDate.put("ICA_NUM", new BigDecimal(3));
			mapWithRenewalDate.put("CRTE_USER_ID", "E07474");

			billDataDao = EasyMock.createMock(BillDataDAO.class);
			billingStepExecutionListener=new BilllingStepExecutionListener( billDataDao , renewalDateUtil );

			childParentMapListWithRenewalDate.add(mapWithRenewalDate);
			ReflectionTestUtils.invokeMethod(billingStepExecutionListener, "updateRenewalDate", childParentMapListWithRenewalDate );

		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testUpdateRenewalDateForMassonboardedIca() {
		Calendar updatedRenewalDate = Calendar.getInstance();
		updatedRenewalDate.setTime(new Date(0L));
		updatedRenewalDate.add(Calendar.DAY_OF_MONTH, 365);
		String renewalDateForIca="31/06/2018";
		try {
			Date date1=new SimpleDateFormat(DD_MM_YYYY).parse(renewalDateForIca);

			billDataDao = EasyMock.createMock(BillDataDAO.class);
			renewalDateUtil = EasyMock.createMock(RenewalDateUtil.class);;
			billingStepExecutionListener=new BilllingStepExecutionListener(billDataDao , renewalDateUtil);

			List<Map<String, Object>> childParentMapListOne = new ArrayList<Map<String,Object>>();
			Map<String, Object> mapOne = new HashMap<String,Object>();
			mapOne.put("CRTE_DT", new Date(0L));
			mapOne.put("RNWL_DT", null);
			mapOne.put("ICA_NUM", new BigDecimal(3));
			mapOne.put("CRTE_USER_ID", "custMassOnboarding");

			childParentMapListOne.add(mapOne);

			ReflectionTestUtils.invokeMethod(billingStepExecutionListener, "updateRenewalDate", childParentMapListOne );

			List<Map<String, Object>> childParentMapListWithRenewalDate = new ArrayList<Map<String,Object>>();
			Map<String, Object> mapWithRenewalDate = new HashMap<String,Object>();
			mapWithRenewalDate.put("CRTE_DT", new Date(0L));
			mapWithRenewalDate.put("RNWL_DT", date1);
			mapWithRenewalDate.put("ICA_NUM", new BigDecimal(3));
			mapWithRenewalDate.put("CRTE_USER_ID", "custMassOnboarding");

			childParentMapListOne.add(mapWithRenewalDate);


			ReflectionTestUtils.invokeMethod(billingStepExecutionListener, "updateRenewalDate", childParentMapListWithRenewalDate );
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}


}
