package com.mastercard.ess.eds.test.batch.reader;

import static org.junit.Assert.assertEquals;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.test.util.ReflectionTestUtils;

import com.mastercard.ess.eds.batch.reader.CPPClearingTxnReader;
import com.mastercard.ess.eds.domain.CPPTxnInfo;

public class CPPClearingTxnReaderTest {
	CPPClearingTxnReader cPPClearingTxnReader;
	PreparedStatementSetter preparedStatementSetter;
	String sql;
	ResultSet rs;
	RowMapper<CPPTxnInfo> rowMapper;
	protected Method m;
	protected static String METHOD_NAME = "cleanupOnClose";
	protected Class[] parameterTypes;
	protected Object[] parameters;
	private DataSource dataSource;
	private PreparedStatement statement;
	private Connection jdbcConnection;

	
	@Before
	public void setUp() throws Exception {
		cPPClearingTxnReader = new CPPClearingTxnReader();
		parameterTypes = new Class[0];
		m = cPPClearingTxnReader.getClass().getDeclaredMethod(METHOD_NAME,
				parameterTypes);
		m.setAccessible(true);
		parameters = new Object[0];
		rowMapper = new RowMapper<CPPTxnInfo>() {

			@Override
			public CPPTxnInfo mapRow(ResultSet arg0, int arg1)
					throws SQLException {
				// TODO Auto-generated method stub
				return null;
			}
		};

	}
	  
	@Test
	public void test() throws Exception {
		cPPClearingTxnReader = new CPPClearingTxnReader();
		cPPClearingTxnReader.setRowMapper(rowMapper);
		cPPClearingTxnReader.setSql("");
		cPPClearingTxnReader.setPreparedStatementSetter(preparedStatementSetter);
		assertEquals("",cPPClearingTxnReader.getSql());
	}
	
	@Test
	public void testing() throws IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		cPPClearingTxnReader = new CPPClearingTxnReader();
		CPPTxnInfo result = (CPPTxnInfo) m.invoke(cPPClearingTxnReader, parameters);
	}
	
	@Test
	public void readCursorTest() throws Exception {
		cPPClearingTxnReader = new CPPClearingTxnReader();
		cPPClearingTxnReader.setRowMapper(rowMapper);
		cPPClearingTxnReader.setSql("CPPClearingTxnReader");
		cPPClearingTxnReader.setDataSource(new BasicDataSource());
		cPPClearingTxnReader.setPreparedStatementSetter(preparedStatementSetter);
		cPPClearingTxnReader.afterPropertiesSet();
		ReflectionTestUtils.invokeMethod(cPPClearingTxnReader, "readCursor", rs, 2);

	}
	
	@Test
	public void openCursorTest() throws Exception{
		dataSource=Mockito.mock(DataSource.class);
		PreparedStatementSetter preparedStatementSetter=new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				
			}
		};
		
		cPPClearingTxnReader = new CPPClearingTxnReader();
		cPPClearingTxnReader.setCurrentItemCount(1);
		cPPClearingTxnReader.setDataSource(dataSource);
		cPPClearingTxnReader.setPreparedStatementSetter(preparedStatementSetter);
		cPPClearingTxnReader.setUseSharedExtendedConnection(true);
		cPPClearingTxnReader.setCurrentItemCount(1);
		cPPClearingTxnReader.setSql("CPPClearingTxnReader");

		
		jdbcConnection = Mockito.mock(Connection.class);
		statement =Mockito.mock(PreparedStatement.class);
		rs= Mockito.mock(ResultSet.class);
		
		Mockito.when(jdbcConnection.prepareStatement("CPPClearingTxnReader",ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY,
				ResultSet.HOLD_CURSORS_OVER_COMMIT)).thenReturn(statement);
		Mockito.when(statement.executeQuery()).thenReturn(rs);
        Mockito.when(rs.isBeforeFirst()).thenReturn(false);
		
		ReflectionTestUtils.invokeMethod(cPPClearingTxnReader, "openCursor",jdbcConnection);

		
	}

}
