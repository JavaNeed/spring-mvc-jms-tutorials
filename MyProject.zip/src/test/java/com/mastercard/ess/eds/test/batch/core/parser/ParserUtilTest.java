package com.mastercard.ess.eds.test.batch.core.parser;

import static org.junit.Assert.assertEquals;

import java.util.Map;

import javax.crypto.SecretKey;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.item.file.transform.FieldSet;

import com.mastercard.ess.eds.core.parser.ParserUtil;
import com.mastercard.ess.eds.core.parser.VendorPayloadTokens;

public class ParserUtilTest {

	private static Logger logger = Logger.getLogger(ParserUtilTest.class);
	private static FieldSet fieldSet = null;
	private static SecretKey key ;
	private static String transform ;
	private static String fieldsToDecrypt;
	@Before
	public void setUp() {
		logger.setLevel(Level.DEBUG);
		fieldSet = EasyMock.createMock(FieldSet.class);
		key = EasyMock.createMock(SecretKey.class);
		transform = "AES/CBC/PKCS5Padding";
	}
	
	@Test
	public void testDecryptValuesLine(){
		EasyMock.expect(fieldSet.readString("iv")).andReturn("XslKTzv2u9VP0gE2kPfvAA==");
		EasyMock.expect(fieldSet.readString("value")).andReturn("SvOS4xgV0DnpGjMpyEw891JaZefPqfjyjUBkVs77db5P6sKSGPt88S5TEO1r+igz");
		EasyMock.replay(fieldSet);
		Map<String, String> values = null;
		try {
			values = ParserUtil.decryptValues(fieldSet, key, transform, null);
			assertEquals(null, values.get(VendorPayloadTokens.VALUE.getDesc()));
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
		
	}
	
	@Test
	public void testDecryptValuesCaseField(){
		fieldsToDecrypt = "value";
		EasyMock.expect(fieldSet.readString("iv")).andReturn("XslKTzv2u9VP0gE2kPfvAA==");
		EasyMock.expect(fieldSet.readString("value")).andReturn("SvOS4xgV0DnpGjMpyEw891JaZefPqfjyjUBkVs77db5P6sKSGPt88S5TEO1r+igz");
		EasyMock.replay(fieldSet);
		try {
			Map<String,String> values = ParserUtil.decryptValues(fieldSet, key, transform, fieldsToDecrypt);
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
	}
	
}
