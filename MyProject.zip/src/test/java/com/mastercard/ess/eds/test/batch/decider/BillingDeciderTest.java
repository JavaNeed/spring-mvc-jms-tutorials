package com.mastercard.ess.eds.test.batch.decider;

import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.decider.BillingDecider;

public class BillingDeciderTest {
    BillingDecider billingDecider;
    JobExecution jobExecution;
    JobInstance jobInstance;
    StepContribution stepContribution;
    ChunkContext chunkContext;
    StepExecution stepExecutionStatus;
    StepContext stepContext;
    JobParameters jobParameters;
    JobParameter jobParameter;
    ExecutionContext executionContext;
    String billRunMode;

    @Test
    public void testDecideGFT() throws Exception {
        billingDecider = new BillingDecider();
        jobInstance = new JobInstance(new Long(123), "decide");
        billRunMode = "GFT_FAILURE";
        Map<String, JobParameter> parameters = new LinkedHashMap<>();
        jobParameter = new JobParameter(billRunMode, true);
        parameters.put("input.file", jobParameter);
        jobParameters = new JobParameters(parameters);
        jobExecution = new JobExecution(jobInstance, jobParameters);
        executionContext = new ExecutionContext();
        executionContext.put("billRunMode", "GFT_FAILURE");
        jobExecution.setExecutionContext(executionContext);
        stepExecutionStatus = new StepExecution("billingDecider", jobExecution);
        stepContext = new StepContext(stepExecutionStatus);
        chunkContext = new ChunkContext(stepContext);
        stepContribution = new StepContribution(stepExecutionStatus);
        billingDecider.decide(jobExecution, stepExecutionStatus);

    }

    @Test
    public void testDecideFile() throws Exception {
        billingDecider = new BillingDecider();
        jobInstance = new JobInstance(new Long(123), "decide");
        billRunMode = "FILE_GENERATION";
        Map<String, JobParameter> parameters = new LinkedHashMap<>();
        jobParameter = new JobParameter(billRunMode, true);
        parameters.put("input.file", jobParameter);
        jobParameters = new JobParameters(parameters);
        jobExecution = new JobExecution(jobInstance, jobParameters);
        executionContext = new ExecutionContext();
        executionContext.put("billRunMode", "FILE_GENERATION");
        jobExecution.setExecutionContext(executionContext);
        stepExecutionStatus = new StepExecution("billingDecider", jobExecution);
        stepContext = new StepContext(stepExecutionStatus);
        chunkContext = new ChunkContext(stepContext);
        stepContribution = new StepContribution(stepExecutionStatus);
        billingDecider.decide(jobExecution, stepExecutionStatus);

    }

}
