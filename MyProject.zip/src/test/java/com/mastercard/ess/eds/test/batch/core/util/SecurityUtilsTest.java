package com.mastercard.ess.eds.test.batch.core.util;

import static org.junit.Assert.assertNull;

import java.io.IOException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.core.util.DevUtil;
import com.mastercard.ess.eds.core.util.EnvironmentUtil;
import com.mastercard.ess.eds.core.util.ProdUtil;
import com.mastercard.ess.eds.core.util.SecurityUtils;


public class SecurityUtilsTest {
	
	SecurityUtils securityUtils;
	EnvironmentUtil environmentUtil;
	Logger logger;
	
	@Before
	public void init() {
		logger = Logger.getLogger(SecurityUtils.class);
		logger.setLevel(Level.DEBUG);
		securityUtils = new SecurityUtilsStub();
		securityUtils.setCryptovaultLabel("nss");
		securityUtils.setKeyStoreAlias("mydomain");
		environmentUtil = new ProdUtil();
	}
	
	
	@Test
	public void testSessionKey() throws IOException {
		environmentUtil = new ProdUtil();
		securityUtils.setEnvUtil(environmentUtil);
		assertNull(securityUtils.getSessionKey("C8/SsY1m16goy/TYl4ZadfcpDqIlpbymKHRBC+5VQaELGptmjDE0pWzmVZ6e4bBCjTj2vxOQ7mn0W1lKEcLVXwaukcO4EpTJqZK9MrdW5ibAPTgoa1tk8+IN6LAiGAHQXsrbbyw2J5EK2bu0B2mWptaDW9AWobdFqgfd7nNJmdgT12/fnjRrTh+VP7RHKhvB23q7yLPJmqpdRLaL3RN9ifdb+vLy3Ylf89FQ1As88JTUnb36BAC6Jrsp/VUNoKDp8GrEYE2pRuXlRsAAhJz1k2wBeI9PmdDJsSgyKQN0GI5FMDbOY0B5MK1aZl/J/gnNEnMCW78iZyenHfnMwHptOA=="));
		
	}
	
	@Test
	public void testSessionKeyForDev() throws IOException {
		DevUtil devUtil = new DevUtil();
		ClassLoader classLoader = getClass().getClassLoader();
		devUtil.setKeyStorePath(classLoader.getResource("keystore").getPath());
		securityUtils.setEnvUtil(devUtil);
		assertNull(securityUtils.getSessionKey("C8/SsY1m16goy/TYl4ZadfcpDqIlpbymKHRBC+5VQaELGptmjDE0pWzmVZ6e4bBCjTj2vxOQ7mn0W1lKEcLVXwaukcO4EpTJqZK9MrdW5ibAPTgoa1tk8+IN6LAiGAHQXsrbbyw2J5EK2bu0B2mWptaDW9AWobdFqgfd7nNJmdgT12/fnjRrTh+VP7RHKhvB23q7yLPJmqpdRLaL3RN9ifdb+vLy3Ylf89FQ1As88JTUnb36BAC6Jrsp/VUNoKDp8GrEYE2pRuXlRsAAhJz1k2wBeI9PmdDJsSgyKQN0GI5FMDbOY0B5MK1aZl/J/gnNEnMCW78iZyenHfnMwHptOA=="));
		
	}
	
	class SecurityUtilsStub extends SecurityUtils{
		
		public String extractPassword(String systemCmd) throws IOException{
			return "ch@nge1t";
		}
		
	}
}
