package com.mastercard.ess.eds.test.core.util;

import static org.junit.Assert.assertEquals;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;

import com.mastercard.ess.eds.core.dao.EDSSourceTypeDao;
import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.core.util.EmailDeliveryReportTasklet;

public class EmailDeliveryReportTaskletTest {
	
	EmailDeliveryReportTasklet emailDeliveryReportTasklet;
	EDSSourceTypeDao edsSourceTypeDao;
	EventPublisher eventPublisher;
	StepContribution stepContribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	String customerDeliveryReportPath="/tmp/CPPReport/CustomerDeliveryReport_";
	Logger logger;
  
    @Before
	public void setUp()
	{
		logger = Logger.getLogger(EmailDeliveryReportTasklet.class);
		logger.setLevel(Level.DEBUG);
		Map<String, JobParameter> parameters = new LinkedHashMap<>();
		
		jobParameter = new JobParameter(customerDeliveryReportPath, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);
		
		jobInstance = new JobInstance(new Long(123), "customerDeliveryReportPath");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("customerDeliveryReportPath", jobExecution);
		
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		stepContribution = new StepContribution(stepExecution);
		
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("tb", "");
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("tb_path", "_mastercard.xlsx");
		edsSourceTypeDao = EasyMock.createMock(EDSSourceTypeDao.class);
	}
    
    @Test
	public void test() throws Exception {
    	emailDeliveryReportTasklet=new EmailDeliveryReportTasklet();
    	emailDeliveryReportTasklet.setCustomerDeliveryReportPath(customerDeliveryReportPath);
    	emailDeliveryReportTasklet.getCustomerDeliveryReportPath();
		assertEquals(null,emailDeliveryReportTasklet.execute(stepContribution,chunkContext));
		
	}


}
