package com.mastercard.ess.eds.test.batch.core.util;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.core.util.ProdUtil;

public class ProdUtilTest {
	
	ProdUtil prodUtil;
	
	@Before
	public void init(){
		prodUtil = new ProdUtil();
	}
	
	@Test
	public void testKeyStorePath(){
		assertNull(prodUtil.getKeyStorePath());
	}

}
