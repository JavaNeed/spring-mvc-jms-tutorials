package com.mastercard.ess.eds.test.batch.listener;

import static org.junit.Assert.assertEquals;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInterruptedException;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mastercard.ess.eds.batch.config.EnvironmentConfig;
import com.mastercard.ess.eds.batch.listener.RawRecordSkipListener;
import com.mastercard.ess.eds.core.dao.EDSRecordDao;
import com.mastercard.ess.eds.core.service.EDSRecordWriterService;
import com.mastercard.ess.eds.domain.RawRecord;
import com.mastercard.ess.eds.test.batch.config.CommonConfigTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {EnvironmentConfig.class,CommonConfigTest.class})
@ActiveProfiles(value = "dev")
public class RawRecordSkipListenerTest {

	 @Autowired
     private JobLauncherTestUtils jobLauncherTestUtils;
	 
	 @Autowired 
	 private ApplicationContext context;
	 
	Logger logger;
	EDSRecordDao stealthRecordDao;
	EDSRecordWriterService stealthRecordWriterService;
	RawRecordSkipListener rawRecordSkipListener;
	
	
	@Before
	public void init(){
		stealthRecordDao = EasyMock.createMock(EDSRecordDao.class);
		stealthRecordWriterService = new EDSRecordWriterService(stealthRecordDao);
		rawRecordSkipListener = new RawRecordSkipListener(stealthRecordWriterService);
		logger = Logger.getLogger(RawRecordSkipListener.class);
	
	}
	
	@Test
	public void onSkipInProcess() {
		logger.setLevel(Level.DEBUG);		
		rawRecordSkipListener.onSkipInProcess(new RawRecord(), new org.springframework.batch.item.validator.ValidationException(null));
	}
	
	@Test
	public void onSkipInProcessInfo() {
		logger.setLevel(Level.INFO);		
		rawRecordSkipListener.onSkipInProcess(new RawRecord(), new org.springframework.batch.item.validator.ValidationException(null));
	}
	
	 @Test
     public void testStepWithSkip() throws JobInterruptedException{
		 logger.setLevel(Level.DEBUG);
		 Job job = (Job) context.getBean("panProcessJob");
		 jobLauncherTestUtils.setJob(job);
         JobExecution jobexecution = jobLauncherTestUtils.launchStep("processPANs");
         assertEquals(BatchStatus.FAILED, jobexecution.getStatus());
     }
	 
	 @Test
     public void testStepWithSkipInfo() throws JobInterruptedException{
		 logger.setLevel(Level.INFO);
		 Job job = (Job) context.getBean("panProcessJob");
		 jobLauncherTestUtils.setJob(job);
         JobExecution jobexecution = jobLauncherTestUtils.launchStep("processPANs");
         assertEquals(BatchStatus.FAILED, jobexecution.getStatus());
     }
	 
	 @Test
	 public void testOnSkipInRead(){
		 logger.setLevel(Level.DEBUG);	
		 rawRecordSkipListener.onSkipInRead(new org.springframework.batch.item.validator.ValidationException(null));
	 }
	 
	 @Test
	 public void testOnSkipInReadInfo(){
		 logger.setLevel(Level.INFO);	
		 rawRecordSkipListener.onSkipInRead(new org.springframework.batch.item.validator.ValidationException(null));
	 }
	 
	 @Test
	 public void testOnSkipInWrite(){
		 logger.setLevel(Level.DEBUG);	
		 rawRecordSkipListener.onSkipInWrite(new RawRecord(),new org.springframework.batch.item.validator.ValidationException(null));
	 }
	 
	 @Test
	 public void testOnSkipInWriteInfo(){
		 logger.setLevel(Level.INFO);	
		 rawRecordSkipListener.onSkipInWrite(new RawRecord(),new org.springframework.batch.item.validator.ValidationException(null));
	 }
}
