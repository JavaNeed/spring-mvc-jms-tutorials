package com.mastercard.ess.eds.test.batch.processor;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.support.CompositeItemProcessor;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mastercard.ess.eds.batch.config.EnvironmentConfig;
import com.mastercard.ess.eds.batch.processor.ADCNotificationProcessor;
import com.mastercard.ess.eds.batch.processor.PANLastActivityProcessor;
import com.mastercard.ess.eds.batch.processor.PANVerifierProcessor;
import com.mastercard.ess.eds.batch.processor.PriceCategoryProcessor;
import com.mastercard.ess.eds.batch.processor.RawRecordToEDSRecordProcessor;
import com.mastercard.ess.eds.batch.processor.RawRecordToEDSRecordTransformProcessor;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.RawRecord;
import com.mastercard.ess.eds.test.batch.config.CommonConfigTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {EnvironmentConfig.class,CommonConfigTest.class})
@ActiveProfiles(value = "dev")
public class CompositeItemProcessorTest {

	private CompositeItemProcessor<RawRecord, EDSRecord> compositeItemProcessor = new CompositeItemProcessor<RawRecord, EDSRecord>();

	private ItemProcessor<RawRecord, EDSRecord> rawRecordToEDSRecordProcessor;
	private ItemProcessor<EDSRecord, EDSRecord> panVerifierProcessor;
	private ItemProcessor<EDSRecord, EDSRecord> rawRecordToStealthRecordTransformProcessor;
	private ItemProcessor<EDSRecord, EDSRecord> adcNotificationProcessor;
	private ItemProcessor<EDSRecord, EDSRecord> lastActivityProcessor;
	private ItemProcessor<EDSRecord, EDSRecord> priceCategoryProcessor;

	@SuppressWarnings({ "unchecked", "serial" })
	@Before
	public void setUp() throws Exception {
		rawRecordToEDSRecordProcessor = mock(RawRecordToEDSRecordProcessor.class);
		panVerifierProcessor = mock(PANVerifierProcessor.class);
		rawRecordToStealthRecordTransformProcessor = mock(RawRecordToEDSRecordTransformProcessor.class);
		adcNotificationProcessor = mock(ADCNotificationProcessor.class);
		lastActivityProcessor = mock(PANLastActivityProcessor.class);
		priceCategoryProcessor = mock(PriceCategoryProcessor.class);

		compositeItemProcessor.setDelegates(new ArrayList() {
			{
				add(rawRecordToEDSRecordProcessor);
				add(panVerifierProcessor);
				add(rawRecordToStealthRecordTransformProcessor);
				add(adcNotificationProcessor);
				add(lastActivityProcessor);
				add(priceCategoryProcessor);
			}
		});

		compositeItemProcessor.afterPropertiesSet();
	}

	@Test
	public void testTransform() throws Exception {
		// Object item = new Object();
		RawRecord rawRecord = new RawRecord();
		EDSRecord itemAfterFirstTransfromation = new EDSRecord();
		EDSRecord itemAfterSecondTransformation = new EDSRecord();
		EDSRecord itemAfterThirdTransformation = new EDSRecord();
		EDSRecord itemAfterFourthTransformation = new EDSRecord();
		EDSRecord itemAfterFifthTransformation = new EDSRecord();
		EDSRecord itemAfterSixthTransformation = new EDSRecord();

		when(rawRecordToEDSRecordProcessor.process(rawRecord)).thenReturn(itemAfterFirstTransfromation);

		when(panVerifierProcessor.process(itemAfterFirstTransfromation)).thenReturn(itemAfterSecondTransformation);

		when(rawRecordToStealthRecordTransformProcessor.process(itemAfterSecondTransformation))
				.thenReturn(itemAfterThirdTransformation);

		when(adcNotificationProcessor.process(itemAfterThirdTransformation)).thenReturn(itemAfterFourthTransformation);

		when(lastActivityProcessor.process(itemAfterFourthTransformation)).thenReturn(itemAfterFifthTransformation);

		when(priceCategoryProcessor.process(itemAfterFifthTransformation)).thenReturn(itemAfterSixthTransformation);

		// assertSame(itemAfterSixthTransformation,
		// compositeItemProcessor.process(rawRecord));

	}

}
