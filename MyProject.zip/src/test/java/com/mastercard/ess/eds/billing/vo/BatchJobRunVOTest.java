package com.mastercard.ess.eds.billing.vo;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

public class BatchJobRunVOTest {
	BatchJobRunVO batchJobRunVO = new BatchJobRunVO();

	@Test
	public void testGetJob_instnce_id(){
		batchJobRunVO.setEds_lst_bat_job_run_id(123);
		assertEquals(123, batchJobRunVO.getEds_lst_bat_job_run_id());
			
	}
	
	@Test
	public void testGetLst_run_bat_job_nam(){
		batchJobRunVO.setLst_run_bat_job_nam("Billing");
		assertEquals("Billing", batchJobRunVO.getLst_run_bat_job_nam());
			
	}
	
	@Test
	public void testGetLst_run_dt(){
		batchJobRunVO.setLst_run_dt(new Date());
		assertNotNull( batchJobRunVO.getLst_run_dt());
			
	}

}

