package com.mastercard.ess.eds.test.renewal.vo;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.junit.Test;

import com.mastercard.ess.eds.renewal.vo.BillIcaLimitVO;



public class BillIcaLimitVOTest {
	public int prntIca;
	public Date startDate;
	public int icaLimit;
	
	BillIcaLimitVO billIcaLimitVO = new BillIcaLimitVO();
	BillIcaLimitVO billIcaLimitVO1 =new BillIcaLimitVO( prntIca, startDate, icaLimit);
	
	@Test
	
	public void testgetLimitId(){
		billIcaLimitVO.setLimitId(123);
		assertEquals(123, billIcaLimitVO.getLimitId());
			
	}
	
	@Test
	
	public void testgetprntIca(){
		billIcaLimitVO.setPrntIca(123);
		assertEquals(123, billIcaLimitVO.getPrntIca());
			
	}
	
	@Test
	
	public void testgetstartDate(){
		billIcaLimitVO.setStartDate(new Date(0L));
		assertEquals(new Date(0L), billIcaLimitVO.getStartDate());
			
	}
	
	@Test
	
	public void testgeticaLimit(){
		billIcaLimitVO.setIcaLimit(123);
		assertEquals(123, billIcaLimitVO.getIcaLimit());
			
	}
	
	}

