package com.mastercard.ess.eds.test.core.util;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easyrules.core.BasicRule;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.mastercard.ess.eds.core.dao.FileGenerationRulesDao;
import com.mastercard.ess.eds.core.rule.FileGenerationCustomRules;
import com.mastercard.ess.eds.core.rule.FileGenerationRules;
import com.mastercard.ess.eds.core.rule.PriceCategoryRule;
import com.mastercard.ess.eds.core.util.FileGenerationRulesCache;


public class FileGenerationRulesCacheTest {
	

	private Logger logger = Logger.getLogger(FileGenerationRulesCache.class);
	private FileGenerationRulesCache fileGenerationRulesCache= new FileGenerationRulesCache();
	@Mock
	FileGenerationRulesDao fileGenerationRulesDao;
	
	@Before
    public void setUp() throws Exception {
		logger.setLevel(Level.DEBUG);
		MockitoAnnotations.initMocks(this);
		fileGenerationRulesCache.setFileGenerationRulesDAO(fileGenerationRulesDao);
		Mockito.when(fileGenerationRulesCache.getCache()).thenReturn(new ArrayList<BasicRule>());
	}

	 	@Test
	    public void testGetCache(){
	         logger.setLevel(Level.DEBUG);
	         fileGenerationRulesCache.getCache();
	 		assertEquals(new ArrayList<PriceCategoryRule>(),fileGenerationRulesCache.getCache());
	 		List<BasicRule> ruleList = new ArrayList<BasicRule>();
	 		ruleList.add(new FileGenerationRules());
	 		fileGenerationRulesCache.getNewList(ruleList);
	 		ruleList.add(new FileGenerationCustomRules());
	 		fileGenerationRulesCache.getNewList(ruleList);
	    }
}