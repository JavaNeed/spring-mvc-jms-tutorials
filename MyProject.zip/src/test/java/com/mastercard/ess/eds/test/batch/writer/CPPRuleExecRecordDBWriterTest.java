package com.mastercard.ess.eds.test.batch.writer;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.writer.CPPRuleExecRecordDBWriter;
import com.mastercard.ess.eds.core.service.CPPRuleRecordService;
import com.mastercard.ess.eds.domain.AuthDebitPanDetailRecord;

public class CPPRuleExecRecordDBWriterTest {
	Logger logger = Logger.getLogger(CPPRuleExecRecordDBWriterTest.class);

	private CPPRuleRecordService cppRuleRecordService;
	private ExecutionContext executionContext;
	public String srcId;
	CPPRuleExecRecordDBWriter cppRuleExecRecordDBWriter;
	List<List<AuthDebitPanDetailRecord>> authDebitPanDetailRecords=new ArrayList<>();

	@Before
	public void init(){
		logger.setLevel(Level.DEBUG);

		cppRuleRecordService = EasyMock.createMock(CPPRuleRecordService.class);
		cppRuleExecRecordDBWriter=new CPPRuleExecRecordDBWriter(cppRuleRecordService);

		AuthDebitPanDetailRecord authDebitPanDetailRecord=new AuthDebitPanDetailRecord();
		authDebitPanDetailRecord.setCppRuleId(new BigDecimal(1));
		authDebitPanDetailRecord.setdWSource("DEBIT");
		authDebitPanDetailRecord.setRawPan("12345");
		List<AuthDebitPanDetailRecord> authDebitPanList=new ArrayList<>();
		authDebitPanList.add(authDebitPanDetailRecord);

		executionContext=new ExecutionContext();
		this.executionContext.put("edsSrcId", 5);
		authDebitPanDetailRecords.add(authDebitPanList);
		cppRuleExecRecordDBWriter=new CPPRuleExecRecordDBWriter();
		cppRuleExecRecordDBWriter.setJobInstanceName("cppRulesExecJob");
		cppRuleExecRecordDBWriter.getJobInstanceName();
		cppRuleExecRecordDBWriter.setExecutionContext(executionContext);
		cppRuleExecRecordDBWriter.getExecutionContext();
		cppRuleExecRecordDBWriter.setCppRuleRecordService(cppRuleRecordService);
		cppRuleExecRecordDBWriter.getCppRuleRecordService();
	}

	@Test
	public void test() throws Exception {
		logger.setLevel(Level.DEBUG);
		cppRuleExecRecordDBWriter.write(authDebitPanDetailRecords);
		EasyMock.expectLastCall();
	}
}
