package com.mastercard.ess.eds.test.batch.core.util;

import java.util.LinkedHashMap;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;

import com.mastercard.ess.eds.core.dao.LastBatchJobRunDao;
import com.mastercard.ess.eds.core.service.LastBatchJobRunService;
import com.mastercard.ess.eds.core.util.LastBatchRunUpdater;

public class LastBatchRunUpdaterTest {
	LastBatchJobRunService lastBatchJobRunService;
	LastBatchRunUpdater lastBatchRunUpdater;
	StepContribution stepContribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	LastBatchJobRunDao lastBatchJobRunDao;
	@Before
	public void init()
	{
		String fileName = "file:///MCI.AR.RABC.X.E1234567.D160812.T111135.C001";
		
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		
		jobParameter = new JobParameter(fileName, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);
		
		jobInstance = new JobInstance(new Long(123), "importRawRecords");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("loadRawRecords", jobExecution);
		
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		stepContribution = new StepContribution(stepExecution);
		
		lastBatchJobRunDao = EasyMock.createMock(LastBatchJobRunDao.class);
		lastBatchJobRunService = new LastBatchJobRunService(lastBatchJobRunDao);
		lastBatchRunUpdater = new LastBatchRunUpdater(lastBatchJobRunService);
		lastBatchRunUpdater.setJobInstanceName("abc");
	}
	@Test
	public void test() throws Exception {

		lastBatchRunUpdater.execute(stepContribution, chunkContext);

	}

}
