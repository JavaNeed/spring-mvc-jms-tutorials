package com.mastercard.ess.eds.test.batch.tasklet;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.config.FileStatus;
import com.mastercard.ess.eds.batch.tasklet.UpdateBillingStatusTasklet;
import com.mastercard.ess.eds.batch.tasklet.UpdateFileGenStatusTasklet;
import com.mastercard.ess.eds.core.service.LastBatchJobRunService;
import com.mastercard.ess.eds.domain.FileDetails;

public class UpdateBillingStatusTaskletTest {

    UpdateBillingStatusTasklet updateBillingStatusTasklet;
    private LastBatchJobRunService lastBatchJobRunService;
    private StepContribution stepContribution;
    private ChunkContext chunkContext;
    private StepExecution stepExecution;
    private StepContext stepContext;
    private JobParameters jobParameters;
    private JobExecution jobExecution;
    private JobInstance jobInstance;
    private ExecutionContext executionContext;

    private static Logger logger = Logger.getLogger(UpdateFileGenStatusTasklet.class);

    @Before
    public void init() {
        logger.setLevel(Level.DEBUG);
        lastBatchJobRunService = EasyMock.createMock(LastBatchJobRunService.class);
        jobInstance = new JobInstance(new Long(123), "updateBillingStatus");
        jobExecution = new JobExecution(jobInstance, jobParameters);
        stepExecution = new StepExecution("updateBillingStatus", jobExecution);
        stepContext = new StepContext(stepExecution);
        chunkContext = new ChunkContext(stepContext);
        stepContribution = new StepContribution(stepExecution);
        executionContext = new ExecutionContext();
    }

    private List<FileDetails> getFileStatusList(String billingMode) {

        List<FileDetails> fileStatusList = new ArrayList<>();
        if (billingMode.equalsIgnoreCase("FILE_GENERATION")) {
            FileDetails fileDetails = new FileDetails();
            fileDetails.setFileName("ABC");
            fileDetails.setStatus(FileStatus.GEN_FAILURE.getStatus());
            fileDetails.setErrorCode("12");
            fileDetails.setErrorDetails("123");
            fileStatusList.add(fileDetails);

            FileDetails fileDetails2 = new FileDetails();
            fileDetails2.setFileName("ABC");
            fileDetails2.setStatus(FileStatus.GEN_SUCCESS.getStatus());
            fileStatusList.add(fileDetails2);
        }

        FileDetails fileDetails1 = new FileDetails();
        fileDetails1.setFileName("CBC");
        fileDetails1.setStatus(FileStatus.GFT_FAILURE.getStatus());
        fileDetails1.setErrorCode("121");
        fileDetails1.setErrorDetails("1123");
        fileStatusList.add(fileDetails1);

        FileDetails fileDetails3 = new FileDetails();
        fileDetails3.setFileName("AB");
        fileDetails3.setStatus(FileStatus.GFT_SUCCESS.getStatus());
        fileStatusList.add(fileDetails3);
        return fileStatusList;

    }

    @Test(expected = Exception.class)
    public void testExecuteFileGenerationMode() throws Exception {

        executionContext.put("fileStatusList", getFileStatusList("FILE_GENERATION"));
        executionContext.put("billRunMode", "FILE_GENERATION");
        jobExecution.setExecutionContext(executionContext);
        updateBillingStatusTasklet = new UpdateBillingStatusTasklet();
        updateBillingStatusTasklet.getJobInstanceId();
        updateBillingStatusTasklet.getJobInstanceName();
        updateBillingStatusTasklet.setJobInstanceName("updateBillingStatusTasklet");
        updateBillingStatusTasklet.setJobInstanceId(new BigDecimal(10));
        updateBillingStatusTasklet.setLastBatchJobRunService(lastBatchJobRunService);
        updateBillingStatusTasklet.execute(stepContribution, chunkContext);
    }

    @Test(expected = Exception.class)
    public void testExecuteGFTFileMode() throws Exception {

        executionContext.put("fileStatusList", getFileStatusList("GFT_FAILURE"));
        executionContext.put("billRunMode", "GFT_FAILURE");
        jobExecution.setExecutionContext(executionContext);
        updateBillingStatusTasklet = new UpdateBillingStatusTasklet();
        updateBillingStatusTasklet.getJobInstanceId();
        updateBillingStatusTasklet.getJobInstanceName();
        updateBillingStatusTasklet.setJobInstanceName("updateBillingStatusTasklet");
        updateBillingStatusTasklet.setJobInstanceId(new BigDecimal(10));
        updateBillingStatusTasklet.setLastBatchJobRunService(lastBatchJobRunService);
        updateBillingStatusTasklet.execute(stepContribution, chunkContext);
    }
}
