package com.mastercard.ess.eds.test.batch.core.util;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.core.util.EDSProcessStatus;

public class EDSProcessStatusTest {
	
	String edsStatus;
	
	@Before
	public void init() {
		edsStatus = EDSProcessStatus.QUEUED.name();

	}
	
	@Test
	public void testEDSStatus() {
		assertEquals("QUEUED", edsStatus);
	}
	
	@Test
	public void testEDSStatusDesc() {
		assertEquals("Queued", EDSProcessStatus.QUEUED.getStatusDesc());
	}
	
	@Test
	public void testEDSStatusCode() {
		assertEquals(1, EDSProcessStatus.QUEUED.getStatusCode());
	}

}
