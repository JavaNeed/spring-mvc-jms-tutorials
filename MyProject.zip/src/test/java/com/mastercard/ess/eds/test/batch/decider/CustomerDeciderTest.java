package com.mastercard.ess.eds.test.batch.decider;

import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.decider.CustomerDecider;

public class CustomerDeciderTest {
    CustomerDecider customerDecider;
    JobExecution jobExecution;
    JobInstance jobInstance;
    StepContribution stepContribution;
    ChunkContext chunkContext;
    StepExecution stepExecutionStatus;
    StepContext stepContext;
    JobParameters jobParameters;
    JobParameter jobParameter;
    ExecutionContext executionContext;
    String customerRunMode;

    @Test
    public void testDecideGFT() throws Exception {
        customerDecider = new CustomerDecider();
        jobInstance = new JobInstance(new Long(123), "decide");
        customerRunMode = "GFT_FAILURE";
        Map<String, JobParameter> parameters = new LinkedHashMap<>();
        jobParameter = new JobParameter(customerRunMode, true);
        parameters.put("input.file", jobParameter);
        jobParameters = new JobParameters(parameters);
        jobExecution = new JobExecution(jobInstance, jobParameters);
        executionContext = new ExecutionContext();
        executionContext.put("customerRunMode", "GFT_FAILURE");
        jobExecution.setExecutionContext(executionContext);
        stepExecutionStatus = new StepExecution("customerDecider", jobExecution);
        stepContext = new StepContext(stepExecutionStatus);
        chunkContext = new ChunkContext(stepContext);
        stepContribution = new StepContribution(stepExecutionStatus);
        customerDecider.decide(jobExecution, stepExecutionStatus);

    }

    @Test
    public void testDecideFile() throws Exception {
        customerDecider = new CustomerDecider();
        jobInstance = new JobInstance(new Long(123), "decide");
        customerRunMode = "FILE_GENERATION";
        Map<String, JobParameter> parameters = new LinkedHashMap<>();
        jobParameter = new JobParameter(customerRunMode, true);
        parameters.put("input.file", jobParameter);
        jobParameters = new JobParameters(parameters);
        jobExecution = new JobExecution(jobInstance, jobParameters);
        executionContext = new ExecutionContext();
        executionContext.put("customerRunMode", "FILE_GENERATION");
        jobExecution.setExecutionContext(executionContext);
        stepExecutionStatus = new StepExecution("customerDecider", jobExecution);
        stepContext = new StepContext(stepExecutionStatus);
        chunkContext = new ChunkContext(stepContext);
        stepContribution = new StepContribution(stepExecutionStatus);
        customerDecider.decide(jobExecution, stepExecutionStatus);

    }
}
