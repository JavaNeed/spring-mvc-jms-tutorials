package com.mastercard.ess.eds.test.constant;

import static org.junit.Assert.assertNotNull;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.junit.Test;

import com.mastercard.ess.eds.constant.SQLQueries;


public class SQLQueriesTest {
	@Test
	public void testQueries(){
		
		Constructor<SQLQueries> constants = null;
		SQLQueries sQLQueries = null;
		try {
			constants = SQLQueries.class.getDeclaredConstructor();
			} catch (NoSuchMethodException | SecurityException ex) {
			}
		constants.setAccessible(true);
		try {
			sQLQueries = constants.newInstance();
		} catch (InstantiationException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException e) {
		}

		assertNotNull(sQLQueries);
	}
}
