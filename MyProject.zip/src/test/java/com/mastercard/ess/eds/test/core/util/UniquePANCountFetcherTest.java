package com.mastercard.ess.eds.test.core.util;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Test;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.batch.test.MetaDataInstanceFactory;
import org.springframework.test.util.ReflectionTestUtils;

import com.mastercard.ess.eds.batch.scheduler.CPPReportGenerationScheduler;
import com.mastercard.ess.eds.core.dao.UniquePANFetchDAO;
import com.mastercard.ess.eds.core.util.UniquePANCountFetcher;

public class UniquePANCountFetcherTest {
	UniquePANCountFetcher uniquePANCountFetcher;
	UniquePANFetchDAO uniquePANFetchDAO;
	CPPReportGenerationScheduler cppReportGenerationScheduler;
	final String zeroGroupJob = "getUniquePanCountWithTxnAmt.dxj";
	final String firstGroupJob = "getUniquePanCountWithoutTxnAmt.dxj";
	final String secondGroupJob = "getDistinctPansCount.dxj";
	final String jobDIR = "LTV";
	List<String> jobList;
	private static Logger logger = Logger.getLogger(UniquePANCountFetcher.class);
	
	@Test
	public void testExecute() {
		logger.setLevel(Level.DEBUG);
		StepExecution stepExecution = MetaDataInstanceFactory
				.createStepExecution();
		 jobList = new ArrayList<String>();
		 jobList.add(zeroGroupJob);
			jobList.add(firstGroupJob);
			jobList.add(secondGroupJob);
			uniquePANCountFetcher = EasyMock.createMock(UniquePANCountFetcher.class);
		
		EasyMock.expect(uniquePANCountFetcher.execute(new StepContribution(
				stepExecution),
				new ChunkContext(new StepContext(stepExecution)))).andReturn(RepeatStatus.FINISHED);
		EasyMock.replay(uniquePANCountFetcher);
		uniquePANCountFetcher = new UniquePANCountFetcher();
		uniquePANCountFetcher.setJobDIR("jobs");
		assertEquals(RepeatStatus.FINISHED, uniquePANCountFetcher.execute(new StepContribution(stepExecution),new ChunkContext(new StepContext(stepExecution))));
	}
	
	@Test
	public void beforeStep() {
		logger.setLevel(Level.DEBUG);
		uniquePANFetchDAO = EasyMock.createMock(UniquePANFetchDAO.class);
		uniquePANCountFetcher = new UniquePANCountFetcher(uniquePANFetchDAO);
		StepExecution stepExecution = MetaDataInstanceFactory
				.createStepExecution();
		uniquePANCountFetcher.beforeStep(stepExecution);
	}
	
	@Test
	public void afterStep() {
		logger.setLevel(Level.DEBUG);
		uniquePANFetchDAO = EasyMock.createMock(UniquePANFetchDAO.class);
		cppReportGenerationScheduler = EasyMock.createMock(CPPReportGenerationScheduler.class);
		uniquePANCountFetcher = new UniquePANCountFetcher(uniquePANFetchDAO, cppReportGenerationScheduler);
		StepExecution stepExecution = MetaDataInstanceFactory
				.createStepExecution();
		uniquePANCountFetcher.afterStep(stepExecution);
			}
	
	@Test
	public void testTruncateTable() {
		logger.setLevel(Level.DEBUG);
		uniquePANFetchDAO = EasyMock.createMock(UniquePANFetchDAO.class);
		uniquePANCountFetcher = new UniquePANCountFetcher(uniquePANFetchDAO);
		ReflectionTestUtils.invokeMethod(uniquePANCountFetcher, "truncateTempTable");
	}
}
