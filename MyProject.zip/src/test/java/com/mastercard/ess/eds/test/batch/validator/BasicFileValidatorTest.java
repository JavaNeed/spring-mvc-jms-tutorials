package com.mastercard.ess.eds.test.batch.validator;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.repeat.RepeatStatus;

import com.mastercard.ess.eds.batch.validator.BasicFileValidator;
import com.mastercard.ess.eds.core.dao.EDSSourceDao;
import com.mastercard.ess.eds.core.dao.EDSSourceTypeDao;
import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.core.service.EDSSourceService;
import com.mastercard.ess.eds.core.service.EDSSourceTypeService;
import com.mastercard.ess.eds.domain.EDSSourceType;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;

public class BasicFileValidatorTest {

	BasicFileValidator basicFileValidator;
	EDSSourceService edsSourceService;
	EDSSourceDao edsSourceDao;
	StepContribution stepContribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	EDSSourceTypeService edsSourceTypeService;
	NotificationEventVO notificationEventVO;
	EDSSourceTypeDao edsSourceTypeDao;
	EventPublisher eventPublisher;
	Logger logger;

	@Before
	public void init() {
		
		String fileName = "file:///DTF.AR.RABC.M.E0072345.D121117.T516377.Y008";
		
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		
		jobParameter = new JobParameter(fileName, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);
		
		jobInstance = new JobInstance(new Long(123), "importRawRecords");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("loadRawRecords", jobExecution);
		
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		
		basicFileValidator = new BasicFileValidator();
		edsSourceDao = EasyMock.createMock(EDSSourceDao.class);
		edsSourceService = new EDSSourceService(edsSourceDao);
		
		edsSourceTypeDao = EasyMock.createMock(EDSSourceTypeDao.class);
		edsSourceTypeService = new EDSSourceTypeService(edsSourceTypeDao);
		
		stepContribution = new StepContribution(stepExecution);
		
		logger = Logger.getLogger(BasicFileValidator.class);
		logger.setLevel(Level.DEBUG);
	}

	@Test
	public void testExecuteWithValidFile() {
		
		basicFileValidator = new BasicFileValidator("RABC",43,100000000,edsSourceService,edsSourceTypeService,new NotificationEventVO(), new EventPublisher());
		try {
			RepeatStatus repeatStatus = basicFileValidator.execute(stepContribution, chunkContext);
			assertEquals(RepeatStatus.FINISHED,repeatStatus);
		} catch (Exception ex) {
			logger.error(ex);
		}
	}
	
	@Test
	public void testExecuteWithInvalidBulkId() {
		basicFileValidator = new BasicFileValidator("RACB",43,100000000,edsSourceService,edsSourceTypeService,new NotificationEventVO(), new EventPublisher());
		try {
			basicFileValidator.execute(stepContribution, chunkContext);
			assertEquals("Invalid bulkId",basicFileValidator.getErrorDetails());
		} catch (Exception ex) {
			logger.error(ex);
		}
	}
	
	@Test
	public void testExecuteWithInvalidEndPoint() {
		basicFileValidator = new BasicFileValidator("RABC",43,100000000,edsSourceService,edsSourceTypeService,new NotificationEventVO(), new EventPublisher());
		try {
			basicFileValidator.execute(stepContribution, chunkContext);
			assertEquals("Invalid EndPoint",basicFileValidator.getErrorDetails());
		} catch (Exception ex) {
			logger.error(ex);
		}
	}
	
	@Test
	public void testExecuteWithInvalidFileLength() {
        
		String fileName = "file:///MC.AR.RABC.X.E1234567.D160812.T35.C001";
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		
		jobParameter = new JobParameter(fileName, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);
		
		jobInstance = new JobInstance(new Long(123), "importRawRecords");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("loadRawRecords", jobExecution);
		
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		
		basicFileValidator = new BasicFileValidator();
		edsSourceDao = EasyMock.createMock(EDSSourceDao.class);
		edsSourceService = new EDSSourceService(edsSourceDao);
		
		stepContribution = new StepContribution(stepExecution);
		edsSourceTypeService = EasyMock.createMock(EDSSourceTypeService.class);
		EasyMock.expect(edsSourceTypeService.getEDSSourceType("1234567.")).andReturn(new EDSSourceType());
		EasyMock.replay(edsSourceTypeService);
		basicFileValidator = new BasicFileValidator("RABC",43,100000000,edsSourceService,edsSourceTypeService,new NotificationEventVO(), new EventPublisher());
		try {
			basicFileValidator.execute(stepContribution, chunkContext);
			assertEquals("Invalid file name",basicFileValidator.getErrorDetails());
		} catch (Exception ex) {
			logger.error(ex);
		}
	}
	
	@Test
	public void testExecuteWithValidFilename() {
        
		String fileName = "file:///DTF.AR.RABC.M.E0072345.D121117.T516377";
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		
		jobParameter = new JobParameter(fileName, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);
		
		jobInstance = new JobInstance(new Long(123), "importRawRecords");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("loadRawRecords", jobExecution);
		
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		
		basicFileValidator = new BasicFileValidator();
		edsSourceDao = EasyMock.createMock(EDSSourceDao.class);
		edsSourceService = new EDSSourceService(edsSourceDao);
		
		stepContribution = new StepContribution(stepExecution);
		edsSourceTypeService = EasyMock.createMock(EDSSourceTypeService.class);
		EasyMock.expect(edsSourceTypeService.getEDSSourceType("E0072345")).andReturn(new EDSSourceType());
		EasyMock.replay(edsSourceTypeService);
		basicFileValidator = new BasicFileValidator("RABC",43,100000000,edsSourceService,edsSourceTypeService,new NotificationEventVO(), new EventPublisher());
		try {
			basicFileValidator.execute(stepContribution, chunkContext);
			
		} catch (Exception ex) {
			logger.error(ex);
		}
	}
	
	@Test
	public void testJobInstanceId() {
		basicFileValidator = new BasicFileValidator();
		basicFileValidator.setJobInstanceId(new BigDecimal(123));
	}

}
