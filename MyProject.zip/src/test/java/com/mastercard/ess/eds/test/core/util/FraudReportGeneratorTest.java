package com.mastercard.ess.eds.test.core.util;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.test.util.ReflectionTestUtils;
import com.mastercard.ess.eds.core.service.CustomerFileReportService;
import com.mastercard.ess.eds.core.util.FraudReportGenerator;
import com.mastercard.ess.eds.domain.FraudReportRecord;

public class FraudReportGeneratorTest {
	private static Logger logger = Logger.getLogger(FraudReportGeneratorTest.class);

	FraudReportGenerator fraudReportGenerator;
	FraudReportRecord fraudReportRecord;
	FraudReportRecord fraudReportRecord1;
	CustomerFileReportService customerFileReportService;
	List<FraudReportRecord> fraudReportList;

	Sheet sheet;
	Workbook workbook;
	Row row;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	BigDecimal jobInstanceId;
	String jobInstanceName;
	String fraudReportPath="..";
	
	@Before
	public void init() {
		logger.setLevel(Level.DEBUG);
		customerFileReportService = EasyMock
				.createMock(CustomerFileReportService.class);
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		jobParameter = new JobParameter(new Date());
		parameters.put("currentDateTime", jobParameter);
		jobParameters = new JobParameters(parameters);
		jobInstanceId = BigDecimal.valueOf(1);
		jobInstanceName = "FraudReportGenerator";
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("fraudRept", jobExecution);

		stepContext = new StepContext(stepExecution);
		FraudReportRecord fraudRept = new FraudReportRecord();
		fraudReportList = new ArrayList<FraudReportRecord>();
		fraudRept.setMonth("1");
		fraudRept.setSubscribedAfterCt(1);
		fraudRept.setSubscribedBeforeCt(0);
		fraudRept.setUnsubscribedAfterCt(2);
		fraudRept.setUnsubscribedBeforeCt(3);
		fraudReportList.add(fraudRept);
	}



	@Test
	public void testsubsribedcustomer() {
		fraudReportGenerator = new FraudReportGenerator();
		fraudReportGenerator.setCustomerFileReportService(customerFileReportService);
		fraudReportGenerator.setFraudReportPath(fraudReportPath);
		workbook = new XSSFWorkbook();
		sheet = workbook.createSheet("US");
		row = sheet.createRow(3);
		FraudReportRecord fraudRept = new FraudReportRecord();
		fraudReportList = new ArrayList<FraudReportRecord>();
		fraudRept.setMonth("1");
		fraudRept.setSubscribedAfterCt(1);
		fraudRept.setSubscribedBeforeCt(0);
		fraudRept.setUnsubscribedAfterCt(2);
		fraudRept.setUnsubscribedBeforeCt(3);
		fraudReportList.add(fraudRept);
		ReflectionTestUtils.invokeMethod(fraudReportGenerator,
				"mapObjectWithFraudReportRecord", fraudReportList, "August-17", "September-17",  new HashMap<Integer, Object[]>(),workbook);


	}

	@Test
	public void testWriteDataInSheet() {
		fraudReportGenerator = new FraudReportGenerator();
		workbook = new XSSFWorkbook();
		sheet = workbook.createSheet("US");
		row = sheet.createRow(3);
		ReflectionTestUtils.invokeMethod(fraudReportGenerator,
				"writeDataInSheet", workbook, sheet, 1, new HashMap<Integer, Object[]>());
	}

	@Test
	public void testName() {
		fraudReportGenerator = new FraudReportGenerator();
		fraudReportGenerator=new FraudReportGenerator(fraudReportPath, customerFileReportService);
		fraudReportGenerator.writeToFraudReport(fraudReportList, jobInstanceId, jobInstanceName);
		fraudReportGenerator.getFormattedDate(new Date(), "MM/DD/YYYY");

	}

	@Test
	public void testCreateCellValue() {
		fraudReportGenerator = new FraudReportGenerator();
		workbook = new XSSFWorkbook();
		sheet = workbook.createSheet("US");
		row = sheet.createRow(3);
		ReflectionTestUtils.invokeMethod(fraudReportGenerator,
				"createCellValue", workbook, row, new Object[] {
				"ICAs Type","17-August","17-July","June-17","May-17" }, 3);
		ReflectionTestUtils.invokeMethod(fraudReportGenerator,
				"createCellValue", workbook, row, new Object[] { null }, 3);
	}

	@After
	public void checkFileDeletion() {
		try {
			File[] dirFiles = new File(".").listFiles();
			// Search Through the list
			for (int i = 0; i < dirFiles.length; i++) { // If the Files start
				if (dirFiles[i].getName().startsWith("Fraud_Report_", 0) || dirFiles[i].getName().startsWith("..Fraud_Report_", 0))
					try {
						File file = new File(fraudReportPath+dirFiles[i].getName());

						if (file.delete()) {

						} else {
							File file1 = new File(dirFiles[i].getName());
							file1.delete();
						}

					} catch (Exception e) {
						e.printStackTrace();
					}
			}

		} catch (Exception e) {

			e.printStackTrace();

		}
	}

}


