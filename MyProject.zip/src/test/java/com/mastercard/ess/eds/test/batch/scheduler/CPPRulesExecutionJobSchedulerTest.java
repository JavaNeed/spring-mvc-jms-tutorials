package com.mastercard.ess.eds.test.batch.scheduler;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.mastercard.ess.eds.batch.scheduler.CPPRulesExecutionJobScheduler;

public class CPPRulesExecutionJobSchedulerTest {
	private Logger logger=Logger.getLogger(CPPRulesExecutionJobScheduler.class);
	private CPPRulesExecutionJobScheduler  jobScheduler;
	
	@Before
	public void setUp() throws Exception {
		logger.setLevel(Level.DEBUG);
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void test()throws Exception{
		jobScheduler=new CPPRulesExecutionJobScheduler();
		ReflectionTestUtils.invokeMethod(jobScheduler, "execute");
	}
}
