package com.mastercard.ess.eds.test.core.util;

import static org.junit.Assert.assertEquals;

import java.util.TreeMap;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.core.dao.CidDAO;
import com.mastercard.ess.eds.core.dao.DAAcctRangeDAO;
import com.mastercard.ess.eds.core.dao.PANAccountRangeDAO;
import com.mastercard.ess.eds.core.util.PANAccountRangeCache;
import com.mastercard.ess.eds.domain.CIDInfo;
import com.mastercard.ess.eds.domain.PANAccountRange;

public class PANAccountRangeCacheTest {
	
	private Logger logger = Logger.getLogger(PANAccountRangeCache.class);
	
	PANAccountRangeCache panAccountRangeCache ;
	
	PANAccountRangeDAO panAccountRangeDao;
	DAAcctRangeDAO daAcctRangeDAO;
	CidDAO cidDAO;
	String scheduleExpression;
	@Before
    public void setUp() throws Exception {
		panAccountRangeCache = new PANAccountRangeCache();
		
		panAccountRangeDao = EasyMock.createMock(PANAccountRangeDAO.class);
		daAcctRangeDAO = EasyMock.createMock(DAAcctRangeDAO.class);
		cidDAO = EasyMock.createMock(CidDAO.class);
		
		panAccountRangeCache.setPanAccountRangeDao(panAccountRangeDao);
		panAccountRangeCache.setDaAcctRangeDAO(daAcctRangeDAO);
		panAccountRangeCache.setCidDAO(cidDAO);
		panAccountRangeCache.getScheduleExpression();
		panAccountRangeCache.setScheduleExpression(scheduleExpression);
		
		
	}

	 	@Test
	    public void testGetCache(){
	 		logger.setLevel(Level.DEBUG);
	 		EasyMock.expect(panAccountRangeDao.getPANAccountRangeCache()).andReturn(new TreeMap<PANAccountRange, PANAccountRange>());
	 		EasyMock.replay(panAccountRangeDao);
	 		//assertEquals(new TreeMap<PANAccountRange, PANAccountRange>(),panAccountRangeCache.getCache());
	        
	    }
	 	
	 	@Test
	    public void testGetRtnCache(){
	 		logger.setLevel(Level.DEBUG);
	 		EasyMock.expect(daAcctRangeDAO.getRtnCache()).andReturn(new TreeMap<PANAccountRange, PANAccountRange>());
	 		EasyMock.replay(daAcctRangeDAO);
	 		//assertEquals(new TreeMap<PANAccountRange, PANAccountRange>(),panAccountRangeCache.getRtnCache());
	        
	    }
	 	
	 	@Test
	    public void testGetCidCache(){
	 		logger.setLevel(Level.DEBUG); 
	 		EasyMock.expect(cidDAO.getCidCache()).andReturn(new TreeMap<String, CIDInfo>());
	 		EasyMock.replay(cidDAO);
	 		//assertEquals(new TreeMap<String, CIDInfo>(),panAccountRangeCache.getCidCache());
	        
	    }
	 	
	 	@Test
	    public void testGetCacheINFO(){
	 		logger.setLevel(Level.INFO);
	 		EasyMock.expect(panAccountRangeDao.getPANAccountRangeCache()).andReturn(new TreeMap<PANAccountRange, PANAccountRange>());
	 		EasyMock.replay(panAccountRangeDao);
	 		//assertEquals(new TreeMap<PANAccountRange, PANAccountRange>(),panAccountRangeCache.getCache());
	        
	    }
	 	
	 	@Test
	    public void testGetRtnCacheINFO(){
	 		logger.setLevel(Level.INFO);
	 		EasyMock.expect(daAcctRangeDAO.getRtnCache()).andReturn(new TreeMap<PANAccountRange, PANAccountRange>());
	 		EasyMock.replay(daAcctRangeDAO);
	 		//assertEquals(new TreeMap<PANAccountRange, PANAccountRange>(),panAccountRangeCache.getRtnCache());
	        
	    }
	 	
	 	@Test
	    public void testGetCidCacheINFO(){
	 		logger.setLevel(Level.INFO); 
	 		EasyMock.expect(cidDAO.getCidCache()).andReturn(new TreeMap<String, CIDInfo>());
	 		EasyMock.replay(cidDAO);
	 		//assertEquals(new TreeMap<String, CIDInfo>(),panAccountRangeCache.getCidCache());
	        
	    }
	 	
	
}