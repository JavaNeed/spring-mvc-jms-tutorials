package com.mastercard.ess.eds.test.batch.tasklet;

import static org.junit.Assert.*;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;

import com.mastercard.ess.eds.batch.tasklet.ExecuteCPPRules;

public class ExecuteCPPRulesTest {
	ExecuteCPPRules executeCPPRules;
	final String cppRuleExecJob = "cppRuleExec.dxj";
	StepContribution stepContribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	ExecutionContext executionContext;
	private Logger logger = Logger.getLogger(ExecuteCPPRules.class);
	
	@Before
	public void init()
	{//
		logger.setLevel(Level.DEBUG);
		executionContext = EasyMock.createMock(ExecutionContext.class);
		jobInstance = new JobInstance(new Long(123), "executeCPPRules");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("executeCPPRules", jobExecution);
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		stepContribution = new StepContribution(stepExecution);
	}
	
	@Test
	public void test() throws Exception {
		logger.setLevel(Level.DEBUG);
		EasyMock.expect(executionContext.get("edsSrcId")).andReturn("edsSrcId");
		EasyMock.replay(executionContext);
		executeCPPRules = new ExecuteCPPRules();
		executeCPPRules.setRunCppRuleForDays("runCppRuleForDays");
		executeCPPRules.setExecutionContext(executionContext);
		executeCPPRules.getExecutionContext();
		executeCPPRules.setJobDIR("jobs");
		assertEquals(RepeatStatus.FINISHED,executeCPPRules.execute(stepContribution, chunkContext));
	}

}
