package com.mastercard.ess.eds.test.batch.tasklet;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.config.FileStatus;
import com.mastercard.ess.eds.batch.tasklet.UpdateFileGenStatusTasklet;
import com.mastercard.ess.eds.core.service.LastBatchJobRunService;
import com.mastercard.ess.eds.domain.ICAStatus;

public class UpdateFileGenStatusTaskletTest {
	private UpdateFileGenStatusTasklet updateFileGenStatusTasklet ;
	private LastBatchJobRunService lastBatchJobRunService;
	private StepContribution stepContribution;
	private ChunkContext chunkContext;
	private StepExecution stepExecution;
	private StepContext stepContext;
	private JobParameters jobParameters;
	private JobExecution jobExecution;
	private JobInstance jobInstance;
	private ExecutionContext executionContext;
	
	private Logger logger = Logger.getLogger(UpdateFileGenStatusTaskletTest.class);

	@Before
	public void init() {
		logger.setLevel(Level.DEBUG);
		lastBatchJobRunService = EasyMock.createMock(LastBatchJobRunService.class);
		jobInstance = new JobInstance(new Long(123), "updateFileGenStatusExecutionStatus");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("updateFileGenStatusExecutionStatus", jobExecution);
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		stepContribution = new StepContribution(stepExecution);
		executionContext=new ExecutionContext();
	}

	private List<ICAStatus>  getICAStatusList(String customerMode) {
		List<ICAStatus> icaStatusList = new ArrayList<>();
		if(customerMode.equalsIgnoreCase("FILE_GENERATION")){
			ICAStatus icaStatus = new ICAStatus();
			icaStatus.setIca("11");
			icaStatus.setFileName("ABC");
			icaStatus.setStatus(FileStatus.GEN_FAILURE.getStatus());
			icaStatus.setErrorCode("12");
			icaStatus.setErrorDetails("123");
			
			icaStatusList.add(icaStatus);
			ICAStatus icaStatus2 = new ICAStatus();
			icaStatus2.setIca("21");
			icaStatus2.setFileName("ABC");
			icaStatus2.setStatus(FileStatus.GEN_SUCCESS.getStatus());
			icaStatusList.add(icaStatus2);
		}
		ICAStatus icaStatus1 = new ICAStatus();
		icaStatus1.setIca("12");
		icaStatus1.setFileName("CBC");
		icaStatus1.setStatus(FileStatus.GFT_FAILURE.getStatus());
		icaStatus1.setErrorCode("121");
		icaStatus1.setErrorDetails("1123");
		icaStatusList.add(icaStatus1);
		
		ICAStatus icaStatus3 = new ICAStatus();
		icaStatus3.setIca("114");
		icaStatus3.setFileName("AB");
		icaStatus3.setStatus(FileStatus.GFT_SUCCESS.getStatus());
		icaStatusList.add(icaStatus3);
		
		
		return icaStatusList;
	}

	@Test(expected=Exception.class)
	public void testExecuteFileGenerationMode() throws Exception {
	
		executionContext.put("icaStatusList" , getICAStatusList("FILE_GENERATION"));
		executionContext.put("customerRunMode", "FILE_GENERATION");
		jobExecution.setExecutionContext(executionContext);
		updateFileGenStatusTasklet = new UpdateFileGenStatusTasklet();
		updateFileGenStatusTasklet.setJobInstanceName("updateCPPRulesExecutionStatus");
		updateFileGenStatusTasklet.setJobInstanceId(new BigDecimal(10));
		updateFileGenStatusTasklet.setLastBatchJobRunService(lastBatchJobRunService);
		updateFileGenStatusTasklet.execute(stepContribution, chunkContext);
	}
	
	@Test(expected=Exception.class)
	public void testExecuteGFTFileMode() throws Exception {
		executionContext.put("icaStatusList" , getICAStatusList("GFT_FAILURE"));
		executionContext.put("customerRunMode", "GFT_FAILURE");
		jobExecution.setExecutionContext(executionContext);
		updateFileGenStatusTasklet = new UpdateFileGenStatusTasklet();
		updateFileGenStatusTasklet.setJobInstanceName("updateCPPRulesExecutionStatus");
		updateFileGenStatusTasklet.setJobInstanceId(new BigDecimal(10));
		updateFileGenStatusTasklet.setLastBatchJobRunService(lastBatchJobRunService);
		updateFileGenStatusTasklet.execute(stepContribution, chunkContext);
	}

}
