package com.mastercard.ess.eds.test.batch.processor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.easyrules.core.BasicRule;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.StepContext;

import com.mastercard.ess.eds.batch.processor.RiskRecordItemProcessor;
import com.mastercard.ess.eds.core.rule.FileGenerationCustomRules;
import com.mastercard.ess.eds.core.rule.FileGenerationRules;
import com.mastercard.ess.eds.core.util.FileGenerationRulesCache;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.ProcessedRecord;

public class RiskRecordItemProcessorTest {
	private EDSRecord edsRecord;
	private ProcessedRecord procRecord;
	FileGenerationRulesCache fileGenerationRulesCache;
	RiskRecordItemProcessor riskRecordItemProcessor;
	List<BasicRule> fileGenerationRuleList;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	FileGenerationRules fileGenerationRules;
	FileGenerationCustomRules fileGenerationCustomRules;
	private Logger logger;
	
	@Before
	public void setUp() 
	{
		String date = "2000-11-01 00:00:00";
		java.sql.Timestamp javaSqlDate = java.sql.Timestamp.valueOf(date); 
		procRecord = new ProcessedRecord();
		procRecord.setIsAccountADCNotified("N");
		procRecord.setAccountValid(true);
		procRecord.setBin("");
		procRecord.setConfidenceScore(-1);
		procRecord.setDaysSinceLastActivity(150);
		procRecord.setIca("");
		procRecord.setIsAccountActive("Y");
		procRecord.setIsFraudReported("N");
		procRecord.setLastUpdatedDate(javaSqlDate);
		procRecord.setLastUpdatedUser("");
		procRecord.setPan(new BigDecimal("625421221662123727"));
		procRecord.setPriceCategory(0);
		procRecord.setProcRawRecordKey(new BigDecimal("1"));
		procRecord.setProcRecordKey(new BigDecimal("1"));
		procRecord.setIsFraudReported("N");
		procRecord.setIsDuplicate("N");
		procRecord.setToBeSentFlag("Y");
		edsRecord = new EDSRecord();
		edsRecord.setProcRecord(procRecord);
		edsRecord = new EDSRecord();
		edsRecord.setProcRecord(procRecord);
		fileGenerationRulesCache = EasyMock.createMock(FileGenerationRulesCache.class);
		fileGenerationRuleList = new ArrayList<BasicRule>();
		fileGenerationRules = new FileGenerationRules();
		fileGenerationRules.setIsAccountActiveFlag("Y");
		fileGenerationRules.setIsFraudReportedFlag("N");
		fileGenerationRules.setIsADCNotifiedFlag("N");
		fileGenerationRules.setIsAlreadyReportedFlag("N");
		fileGenerationRules.setIsDuplicateFlag("N");
		fileGenerationRules.setInputToRule(procRecord);
		fileGenerationCustomRules = new FileGenerationCustomRules();
		fileGenerationCustomRules.setIsAccountActiveFlag("Y");
		fileGenerationCustomRules.setInputToRule(procRecord);
		fileGenerationRuleList.add(fileGenerationRules);
		fileGenerationRuleList.add(fileGenerationCustomRules);
		EasyMock.expect(fileGenerationRulesCache.getCache()).andReturn(fileGenerationRuleList);
		EasyMock.replay(fileGenerationRulesCache);
		riskRecordItemProcessor = new RiskRecordItemProcessor(fileGenerationRulesCache);
		logger = Logger.getLogger(RiskRecordItemProcessor.class);
		logger.setLevel(Level.DEBUG);
		
	}
	@Test
	public void test() {
		riskRecordItemProcessor.process(edsRecord);
		riskRecordItemProcessor.beforeStep(null);
		riskRecordItemProcessor.setJobInstanceName("");
		riskRecordItemProcessor.getStepExecution();
		
	}
	@Test
	public void test1()
	{
		
		procRecord.setIsFiltered("N");
		riskRecordItemProcessor.process(edsRecord);
	}
	@Test
	public void test2() {
		String fileName = "file:///MCI.AR.RABC.X.E1234567.D160812.T111135.C001";
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		jobParameter = new JobParameter(fileName, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);
		jobInstance = new JobInstance(new Long(123), "importRawRecords");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("loadRawRecords", jobExecution);
		stepExecution.setExitStatus(ExitStatus.COMPLETED);
		riskRecordItemProcessor = new RiskRecordItemProcessor(fileGenerationRulesCache);
		riskRecordItemProcessor.afterStep(stepExecution);		
	}

	
}
