package com.mastercard.ess.eds.test.core.util;

import static org.junit.Assert.assertEquals;
import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.repeat.RepeatStatus;

import com.mastercard.ess.eds.core.dao.EDSSourceTypeDao;
import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.core.util.EmailFraudReportTasklet;
import com.mastercard.ess.eds.domain.EDSSourceType;

public class EmailFraudReportTaskletTest {

	EventPublisher eventPublisher;
	EmailFraudReportTasklet emailFraudReportTasklet;
	StepContribution stepContribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	Logger logger;
	EDSSourceType EDSSourceType;
	EDSSourceTypeDao edsSourceTypeDao;
	String fraudReportPath = "..FraudDetailReport_";

	@Before
	public void setUp()
	{
		logger = Logger.getLogger(EmailFraudReportTaskletTest.class);
		logger.setLevel(Level.DEBUG);
		String fileName = "file:///MCI.AR.RABC.X.E1234567.D160812.T111135.C001";

		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();

		jobParameter = new JobParameter(fileName, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);

		jobInstance = new JobInstance(new Long(123), "fraudReportFile");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("fraudReportFile", jobExecution);

		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		stepContribution = new StepContribution(stepExecution);

		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("tb", "");
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("tb_path", "_mastercard.xlsx");
		edsSourceTypeDao = EasyMock.createMock(EDSSourceTypeDao.class);
	}

	@Test
	public void test() throws Exception {
		emailFraudReportTasklet = new EmailFraudReportTasklet(edsSourceTypeDao);
		emailFraudReportTasklet.setFraudReportPath(fraudReportPath);
		assertEquals(RepeatStatus.FINISHED,emailFraudReportTasklet.execute(stepContribution,chunkContext));
	}

}
