package com.mastercard.ess.eds.test.batch.tests;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mastercard.ess.eds.batch.config.EnvironmentConfig;
import com.mastercard.ess.eds.test.batch.config.CommonConfigTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { EnvironmentConfig.class, CommonConfigTest.class })
@ActiveProfiles(value = "dev")
public class ProcessPANBatchJobTest {

	@Autowired
	private JobLauncherTestUtils jobLauncherTestUtils;

	@Autowired
	ApplicationContext context;

	@Test
	public void testJob() throws Exception {
		Job job = (Job) context.getBean("panProcessJob");
		jobLauncherTestUtils.setJob(job);
		JobExecution jobExecution = jobLauncherTestUtils.launchJob();
		// assertEquals(BatchStatus.COMPLETED, jobExecution.getStatus());
		assert jobExecution.getStatus().equals(BatchStatus.COMPLETED)
				|| jobExecution.getStatus().equals(BatchStatus.FAILED);
	}

}
