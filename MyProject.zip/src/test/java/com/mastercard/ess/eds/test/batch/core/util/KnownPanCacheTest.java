package com.mastercard.ess.eds.test.batch.core.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.junit.Test;

import com.mastercard.ess.eds.core.util.KnownPanCache;
import com.mastercard.ess.eds.core.util.PanResultHolder;

public class KnownPanCacheTest {
	KnownPanCache knownPanCache;
	String pan;
	String result;

	@Test
	public void testInsert() {
		knownPanCache=new KnownPanCache();
		Map<String, String> cache = new ConcurrentHashMap<String, String>();
			cache.put("123", "true");
		knownPanCache.insert("123", "true");
		knownPanCache.getResult("123");
	}
	@Test
	public void testInsert1() {
		knownPanCache=new KnownPanCache();
		Map<String, String> cache = new ConcurrentHashMap<String, String>();
		cache.put("123", "true");
		knownPanCache.insert(pan,result);
	}

	@Test
	public void testBulkInsert() {
		knownPanCache=new KnownPanCache();
		List<PanResultHolder> pans=new ArrayList<PanResultHolder>();
		PanResultHolder panResultHolder=new PanResultHolder();
		panResultHolder.setPan("146");
		panResultHolder.setResult("result");
		pans.add(panResultHolder);
		knownPanCache.bulkInsert(pans);
		
	}

}
