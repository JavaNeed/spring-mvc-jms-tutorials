package com.mastercard.ess.eds.test.batch.tasklet;

import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;

import com.mastercard.ess.eds.core.util.FileDeletingTasklet;

public class FileDeletingTaskletTest {

	private FileDeletingTasklet fileDeletingTasklet;
	private String archiveDirectory;
	private String deleteDirectory;
	private StepContribution contribution;
	private ChunkContext chunkContext;
	private JobParameters jobParameters;
	private	JobParameter jobParameter;
	private	StepExecution stepExecution;
	private	StepContext stepContext;
	private JobExecution jobExecution;
	private	JobInstance jobInstance;
	 
	 @Before
		public void init() {
			
		String fileName ="test/test.txt";
		
			Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
			jobParameter = new JobParameter(fileName, true);
			parameters.put("input.file", jobParameter);
			jobParameters = new JobParameters(parameters);
			jobInstance = new JobInstance(new Long(123), "importRawRecords");
			jobExecution = new JobExecution(jobInstance, jobParameters);
			stepExecution = new StepExecution("loadRawRecords", jobExecution);
			stepContext = new StepContext(stepExecution);
			chunkContext = new ChunkContext(stepContext);
			contribution=new StepContribution(stepExecution);
			fileDeletingTasklet=new FileDeletingTasklet();
			
		
			
	 }

	 @Test
	 public void executetest() throws Exception
	 {
		 archiveDirectory = "/";
		 deleteDirectory = "/";
		 fileDeletingTasklet.setArchiveDirectory(archiveDirectory);
		 fileDeletingTasklet.setDeleteDirectory(deleteDirectory);
		 fileDeletingTasklet.afterPropertiesSet();
		 fileDeletingTasklet.execute(contribution, chunkContext);
	 }

}
