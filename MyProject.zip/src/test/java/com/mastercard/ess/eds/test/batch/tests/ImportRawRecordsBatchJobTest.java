package com.mastercard.ess.eds.test.batch.tests;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mastercard.ess.eds.batch.config.EnvironmentConfig;
import com.mastercard.ess.eds.test.batch.config.CommonConfigTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { EnvironmentConfig.class, CommonConfigTest.class })
@ActiveProfiles("dev")

public class ImportRawRecordsBatchJobTest {

	@Autowired
	private JobLauncherTestUtils jobLauncherTestUtils;

	@Autowired
	ApplicationContext context;

	@Test
	public void testLaunchJob() throws Exception {

		JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
		jobParametersBuilder.addString("input.file", "classpath:MCI.AR.RABC.X.E1234567.D160812.T111135.C066");
		JobParameters jobParameters = jobParametersBuilder.toJobParameters();
		Job job = (Job) context.getBean("importRawRecords");
		jobLauncherTestUtils.setJob(job);
		JobExecution jobExecution = jobLauncherTestUtils.launchJob(jobParameters);
		assertEquals(BatchStatus.COMPLETED, jobExecution.getStatus());

	}

}
