package com.mastercard.ess.eds.test.batch.mapper;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.validation.BindException;

import com.mastercard.ess.eds.batch.mapper.RawRecordFieldSetMapper;
import com.mastercard.ess.eds.core.parser.VendorPayloadTokens;
import com.mastercard.ess.eds.core.util.EDSProcessStatus;
import com.mastercard.ess.eds.domain.RawRecord;

public class RawRecordFieldSetMapperTest {

	RawRecordFieldSetMapper rawRecordFieldSetMapper;
	FieldSet fieldSet;
	RawRecord rawRecordExpected;
	Logger logger;
	ExecutionContext executionContext;
	String endPointReceived;
	private static final String TERBIUM_ENDPOINT = "E0072345";
	private static final String FOXIT_ENDPOINT = "E1234567";

	@Before
	public void init() {
		logger = Logger.getLogger(RawRecordFieldSetMapper.class);
		executionContext = new ExecutionContext();
		rawRecordFieldSetMapper = new RawRecordFieldSetMapper();
		fieldSet = EasyMock.createMock(FieldSet.class);
		rawRecordExpected = new RawRecord(new HashMap<String,String>());
		rawRecordExpected.addPayloadEntry(VendorPayloadTokens.CWID.getDesc(), "5e27a1ef1904933f40d9d8a1a82c8a02");
		rawRecordExpected.addPayloadEntry(VendorPayloadTokens.URL.getDesc(), "http://cardertools.su");
		rawRecordExpected.addPayloadEntry(VendorPayloadTokens.RAW_DATA.getDesc(), "(Email)");
		rawRecordExpected.setRawPan("5194950303591144");
		rawRecordExpected.setStatus(EDSProcessStatus.UNPROCESSED.getStatusCode());
		rawRecordExpected.setLastUpdateDate(new Date());
		
	}

	@Test
	public void mapFieldSetTestForTerbium(){
		
		logger.setLevel(Level.DEBUG);
		endPointReceived = TERBIUM_ENDPOINT;
		Resource resource = new ClassPathResource( endPointReceived + ".properties");
		Properties propertyFile = null;
		try {
			propertyFile = PropertiesLoaderUtils.loadProperties(resource );
		} catch (IOException e) {
			e.printStackTrace();
		}
		executionContext.put("vendorProperties", propertyFile);
		rawRecordFieldSetMapper.setExecutionContext(executionContext);
		EasyMock.expect(fieldSet.readString("cwid")).andReturn("5e27a1ef1904933f40d9d8a1a82c8a02");
		EasyMock.expect(fieldSet.readString("url")).andReturn("http://cardertools.su");
		EasyMock.expect(fieldSet.readString("value")).andReturn("5194950303591144::(Email)");
		EasyMock.expect(fieldSet.readString("iv")).andReturn("JpYj2eK9tz2nqYMNlr2Uww==");
		EasyMock.replay(fieldSet);
		
		try{
			RawRecord rawRecordActual = rawRecordFieldSetMapper.mapFieldSet(fieldSet);
			assertEquals(rawRecordExpected.getPayloadValue(VendorPayloadTokens.CWID.getDesc()),rawRecordActual.getPayloadValue(VendorPayloadTokens.CWID.getDesc()));
			assertEquals(rawRecordExpected.getPayloadValue(VendorPayloadTokens.URL.getDesc()),rawRecordActual.getPayloadValue(VendorPayloadTokens.URL.getDesc()));
			//assertEquals(rawRecordExpected.getRawPan(),rawRecordActual.getRawPan());
			//assertEquals(rawRecordExpected.getPayloadValue(VendorPayloadTokens.RAW_DATA.getDesc()),rawRecordActual.getPayloadValue(VendorPayloadTokens.RAW_DATA.getDesc()));
			//assertEquals(rawRecordExpected.getStatus(),rawRecordActual.getStatus());
			
			
		    
		}catch(BindException bindException){
			
		}
		
	}
	
	@Test
	public void testJobInstance() {
		rawRecordFieldSetMapper = new RawRecordFieldSetMapper();
		rawRecordFieldSetMapper.setJobInstanceName("rawRecord");
		assertEquals("rawRecord", rawRecordFieldSetMapper.getJobInstanceName());
	}
	
	@Test
	public void testExecutionContext() {
		rawRecordFieldSetMapper = new RawRecordFieldSetMapper();
		rawRecordFieldSetMapper.setExecutionContext(executionContext);
		assertEquals(executionContext, rawRecordFieldSetMapper.getExecutionContext());
	}
	
	
}
