package com.mastercard.ess.eds.test.batch.tasklet;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.tasklet.TruncateCPPSimulationDataTasklet;
import com.mastercard.ess.eds.core.service.CPPSimulationService;
import com.mastercard.ess.eds.core.service.RawRecordDBWriterService;

public class TruncateCPPSimulationDataTaskletTest {
	TruncateCPPSimulationDataTasklet truncateCPPSimulationDataTasklet;	
	CPPSimulationService cppSimulationService;
	RawRecordDBWriterService rawRecordDBWriterService;
	String cppRunMode;
	StepContribution stepContribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobExecution jobExecution;
	JobInstance jobInstance;
	ExecutionContext executionContext;
	Logger logger = Logger.getLogger(TruncateCPPSimulationDataTaskletTest.class);

	@Before
	public void setUp() throws Exception {
		logger.setLevel(Level.DEBUG);
		cppRunMode="SIMULATION";
		truncateCPPSimulationDataTasklet=new TruncateCPPSimulationDataTasklet();
		cppSimulationService=new CPPSimulationService();
		cppSimulationService=EasyMock.createMock(CPPSimulationService.class);
		rawRecordDBWriterService=new RawRecordDBWriterService();
		rawRecordDBWriterService=EasyMock.createMock(RawRecordDBWriterService.class);
		jobParameters = new JobParameters();
		jobInstance = new JobInstance(new Long(123), "cppsimulationData");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		executionContext=new ExecutionContext();
		jobExecution.setExecutionContext(executionContext);
		executionContext.put("cppRunMode", "SIMULATION");
		stepExecution = new StepExecution("cppsimulationData", jobExecution);
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		stepContribution = new StepContribution(stepExecution);
		truncateCPPSimulationDataTasklet.setCppSimulationService(cppSimulationService);	
		truncateCPPSimulationDataTasklet.setCppRunMode(cppRunMode);
		truncateCPPSimulationDataTasklet.getCppRunMode();
		truncateCPPSimulationDataTasklet.setRawRecordDBWriterService(rawRecordDBWriterService);
	}

	@Test
	public void testExecute() throws Exception {

		truncateCPPSimulationDataTasklet.execute(stepContribution, chunkContext);
	}


}
