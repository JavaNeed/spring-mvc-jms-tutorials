package com.mastercard.ess.eds.test.core.service;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.core.dao.EDSSourceDataDAO;
import com.mastercard.ess.eds.core.dao.EDSSourceRuleDAO;
import com.mastercard.ess.eds.core.service.CPPRuleRecordService;
import com.mastercard.ess.eds.domain.AuthDebitPanDetailRecord;
import com.mastercard.ess.eds.domain.CPPRuleRecord;

public class CPPRuleRecordServiceTest {
	
	Logger logger = Logger.getLogger(CPPRuleRecordServiceTest.class);

	
	private EDSSourceDataDAO edsSourceDataDAO;
	private EDSSourceRuleDAO edsSourceRuleDAO;
	CPPRuleRecord cPPRules = new CPPRuleRecord();

	List<Integer> cppRuleIds=new ArrayList<>();
	CPPRuleRecord cppRuleRcrd ;;
	List<AuthDebitPanDetailRecord> authDebitPanDetailRecords=new ArrayList<>();
	AuthDebitPanDetailRecord authPanDetailRecord=new AuthDebitPanDetailRecord();
	AuthDebitPanDetailRecord debitPanDetailRecord=new AuthDebitPanDetailRecord();
	CPPRuleRecordService cPPRuleRecordService;

	@Before
	public void init() {
		logger.setLevel(Level.DEBUG);

		cppRuleIds.add(1);
		cppRuleIds.add(2);
		cppRuleIds.add(3);
		cppRuleIds.add(4);
		cppRuleIds.add(5);


		cppRuleRcrd=new CPPRuleRecord();
		cppRuleRcrd.setActiveSW("Y");
		cppRuleRcrd.setCatCD("E");
		cppRuleRcrd.setClsIssrCntry("ONEOF");
		cppRuleRcrd.setClsLocTranAmt("EQUALS");
		cppRuleRcrd.setClsMerchant("EQUALS");
		cppRuleRcrd.setCreateDate(new Date(2017, 01, 10));
		cppRuleRcrd.setCreatedBy(null);
		cppRuleRcrd.setFirstRunSW("Y");
		cppRuleRcrd.setLastUpdateDate(new Date(2017, 01, 10));
		cppRuleRcrd.setLastUpdatedBy(null);
		cppRuleRcrd.setUnitTmCount("WEEKS");
		cppRuleRcrd.setValIssrCntry("USA");
		cppRuleRcrd.setValLocTranAmt(new BigDecimal(100));
		cppRuleRcrd.setValMerchant(0);
		cppRuleRcrd.setValTmCount(90);
		cppRuleRcrd.setCppRuleId(new BigDecimal(100));

		authPanDetailRecord.setCppRuleId(new BigDecimal(1));
		authPanDetailRecord.setdWSource("auth");
		authPanDetailRecord.setRawPan("1010101");


		debitPanDetailRecord.setCppRuleId(new BigDecimal(1));
		debitPanDetailRecord.setdWSource("debit");
		debitPanDetailRecord.setRawPan("1010101");
		authDebitPanDetailRecords.add(authPanDetailRecord);
		
		edsSourceDataDAO = EasyMock.createMock(EDSSourceDataDAO.class);
		edsSourceRuleDAO = EasyMock.createMock(EDSSourceRuleDAO.class);
		cPPRuleRecordService=EasyMock.createMock(CPPRuleRecordService.class);
		
		cPPRuleRecordService = new CPPRuleRecordService(edsSourceDataDAO, edsSourceRuleDAO);

		
	}


	@Test
	public void testSaveRecord() throws Exception {
		logger.setLevel(Level.DEBUG);
		EasyMock.expect(edsSourceDataDAO.saveSourceData(authPanDetailRecord, "CPPRuleRecord", "1", new BigDecimal(1))).andReturn(1);
		EasyMock.replay(edsSourceDataDAO);
		ConcurrentHashMap<String, Set> panRuleMap = new ConcurrentHashMap<String, Set>();
		Set ruleSet = new LinkedHashSet<BigDecimal>();
		ruleSet.add(null);
		ruleSet.add(new BigDecimal(123));
		panRuleMap.put("1010101", ruleSet);
		cPPRuleRecordService.saveRecord(authDebitPanDetailRecords, "CPPRuleRecord", "1",  new BigDecimal(1), panRuleMap);
		assertEquals(panRuleMap.get("1010101").contains(new BigDecimal(1)), true);
	}
	
	@Test
	public void testSaveRuleMapForDupe() throws Exception {
		logger.setLevel(Level.DEBUG);
		ConcurrentHashMap<String, Set> panRuleMap = new ConcurrentHashMap<String, Set>();
		Set ruleSet = new LinkedHashSet<BigDecimal>();
		ruleSet.add(new BigDecimal(1));
		ruleSet.add(new BigDecimal(123));
		ruleSet.add(new BigDecimal(345));
		panRuleMap.put("1010101", ruleSet);
		cPPRuleRecordService.saveRuleMap(panRuleMap, "1", null);
		//assertEquals(panRuleMap.get("1010101").toString(),"1,123");
	}


}
