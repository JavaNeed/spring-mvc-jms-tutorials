package com.mastercard.ess.eds.test.core.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.dao.DerivedExternalDao;
import com.mastercard.ess.eds.core.dao.EDSCPPRulesDao;
import com.mastercard.ess.eds.core.service.DerivedExternalService;
import com.mastercard.ess.eds.core.util.CPPRuleIdHolder;
import com.mastercard.ess.eds.core.util.EDSSourceRuleDataCache;
import com.mastercard.ess.eds.core.util.RuleCatCdRecord;
import com.mastercard.ess.eds.domain.ProcessedRecord;

public class DerivedExternalServiceTest {
	private DerivedExternalService derivedExternalService;
	private DerivedExternalDao derivedExternalDao;
	private EDSCPPRulesDao eDSCPPRulesDao;
	private EDSSourceRuleDataCache eDSSourceRuleDataCache;
	private ProcessedRecord processedRecord;
	private Logger logger = Logger.getLogger(DerivedExternalService.class);
	
	@Before
	public void setUp() throws Exception {
		processedRecord = new ProcessedRecord();
		derivedExternalDao = EasyMock.createMock(DerivedExternalDao.class);
		eDSCPPRulesDao = EasyMock.createMock(EDSCPPRulesDao.class);
		eDSSourceRuleDataCache = EasyMock.createMock(EDSSourceRuleDataCache.class);
		derivedExternalService = new DerivedExternalService(derivedExternalDao,eDSCPPRulesDao,eDSSourceRuleDataCache);
		List<CPPRuleIdHolder> srcRuleData = new ArrayList<CPPRuleIdHolder>();
		eDSSourceRuleDataCache.bulkInsert(srcRuleData );
	}

	@Test
	public void test() {
		logger.setLevel(Level.DEBUG);
		RuleCatCdRecord ruleCatCdRecord = new RuleCatCdRecord(new Long(123), "I");
		EasyMock.expect(eDSSourceRuleDataCache.getResult(new Long(123))).andReturn(ruleCatCdRecord);
		EasyMock.replay(eDSSourceRuleDataCache);
		derivedExternalService.updateExternalDerivedForPricingCategory(BigDecimal.valueOf(123), processedRecord);
		
	}

}
