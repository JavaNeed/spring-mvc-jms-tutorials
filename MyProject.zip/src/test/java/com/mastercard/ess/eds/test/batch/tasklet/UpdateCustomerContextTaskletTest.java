package com.mastercard.ess.eds.test.batch.tasklet;

import static org.junit.Assert.fail;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.tasklet.UpdateCustomerContextTasklet;
import com.mastercard.ess.eds.core.service.LastBatchJobRunService;

public class UpdateCustomerContextTaskletTest {

	private UpdateCustomerContextTasklet updateCustomerContextTasklet ;
	private StepContribution stepContribution;
	private ChunkContext chunkContext;
	private StepExecution stepExecution;
	private StepContext stepContext;
	private JobParameters jobParameters;
	private JobExecution jobExecution;
	private JobInstance jobInstance;
	private ExecutionContext executionContext;
	
	private Logger logger = Logger.getLogger(UpdateCustomerContextTasklet.class);
	
	@Before
	public void setUp() throws Exception {
		
		logger.setLevel(Level.DEBUG);
		jobInstance = new JobInstance(new Long(123), "updateCustomerContextTasklet");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("updateFileGenStatusExecutionStatus", jobExecution);
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		stepContribution = new StepContribution(stepExecution);
		executionContext=new ExecutionContext();
		updateCustomerContextTasklet = new UpdateCustomerContextTasklet();
	}

	@Test
	public void testExecute() {
		jobExecution.setExecutionContext(executionContext);
		updateCustomerContextTasklet.setExecutionContext(executionContext);
		updateCustomerContextTasklet.setCustomerRunMode("FILE_GENERATION");
		updateCustomerContextTasklet.execute(stepContribution, chunkContext);
		
	}

}
