package com.mastercard.ess.eds.test.batch.tasklet;

import static org.junit.Assert.assertEquals;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.repeat.RepeatStatus;

import com.mastercard.ess.eds.batch.tasklet.UpdateDistinctPANCountTasklet;
import com.mastercard.ess.eds.core.dao.UniquePANFetchDAO;

public class UpdateDistinctPANCountTaskletTest {
	UpdateDistinctPANCountTasklet updateDistinctPANCountTasklet;
	UniquePANFetchDAO uniquePANFetchDAO;
	StepContribution contribution;
	ChunkContext chunkContext;
	 StepExecution stepExecution;
	 StepContext stepContext;
		JobParameters jobParameters;
		JobParameter jobParameter;
		JobExecution jobExecution;
		JobInstance jobInstance;
		Logger logger = Logger.getLogger(UpdateDistinctPANCountTaskletTest.class);
		
	 @Before
	public void init() {
				logger.setLevel(Level.DEBUG);
				updateDistinctPANCountTasklet = new UpdateDistinctPANCountTasklet();
				jobInstance = new JobInstance(new Long(123),"updateDistinctPANCountTasklet");
				jobExecution = new JobExecution(jobInstance, jobParameters);
				stepExecution = new StepExecution("updateDistinctPANCountTasklet",jobExecution);
				stepContext = new StepContext(stepExecution);
				chunkContext = new ChunkContext(stepContext);
				contribution = new StepContribution(stepExecution);
				uniquePANFetchDAO = EasyMock.createMock(UniquePANFetchDAO.class);
	 }
	 
	 @Test
	 public void executeTest()throws Exception{
			uniquePANFetchDAO = EasyMock.createMock(UniquePANFetchDAO.class);
			updateDistinctPANCountTasklet = new UpdateDistinctPANCountTasklet();
			updateDistinctPANCountTasklet.setUniquePANFetchDAO(uniquePANFetchDAO);
			assertEquals(RepeatStatus.FINISHED,updateDistinctPANCountTasklet.execute(contribution, chunkContext));

	 }
}
