package com.mastercard.ess.eds.test.batch.partitioner;


import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.partitioner.PanProcessPartitioner;
import com.mastercard.ess.eds.core.dao.EDSRecordDao;
import com.mastercard.ess.eds.core.service.EDSRecordWriterService;

public class PanProcessPartitionerTest {
	EDSRecordWriterService edsRecordWriterService;
	PanProcessPartitioner panProcessPartitioner;
	EDSRecordDao edsRecordDao;
	Logger logger;
	@Before
	public void init() {
		logger = Logger.getLogger(PanProcessPartitionerTest.class);
		edsRecordDao = EasyMock.createMock(EDSRecordDao.class);
		edsRecordWriterService = new EDSRecordWriterService();
		edsRecordWriterService = new EDSRecordWriterService(edsRecordDao);
		panProcessPartitioner = new PanProcessPartitioner();
		panProcessPartitioner.getEdsRecordWriterService();
		panProcessPartitioner.setEdsRecordWriterService(edsRecordWriterService);
		panProcessPartitioner.getNumRecords();
		panProcessPartitioner.setNumRecords(200);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("startIndex", 1);
		map.put("endIndex", 300);
		map.put("numRecords", 200);
		map.put("totalCount",201 );
		map.put("threadCount",3);
		map.put("totalRecords", 98);
		map.put("finalEndIndex", 99);
		EasyMock.expect(edsRecordDao.getIndexesForEDSSrcDataId()).andReturn(map);
		EasyMock.replay(edsRecordDao);
	}
	@Test
	public void initTest() {
		logger = Logger.getLogger(PanProcessPartitionerTest.class);
		edsRecordDao = EasyMock.createMock(EDSRecordDao.class);
		edsRecordWriterService = new EDSRecordWriterService();
		edsRecordWriterService = new EDSRecordWriterService(edsRecordDao);
		panProcessPartitioner = new PanProcessPartitioner();
		panProcessPartitioner.getEdsRecordWriterService();
		panProcessPartitioner.setEdsRecordWriterService(edsRecordWriterService);
		panProcessPartitioner.getNumRecords();
		panProcessPartitioner.setNumRecords(200);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("startIndex", 1);
		map.put("endIndex", 199);
		map.put("numRecords", 200);
		map.put("totalCount",201 );
		map.put("threadCount",3);
		map.put("totalRecords", 98);
		map.put("finalEndIndex", 199);
		EasyMock.expect(edsRecordDao.getIndexesForEDSSrcDataId()).andReturn(map);
		EasyMock.replay(edsRecordDao);
		panProcessPartitioner.partition(3);
	}	
	@Test
	public void initTest1() {
		logger = Logger.getLogger(PanProcessPartitionerTest.class);
		edsRecordDao = EasyMock.createMock(EDSRecordDao.class);
		edsRecordWriterService = new EDSRecordWriterService();
		edsRecordWriterService = new EDSRecordWriterService(edsRecordDao);
		panProcessPartitioner = new PanProcessPartitioner();
		panProcessPartitioner.getEdsRecordWriterService();
		panProcessPartitioner.setEdsRecordWriterService(edsRecordWriterService);
		panProcessPartitioner.getNumRecords();
		panProcessPartitioner.setNumRecords(200);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("startIndex", 1);
		map.put("endIndex", 1);
		map.put("finalEndIndex", 1);
		map.put("Thread Index",1);
		EasyMock.expect(edsRecordDao.getIndexesForEDSSrcDataId()).andReturn(map);
		EasyMock.replay(edsRecordDao);
		panProcessPartitioner.partition(3);
	}

	@Test
	public void testpartition() {
		logger.setLevel(Level.DEBUG);
		ExecutionContext executionContext = new ExecutionContext();
		Map<String, ExecutionContext> partitionMap1 = new LinkedHashMap<String, ExecutionContext>();
		partitionMap1.put("Thread Index-1", executionContext);
		panProcessPartitioner.partition(3);

	}

}