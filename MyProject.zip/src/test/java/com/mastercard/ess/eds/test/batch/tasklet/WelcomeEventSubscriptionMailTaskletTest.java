package com.mastercard.ess.eds.test.batch.tasklet;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;

import com.mastercard.ess.eds.batch.tasklet.WelcomeEventSubscriptionMailTasklet;
import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.core.service.CustomerMasterService;
import com.mastercard.ess.eds.core.service.EventSubscriptionService;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;

public class WelcomeEventSubscriptionMailTaskletTest {

	EventPublisher eventPublisher;
	CustomerMasterService customerMasterService;
	EventSubscriptionService eventSubscriptionService;
	NotificationEventVO notificationEventVO;
	StepContribution contribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;

	@Test
	public void testExecute() throws Exception {
		WelcomeEventSubscriptionMailTasklet welcomeEventSubscriptionMailTasklet=new WelcomeEventSubscriptionMailTasklet();
		List<String> list = new ArrayList<String>();
		list.add("te_st@mastercard.com");
		
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		jobInstance = new JobInstance(new Long(123), "welcomeEmail");
		jobParameter = new JobParameter("welcomeeventsub", true);
		parameters.put("mail", jobParameter);
		jobParameters = new JobParameters(parameters);
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("billdataFile", jobExecution);
		
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		contribution = new StepContribution(stepExecution);
		
		eventSubscriptionService = EasyMock.createMock(EventSubscriptionService.class);
		EasyMock.expect(eventSubscriptionService.getEmailIdsByEventType("E" , 1)).andReturn(list);
		EasyMock.replay(eventSubscriptionService);
		
		eventPublisher = new EventPublisher();
		WelcomeEventSubscriptionMailTasklet wesmt = new WelcomeEventSubscriptionMailTasklet(eventPublisher, null, eventSubscriptionService);
		wesmt.getNumberOfDays();
		wesmt.setNumberOfDays(1);
		wesmt.execute(contribution, chunkContext);
	}
	
}
