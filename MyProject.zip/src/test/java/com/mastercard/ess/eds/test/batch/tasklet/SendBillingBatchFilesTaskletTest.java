package com.mastercard.ess.eds.test.batch.tasklet;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.billing.tasklet.SendBillingBatchFilesTasklet;

public class SendBillingBatchFilesTaskletTest {
	SendBillingBatchFilesTasklet sendBillingBatchFilesTasklet;
	ExecutionContext executionContext;
	String billingFileName;
	StepContribution paramStepContribution;
	ChunkContext paramChunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	String line;
	List<ProcessBuilder> processBuilder;
	
	
	Logger logger = Logger
			.getLogger(SendBillingBatchFilesTasklet.class);
	
	@Before
	public void init()
	{
		
		logger.setLevel(Level.DEBUG);
		executionContext = EasyMock.createMock(ExecutionContext.class);
		jobInstance = new JobInstance(new Long(123), "sendBillingBatchFilesTasklet");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("sendBillingBatchFilesTasklet", jobExecution);
		stepContext = new StepContext(stepExecution);
		paramChunkContext = new ChunkContext(stepContext);
		paramStepContribution = new StepContribution(stepExecution);
		sendBillingBatchFilesTasklet = new SendBillingBatchFilesTasklet();
		
	}
	@Test
	public void executetest()throws Exception
	{
		logger.setLevel(Level.DEBUG);
		executionContext=new ExecutionContext();
		executionContext.put("billingFileName", new Object());
		sendBillingBatchFilesTasklet.setExecutionContext(executionContext);
		assertEquals(executionContext,sendBillingBatchFilesTasklet.getExecutionContext());
		sendBillingBatchFilesTasklet.execute(paramStepContribution, paramChunkContext);
		
		}
}
