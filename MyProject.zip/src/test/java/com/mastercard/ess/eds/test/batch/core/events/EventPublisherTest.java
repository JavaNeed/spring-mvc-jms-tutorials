
package com.mastercard.ess.eds.test.batch.core.events;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;

import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.notification.dao.NotificationDAO;
import com.mastercard.ess.eds.notification.events.Receiver;
import com.mastercard.ess.eds.notification.util.NotificationEventCache;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;
import com.mastercard.ess.eds.notification.vo.NotificationVO;


public class EventPublisherTest {
	private int eventID;
	private String batchjob;
	MessageChannel input;
	Receiver receiver;

	NotificationDAO notificationDao ;
	NotificationEventCache notificationeventCache;
	NotificationEventVO notificationEventVO = new NotificationEventVO();
	Map<String,String> jobParams = new HashMap<String,String>();
	@Mock
	private Map<Integer,NotificationVO> notificationEmailTemplates = new HashMap<Integer,NotificationVO>();
	NotificationVO notificationVO = new NotificationVO();
	NotificationEventVO evtVO = new NotificationEventVO();
	
	private static Logger logger = Logger.getLogger(EventPublisher.class);
	
	@Test 
	public void placeEventTest(){
		logger.setLevel(Level.DEBUG);
		notificationDao= EasyMock
				.createMock(NotificationDAO.class);
		notificationeventCache =EasyMock
				.createMock(NotificationEventCache.class);
		logger.info("inside EventPublisher class| placeEventTest");
		notificationVO.setBody("AA");
	//	notificationVO.setEmailId("AA");
		notificationVO.setEventId(1);
		notificationVO.setEventname("AA");
		notificationVO.setFrom("AA");
		notificationVO.setSign("AA");
		notificationVO.setSubject("AA");
		evtVO.setEventName("AA");
		evtVO.setJobName("AA");
		jobParams.put("AA", "AA");
		evtVO.setJobParams(jobParams);
		notificationEmailTemplates.put(1, notificationVO);
		
	eventID =1;
	batchjob = "AA";
	input = new MessageChannel() {
		
		@Override
		public boolean send(Message<?> arg0, long arg1) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public boolean send(Message<?> arg0) {
			// TODO Auto-generated method stub
			return false;
		}
	};
	
	receiver = new Receiver();
	EventPublisher eventPublisher = new EventPublisher(input,receiver);
	notificationEventVO.setEventName("AA");
	notificationEventVO.setJobName("AA");
	jobParams.put("AA", "AA");
	notificationEventVO.setJobParams(jobParams);
	
	HashMap<Integer, NotificationVO> eventCache = new HashMap<Integer,NotificationVO>();
	eventCache.put(1, notificationVO);

	EasyMock.expect(notificationeventCache.getCache()).andReturn(eventCache);
	EasyMock.replay(notificationeventCache);

	EasyMock.expect(notificationDao.getEmailTemplates()).andReturn(notificationEmailTemplates);
	EasyMock.replay(notificationDao);
	eventPublisher.placeEvent(notificationEventVO);

	}
	
	@Test
	public void testExceptionInPlaceEvt()
	{
		EventPublisher eventPublisher = new EventPublisher();

		eventPublisher.placeEvent(notificationEventVO);

		
	}
}
