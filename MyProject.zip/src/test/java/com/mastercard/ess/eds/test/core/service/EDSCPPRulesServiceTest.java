package com.mastercard.ess.eds.test.core.service;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.mastercard.ess.eds.core.dao.DWDao;
import com.mastercard.ess.eds.core.dao.EDSCPPRulesDao;
import com.mastercard.ess.eds.core.service.EDSCPPRulesService;
import com.mastercard.ess.eds.domain.AuthDebitPanDetailRecord;
import com.mastercard.ess.eds.domain.CPPRuleRecord;

public class EDSCPPRulesServiceTest {
	EDSCPPRulesService eDSCPPRulesService;
	EDSCPPRulesDao edsCPPRulesDao;
	DWDao dWDao;
	List<Integer> cppRuleIds=new ArrayList<Integer>();
	CPPRuleRecord cppRuleRcrd ;;
	List<AuthDebitPanDetailRecord> authDebitPanDetailRecords=new ArrayList<AuthDebitPanDetailRecord>();
	AuthDebitPanDetailRecord authPanDetailRecord=new AuthDebitPanDetailRecord();
	AuthDebitPanDetailRecord debitPanDetailRecord=new AuthDebitPanDetailRecord();

	@Before
	public void init() {
		cppRuleIds.add(1);cppRuleIds.add(2);cppRuleIds.add(3);cppRuleIds.add(4);cppRuleIds.add(5);


		cppRuleRcrd=new CPPRuleRecord();
		cppRuleRcrd.setActiveSW("Y");
		cppRuleRcrd.setCatCD("E");
		cppRuleRcrd.setClsIssrCntry("ONEOF");
		cppRuleRcrd.setClsLocTranAmt("EQUALS");
		cppRuleRcrd.setClsMerchant("EQUALS");
		cppRuleRcrd.setCreateDate(new Date(2017, 01, 10));
		cppRuleRcrd.setCreatedBy(null);
		cppRuleRcrd.setFirstRunSW("Y");
		cppRuleRcrd.setLastUpdateDate(new Date(2017, 01, 10));
		cppRuleRcrd.setLastUpdatedBy(null);
		cppRuleRcrd.setUnitTmCount("WEEKS");
		cppRuleRcrd.setValIssrCntry("USA");
		cppRuleRcrd.setValLocTranAmt(new BigDecimal(100));
		cppRuleRcrd.setValMerchant(0);
		cppRuleRcrd.setValTmCount(90);
		cppRuleRcrd.setCppRuleId(new BigDecimal(100));

		authPanDetailRecord.setCppRuleId(new BigDecimal(1));
		authPanDetailRecord.setdWSource("auth");
		authPanDetailRecord.setRawPan("1010101");


		debitPanDetailRecord.setCppRuleId(new BigDecimal(1));
		debitPanDetailRecord.setdWSource("debit");
		debitPanDetailRecord.setRawPan("1010101");
		authDebitPanDetailRecords.add(authPanDetailRecord);
		authDebitPanDetailRecords.add(debitPanDetailRecord);

		edsCPPRulesDao = EasyMock.createMock(EDSCPPRulesDao.class);
		dWDao = EasyMock.createMock(DWDao.class);
		edsCPPRulesDao.setCppRuleRecord(cppRuleRcrd);
		edsCPPRulesDao.setListOfCPPRuleIds(cppRuleIds);
		edsCPPRulesDao.setCppRuleRecord(cppRuleRcrd);
		eDSCPPRulesService = new EDSCPPRulesService();
		eDSCPPRulesService.setDao(edsCPPRulesDao);

	}

	@Test
	public void testUpdateCPPSrcStatusPostProcessing() {
		edsCPPRulesDao = EasyMock.createMock(EDSCPPRulesDao.class);
		eDSCPPRulesService = new EDSCPPRulesService();
		eDSCPPRulesService.setDao(edsCPPRulesDao);
		eDSCPPRulesService.updateCPPSrcStatusPostProcessing("", "",0);
	}

	@Test
	public void testUpdateFirstRunSW() {
		edsCPPRulesDao = EasyMock.createMock(EDSCPPRulesDao.class);
		eDSCPPRulesService = new EDSCPPRulesService();
		eDSCPPRulesService.setDao(edsCPPRulesDao);
		eDSCPPRulesService.updateFirstRunSW("", new ArrayList<String>());
	}

	@Test
	public void testGetCPPRulesByRuleId() {


		EasyMock.expect(edsCPPRulesDao.getCPPRulesByRuleId("Y",100)).andReturn(cppRuleRcrd);
		EasyMock.replay(edsCPPRulesDao);


		Assert.assertNotNull(eDSCPPRulesService.getCPPRulesByRuleId(100));

	}

	@Ignore
	public void testGetCPPRuleIds() {

		EasyMock.expect(edsCPPRulesDao.getCPPRuleIds("EXECUTION")).andReturn(cppRuleIds);
		EasyMock.replay(edsCPPRulesDao);
		Assert.assertNotNull(eDSCPPRulesService.getCPPRuleIds("EXECUTION"));

	}

	@Test
	public void testAuthRecordsByRule() {

		EasyMock.expect(dWDao.getAuthRecordsByRule(cppRuleRcrd, "5")).andReturn(authDebitPanDetailRecords);
		EasyMock.replay(dWDao);
		List<AuthDebitPanDetailRecord> authDebitPanDetailRecordList = dWDao.getAuthRecordsByRule(cppRuleRcrd, "5");
		Assert.assertNotNull(authDebitPanDetailRecordList);
	}

	@Test
	public void testDebitRecordsByRule() {
		EasyMock.expect(dWDao.getDebitRecordsByRule(cppRuleRcrd,"5")).andReturn(authDebitPanDetailRecords);
		EasyMock.replay(dWDao);
		List<AuthDebitPanDetailRecord> authDebitPanDetailRecordList = dWDao.getDebitRecordsByRule(cppRuleRcrd, "5");
		Assert.assertNotNull(authDebitPanDetailRecordList);

	}
}
