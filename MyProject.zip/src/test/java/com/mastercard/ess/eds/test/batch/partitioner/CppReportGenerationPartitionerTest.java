package com.mastercard.ess.eds.test.batch.partitioner;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.partitioner.CppReportGenerationPartitioner;
import com.mastercard.ess.eds.core.dao.CPPReportDAO;
import com.mastercard.ess.eds.core.service.CPPReportService;

public class CppReportGenerationPartitionerTest {
	CPPReportService cPPReportService;
	CppReportGenerationPartitioner cppReportGenerationPartitioner;
	CPPReportDAO cppReportDAO;

	@Before
	public void init() {
		cppReportDAO = EasyMock.createMock(CPPReportDAO.class);
		cPPReportService = new CPPReportService();
		cPPReportService.setCPPReportDAO(cppReportDAO);
		cppReportGenerationPartitioner = new CppReportGenerationPartitioner();
		cppReportGenerationPartitioner.setCppReportService(cPPReportService);

		String IssuerCountry1 = "INDIA";
		String IssuerCountry2 = "GERMANY";

		List<String> cPPReportInfoList = new ArrayList<String>();

		cPPReportInfoList.add(IssuerCountry1);
		cPPReportInfoList.add(IssuerCountry2);

		EasyMock.expect(cppReportDAO.getListOfCountries()).andReturn(
				cPPReportInfoList);
		EasyMock.replay(cppReportDAO);

	}

	@Test
	public void testpartition() {
		ExecutionContext executionContext = new ExecutionContext();
		String issuerCountry6 = "INDIA";
		executionContext.put("issr_cntry_cd", issuerCountry6);

		ExecutionContext executionContext1 = new ExecutionContext();
		String issuerCountry7 = "GERMANY";
		executionContext1.put("issr_cntry_cd", issuerCountry7);

		Map<String, ExecutionContext> partitionMapExpected = new HashMap<String, ExecutionContext>();
		partitionMapExpected
				.put("CPPFileGenerationThread -0", executionContext);
		partitionMapExpected.put("CPPFileGenerationThread -1",
				executionContext1);
		Map<String, ExecutionContext> partitionMap = cppReportGenerationPartitioner
				.partition(3);
		assertEquals(partitionMap, partitionMapExpected);

	}

}
