package com.mastercard.ess.eds.test.core.util;

import static org.junit.Assert.assertEquals;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.repeat.RepeatStatus;

import com.mastercard.ess.eds.batch.tasklet.EmailSimulationReportTasklet;
import com.mastercard.ess.eds.core.dao.EDSSourceTypeDao;
import com.mastercard.ess.eds.domain.EDSSourceType;

public class EmailSimulationReportTaskletTest {

	private EmailSimulationReportTasklet emailSimulationReportTasklet;
	private StepContribution stepContribution;
	private ChunkContext chunkContext;
	private StepExecution stepExecution;
	private StepContext stepContext;
	private JobParameters jobParameters;
	private JobParameter jobParameter;
	private JobExecution jobExecution;
	private JobInstance jobInstance;
	private Logger logger;
	EDSSourceType EDSSourceType;
	EDSSourceTypeDao edsSourceTypeDao;
	String simulationReportPath = "..CPPSimulationReport";

	@Before
	public void setUp()
	{
		logger = Logger.getLogger(EmailSimulationReportTaskletTest.class);
		logger.setLevel(Level.DEBUG);
		String fileName = "simulationFile";

		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();

		jobParameter = new JobParameter(fileName, true);
		parameters.put("file", jobParameter);
		jobParameters = new JobParameters(parameters);

		jobInstance = new JobInstance(new Long(123), "simulationReportPath");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("simulationReportPath", jobExecution);

		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		stepContribution = new StepContribution(stepExecution);

		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("tb", "");
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("tb_path", "_mastercard.xlsx");
		edsSourceTypeDao = EasyMock.createMock(EDSSourceTypeDao.class);
	}

	@Test
	public void test() throws Exception {
		emailSimulationReportTasklet = new EmailSimulationReportTasklet(edsSourceTypeDao);
		emailSimulationReportTasklet.setCustomerEnrollmentReportPath(simulationReportPath);
		assertEquals(RepeatStatus.FINISHED,emailSimulationReportTasklet.execute(stepContribution,chunkContext));
	}

}
