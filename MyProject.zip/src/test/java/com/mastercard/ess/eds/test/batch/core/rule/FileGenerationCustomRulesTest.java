package com.mastercard.ess.eds.test.batch.core.rule;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.mastercard.ess.eds.core.dao.BrandExclusionDAO;
import com.mastercard.ess.eds.core.rule.FileGenerationCustomRules;
import com.mastercard.ess.eds.core.util.BrandExclusionCache;
import com.mastercard.ess.eds.domain.ProcessedRecord;

public class FileGenerationCustomRulesTest {
	FileGenerationCustomRules fileGenerationCustomRules;
	FileGenerationCustomRules custom, custom1;
	BrandExclusionCache brandExclusionCache;
	List<String> listExcludedBrands;
	Map<String, String> icaToIsSilentMap;
	ProcessedRecord procRecord;
	BrandExclusionDAO brandExclusionDAO;


	@Before
	public void setUp() {
		
		custom = new FileGenerationCustomRules ();
		brandExclusionCache = EasyMock.createMock(BrandExclusionCache.class);
		listExcludedBrands = new ArrayList<String>();
		listExcludedBrands.add("brandProductCode");
		listExcludedBrands.add("brandProductCodeOne");
		icaToIsSilentMap = new HashMap<String, String>();
		custom.setAccountValidFlag(true);
		custom.setBrandExclusionCache(brandExclusionCache);
		custom.setDescription("");
		custom.setExcludedBrandList(listExcludedBrands);
		custom.setIcaToIsSilentMap(icaToIsSilentMap);
		procRecord = new ProcessedRecord();
		procRecord.setIsAccountADCNotified("N");
		procRecord.setAccountValid(true);
		procRecord.setBin("");
		procRecord.setConfidenceScore(-1);
		procRecord.setDaysSinceLastActivity(150);
		procRecord.setIca("");
		procRecord.setIsAccountActive("Y");
		procRecord.setIsFraudReported("N");
		String date = "2000-11-01 00:00:00";
		java.sql.Timestamp javaSqlDate = java.sql.Timestamp.valueOf(date); 
		procRecord.setLastUpdatedDate(javaSqlDate);
		procRecord.setLastUpdatedUser("");
		procRecord.setPan(new BigDecimal("625421221662123727"));
		procRecord.setPriceCategory(0);
		procRecord.setProcRawRecordKey(new BigDecimal("1"));
		procRecord.setProcRecordKey(new BigDecimal("1"));
		procRecord.setIsFraudReported("N");
		procRecord.setIsDuplicate("N");
		custom.setInputToRule(procRecord);
		custom.setIsAccountActiveFlag("Y");
		custom.setIsADCNotifiedFlag("Y");
		custom.setIsAlreadyReportedFlag("Y");
		custom.setIsDuplicateFlag("");
		custom.setIsFraudReportedFlag("");
		custom1 = new FileGenerationCustomRules();
		custom1.setAccountValidFlag(true);
		custom1.setBrandExclusionCache(brandExclusionCache);
		custom1.setDescription("");
		custom1.setExcludedBrandList(listExcludedBrands);
		custom1.setIcaToIsSilentMap(icaToIsSilentMap);
		custom1.setInputToRule(procRecord);
		custom1.setIsAccountActiveFlag("Y");
		custom1.setIsADCNotifiedFlag("Y");
		custom1.setIsAlreadyReportedFlag("Y");
		custom1.setIsDuplicateFlag("");
		custom1.setIsFraudReportedFlag("");
		
	}
	
	@Test
	public void test()
	{
		EasyMock.expect(brandExclusionCache.getListOfExcludedBrands()).andReturn(listExcludedBrands);
		EasyMock.replay(brandExclusionCache);
		custom.evaluate();
		custom.execute();
		assertEquals(brandExclusionCache,custom.getBrandExclusionCache());
		assertEquals(listExcludedBrands,custom.getExcludedBrandList());
		assertEquals(icaToIsSilentMap,custom.getIcaToIsSilentMap());
		new FileGenerationCustomRules("");
		assertEquals("",custom.getIsDuplicateFlag());
		assertEquals("Y",custom.getIsAlreadyReportedFlag());
		assertEquals("Y",custom.getIsADCNotifiedFlag());
		assertEquals("",custom.getIsFraudReportedFlag());
		assertEquals(true,custom.isAccountValidFlag());
		custom.getIsAccountActiveFlag();
		new FileGenerationCustomRules(custom);
		assertEquals(true,ReflectionTestUtils.invokeMethod(custom, "checkBooleanForReports", true,true,true));
		assertEquals(false,ReflectionTestUtils.invokeMethod(custom, "checkBooleanForReports", true,false,true));
		assertEquals(false,ReflectionTestUtils.invokeMethod(custom, "checkActiveValidProcessBoolean", true,false,true));
		assertEquals(true,ReflectionTestUtils.invokeMethod(custom, "checkActiveValidProcessBoolean", true,true,true));
		custom.hashCode();
		
		}
	
	@Test
	public void testOne() {
		custom.equals(brandExclusionCache);
		custom.equals(custom);
		custom.equals(null);
		custom.equals(custom1);
		custom.setIcaToIsSilentMap(null);
		custom.equals(custom1);
		custom.setIcaToIsSilentMap(icaToIsSilentMap);
		custom.setIsADCNotifiedFlag(null);
		custom.equals(custom1);
		custom.setIsADCNotifiedFlag("Y");
		custom.setIsAccountActiveFlag(null);
		custom.equals(custom1);
		custom.setIsAccountActiveFlag("Y");
		custom.setIsFraudReportedFlag(null);
		custom.equals(custom1);
		custom.setIsFraudReportedFlag("");
		custom.setIsDuplicateFlag(null);
		custom.equals(custom1);
		custom.setIsDuplicateFlag("");
		custom.setIsAlreadyReportedFlag(null);
		custom.equals(custom1);
		custom.setIsAlreadyReportedFlag("Y");
	procRecord.setIsAccountADCNotified(null);
		procRecord.setAccountValid(false);
		procRecord.setBin("1");
		procRecord.setConfidenceScore(1);
		procRecord.setDaysSinceLastActivity(250);
		procRecord.setIca("3");
		procRecord.setIsAccountActive("N");
		procRecord.setIsFraudReported(null);
		String date = "2000-11-01 00:00:00";
		java.sql.Timestamp javaSqlDate = java.sql.Timestamp.valueOf(date); 
		procRecord.setLastUpdatedDate(javaSqlDate);
		procRecord.setLastUpdatedUser("4");
		procRecord.setPan(new BigDecimal("6245421221662123727"));
		procRecord.setPriceCategory(3);
		procRecord.setProcRawRecordKey(new BigDecimal("3"));
		procRecord.setProcRecordKey(new BigDecimal("3"));
		procRecord.setIsFraudReported("Y");
		procRecord.setIsDuplicate("Y");
		custom.setInputToRule(procRecord);
		custom.equals(custom1);
		procRecord.setIsAccountADCNotified("N");
		procRecord.setAccountValid(true);
		procRecord.setBin("");
		procRecord.setConfidenceScore(-1);
		procRecord.setDaysSinceLastActivity(150);
		procRecord.setIca("");
		procRecord.setIsAccountActive("Y");
		procRecord.setIsFraudReported("N");
		String dateOne = "2000-11-01 00:00:00";
		java.sql.Timestamp javaSqlDateOne = java.sql.Timestamp.valueOf(dateOne); 
		procRecord.setLastUpdatedDate(javaSqlDateOne);
		procRecord.setLastUpdatedUser("");
		procRecord.setPan(new BigDecimal("625421221662123727"));
		procRecord.setPriceCategory(0);
		procRecord.setProcRawRecordKey(new BigDecimal("1"));
		procRecord.setProcRecordKey(new BigDecimal("1"));
		procRecord.setIsFraudReported("N");
		procRecord.setIsDuplicate("N");
		custom.setInputToRule(procRecord);
		
		
	}
	

}
