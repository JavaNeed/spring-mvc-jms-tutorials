package com.mastercard.ess.eds.test.core.util;

import static org.junit.Assert.assertEquals;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.batch.test.MetaDataInstanceFactory;

import com.mastercard.ess.eds.core.dao.CPPDAO;
import com.mastercard.ess.eds.core.util.TruncateCPPData;

public class TruncateCPPDataTest {

	TruncateCPPData truncateCPPData;
	CPPDAO cPPDAO;
	private static Logger logger = Logger.getLogger(TruncateCPPData.class);
	
	@Test
	public void test() throws Exception {
		logger.setLevel(Level.DEBUG);
		cPPDAO = EasyMock.createMock(CPPDAO.class);
		truncateCPPData = new TruncateCPPData();
		truncateCPPData.setTruncateCPPData(cPPDAO);
		StepExecution stepExecution = MetaDataInstanceFactory
				.createStepExecution();
		RepeatStatus status = truncateCPPData.execute(new StepContribution(
				stepExecution),
				new ChunkContext(new StepContext(stepExecution)));
		assertEquals(RepeatStatus.FINISHED, status);
	}

}
