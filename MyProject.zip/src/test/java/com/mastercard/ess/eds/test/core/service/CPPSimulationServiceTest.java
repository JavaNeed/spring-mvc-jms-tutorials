package com.mastercard.ess.eds.test.core.service;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.core.dao.CPPSimulationDataDAO;
import com.mastercard.ess.eds.core.dao.CPPSimulationSourceDAO;
import com.mastercard.ess.eds.core.dao.EDSCPPRulesDao;
import com.mastercard.ess.eds.core.dao.LocationDAO;
import com.mastercard.ess.eds.core.service.CPPSimulationService;
import com.mastercard.ess.eds.domain.CPPRuleRecord;

public class CPPSimulationServiceTest {
	private CPPSimulationService cPPSimulationService;
	private CPPSimulationSourceDAO cppSimulationSourceDAO;
	private CPPSimulationDataDAO cppSimulationDataDAO;
	private LocationDAO locationDAO;
	private EDSCPPRulesDao edscppRulesDao;
	List<CPPRuleRecord> cPPRuleRecord;
	CPPRuleRecord cppRuleRecord;
	String srcName="abc";

	@Before
	public void setUp() throws Exception {
		cPPSimulationService = new CPPSimulationService();
		cppRuleRecord=new CPPRuleRecord();
		cppSimulationSourceDAO=EasyMock.createMock(CPPSimulationSourceDAO.class);
		cppSimulationDataDAO=EasyMock.createMock(CPPSimulationDataDAO.class);
		locationDAO=EasyMock.createMock(LocationDAO.class);
		edscppRulesDao = EasyMock.createMock(EDSCPPRulesDao.class);
		cPPSimulationService=new CPPSimulationService(cppSimulationSourceDAO, cppSimulationDataDAO);
		cPPSimulationService.setCppSimulationDataDAO(cppSimulationDataDAO);
		cPPSimulationService.setCppSimulationSourceDAO(cppSimulationSourceDAO);
		cPPSimulationService.setLocationDAO(locationDAO);
		cPPSimulationService.setEdscppRulesDao(edscppRulesDao);
		cppRuleRecord.setValMerchant(1);

	}


	@Test
	public void testCreateSimulationSource() {
		EasyMock.expect(cppSimulationSourceDAO.createSimulationSource("simulationFile", "SimulationJob", new BigDecimal(123), 5)).andReturn("1");
		EasyMock.replay(cppSimulationSourceDAO);
		cPPSimulationService.createSimulationSource("simulationFile", "SimulationJob", new BigDecimal(123), 5);
	}

	@Test
	public void testSaveSimulationResults() {
		Map<String, Integer> simulationMapCount=new LinkedHashMap<>();
		simulationMapCount.put("1254", 1);
		EasyMock.expect(edscppRulesDao.getCPPRulesByRuleId("P", 1254)).andReturn(cppRuleRecord);
		EasyMock.replay(edscppRulesDao);
		cPPSimulationService.saveSimulationResults(simulationMapCount,  new BigDecimal(142), "simjob", "2");

	}

	@Test
	public void testFetchSimulationResults() {
		EasyMock.expect(cppSimulationDataDAO.fetchSimulationReport("11")).andReturn(cPPRuleRecord);
		EasyMock.replay(cppSimulationSourceDAO);
		cPPSimulationService.fetchSimulationResults("11");
	}

	@Test
	public void testUpdateSimulationSourcePostProcessing() {

		cPPSimulationService.updateSimulationSourcePostProcessing("simfile", "cppjob",5);
	}

	@Test
	public void testTruncateCPPSimulationData() {

		cPPSimulationService.truncateCPPSimulationData();
	}
	@Test
	public void testGetSimulationSrcId() {
		EasyMock.expect(cppSimulationSourceDAO.getSimulationSrcId("abc")).andReturn(srcName);
		EasyMock.replay(cppSimulationSourceDAO);
		cPPSimulationService.getSimulationSrcId("abc");
	}

}
