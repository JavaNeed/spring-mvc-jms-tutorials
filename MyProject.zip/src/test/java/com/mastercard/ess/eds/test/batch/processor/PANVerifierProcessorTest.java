package com.mastercard.ess.eds.test.batch.processor;

import java.util.TreeMap;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.mastercard.ess.eds.batch.processor.PANVerifierProcessor;
import com.mastercard.ess.eds.core.util.PANAccountRangeCache;
import com.mastercard.ess.eds.domain.CIDInfo;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.PANAccountRange;
import com.mastercard.ess.eds.domain.ProcessedRecord;
import com.mastercard.ess.eds.domain.RawRecord;

public class PANVerifierProcessorTest {
	
	private static Logger logger = Logger.getLogger(PANVerifierProcessor.class);
	
	@Mock
	private PANAccountRangeCache panAccountRangeCache;
	
	private RawRecord rawRecord;
	
	private EDSRecord edsRecord;
	
	
	@InjectMocks
	private PANVerifierProcessor panVerifierProcessor = new PANVerifierProcessor();
	
	@Before
    public void setUp() throws Exception {
		logger.setLevel(Level.DEBUG);
		MockitoAnnotations.initMocks(this);
		rawRecord = new RawRecord();
		rawRecord.setRawPan("7845892402");
		edsRecord = new EDSRecord();
		edsRecord.setRawRecord(rawRecord);
		logger = Logger.getLogger(PANVerifierProcessor.class);
		panVerifierProcessor.setTimestamp("02-11-2016 00:00:00");
		Mockito.when(panAccountRangeCache.getCache()).thenReturn(new TreeMap<PANAccountRange, PANAccountRange>());
	}
	 @Test
	public void testProcess() throws Exception {
		 	logger.setLevel(Level.DEBUG);
	        EDSRecord eds = panVerifierProcessor.process(edsRecord);
	        Assert.assertNotNull(eds);
	    }
	 
	 @Test
	public void testProcessInfo() throws Exception {
			 	logger.setLevel(Level.INFO);
		        EDSRecord eds = panVerifierProcessor.process(edsRecord);
		        Assert.assertNotNull(eds);
		    }
	 
	 @Test
	 public void testSetJobInstanceName(){
		 panVerifierProcessor.setJobInstanceName("panProcessJob");
		 Assert.assertNotNull(panVerifierProcessor.getJobInstanceName());
		 Assert.assertEquals(panVerifierProcessor.getJobInstanceName(), "panProcessJob");
	 }
	 
	 @Test
	 public void testIsValidAndIsVerfied(){
		 PANAccountRange panAccountRange = new PANAccountRange("7845892402");
		 panAccountRange.setMbrId("mbrId");
		 panAccountRange.setBrandProductCode("MDS");
		 panAccountRange.setStatus("A");
		 ProcessedRecord processedRecord = new ProcessedRecord();
		 panVerifierProcessor.setIsValidAndIsVerfied(panAccountRange, processedRecord);
		 Assert.assertEquals(processedRecord.getIsAccountActive(),"Y");
		 
	 }
	 
	 @Test
	 public void testIsValidAndIsVerfiedStatusDeactivated(){
		 PANAccountRange panAccountRange = new PANAccountRange("7845892402");
		 panAccountRange.setStatus("D");
		 ProcessedRecord processedRecord = new ProcessedRecord();
		 panVerifierProcessor.setIsValidAndIsVerfied(panAccountRange, processedRecord);
		 Assert.assertEquals(processedRecord.getIsAccountActive(),"N");
		 
	 }
}
