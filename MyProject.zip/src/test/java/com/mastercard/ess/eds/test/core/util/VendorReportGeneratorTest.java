package com.mastercard.ess.eds.test.core.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test; 
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.test.util.ReflectionTestUtils;

import com.mastercard.ess.eds.core.dao.CustomerPanReportDao;
import com.mastercard.ess.eds.core.service.CustomerFileReportService;
import com.mastercard.ess.eds.core.util.VendorReportGenerator;
import com.mastercard.ess.eds.domain.VendorActiveAccountRecord;

public class VendorReportGeneratorTest {

	VendorReportGenerator vendorReportGenerator;
	VendorActiveAccountRecord monthlySummary;
	VendorActiveAccountRecord vendorActiveAccountRecord1;
	CustomerFileReportService customerFileReportService;
	CustomerPanReportDao customerPanReportDao;
	List<VendorActiveAccountRecord> summaryList;
	Sheet sheet;
	Workbook workbook;
	Row row;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	String vendor;
	String previousMonth;
	BigDecimal jobInstanceId;
	String jobInstanceName;
	String filePath = "..Terbium_January.xlsx";
	String vendorReportPath = "..";
	private static Logger logger = Logger
			.getLogger(VendorReportGenerator.class);

	@Before
	public void init() {
		logger.setLevel(Level.DEBUG);
		customerFileReportService = EasyMock
				.createMock(CustomerFileReportService.class);
		String fileName = "file:///MCI.AR.RABC.X.E1234567.D160812.T111135.C001";
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		jobParameter = new JobParameter(fileName, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);
		jobInstanceId = BigDecimal.valueOf(1);
		jobInstanceName = "VendorReportGenerator";
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("VendorReportGenerator", jobExecution);

		stepContext = new StepContext(stepExecution);

		summaryList = new ArrayList<VendorActiveAccountRecord>();
		monthlySummary = new VendorActiveAccountRecord();
		monthlySummary.setActivePANCount(2);
		monthlySummary.setInactivePANCount(2);
		//monthlySummary.setNewPANCount(1);
		monthlySummary.setUniquePANCount(2);
		//monthlySummary.setValidPANCount(2);
		monthlySummary.setReceivedPANCount(2);
		summaryList.add(monthlySummary);

	}

	@Test
	public void test() {

		logger.setLevel(Level.DEBUG);
		EasyMock.expect(
				customerFileReportService.createGeneratedFileRecord(filePath,
						new BigDecimal(1), jobInstanceName, 4)).andReturn(1);
		EasyMock.replay(customerFileReportService);
		vendor = "Terbium";
		previousMonth = "January";
		vendorReportGenerator = new VendorReportGenerator();
		vendorReportGenerator = new VendorReportGenerator(vendorReportPath,
				customerFileReportService);
		vendorReportGenerator.writeToVendorReport(stepExecution, summaryList,
				monthlySummary, jobInstanceId, jobInstanceName, vendor,
				previousMonth);

	}

	/*@Test
	public void testMapObjectWithVendorActiveRecord()
			throws FileNotFoundException {
		Map<Integer, Object[]> rowEntry = new TreeMap<Integer, Object[]>();
		vendorReportGenerator = new VendorReportGenerator();
		FileOutputStream fos = new FileOutputStream("vendorReportPath");
		workbook = new HSSFWorkbook();
		sheet = workbook.createSheet("summary");
		row = sheet.createRow(3);
		ReflectionTestUtils.invokeMethod(vendorReportGenerator,
				"mapObjectWithVendorActiveRecord", summaryList , monthlySummary, "vendor", "January", "2", "22", sheet, 5,  rowEntry);
				  
		vendorReportGenerator = new VendorReportGenerator();
		ReflectionTestUtils.invokeMethod(vendorReportGenerator, "createRow",
				sheet, 5);
		vendorReportGenerator = new VendorReportGenerator();
		ReflectionTestUtils.invokeMethod(vendorReportGenerator, "writeToFile",
				workbook, fos);
		vendorReportGenerator = new VendorReportGenerator();

	}*/

	@Test
	public void testTwo() {
		vendorReportGenerator = new VendorReportGenerator();
		workbook = new XSSFWorkbook();
		sheet = workbook.createSheet("summary");
		row = sheet.createRow(3);
		ReflectionTestUtils.invokeMethod(vendorReportGenerator,
				"createCellValue", workbook, row, new Object[] {
				"Monthly Active Account Report", "Summary", 2 }, 3);
		ReflectionTestUtils.invokeMethod(vendorReportGenerator,
				"createCellValue", workbook, row, new Object[] { null }, 3);
	}

	@Test
	public void testCellWithStyle() {
		workbook = new XSSFWorkbook();
		sheet = workbook.createSheet("summary");
		row = sheet.createRow(3);
		XSSFCellStyle style2 = (XSSFCellStyle) workbook.createCellStyle();
		Font f2 = workbook.createFont();
		f2.setBoldweight(Font.BOLDWEIGHT_BOLD);
		f2.setFontHeightInPoints((short) 10);
		style2.setFont(f2);

		Cell c = row.createCell(3);
		vendorReportGenerator = new VendorReportGenerator();
		ReflectionTestUtils.invokeMethod(vendorReportGenerator,
				"setCellWithStyle1", new String("Month"), style2, c);
		ReflectionTestUtils.invokeMethod(vendorReportGenerator,
				"setCellWithStyle1", new String("Vendor"), style2, c);
		ReflectionTestUtils.invokeMethod(vendorReportGenerator,
				"setCellWithStyle1", new String("Inactive"), style2, c);
	}

	@AfterClass
	public static  void checkFileDeletion() {
		try {
			File[] dirFiles = new File(".").listFiles();
			// Search Through the list
			for (int i = 0; i < dirFiles.length; i++) { // If the Files start

				if (dirFiles[i].getName().startsWith("..Terbium_", 0) || dirFiles[i].getName().startsWith("Terbium_", 0))
					try {
						File file = new File(dirFiles[i].getName());
						boolean isDeleted = file.delete();

						if (isDeleted) {
							System.out.println("If File Deleted"+ " " +isDeleted+" file"+ dirFiles[i].getName());
						} else {
							System.out.println("else File Deleted"+ " " +isDeleted+" file"+ dirFiles[i].getName());

							File file1 = new File(dirFiles[i].getName());
							file1.delete();
						}

					} catch (Exception e) {

						e.printStackTrace();

					}

			}

		} catch (Exception e) {

			e.printStackTrace();

		}
	}

}