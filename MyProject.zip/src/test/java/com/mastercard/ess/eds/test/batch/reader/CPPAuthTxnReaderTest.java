package com.mastercard.ess.eds.test.batch.reader;

import static org.junit.Assert.assertEquals;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.test.util.ReflectionTestUtils;

import com.mastercard.ess.eds.batch.reader.CPPAuthTxnReader;
import com.mastercard.ess.eds.domain.CPPTxnInfo;

public class CPPAuthTxnReaderTest {
	CPPAuthTxnReader cPPAuthTxnReader;
	PreparedStatementSetter preparedStatementSetter;
	RowMapper<CPPTxnInfo> rowMapper;
	ResultSet rs;
	protected Method m;
	protected static String METHOD_NAME = "cleanupOnClose";
	protected Class[] parameterTypes;
	protected Object[] parameters;
	private DataSource dataSource;
	private PreparedStatement statement;
	private Connection jdbcConnection;
	@Before
	public void setUp() throws Exception {
		cPPAuthTxnReader = new CPPAuthTxnReader();
		parameterTypes = new Class[0];
		m = cPPAuthTxnReader.getClass().getDeclaredMethod(METHOD_NAME,
				parameterTypes);
		m.setAccessible(true);
		parameters = new Object[0];
		rowMapper = new RowMapper<CPPTxnInfo>() {

			@Override
			public CPPTxnInfo mapRow(ResultSet arg0, int arg1)
					throws SQLException {
				// TODO Auto-generated method stub
				return null;
			}
		};

	}

	@Test
	public void test() throws Exception {
		cPPAuthTxnReader = new CPPAuthTxnReader();
		cPPAuthTxnReader.setRowMapper(rowMapper);
		cPPAuthTxnReader.setSql("");
		cPPAuthTxnReader.setPreparedStatementSetter(preparedStatementSetter);
		assertEquals("", cPPAuthTxnReader.getSql());

	}

	@Test
	public void testing() throws IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		cPPAuthTxnReader = new CPPAuthTxnReader();
		CPPTxnInfo result = (CPPTxnInfo) m.invoke(cPPAuthTxnReader, parameters);
	}
	
	@Test
	public void readCursortest() throws Exception {
		cPPAuthTxnReader = new CPPAuthTxnReader();
		cPPAuthTxnReader.setRowMapper(rowMapper);
		cPPAuthTxnReader.setSql("");
		cPPAuthTxnReader.setDataSource(new BasicDataSource());
		cPPAuthTxnReader.setPreparedStatementSetter(preparedStatementSetter);
		cPPAuthTxnReader.afterPropertiesSet();
		ReflectionTestUtils.invokeMethod(cPPAuthTxnReader, "readCursor", rs, 2);
		
	}
	
	@Test
	public void openCursorTest() throws Exception{
		dataSource=Mockito.mock(DataSource.class);
		PreparedStatementSetter preparedStatementSetter=new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
			}
		};
		
		cPPAuthTxnReader = new CPPAuthTxnReader();
		cPPAuthTxnReader.setPreparedStatementSetter(preparedStatementSetter);
		cPPAuthTxnReader.setUseSharedExtendedConnection(true);

		cPPAuthTxnReader.setDataSource(dataSource);
		cPPAuthTxnReader.setCurrentItemCount(1);
		cPPAuthTxnReader.setDriverSupportsAbsolute(true);
		cPPAuthTxnReader.setSql("CppAuthTxnReader");


		jdbcConnection = Mockito.mock(Connection.class);
		statement =Mockito.mock(PreparedStatement.class);
		rs= Mockito.mock(ResultSet.class);

		Mockito.when(jdbcConnection.prepareStatement("CppAuthTxnReader",ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY,
				ResultSet.HOLD_CURSORS_OVER_COMMIT)).thenReturn(statement);
		Mockito.when(statement.executeQuery()).thenReturn(rs);
        Mockito.when(rs.isBeforeFirst()).thenReturn(false);

		ReflectionTestUtils.invokeMethod(cPPAuthTxnReader, "openCursor",jdbcConnection);

		
	}
	

}
