package com.mastercard.ess.eds.test.batch.processor;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.retry.support.RetryTemplate;

import com.mastercard.ess.eds.batch.exception.EDSCoreException;
import com.mastercard.ess.eds.batch.processor.FraudDetectionProcessor;
import com.mastercard.ess.eds.core.dao.FraudDao;
import com.mastercard.ess.eds.core.service.FraudDetectionService;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.ProcessedRecord;
import com.mastercard.ess.eds.domain.RawRecord;

public class FraudDetectionProcessorTest {

	private static Logger logger = Logger.getLogger(FraudDetectionProcessor.class);

	@InjectMocks
	private FraudDetectionProcessor fraudDetectionProcessor = new FraudDetectionProcessor();

	@Mock
	private FraudDetectionService fraudDetectionService;

	@Mock
	private FraudDao fraudDao;

	@Mock
	private RetryTemplate retryTemplate ;
	
	private EDSRecord edsRecord;

	@Before
	public void setUp() throws Exception {
		logger.setLevel(Level.DEBUG);
		MockitoAnnotations.initMocks(this);
		edsRecord = new EDSRecord();
		RawRecord rawRecord = new RawRecord();
		rawRecord.setRawPan("5676843795894843");
		ProcessedRecord procRecord = new ProcessedRecord();
		edsRecord.setProcRecord(procRecord);
		edsRecord.setRawRecord(rawRecord);
		fraudDetectionService = new FraudDetectionService(fraudDao , retryTemplate);
	}

	@Test
	public void testProcess() throws EDSCoreException {
		EDSRecord edsrecord = fraudDetectionProcessor.process(edsRecord);
		Assert.assertNotNull(edsrecord);
	}

	@Test
	public void testProcessInfo() throws EDSCoreException {
		logger.setLevel(Level.INFO);
		EDSRecord edsrecord = fraudDetectionProcessor.process(edsRecord);
		Assert.assertNotNull(edsrecord);
	}

	@Test
	public void testservice() throws EDSCoreException {
		fraudDetectionService = EasyMock.createMock(FraudDetectionService.class);
		EasyMock.expect(fraudDetectionService.isFraudReported("5676843795894843")).andReturn(true);
		EasyMock.replay(fraudDetectionService);
		fraudDetectionProcessor.setService(fraudDetectionService);
		EDSRecord edsrecord = fraudDetectionProcessor.process(edsRecord);
		Assert.assertNotNull(edsrecord);
		
	}
}
