package com.mastercard.ess.eds.test.batch.core.rule;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.mastercard.ess.eds.core.rule.FileGenerationRules;
import com.mastercard.ess.eds.domain.ProcessedRecord;

public class FileGenerationRulesTest {
	FileGenerationRules fileGenerationRules, fileGenerationRulesOne;
	ProcessedRecord procRecord;
	private Logger logger;


	@Before
	public void setUp()
	{
		fileGenerationRules = new FileGenerationRules();
		procRecord = new ProcessedRecord();
		procRecord.setIsAccountADCNotified("N");
		procRecord.setAccountValid(true);
		procRecord.setBin("");
		procRecord.setConfidenceScore(-1);
		procRecord.setDaysSinceLastActivity(150);
		procRecord.setIca("");
		procRecord.setIsAccountActive("Y");
		procRecord.setIsFraudReported("N");
		procRecord.setIsReported("Y");
		String date = "2000-11-01 00:00:00";
		java.sql.Timestamp javaSqlDate = java.sql.Timestamp.valueOf(date); 
		procRecord.setLastUpdatedDate(javaSqlDate);
		procRecord.setLastUpdatedUser("");
		procRecord.setPan(new BigDecimal("625421221662123727"));
		procRecord.setPriceCategory(0);
		procRecord.setProcRawRecordKey(new BigDecimal("1"));
		procRecord.setProcRecordKey(new BigDecimal("1"));
		procRecord.setIsFraudReported("N");
		procRecord.setIsDuplicate("N");
		fileGenerationRules.setIsAccountActiveFlag("Y");
		fileGenerationRules.setAccountValidFlag(true);
		fileGenerationRules.setIsFraudReportedFlag("N");
		fileGenerationRules.setIsADCNotifiedFlag("N");
		fileGenerationRules.setIsAlreadyReportedFlag("Y");
		fileGenerationRules.setIsDuplicateFlag("N");
		fileGenerationRules.setInputToRule(procRecord);
		new FileGenerationRules(fileGenerationRules);
		fileGenerationRulesOne = new FileGenerationRules();
		fileGenerationRulesOne.setIsAccountActiveFlag("Y");
		fileGenerationRulesOne.setAccountValidFlag(true);
		fileGenerationRulesOne.setIsFraudReportedFlag("N");
		fileGenerationRulesOne.setIsADCNotifiedFlag("N");
		fileGenerationRulesOne.setIsAlreadyReportedFlag("Y");
		fileGenerationRulesOne.setIsDuplicateFlag("N");
		fileGenerationRulesOne.setInputToRule(procRecord);
		new FileGenerationRules();
		new FileGenerationRules("");
		logger = Logger.getLogger(FileGenerationRules.class);
		logger.setLevel(Level.DEBUG);
		
	}
	
	@Test
	public void test() {
		assertEquals("Y",fileGenerationRules.getIsAccountActiveFlag());
		assertEquals(true,fileGenerationRules.isAccountValidFlag());
		assertEquals("N",fileGenerationRules.getIsFraudReportedFlag());
		assertEquals("N",fileGenerationRules.getIsADCNotifiedFlag());
		assertEquals("Y",fileGenerationRules.getIsAlreadyReportedFlag());
		assertEquals("N",fileGenerationRules.getIsDuplicateFlag());
	}
	@Test
	public void test1() {
		fileGenerationRules.evaluate();
		fileGenerationRules.execute();
	}
	@Test
	public void test2() {
		fileGenerationRules.setAccountValidFlag(false);
		fileGenerationRules.evaluate();
	}

	@Test
	public void testHashCode() {
		ReflectionTestUtils.invokeMethod(fileGenerationRules, "checkConditions", procRecord, true, true);
		assertEquals(-285144098,fileGenerationRules.hashCode());
	}
	
	@Test
	public void testEquals() {
		
		procRecord.setIsAccountADCNotified(null);
		procRecord.setAccountValid(false);
		procRecord.setBin(null);
		procRecord.setConfidenceScore(1);
		procRecord.setDaysSinceLastActivity(50);
		procRecord.setIca(null);
		procRecord.setIsAccountActive(null);
		procRecord.setIsFraudReported(null);
		procRecord.setIsReported(null);
		String date = "2000-11-01 00:00:00";
		java.sql.Timestamp javaSqlDate = java.sql.Timestamp.valueOf(date); 
		procRecord.setLastUpdatedDate(javaSqlDate);
		procRecord.setLastUpdatedUser(null);
		procRecord.setPan(new BigDecimal("25421221662123727"));
		procRecord.setPriceCategory(60);
		procRecord.setProcRawRecordKey(new BigDecimal("0"));
		procRecord.setProcRecordKey(new BigDecimal("0"));
		procRecord.setIsFraudReported(null);
		procRecord.setIsDuplicate(null);
		fileGenerationRules.equals(procRecord);
		fileGenerationRules.equals(fileGenerationRules);
		fileGenerationRules.equals(null);
		fileGenerationRules.equals(fileGenerationRulesOne);
		fileGenerationRules.setAccountValidFlag(false);
		fileGenerationRules.setDescription(null);
		fileGenerationRules.setInputToRule(procRecord);
		fileGenerationRules.setIsAccountActiveFlag(null);
		fileGenerationRules.setIsADCNotifiedFlag(null);
		fileGenerationRules.setIsAlreadyReportedFlag(null);
		fileGenerationRules.setIsDuplicateFlag(null);
		fileGenerationRules.setIsFraudReportedFlag(null);
		fileGenerationRules.setPriority(0);
		fileGenerationRules.equals(fileGenerationRulesOne);
		procRecord.setIsAccountADCNotified("N");
		procRecord.setAccountValid(true);
		procRecord.setBin("");
		procRecord.setConfidenceScore(-1);
		procRecord.setDaysSinceLastActivity(150);
		procRecord.setIca("");
		procRecord.setIsAccountActive("Y");
		procRecord.setIsFraudReported("N");
		procRecord.setIsReported("Y");
		String dateOne = "2000-11-01 00:00:00";
		java.sql.Timestamp javaSqlDateOne = java.sql.Timestamp.valueOf(dateOne); 
		procRecord.setLastUpdatedDate(javaSqlDateOne);
		procRecord.setLastUpdatedUser("");
		procRecord.setPan(new BigDecimal("625421221662123727"));
		procRecord.setPriceCategory(0);
		procRecord.setProcRawRecordKey(new BigDecimal("1"));
		procRecord.setProcRecordKey(new BigDecimal("1"));
		procRecord.setIsFraudReported("N");
		procRecord.setIsDuplicate("N");
		fileGenerationRules.setIsAccountActiveFlag("Y");
		fileGenerationRules.setAccountValidFlag(true);
		fileGenerationRules.setIsFraudReportedFlag("N");
		fileGenerationRules.setIsADCNotifiedFlag("N");
		fileGenerationRules.setIsAlreadyReportedFlag("Y");
		fileGenerationRules.setIsDuplicateFlag("N");
		fileGenerationRules.setInputToRule(procRecord);
		
		
	}
}
