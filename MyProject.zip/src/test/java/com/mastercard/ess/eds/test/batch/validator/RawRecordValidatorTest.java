package com.mastercard.ess.eds.test.batch.validator;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.item.validator.ValidationException;

import com.mastercard.ess.eds.batch.validator.RawRecordValidator;
import com.mastercard.ess.eds.domain.RawRecord;

public class RawRecordValidatorTest {
	
	RawRecordValidator rawRecordValidator;
	RawRecord rawRecord;
	
	@Before
	public void setUp(){
		rawRecord = new RawRecord();
		rawRecordValidator = new RawRecordValidator();
		try {
			rawRecordValidator.afterPropertiesSet();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Test (expected = ValidationException.class)
	public void testValidationInvalidPAN(){
		rawRecord.setRawPan("738473438498389059");
		rawRecordValidator.validate(rawRecord);
	}
	
	//19 digit PAN
	@Test
	public void testValidationValidPAN(){
		rawRecord.setRawPan("2221001234123450");
		ValidationException validationException = null;
		
		try{
		rawRecordValidator.validate(rawRecord);
		}catch(ValidationException e){
			validationException = e;
		}
		Assert.assertEquals(null,validationException);
	}
	
	//16 digit PAN
		@Test
		public void testValidationOtherValidPAN(){
			rawRecord.setRawPan("4012888888881881");
			ValidationException validationException = null;
			
			try{
			rawRecordValidator.validate(rawRecord);
			}catch(ValidationException e){
				validationException = e;
			}
			Assert.assertEquals(null,validationException);
		}
}
