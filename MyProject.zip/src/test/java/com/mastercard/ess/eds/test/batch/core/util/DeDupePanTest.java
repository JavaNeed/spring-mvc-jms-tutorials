package com.mastercard.ess.eds.test.batch.core.util;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.core.util.DeDupeLevels;
import com.mastercard.ess.eds.core.util.DeDupePan;
import com.mastercard.ess.eds.domain.PANMetadataRecord;

public class DeDupePanTest {
	
	private DeDupePan deDupePan = null;
	
	@Before
	public void setUp() {
		deDupePan = DeDupePan.getInstance();
	}
	
	@Test
	public void testIsDuplicate(){
		PANMetadataRecord panMetadataRecord = new PANMetadataRecord();
		panMetadataRecord.setPan("777");
		assertEquals(false, deDupePan.isDuplicate(panMetadataRecord, DeDupeLevels.LEVEL_LOCAL));
	}
	
	@Test
	public void testIsDuplicateWithAdd(){
		PANMetadataRecord panMetadataRecord = new PANMetadataRecord();
		panMetadataRecord.setPan("345");
		deDupePan.isDuplicate(panMetadataRecord, DeDupeLevels.LEVEL_LOCAL);
		deDupePan.addPan(panMetadataRecord, DeDupeLevels.LEVEL_LOCAL );
		assertEquals(true, deDupePan.isDuplicate(panMetadataRecord, DeDupeLevels.LEVEL_LOCAL));
	}
	
	@Test
	public void testAddBulk(){
		List<PANMetadataRecord> panMetadataRecordList = new ArrayList<PANMetadataRecord>();
		PANMetadataRecord panMetadataRecord1 = new PANMetadataRecord();
		panMetadataRecord1.setPan("999");
		PANMetadataRecord panMetadataRecord2 = new PANMetadataRecord();
		panMetadataRecord2.setPan("888");
		panMetadataRecordList.add(panMetadataRecord1);
		panMetadataRecordList.add(panMetadataRecord2);
		deDupePan.addPanInBulk(panMetadataRecordList, DeDupeLevels.LEVEL_LOCAL );
		assertEquals(true, deDupePan.isDuplicate(panMetadataRecord1, DeDupeLevels.LEVEL_LOCAL));
		assertEquals(true, deDupePan.isDuplicate(panMetadataRecord2, DeDupeLevels.LEVEL_LOCAL));
	}
	
	
}
