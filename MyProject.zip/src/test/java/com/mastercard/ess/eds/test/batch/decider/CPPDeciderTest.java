package com.mastercard.ess.eds.test.batch.decider;

import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.decider.CPPDecider;

public class CPPDeciderTest {
	CPPDecider cPPDecider;
	JobExecution jobExecution;
	JobInstance jobInstance;
	StepContribution stepContribution;
	ChunkContext chunkContext;
	StepExecution stepExecutionStatus;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	ExecutionContext executionContext;
	String cppRunMode;

	@Test
	public void testDecideSimulation() throws Exception {
		cPPDecider=new CPPDecider();
		jobInstance = new JobInstance(new Long(123), "decide");
		cppRunMode="SIMULATION";
		Map<String, JobParameter> parameters = new LinkedHashMap<>();
		jobParameter = new JobParameter(cppRunMode, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);
		jobExecution = new JobExecution(jobInstance, jobParameters);
		executionContext=new ExecutionContext();
		executionContext.put("cppRunMode", "SIMULATION");
		jobExecution.setExecutionContext(executionContext);
		stepExecutionStatus = new StepExecution("cPPDecider", jobExecution);
		stepContext = new StepContext(stepExecutionStatus);
		chunkContext = new ChunkContext(stepContext);
		stepContribution = new StepContribution(stepExecutionStatus);
		cPPDecider.decide(jobExecution, stepExecutionStatus);
	}

	@Test
	public void testDecideExecution() {
		cPPDecider=new CPPDecider();
		jobInstance = new JobInstance(new Long(123), "decide");
		Map<String, JobParameter> parameters = new LinkedHashMap<>();
		jobParameter = new JobParameter(cppRunMode, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);
		jobExecution = new JobExecution(jobInstance, jobParameters);
		executionContext=new ExecutionContext();
		executionContext.put("cppRunMode", "EXECUTION");
		jobExecution.setExecutionContext(executionContext);
		stepExecutionStatus = new StepExecution("cPPDecider", jobExecution);
		stepContext = new StepContext(stepExecutionStatus);
		chunkContext = new ChunkContext(stepContext);
		stepContribution = new StepContribution(stepExecutionStatus);
		cPPDecider.decide(jobExecution, stepExecutionStatus);
	}

}
