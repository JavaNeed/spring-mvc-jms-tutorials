package com.mastercard.ess.eds.test.batch.processor;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.easyrules.api.RulesEngine;
import org.easyrules.core.RulesEngineBuilder;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.batch.processor.PriceCategoryProcessor;
import com.mastercard.ess.eds.core.dao.PriceCategoryDAO;
import com.mastercard.ess.eds.core.rule.PriceCategoryRule;
import com.mastercard.ess.eds.core.util.PriceCategoryRuleCache;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.EDSSourceType;
import com.mastercard.ess.eds.domain.ProcessedRecord;

/*
 * 
 * This is to test assigning price Category and Confidence score
 * 
 */
public class PriceCategoryProcessorTest {

	private static Logger logger = Logger.getLogger(PriceCategoryProcessor.class);

	private EDSRecord edsRecord;
	private ProcessedRecord procRecord;
	String date = "2000-11-01 00:00:00";
	java.sql.Timestamp javaSqlDate = java.sql.Timestamp.valueOf(date);

	private PriceCategoryRuleCache priceCategoryRuleCache;

	private PriceCategoryProcessor priceCategoryProcessor;

	private PriceCategoryDAO priceCategoryDao;

	private PriceCategoryRule priceCategoryRule1, priceCategoryRule2;
	private static int OriginalConfi = -1;
	int srcKey;
	private RulesEngine rulesEngine;
	EDSSourceType recordSourceType;
	EDSSourceType edsSourceType;

	private List<PriceCategoryRule> priceCategoryRuleList = new ArrayList<PriceCategoryRule>();

	@Before
	public void setUp() throws Exception {
		logger.setLevel(Level.DEBUG);

		rulesEngine = RulesEngineBuilder.aNewRulesEngine().build();
		priceCategoryRule1 = new PriceCategoryRule("rule_1");
		priceCategoryRule2 = new PriceCategoryRule("rule_2");

		priceCategoryRule1.setOperand1(new BigDecimal(90));
		priceCategoryRule1.setOperator1(">");
		priceCategoryRule1.setOperand2(new BigDecimal(180));
		priceCategoryRule1.setOperator2("<");
		priceCategoryRule1.setAdcNotified("N");

		priceCategoryRule1.setExternal("Y");
		priceCategoryRule1.setDerived("Y");
		priceCategoryRule1.setPriceCategory(2);
		priceCategoryRule1.setConfidenceScore(65);

		priceCategoryRule2.setOperand1(new BigDecimal(100));
		priceCategoryRule2.setOperator1(">");
		priceCategoryRule2.setOperand2(new BigDecimal(300));
		priceCategoryRule2.setOperator2("<");
		priceCategoryRule2.setAdcNotified("N");

		priceCategoryRule2.setExternal("Y");
		priceCategoryRule2.setDerived("N");
		priceCategoryRule2.setPriceCategory(3);
		priceCategoryRule2.setConfidenceScore(75);

		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String dateInString = "07/06/2013";

		Date date = formatter.parse(dateInString);

		priceCategoryRuleCache = EasyMock.createMock(PriceCategoryRuleCache.class);
		priceCategoryDao = EasyMock.createMock(PriceCategoryDAO.class);

		priceCategoryRule1.setStartDate(date);
		priceCategoryRule2.setStartDate(date);
		priceCategoryRule1.setEndDate((new java.util.Date(Calendar.getInstance().getTime().getTime())));

		priceCategoryProcessor = new PriceCategoryProcessor(priceCategoryRuleCache, priceCategoryDao);
		procRecord = new ProcessedRecord();
		procRecord.setIsAccountADCNotified("N");
		procRecord.setIsDerived("N");
		procRecord.setIsExternal("N");
		procRecord.setAccountValid(true);
		procRecord.setBin("");
		procRecord.setConfidenceScore(-1);
		procRecord.setDaysSinceLastActivity(150);
		procRecord.setIca("");
		procRecord.setIsAccountActive("Y");
		procRecord.setIsFraudReported("N");
		procRecord.setLastUpdatedDate(javaSqlDate);
		procRecord.setLastUpdatedUser("");
		procRecord.setPan(new BigDecimal("625421221662123727"));
		procRecord.setPriceCategory(0);
		procRecord.setProcRawRecordKey(new BigDecimal("1"));
		procRecord.setProcRecordKey(new BigDecimal("1"));
		edsRecord = new EDSRecord();
		edsRecord.setProcRecord(procRecord);
		edsSourceType = new EDSSourceType();
		edsSourceType.setDescr("File from GFT Endpoint");
		edsSourceType.setExternal(true);
		edsSourceType.setDerived(false);
		edsSourceType.setLocation("E1234567");
		edsSourceType.setProvider("Terbium");
		edsSourceType.setPurgedReqd(true);
		edsSourceType.setType("file");
		procRecord.setEdsSourceType(edsSourceType);
		priceCategoryRuleList.add(priceCategoryRule1);
		priceCategoryRuleList.add(priceCategoryRule2);

		EasyMock.expect(priceCategoryRuleCache.getCache()).andReturn(priceCategoryRuleList);

		EasyMock.replay(priceCategoryRuleCache);

		EasyMock.expect(priceCategoryDao.getEDSSourceType(1)).andReturn(edsSourceType);
		EasyMock.replay(priceCategoryDao);
	}

	@Test
	public void testProcess() throws Exception {

		logger.setLevel(Level.DEBUG);

		EDSRecord record = priceCategoryProcessor.process(edsRecord);

		Assert.assertEquals(0, record.getProcRecord().getPriceCategory());

	}
	
	@Test
	public void testNull() throws Exception {
		logger.setLevel(Level.DEBUG);
		EDSRecord record = null;
		priceCategoryProcessor.process(record);
		
	}

}
