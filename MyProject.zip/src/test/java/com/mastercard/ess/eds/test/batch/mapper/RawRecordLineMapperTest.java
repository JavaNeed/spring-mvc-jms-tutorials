package com.mastercard.ess.eds.test.batch.mapper;

import static org.junit.Assert.assertEquals;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.item.file.transform.DefaultFieldSet;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.validation.BindException;

import com.mastercard.ess.eds.batch.mapper.RawRecordFieldSetMapper;
import com.mastercard.ess.eds.batch.mapper.RawRecordLineMapper;
import com.mastercard.ess.eds.core.parser.VendorPayloadTokens;
import com.mastercard.ess.eds.domain.RawRecord;

public class RawRecordLineMapperTest {
	
	private Logger logger = Logger.getLogger(RawRecordLineMapper.class);
	
	RawRecordLineMapper rawRecordLineMapper;
	RawRecordFieldSetMapper rawRecordFieldSetMapper;
	RawRecord rawRecord;

	@Before
	public void init() {
		rawRecordLineMapper = new RawRecordLineMapper();
		rawRecord = new RawRecord(new HashMap<String,String>());
		rawRecordFieldSetMapper = new RawRecordFieldSetMapper();
		rawRecord.addPayloadEntry(VendorPayloadTokens.CWID.getDesc(), "1");
		rawRecord.addPayloadEntry(VendorPayloadTokens.URL.getDesc(), "2");
		rawRecord.setRawPan("3");
		rawRecord.addPayloadEntry(VendorPayloadTokens.RAW_DATA.getDesc(), "4");
		
		rawRecord.setStatus(4);
		rawRecord.setLastUpdateDate(new  Date());
		
	}

	@Test
	public void testAfterPropertiesSet() throws Exception {
		final String line = "1,2,3::4";                                                  
		final FieldSet fieldSet = new DefaultFieldSet(new String[] {"1","2","3::4"}, new String[] {"cwid", "url", "value"}); 
		LineTokenizer tokenizer = EasyMock.createStrictMock(LineTokenizer.class);             
		EasyMock.expect(tokenizer.tokenize(line)).andReturn(fieldSet);                              
		EasyMock.replay(tokenizer);   
		rawRecordFieldSetMapper = EasyMock.createMock(RawRecordFieldSetMapper.class);
		EasyMock.expect(rawRecordFieldSetMapper.mapFieldSet(fieldSet)).andReturn(rawRecord);                                       
		EasyMock.replay(rawRecordFieldSetMapper);                                                                       
		rawRecordLineMapper.setLineTokenizer(tokenizer);
		rawRecordLineMapper.setFieldSetMapper(rawRecordFieldSetMapper);  
		rawRecordLineMapper.afterPropertiesSet();
	}
	
	@Test
	public void mapLine() throws Exception {
		final String line = "1,2,3::4";                                                  
		final FieldSet fieldSet = new DefaultFieldSet(new String[] {"1","2","3::4"}, new String[] {"cwid", "url", "value"});                                                 
		                                                                             
		LineTokenizer tokenizer = EasyMock.createStrictMock(LineTokenizer.class);             
		EasyMock.expect(tokenizer.tokenize(line)).andReturn(fieldSet);                              
		EasyMock.replay(tokenizer);   
		rawRecordFieldSetMapper = EasyMock.createMock(RawRecordFieldSetMapper.class);
		EasyMock.expect(rawRecordFieldSetMapper.mapFieldSet(fieldSet)).andReturn(rawRecord);                                       
		EasyMock.replay(rawRecordFieldSetMapper);                                                                       
		rawRecordLineMapper.setLineTokenizer(tokenizer);
		rawRecordLineMapper.setFieldSetMapper(rawRecordFieldSetMapper);                                          
		              
			RawRecord actualRawRecord = rawRecordLineMapper.mapLine(line, 2);
			rawRecord.setLastUpdateDate(actualRawRecord.getLastUpdateDate());
			assertEquals(rawRecord.getPayloadValue(VendorPayloadTokens.CWID.getDesc()), actualRawRecord.getPayloadValue(VendorPayloadTokens.CWID.getDesc()));
			assertEquals(rawRecord.getPayloadValue(VendorPayloadTokens.URL.getDesc()), actualRawRecord.getPayloadValue(VendorPayloadTokens.URL.getDesc()));
			assertEquals(rawRecord.getPayloadValue(VendorPayloadTokens.RAW_DATA.getDesc()), actualRawRecord.getPayloadValue(VendorPayloadTokens.RAW_DATA.getDesc()));
			assertEquals(rawRecord.getRawPan(), actualRawRecord.getRawPan());
			assertEquals(rawRecord.getStatus(), actualRawRecord.getStatus());
			assertEquals(rawRecord.getLastUpdateDate(), actualRawRecord.getLastUpdateDate());
	}
	
	@Test
	public void mapLineOne() {
		final String line = "1,2,3::4";                                                  
		final FieldSet fieldSet = new DefaultFieldSet(new String[] {"1","2","3::4"}, new String[] {"cwid", "url", "value"});                                                 
		                                                                             
		LineTokenizer tokenizer = EasyMock.createStrictMock(LineTokenizer.class);             
		EasyMock.expect(tokenizer.tokenize(line)).andReturn(fieldSet);                              
		EasyMock.replay(tokenizer);                                                                         
		rawRecordLineMapper.setLineTokenizer(tokenizer);
		rawRecordLineMapper.setFieldSetMapper(new RawRecordFieldSetMapper());                                          
		     try{         
			RawRecord actualRawRecord = rawRecordLineMapper.mapLine(line, 2);
			rawRecord.setLastUpdateDate(actualRawRecord.getLastUpdateDate());
			assertEquals(rawRecord.getPayloadValue(VendorPayloadTokens.CWID.getDesc()), actualRawRecord.getPayloadValue(VendorPayloadTokens.CWID.getDesc()));
			assertEquals(rawRecord.getPayloadValue(VendorPayloadTokens.URL.getDesc()), actualRawRecord.getPayloadValue(VendorPayloadTokens.URL.getDesc()));
			assertEquals(rawRecord.getPayloadValue(VendorPayloadTokens.RAW_DATA.getDesc()), actualRawRecord.getPayloadValue(VendorPayloadTokens.RAW_DATA.getDesc()));
			assertEquals(rawRecord.getRawPan(), actualRawRecord.getRawPan());
			assertEquals(rawRecord.getStatus(), actualRawRecord.getStatus());
			assertEquals(rawRecord.getLastUpdateDate(), actualRawRecord.getLastUpdateDate());
		     
	}
		     catch(Exception e) {
		    	 e.printStackTrace();
		     }
}
}
