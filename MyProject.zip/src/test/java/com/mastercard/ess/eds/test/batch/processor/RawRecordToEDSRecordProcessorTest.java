package com.mastercard.ess.eds.test.batch.processor;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.mastercard.ess.eds.batch.processor.RawRecordToEDSRecordProcessor;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.RawRecord;

public class RawRecordToEDSRecordProcessorTest {

	private static Logger logger = Logger.getLogger(RawRecordToEDSRecordProcessor.class);
	
	private RawRecord rawRecord;
	
	@InjectMocks
	private RawRecordToEDSRecordProcessor rawRecordToEDSRecordProcessor = new RawRecordToEDSRecordProcessor();
	
	@Before
    public void setUp() throws Exception {		
		MockitoAnnotations.initMocks(this);		
		rawRecord = new RawRecord();		
	}
	
	@Test
	public void testProcess() throws Exception{
		logger.setLevel(Level.DEBUG);
		EDSRecord edsrecord = rawRecordToEDSRecordProcessor.process(rawRecord);
		Assert.assertNotNull(edsrecord);
	}
}
