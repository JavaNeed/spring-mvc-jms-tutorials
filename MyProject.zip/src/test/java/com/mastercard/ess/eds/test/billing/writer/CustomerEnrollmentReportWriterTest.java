package com.mastercard.ess.eds.test.billing.writer;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList; 
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;

import com.mastercard.ess.eds.billing.writer.CustomerEnrollmentReportWriter;
import com.mastercard.ess.eds.core.service.CustomerFileReportService;
import com.mastercard.ess.eds.core.util.CustomerEnrollmentReportGenerator;
import com.mastercard.ess.eds.domain.CustomerEnrollmentReport;

public class CustomerEnrollmentReportWriterTest {
	private static Logger logger = Logger.getLogger(CustomerEnrollmentReportWriter.class);

	CustomerEnrollmentReportWriter customerEnrollmentReportWriter;
	CustomerEnrollmentReportGenerator customerEnrollmentReportGenerator;
	StepExecution stepExecution;
	CustomerEnrollmentReport customerEnrollmentReport;
	List<CustomerEnrollmentReport> customerEnrollmentReportList;
	BigDecimal jobInstanceId;
	String jobInstanceName;
	String stepName;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobInstance jobInstance;
	JobExecution jobExecution;
	CustomerFileReportService customerFileReportService;
	static String customerEnrollmentReportPath="..";


	@Before
	public void init() {
		logger.setLevel(Level.DEBUG);
		customerEnrollmentReportGenerator=new CustomerEnrollmentReportGenerator();
		customerEnrollmentReportGenerator.setCustomerEnrollmentReportPath("");
		customerEnrollmentReportWriter=new CustomerEnrollmentReportWriter();
		customerEnrollmentReportList = new ArrayList<CustomerEnrollmentReport>();

		jobInstance = new JobInstance(new Long(123), "importRawRecords");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("shiv",jobExecution);


	}
	@Test
	public void test() throws Exception
	{
		logger.setLevel(Level.DEBUG);

		customerEnrollmentReportGenerator = new CustomerEnrollmentReportGenerator(customerEnrollmentReportPath, customerFileReportService);
		customerEnrollmentReportGenerator = EasyMock.createMock(CustomerEnrollmentReportGenerator.class);
		customerEnrollmentReportWriter.setGenerated(true);
		customerEnrollmentReportWriter.afterStep(stepExecution);
		customerEnrollmentReportWriter.beforeStep(stepExecution);

		customerEnrollmentReportWriter.setJobInstanceId(null);
		assertEquals(jobInstanceId, customerEnrollmentReportWriter.getJobInstanceId());
		customerEnrollmentReportWriter.setJobInstanceName(null);
		assertEquals(jobInstanceName,customerEnrollmentReportWriter.getJobInstanceName());

		customerEnrollmentReportWriter.setStepExecution(stepExecution);
		assertEquals(stepExecution,customerEnrollmentReportWriter.getStepExcecution());
		customerEnrollmentReportWriter.setCustomerEnrollmentReportGenerator(customerEnrollmentReportGenerator);
		customerEnrollmentReportWriter.write(customerEnrollmentReportList);


	}



	@Test
	public void test1() throws Exception
	{
		logger.setLevel(Level.DEBUG);
		customerEnrollmentReportGenerator = new CustomerEnrollmentReportGenerator(customerEnrollmentReportPath, customerFileReportService);
		customerEnrollmentReportGenerator = EasyMock.createMock(CustomerEnrollmentReportGenerator.class);
		customerEnrollmentReportGenerator.writeToCustomerEnrollmentReport(customerEnrollmentReportList, jobInstanceId, jobInstanceName);
		EasyMock.expectLastCall();
		EasyMock.replay(customerEnrollmentReportGenerator);
		customerEnrollmentReportGenerator.writeToCustomerEnrollmentReport(customerEnrollmentReportList, jobInstanceId, jobInstanceName);
		logger.setLevel(Level.DEBUG);
	}

	//We will delete the Customer_Enrollment_Report from classpath in after block
	@AfterClass
	public static void  checkFileDeletion() {
		try {
			File[] dirFiles = new File(".").listFiles();
			// Search Through the list 
			for (int i = 0; i < dirFiles.length; i++) { // If the Files start

				if (dirFiles[i].getName().startsWith("..Customer_Enrollment_Report_", 0) || dirFiles[i].getName().startsWith("Customer_Enrollment_Report_", 0))
					try {
						File file = new File(dirFiles[i].getName());

						if (file.delete()) {
							logger.info("Test CustomerDelivery File is deleted in after block for file :"+file);		

						} else {
							File file1 = new File(customerEnrollmentReportPath+dirFiles[i].getName());
							file1.delete();
							logger.info("Test CustomerDelivery File is deleted in after block for file :"+file1);		
						}

					} catch (Exception e) {
						e.printStackTrace();
					}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}


