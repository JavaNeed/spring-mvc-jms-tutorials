package com.mastercard.ess.eds.test.batch.core.util;


import java.math.BigDecimal;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mastercard.ess.eds.batch.config.EnvironmentConfig;
import com.mastercard.ess.eds.core.dao.EDSSourceDao;
import com.mastercard.ess.eds.core.service.EDSSourceService;
import com.mastercard.ess.eds.core.util.PreProcessingPANStatusManager;
import com.mastercard.ess.eds.test.batch.config.CommonConfigTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {EnvironmentConfig.class,CommonConfigTest.class})
@ActiveProfiles(value="dev")
public class PreProcessingPANStatusManagerTest {
	
	private Logger logger = Logger.getLogger(PreProcessingPANStatusManager.class);
	
	@Autowired
	private JobLauncherTestUtils jobLauncherTestUtils;

	@Autowired 
   ApplicationContext context;
	
	JobExecution jobExecution;
	JobInstance jobInstance;
	StepContribution stepContribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	PreProcessingPANStatusManager preProcessPANStatusManager;
	EDSSourceService edsSourceService;
	EDSSourceDao edsSourceDao;
	
	@Before
	public void init(){
		logger.setLevel(Level.DEBUG);
		jobInstance = new JobInstance(new Long(123), "panProcessJob");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("prePANProcessingUpdateStatus", jobExecution);
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		stepContribution = new StepContribution(stepExecution);
		preProcessPANStatusManager = new PreProcessingPANStatusManager();
		edsSourceDao = EasyMock.createMock(EDSSourceDao.class);
		edsSourceService = new EDSSourceService(edsSourceDao);
		preProcessPANStatusManager.setEDSSourceService(edsSourceService);
		preProcessPANStatusManager.setJobInstanceId(BigDecimal.valueOf(123));
	}
	
	@Test
	public void testStepLaunch() throws Exception{
		logger.setLevel(Level.DEBUG);
		Job job = (Job) context.getBean("panProcessJob");
		jobLauncherTestUtils.setJob(job);
		JobExecution jobExecution = jobLauncherTestUtils.launchStep("prePANProcessingUpdateStatus");
		assert jobExecution.getStatus().equals(BatchStatus.COMPLETED) || jobExecution.getStatus().equals(BatchStatus.FAILED);
	}
	
	@Test
	public void testExecute(){
	
		try {
			preProcessPANStatusManager.execute(stepContribution, chunkContext);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
