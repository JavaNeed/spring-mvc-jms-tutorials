package com.mastercard.ess.eds.test.batch.processor;

import java.math.BigDecimal;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Test;

import com.mastercard.ess.eds.batch.exception.InvalidCPPRecordException;
import com.mastercard.ess.eds.batch.processor.ValidateCPPRecordProcessor;
import com.mastercard.ess.eds.core.util.EDSSourceRuleDataCache;
import com.mastercard.ess.eds.core.util.RuleCatCdRecord;
import com.mastercard.ess.eds.domain.RawRecord;

public class ValidateCPPRecordProcessorTest {
	ValidateCPPRecordProcessor validateCPPRecordProcessor;
	RawRecord rawRecord;
	EDSSourceRuleDataCache eDSSourceRuleDataCache;
	RuleCatCdRecord ruleCatCdRecord;
	private static Logger logger = Logger.getLogger(ValidateCPPRecordProcessor.class);
	
	@Test (expected=InvalidCPPRecordException.class)
	public void testProcess() throws Exception {
		logger.setLevel(Level.DEBUG);
		validateCPPRecordProcessor=new ValidateCPPRecordProcessor();
		eDSSourceRuleDataCache=EasyMock.createMock(EDSSourceRuleDataCache.class);
		EasyMock.expect(eDSSourceRuleDataCache.getResult(new Long(1234))).andReturn(null);
		EasyMock.replay(eDSSourceRuleDataCache);
		validateCPPRecordProcessor.seteDSSourceRuleDataCache(eDSSourceRuleDataCache);
		rawRecord=new RawRecord();
		rawRecord.setDerivedSw("Y");
		rawRecord.setSrc_data_ky(new BigDecimal(1234));
		validateCPPRecordProcessor.process(rawRecord);
	}
	
	@Test 
	public void testProcess1() throws Exception {
		logger.setLevel(Level.DEBUG);
		validateCPPRecordProcessor=new ValidateCPPRecordProcessor();
		RuleCatCdRecord ruleCatCdRecord=new RuleCatCdRecord(new Long(1), "5");
		eDSSourceRuleDataCache=EasyMock.createMock(EDSSourceRuleDataCache.class);
		EasyMock.expect(eDSSourceRuleDataCache.getResult(new Long(1))).andReturn(ruleCatCdRecord);
		EasyMock.replay(eDSSourceRuleDataCache);
		validateCPPRecordProcessor.seteDSSourceRuleDataCache(eDSSourceRuleDataCache);
		rawRecord=new RawRecord();
		rawRecord.setDerivedSw("N");
		rawRecord.setSrc_data_ky(new BigDecimal(1));
		validateCPPRecordProcessor.process(rawRecord);
	}
}
