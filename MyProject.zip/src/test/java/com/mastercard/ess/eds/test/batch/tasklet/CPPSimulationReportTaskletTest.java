package com.mastercard.ess.eds.test.batch.tasklet;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.tasklet.CPPSimulationReportTasklet;
import com.mastercard.ess.eds.core.service.CPPSimulationService;
import com.mastercard.ess.eds.core.util.CPPSimulationReportGenerator;

public class CPPSimulationReportTaskletTest {
	CPPSimulationService cppSimulationService;
	CPPSimulationReportGenerator cppSimulationReportGenerator ;
	CPPSimulationReportTasklet cPPSimulationReportTasklet;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	StepContribution stepContribution;
	ExecutionContext executionContext;
	Logger logger = Logger.getLogger(CPPSimulationReportTaskletTest.class);

	@Before
	public void setUp()
	{

		logger.setLevel(Level.DEBUG);
		cPPSimulationReportTasklet=new CPPSimulationReportTasklet();
		String jobInstanceName="cppSimulation";
		Map<String, JobParameter> parameters = new LinkedHashMap<>();
		jobParameter = new JobParameter(jobInstanceName, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);
		executionContext=new ExecutionContext();
		executionContext.put("edsSimSrcId", "12");
		jobInstance = new JobInstance(new Long(123), "cppReport");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		jobExecution.setExecutionContext(executionContext);
		stepExecution = new StepExecution("cppReport", jobExecution);
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		stepContribution = new StepContribution(stepExecution);
		cppSimulationService=EasyMock.createMock(CPPSimulationService.class);
		cppSimulationReportGenerator=EasyMock.createMock(CPPSimulationReportGenerator.class);
		cPPSimulationReportTasklet.setCppSimulationReportGenerator(cppSimulationReportGenerator);
		cPPSimulationReportTasklet.setCppSimulationService(cppSimulationService);

	}
	@Test
	public void executeTest() throws Exception
	{

		cPPSimulationReportTasklet.execute(stepContribution, chunkContext);

	}

}
