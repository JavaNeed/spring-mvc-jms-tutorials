package com.mastercard.ess.eds.test.batch.tasklet;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.activation.DataSource;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;

import com.mastercard.ess.eds.batch.tasklet.CustomerEnrollmentReportTasklet;
import com.mastercard.ess.eds.core.dao.CustomerEnrollmentReportDao;
import com.mastercard.ess.eds.core.dao.CustomerMasterDAO;
import com.mastercard.ess.eds.core.service.CustomerMasterService;

public class CustomerEnrollmentReportTaskletTest {
    CustomerEnrollmentReportTasklet customerEnrollmentReportTasklet;
    CustomerMasterService customerMasterService;
    CustomerEnrollmentReportDao customerEnrollmentReportDao;
    List<Map<String, Object>> enrolledCustomerDetail;
    Map<String, Integer> UnEnrolledCustomerDetail;
    List<Map<String, Object>> ActiveCustomerDetail;
    StepContribution contribution;
    ChunkContext chunkContext;
    StepExecution stepExecution;
    DataSource dataSource;
    String stepName;
    JobExecution jobExecution;
    StepContext stepContext;
    CustomerMasterDAO customerMasterDAO;
    JobInstance jobInstance;
    JobParameters jobParameters;
    private static Logger logger = Logger.getLogger(CustomerEnrollmentReportTasklet.class);

    @Before
    public void init() {
        jobInstance = new JobInstance(new Long(123), "welcomeEmail");
        jobExecution = new JobExecution(jobInstance, jobParameters);
        stepExecution = new StepExecution("billdataFile", jobExecution);

        stepContext = new StepContext(stepExecution);
        chunkContext = new ChunkContext(stepContext);
        contribution = new StepContribution(stepExecution);

        List<Map<String, Object>> enrolledCustomerDetail = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> activeCustomerDetail = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> unEnrolledCustomerDetail = new ArrayList<Map<String, Object>>();
        customerMasterService = EasyMock.createMock(CustomerMasterService.class);
        customerEnrollmentReportDao = EasyMock.createMock(CustomerEnrollmentReportDao.class);
        logger.setLevel(Level.DEBUG);

        EasyMock.expect(customerMasterService.getEnrolledCustomerDetail()).andReturn(enrolledCustomerDetail);
        EasyMock.expect(customerMasterService.getActiveCustomerDetail()).andReturn(activeCustomerDetail);
        EasyMock.expect(customerMasterService.getUnEnrolledCustomerDetail()).andReturn(unEnrolledCustomerDetail);
        EasyMock.replay(customerMasterService);

        customerEnrollmentReportTasklet = new CustomerEnrollmentReportTasklet();
        customerEnrollmentReportTasklet.setCustomerMasterService(customerMasterService);
        customerEnrollmentReportTasklet.setCustomerEnrollmentReportDao(customerEnrollmentReportDao);

    }

    @Test
    public void testExecute() throws Exception {
        customerEnrollmentReportTasklet.execute(contribution, chunkContext);
    }
}
