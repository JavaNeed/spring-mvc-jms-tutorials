package com.mastercard.ess.eds.test.batch.tasklet;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.core.util.DeDupeInitTasklet;

public class DeDupeInitTaskletTest {
	DeDupeInitTasklet deDupeInitTasklet;
	StepContribution stepContribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobExecution jobExecution;
	JobInstance jobInstance;
	ExecutionContext executionContext;

	private static Logger logger = Logger.getLogger(DeDupeInitTasklet.class);
	
	@Before
	public void setUp() throws Exception {
		
		logger.setLevel(Level.DEBUG);
		jobInstance = new JobInstance(new Long(123), "DeDupeInitTaskletTest");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("deDupe", jobExecution);
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		stepContribution = new StepContribution(stepExecution);
		executionContext=new ExecutionContext();
		deDupeInitTasklet=new DeDupeInitTasklet();
	
	}
	@Test
	public void testExecute() throws Exception {
		deDupeInitTasklet.execute(stepContribution, chunkContext);
	}

}
