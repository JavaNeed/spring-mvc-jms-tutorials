package com.mastercard.ess.eds.test.batch.listener;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;

import com.mastercard.ess.eds.batch.listener.RawRecordReadWriteStepListener;
import com.mastercard.ess.eds.core.dao.EDSSourceDao;
import com.mastercard.ess.eds.core.service.EDSSourceService;




public class RawRecordReadWriteStepListenerTest {
	
	RawRecordReadWriteStepListener rawRecordReadWriteStepListener;
	EDSSourceService edsSourceService;
	EDSSourceDao edsSourceDao;
	StepExecution stepExecution;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	Logger logger;
	
	@Before
	public void init(){
		logger = Logger.getLogger(RawRecordReadWriteStepListener.class);
		logger.setLevel(Level.DEBUG);
		edsSourceDao = EasyMock.createMock(EDSSourceDao.class);
		edsSourceService = new EDSSourceService(edsSourceDao);
		rawRecordReadWriteStepListener = new RawRecordReadWriteStepListener();
		rawRecordReadWriteStepListener = new RawRecordReadWriteStepListener(edsSourceService);
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		String fileName = "MastercardPilot_100778.txt";
		jobInstance = new JobInstance(new Long(123), "importRawRecords");
		jobParameter = new JobParameter(fileName, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("loadRawRecords", jobExecution);
		stepExecution.setStatus(BatchStatus.COMPLETED);
		
	}

	@Test
	public void afterStepTest() {
		ExitStatus statusActual = rawRecordReadWriteStepListener.afterStep(stepExecution);
		assertEquals(ExitStatus.COMPLETED,statusActual);
	}
	
	@Test
	public void setJobInstanceId() {
		BigDecimal bd = new BigDecimal(1231423);
		rawRecordReadWriteStepListener.setJobInstanceId(bd);
	}
	
	@Test
	public void testBeforeStep() {
		 rawRecordReadWriteStepListener.beforeStep(stepExecution);
	}
}
