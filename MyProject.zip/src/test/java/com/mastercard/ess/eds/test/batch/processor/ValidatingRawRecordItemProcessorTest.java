package com.mastercard.ess.eds.test.batch.processor;


import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.mock;
import org.junit.Test;
import static org.mockito.Mockito.when;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.batch.item.validator.ValidationException;

import com.mastercard.ess.eds.batch.processor.ValidatingRawRecordItemProcessor;
import com.mastercard.ess.eds.batch.validator.RawRecordValidator;
import com.mastercard.ess.eds.domain.RawRecord;

public class ValidatingRawRecordItemProcessorTest {

	Logger logger = Logger.getLogger(ValidatingRawRecordItemProcessor.class);
	private RawRecordValidator validator = mock(RawRecordValidator.class);

	@Test
	public void testSuccessfulValidation() throws Exception {
		logger.setLevel(Level.DEBUG);
		ValidatingRawRecordItemProcessor validatingRawRecordItemProcessor = new ValidatingRawRecordItemProcessor();
		validatingRawRecordItemProcessor.setValidator(validator);
		validatingRawRecordItemProcessor.getValidator();

		RawRecord rawRecord = new RawRecord();
		validator.validate(rawRecord);

		assertSame(rawRecord, validatingRawRecordItemProcessor.process(rawRecord));
	}
	
	@Test(expected = ValidationException.class)
	public void testFailedValidation() throws Exception {
		logger.setLevel(Level.DEBUG);
		ValidatingRawRecordItemProcessor validatingRawRecordItemProcessor = new ValidatingRawRecordItemProcessor();
		validatingRawRecordItemProcessor.setValidator(validator);

		processFailedValidation(validatingRawRecordItemProcessor);
	}

	private RawRecord processFailedValidation(ValidatingRawRecordItemProcessor validatingRawRecordItemProcessor) {
		RawRecord rawRecord = new RawRecord();
		validator.validate(rawRecord);
		when(validator).thenThrow(new ValidationException("invalid raw record"));

		return validatingRawRecordItemProcessor.process(rawRecord);
		
	}
}
