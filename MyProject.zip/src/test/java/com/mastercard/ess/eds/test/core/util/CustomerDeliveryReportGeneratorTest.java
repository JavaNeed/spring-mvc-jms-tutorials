package com.mastercard.ess.eds.test.core.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.easymock.EasyMock;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.test.util.ReflectionTestUtils;

import com.mastercard.ess.eds.core.dao.CustomerPanReportDao;
import com.mastercard.ess.eds.core.service.CustomerFileReportService;
import com.mastercard.ess.eds.core.util.CustomerDeliveryReportGenerator;
import com.mastercard.ess.eds.domain.CustomerDeliveryReportRecord;


public class CustomerDeliveryReportGeneratorTest {
	private static Logger logger = Logger.getLogger(CustomerDeliveryReportGeneratorTest.class);

	CustomerDeliveryReportGenerator customerDeliveryReportGenerator;
	CustomerDeliveryReportRecord customerDeliveryReportRecord;
	CustomerDeliveryReportRecord customerDeliveryReportRecord1;
	CustomerFileReportService customerFileReportService;
	CustomerPanReportDao customerPanReportDao;
	List<CustomerDeliveryReportRecord> customerDeliveryReportRecordList;
	Map<String, Map<Integer, List<Object>>> contimenMap;

	Sheet sheet;
	Workbook workbook;
	Row row;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	BigDecimal jobInstanceId;
	String jobInstanceName;
	String filePath;
	static String customerDeliveryReportPath="..";
	private static final String MMM_YYYY = "MMM-yyyy"; 

	@Before
	public void init() {
		logger.setLevel(Level.DEBUG);
		customerFileReportService = EasyMock.createMock(CustomerFileReportService.class);
		customerDeliveryReportGenerator=new CustomerDeliveryReportGenerator(customerDeliveryReportPath, customerFileReportService);
		String fileName = "file:///MCI.AR.RABC.X.E1234567.D160812.T111135.C001";
		Map<String, JobParameter> parameters = new LinkedHashMap<>();
		jobParameter = new JobParameter(fileName, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);
		jobInstanceId = BigDecimal.valueOf(1);
		jobInstanceName = "CustomerDeliveryReportGenerator";
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("CustomerDeliveryReportGenerator", jobExecution);

		stepContext = new StepContext(stepExecution);

		List<Object> panCountForMonthList1=new LinkedList<>();
		panCountForMonthList1.add(120);panCountForMonthList1.add(10);panCountForMonthList1.add(0);panCountForMonthList1.add(50);panCountForMonthList1.add(85);

		List<Object> panCountForMonthList2=new LinkedList<>();
		panCountForMonthList2.add(120);panCountForMonthList2.add(10);panCountForMonthList2.add(0);panCountForMonthList2.add(50);panCountForMonthList2.add(85);

		contimenMap=new LinkedHashMap<>();
		Map<Integer, List<Object>> prizingMap=new TreeMap<>();
		prizingMap.put(1,panCountForMonthList1 );
		Map<Integer, List<Object>> prizingMap2=new TreeMap<>();

		prizingMap2.put(2, panCountForMonthList2);
		contimenMap.put("A", prizingMap);
		contimenMap.put("a", prizingMap2);
		Calendar currentCal = Calendar.getInstance();  
		DateFormat dateFormat = new SimpleDateFormat(MMM_YYYY);
		String currentMonth=dateFormat.format(currentCal.getTime());
		filePath =  "..Customer_Internal_DeliveryReport"+ "_" + currentMonth + ".xlsx";
	}
	@Test
	public void testWriteToCustomerDeliveryReport() {

		logger.setLevel(Level.DEBUG);

		customerFileReportService = EasyMock.createMock(CustomerFileReportService.class);

		EasyMock.expect(customerFileReportService.createGeneratedFileRecord(filePath,
				new BigDecimal(1), jobInstanceName, 5)).andReturn(1);
		EasyMock.replay(customerFileReportService);

		customerDeliveryReportGenerator = new CustomerDeliveryReportGenerator();
		customerDeliveryReportGenerator = new CustomerDeliveryReportGenerator(customerDeliveryReportPath,customerFileReportService);
		assertFalse(contimenMap.get("A").isEmpty());		
		customerDeliveryReportGenerator.writeToCustomerDeliveryReport( contimenMap, jobInstanceId, jobInstanceName);
		File shouldExist = new File(customerDeliveryReportPath);
		assertTrue(shouldExist.exists());
	}

	@Test
	public void createCellValueTest() { 
		customerDeliveryReportGenerator = new CustomerDeliveryReportGenerator();
		workbook = new XSSFWorkbook();
		sheet = workbook.createSheet("US");
		row = sheet.createRow(3);
		ReflectionTestUtils.invokeMethod(customerDeliveryReportGenerator,"createCellValue", workbook, row, new Object[] {
				"Confidence Score", "Activity","17-Aug","17-Jul","Jun-17","May-17" }, 3);
		ReflectionTestUtils.invokeMethod(customerDeliveryReportGenerator,
				"createCellValue", workbook, row, new Object[] { null }, 3);
	}

	@Test
	public void testCellWithStyle() {
		workbook = new XSSFWorkbook();
		sheet = workbook.createSheet("customerdeliveryreport");
		row = sheet.createRow(3);
		XSSFCellStyle style2 = (XSSFCellStyle) workbook.createCellStyle();
		Font f2 = workbook.createFont();
		f2.setBoldweight(Font.BOLDWEIGHT_BOLD);
		f2.setFontHeightInPoints((short) 10);
		style2.setFont(f2);

		Cell c = row.createCell(2);
		customerDeliveryReportGenerator = new CustomerDeliveryReportGenerator();
		ReflectionTestUtils.invokeMethod(customerDeliveryReportGenerator,
				"setCellWithStyle1", new String("Issuer Region"), style2, c);
		ReflectionTestUtils.invokeMethod(customerDeliveryReportGenerator,
				"setCellWithStyle1", new String("Date Range"), style2, c);

	}


	@Test
	public void testSheetName() {
		customerDeliveryReportGenerator = new CustomerDeliveryReportGenerator();
		assertEquals("US",customerDeliveryReportGenerator.getSheetNameByContinentId("1"));
		assertEquals("NAM",customerDeliveryReportGenerator.getSheetNameByContinentId("A"));
		assertEquals("EUROPE",customerDeliveryReportGenerator.getSheetNameByContinentId("B"));
		assertEquals("LAC",customerDeliveryReportGenerator.getSheetNameByContinentId("C"));
		assertEquals("APAC",customerDeliveryReportGenerator.getSheetNameByContinentId("D"));
		assertEquals("MEA",customerDeliveryReportGenerator.getSheetNameByContinentId("E"));
		assertEquals("US",customerDeliveryReportGenerator.getSheetNameByContinentId("default"));


	}

	@Test
	public void testGetPrevMonthList() {
		List<String> prevMonthList = CustomerDeliveryReportGenerator.getPrevMonthList();
		assertFalse(prevMonthList.isEmpty());
	}

	//We will delete the Customer_Internal_DeliveryReport from classpath in after block
	@AfterClass
	public static void  checkFileDeletion() {
		try {
			File[] dirFiles = new File(".").listFiles();
			// Search Through the list 
			for (int i = 0; i < dirFiles.length; i++) { // If the Files start

				if (dirFiles[i].getName().startsWith("..Customer_Internal_DeliveryReport_", 0) || dirFiles[i].getName().startsWith("Customer_Internal_DeliveryReport_", 0))
					try {
						File file = new File(dirFiles[i].getName());

						if (file.delete()) {
							logger.info("Test CustomerDelivery File is deleted in after block for file :"+file);		
						} else {
							File file1 = new File(customerDeliveryReportPath+dirFiles[i].getName());
							file1.delete();
							logger.info("Test CustomerDelivery File is deleted in after block for file :"+file1);		
						}

					} catch (Exception e) {
						e.printStackTrace();
					}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
