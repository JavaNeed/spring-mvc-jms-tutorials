package com.mastercard.ess.eds.test.batch.core.util;

import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.core.util.EnvironmentUtil;
import com.mastercard.ess.eds.core.util.ProdUtil;

public class EnvironmentUtilTest {
	
	EnvironmentUtil environmentUtil;
	
	@Before
	public void init(){
		environmentUtil = new ProdUtil();
	}
	
	@Test
	public void testKeyStorePath(){
		assertNull(environmentUtil.getKeyStorePath());
	}

}
