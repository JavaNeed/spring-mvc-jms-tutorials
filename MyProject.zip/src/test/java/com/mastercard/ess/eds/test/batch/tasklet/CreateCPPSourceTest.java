package com.mastercard.ess.eds.test.batch.tasklet;

import java.math.BigDecimal;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;

import com.mastercard.ess.eds.batch.tasklet.CreateCPPSource;
import com.mastercard.ess.eds.core.service.EDSSourceService;
import com.mastercard.ess.eds.core.service.EDSSourceTypeService;
import com.mastercard.ess.eds.core.service.RawRecordDBWriterService;
import com.mastercard.ess.eds.domain.EDSSourceType;

public class CreateCPPSourceTest {
	CreateCPPSource createCPPSource;
	EDSSourceType edsSourceType;
	BigDecimal jobInstanceId;
	EDSSourceTypeService edsSourceTypeService;
	EDSSourceType eDSSourceType;
	RawRecordDBWriterService rawRecordDBWriterService;
	EDSSourceService edsSourceService;
	StepContribution stepContribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	private Logger logger = Logger.getLogger(CreateCPPSource.class);
	
	@Before
	public void init()
	{
		logger.setLevel(Level.DEBUG);
		edsSourceService = EasyMock.createMock(EDSSourceService.class);
		rawRecordDBWriterService = EasyMock.createMock(RawRecordDBWriterService.class);
		jobInstance = new JobInstance(new Long(123), "createCPPSource");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("createCPPSource", jobExecution);
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		stepContribution = new StepContribution(stepExecution);
	}
	@Test
	public void test() throws Exception {
		logger.setLevel(Level.DEBUG);
		eDSSourceType = new EDSSourceType();
		eDSSourceType.setDerived(true);
		eDSSourceType.setDescr("");
		eDSSourceType.setExternal(true);
		eDSSourceType.setLocation("");
		eDSSourceType.setProvider("");
		eDSSourceType.setPurgedReqd(true);
		eDSSourceType.setSourceTypeId(123);
		eDSSourceType.setType("");
		edsSourceTypeService = EasyMock.createMock(EDSSourceTypeService.class);
		EasyMock.expect(edsSourceTypeService.getEDSSourceTypeFromProvider("CPP")).andReturn(eDSSourceType);
		EasyMock.replay(edsSourceTypeService);
		createCPPSource = new CreateCPPSource();
		createCPPSource.setServices(edsSourceTypeService, edsSourceService, rawRecordDBWriterService);
		createCPPSource.execute(stepContribution, chunkContext);
		createCPPSource.setJobInstanceId(BigDecimal.valueOf(123));
	}
	
	@Test
	public void testNull() throws Exception {
		eDSSourceType = null;
		edsSourceTypeService = EasyMock.createMock(EDSSourceTypeService.class);
		EasyMock.expect(edsSourceTypeService.getEDSSourceTypeFromProvider("CPP")).andReturn(null);
		EasyMock.replay(edsSourceTypeService);
		logger.setLevel(Level.DEBUG);
		createCPPSource = new CreateCPPSource();
		createCPPSource.setServices(edsSourceTypeService, edsSourceService, rawRecordDBWriterService);
		createCPPSource.execute(stepContribution, chunkContext);
		createCPPSource.setJobInstanceId(BigDecimal.valueOf(123));
	}

}
