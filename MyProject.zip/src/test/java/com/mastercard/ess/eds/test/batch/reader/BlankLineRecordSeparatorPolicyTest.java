package com.mastercard.ess.eds.test.batch.reader;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.batch.reader.BlankLineRecordSeparatorPolicy;

public class BlankLineRecordSeparatorPolicyTest {
	
	BlankLineRecordSeparatorPolicy blankLineRecordSeparatorPolicy;
	
	@Before
	public void init(){
		blankLineRecordSeparatorPolicy = new BlankLineRecordSeparatorPolicy();
	}
	
	@Test
	public void isEndOfRecordTestForRecordsInFile() {
		boolean isNotEndOfRecord = blankLineRecordSeparatorPolicy.isEndOfRecord("This is not the end of record");
		assertTrue(isNotEndOfRecord);
	}
	
	@Test
	public void isEndOfRecordTestForFileEnd() {
		boolean isNotEndOfRecord = blankLineRecordSeparatorPolicy.isEndOfRecord("");
		assertFalse(isNotEndOfRecord);
	}
	
	@Test
	public void postProcessTest() {
		String record = blankLineRecordSeparatorPolicy.postProcess("This is not the end of record");
		assertNotNull(record);
		
	}
	
	@Test
	public void postProcessTestForEOF() {
		String record = blankLineRecordSeparatorPolicy.postProcess("");
		assertNull(record);
		
	}
	
	@Test
	public void postProcessTestForNull() {
		String record = blankLineRecordSeparatorPolicy.postProcess(null);
		assertNull(record);
	}

}
