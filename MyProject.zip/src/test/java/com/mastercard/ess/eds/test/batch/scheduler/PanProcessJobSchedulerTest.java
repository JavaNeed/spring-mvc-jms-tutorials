package com.mastercard.ess.eds.test.batch.scheduler;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.mastercard.ess.eds.batch.scheduler.PanProcessJobScheduler;
import com.mastercard.ess.eds.core.service.EDSSourceService;
import com.mastercard.ess.eds.domain.EDSSource;

public class PanProcessJobSchedulerTest {
	
	private Logger logger=Logger.getLogger(PanProcessJobScheduler.class);
		Job job;
	   JobExecution jobExecution;
		@Mock
		JdbcTemplate jdbcTemplate;

		@Mock
		PanProcessJobScheduler panProcessJobScheduler;

		@Mock
		EDSSourceService edsSourceService, edsSourceServiceOne;
		
		@Mock
		ApplicationContext context;
		
		@Mock
		JobLauncher joLauncher;

		@Before
		public void setUp() throws Exception {
			logger.setLevel(Level.DEBUG);
			MockitoAnnotations.initMocks(this);
		}

		@Test
		public void should_populate_eds_source_list_from_map_when_is_purged_is_N()throws InterruptedException {
			// Given
			Map<String, Object> givenRowMap = new HashMap<>();
			givenRowMap.put("EDS_SRC_ID", new BigDecimal(23.23));
			givenRowMap.put("ERR_FILE_NAM", "SOME_ERROR_FILE");
			givenRowMap.put("ERR_FILE_LOC_TXT", "SOME_ERROR_FILE_LOCATION");
			givenRowMap.put("IS_PURGED_SW", "N");
			givenRowMap.put("LST_UPDT_DT", new Timestamp(6L));
			givenRowMap.put("LST_UPDT_USER_ID", "e056636");
			givenRowMap.put("EDS_SRC_TYPE_ID", new BigDecimal(23.23));
			givenRowMap.put("SRC_NAM", "Deepankar");

			// When
			PanProcessJobScheduler panProcessJobScheduler = new PanProcessJobScheduler();
			EDSSource edsSource= panProcessJobScheduler.populateEDSSourceInstanceList(givenRowMap);

			// Then
			assertEquals(new BigDecimal(23.23), edsSource.getSrc_ky());
			assertEquals("SOME_ERROR_FILE", edsSource.getErrorFile());
			assertEquals("SOME_ERROR_FILE_LOCATION", edsSource.getErrorFileLocation());
			assertEquals(false, edsSource.getIsPurged());
			assertEquals("e056636", edsSource.getLastUpdatedBy());

		}

		@Test
		public void should_populate_eds_source_list_from_map_when_is_purged_is_()throws InterruptedException {
			// Given
			Map<String, Object> givenRowMap = new HashMap<>();
			givenRowMap.put("EDS_SRC_ID", new BigDecimal(23.23));
			givenRowMap.put("ERR_FILE_NAM", "SOME_ERROR_FILE");
			givenRowMap.put("ERR_FILE_LOC_TXT", "SOME_ERROR_FILE_LOCATION");
			givenRowMap.put("IS_PURGED_SW", "Y");
			givenRowMap.put("LST_UPDT_DT", new Timestamp(6L));
			givenRowMap.put("LST_UPDT_USER_ID", "e056636");
			givenRowMap.put("EDS_SRC_TYPE_ID", new BigDecimal(23.23));
			givenRowMap.put("SRC_NAM", "Deepankar");

			// When
			PanProcessJobScheduler panProcessJobScheduler = new PanProcessJobScheduler();
			EDSSource edsSource= panProcessJobScheduler.populateEDSSourceInstanceList(givenRowMap);
					// Then
					assertEquals(new BigDecimal(23.23), edsSource.getSrc_ky());
					assertEquals("SOME_ERROR_FILE", edsSource.getErrorFile());
					assertEquals("SOME_ERROR_FILE_LOCATION", edsSource.getErrorFileLocation());
					assertEquals(true, edsSource.getIsPurged());
					assertEquals("e056636", edsSource.getLastUpdatedBy());

		}

		@SuppressWarnings("unchecked")
		@Test(expected = NullPointerException.class)
		public void test(){
			// Given
			PanProcessJobScheduler panProcessJobScheduler = new PanProcessJobScheduler();
			@SuppressWarnings("rawtypes")
			List expectedList = new ArrayList<>();
			expectedList.add("ExpectedList");
			List<Map<String, Object>> edsSourceList = new ArrayList<>();
			Map<String, Object> map = new HashMap<>();
			map.put("IS_PURGED_SW", "N");
			map.put("SRC_NAM", "XYZ");
			edsSourceList.add(map);
			Mockito.when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.anyInt())).thenReturn(edsSourceList);

			panProcessJobScheduler.execute();

			Mockito.verify(panProcessJobScheduler).populateEDSSourceInstanceList(map);

		}



}
