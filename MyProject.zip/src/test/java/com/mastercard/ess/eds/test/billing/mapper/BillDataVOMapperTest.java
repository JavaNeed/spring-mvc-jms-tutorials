package com.mastercard.ess.eds.test.billing.mapper;

import static org.junit.Assert.assertEquals;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.mastercard.ess.eds.billing.mapper.BillDataVOMapper;
import com.mastercard.ess.eds.billing.vo.BillDataVO;

public class BillDataVOMapperTest {

	private static Logger logger = Logger.getLogger(BillDataVOMapper.class);

	@Before
	public void init() {
		logger.setLevel(Level.DEBUG);
	}

	@Test
	public void testMapRow() {

		logger.setLevel(Level.DEBUG);
		BillDataVOMapper billdataVOMapper = new BillDataVOMapper();

		ResultSet r = Mockito.mock(ResultSet.class);

		try {
			Mockito.when(r.getLong("PAN_NUM")).thenReturn(1234L);
			Mockito.when(r.getLong("PRICE_CAT_CD")).thenReturn(1235L);

			BillDataVO vo = billdataVOMapper.mapRow(r, 4);
			assertEquals(1234L, vo.getPanNum());
			assertEquals(1235L, vo.getPriceCatid());

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
