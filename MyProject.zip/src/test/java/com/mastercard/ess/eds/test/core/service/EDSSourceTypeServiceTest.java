package com.mastercard.ess.eds.test.core.service;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.core.service.EDSSourceTypeService;
import com.mastercard.ess.eds.core.dao.EDSSourceTypeDao;
import com.mastercard.ess.eds.domain.EDSSourceType;

public class EDSSourceTypeServiceTest {
	EDSSourceTypeService eDSSourceTypeService;
	EDSSourceTypeDao edsSourceTypeDao;
	EDSSourceType eDSSourceType;
	List<String> list;
	
	@Before
	public void init() {
		eDSSourceType = new EDSSourceType();
		eDSSourceType.setDerived(true);
		eDSSourceType.setDescr("");
		eDSSourceType.setExternal(true);
		eDSSourceType.setLocation("");
		eDSSourceType.setProvider("");
		eDSSourceType.setPurgedReqd(true);
		eDSSourceType.setSourceTypeId(3);
		eDSSourceType.setType("");
	}
	@Test
	public void test() {
		edsSourceTypeDao = EasyMock.createMock(EDSSourceTypeDao.class);
		EasyMock.expect(edsSourceTypeDao.getEDSSourceTypeFromProvider("")).andReturn(eDSSourceType);
		EasyMock.expect(edsSourceTypeDao.getEDSSourceType("")).andReturn(eDSSourceType);
		EasyMock.expect(edsSourceTypeDao.getVendorList()).andReturn(new ArrayList<String>());
		EasyMock.replay(edsSourceTypeDao);
		eDSSourceTypeService = new EDSSourceTypeService();
		eDSSourceTypeService.setEdsSourceTypeDao(edsSourceTypeDao);
		eDSSourceTypeService = new EDSSourceTypeService(edsSourceTypeDao);
		eDSSourceTypeService.getEDSSourceTypeFromProvider("");
		eDSSourceTypeService.getEDSSourceType("");
		eDSSourceTypeService.getVendorList();
	}

}
