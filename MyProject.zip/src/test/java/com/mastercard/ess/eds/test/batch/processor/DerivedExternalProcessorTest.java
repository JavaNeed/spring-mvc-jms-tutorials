package com.mastercard.ess.eds.test.batch.processor;

import java.math.BigDecimal;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.batch.processor.DerivedExternalProcessor;
import com.mastercard.ess.eds.core.service.DerivedExternalService;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.ProcessedRecord;
import com.mastercard.ess.eds.domain.RawRecord;

public class DerivedExternalProcessorTest {

	 private  DerivedExternalService derivedExternalService;
	 private DerivedExternalProcessor derivedExternalProcessor;
	 private static Logger logger = Logger.getLogger(DerivedExternalProcessor.class);
	 private EDSRecord edsRecord;
	 private ProcessedRecord procRecord;
	 private RawRecord rawRecord;
	 
	@Before
	public void setUp() throws Exception {
		edsRecord = new EDSRecord();
		procRecord = new ProcessedRecord();
		rawRecord = new RawRecord();
		rawRecord.setSrc_data_ky(BigDecimal.valueOf(123));
		rawRecord.setSrc_ky(BigDecimal.valueOf(123));
		rawRecord.setDerivedSw("Y");
		edsRecord.setProcRecord(procRecord);
		edsRecord.setRawRecord(rawRecord);
		derivedExternalService = EasyMock.createMock(DerivedExternalService.class);
		derivedExternalProcessor = new DerivedExternalProcessor(derivedExternalService);
	}

	@Test
	public void test() throws Exception {
		logger.setLevel(Level.DEBUG);
		derivedExternalProcessor.process(edsRecord);
	}
	

}
