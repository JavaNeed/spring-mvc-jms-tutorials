package com.mastercard.ess.eds.test.batch.tasklet;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;

import com.mastercard.ess.eds.batch.tasklet.UpdateCPPRulesExecutionStatus;
import com.mastercard.ess.eds.batch.tasklet.UpdatePurgeFileStatusTasklet;
import com.mastercard.ess.eds.core.dao.CustomerPanReportDao;

public class UpdatePurgeFileStatusTaskletTest {
	CustomerPanReportDao customerPanReportDao;
	UpdatePurgeFileStatusTasklet updatePurgeFileStatusTasklet;
	StepContribution contribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	private Logger logger = Logger
			.getLogger(UpdateCPPRulesExecutionStatus.class);

	@Before
	public void init() {
		logger.setLevel(Level.DEBUG);
		updatePurgeFileStatusTasklet = new UpdatePurgeFileStatusTasklet();

		jobInstance = new JobInstance(new Long(123),
				"updatePurgeFileStatusTasklet");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("updatePurgeFileStatusTasklet",
				jobExecution);
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		contribution = new StepContribution(stepExecution);
		customerPanReportDao = EasyMock.createMock(CustomerPanReportDao.class);
	}

	@Test
	public void executetest() throws Exception {
		updatePurgeFileStatusTasklet.afterPropertiesSet();
		updatePurgeFileStatusTasklet
				.setCustomerPanReportDao(customerPanReportDao);
		updatePurgeFileStatusTasklet.execute(contribution, chunkContext);
	}
}
