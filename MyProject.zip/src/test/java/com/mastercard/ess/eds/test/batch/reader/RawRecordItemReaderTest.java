package com.mastercard.ess.eds.test.batch.reader;

import static org.junit.Assert.assertNotNull;

import javax.sql.DataSource;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.ReaderNotOpenException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.test.MetaDataInstanceFactory;
import org.springframework.batch.test.StepScopeTestExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;

import com.mastercard.ess.eds.batch.config.EnvironmentConfig;
import com.mastercard.ess.eds.batch.reader.RawRecordItemReader;
import com.mastercard.ess.eds.domain.RawRecord;
import com.mastercard.ess.eds.test.batch.config.CommonConfigTest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {EnvironmentConfig.class,CommonConfigTest.class})
@ActiveProfiles(value = "dev")
@TestExecutionListeners({ DependencyInjectionTestExecutionListener.class, StepScopeTestExecutionListener.class })
public class RawRecordItemReaderTest {

	RawRecordItemReader itemReader;
	DataSource dataSource;
	RawRecord rawRecord;

	private Logger logger;

	@Autowired
	private org.springframework.batch.item.file.ResourceAwareItemReaderItemStream<RawRecord> rawRecordItemReader;

	@Before
	public void init() {
		rawRecord = new RawRecord();
		dataSource = new DriverManagerDataSource();
		itemReader = new RawRecordItemReader(dataSource);
		logger = Logger.getLogger(RawRecordItemReader.class);
		logger.setLevel(Level.DEBUG);
	}

	public StepExecution getStepExection() {
		StepExecution execution = MetaDataInstanceFactory.createStepExecution();
		execution.getExecutionContext().putString("input.data", "foo,bar,spam");
		return execution;
	}

	@Test
	public void testReader() {
		// The reader is initialized and bound to the input data
		logger.setLevel(Level.DEBUG);
		try {
			assertNotNull(rawRecordItemReader.read());
		} catch (UnexpectedInputException e) {

			logger.error(e);
		} catch (ParseException e) {

			logger.error(e);
		} catch (NonTransientResourceException e) {

			logger.error(e);
		} catch (Exception e) {

			logger.error(e);
		}
	}

	@Test(expected = ReaderNotOpenException.class)
	public void testReadBeforeOpen() throws Exception {
		logger.setLevel(Level.DEBUG);
		rawRecordItemReader.read();
	}

	@Test
	public void testread() {
		logger.setLevel(Level.DEBUG);
		rawRecord = itemReader.read();
	}

}