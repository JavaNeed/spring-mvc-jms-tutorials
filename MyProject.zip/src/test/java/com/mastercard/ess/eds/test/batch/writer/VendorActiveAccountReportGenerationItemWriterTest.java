package com.mastercard.ess.eds.test.batch.writer;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;

import com.mastercard.ess.eds.batch.writer.VendorActiveAccountReportGenerationItemWriter;
import com.mastercard.ess.eds.core.util.VendorReportGenerator;
import com.mastercard.ess.eds.domain.VendorActiveAccountRecord;

public class VendorActiveAccountReportGenerationItemWriterTest {
    VendorActiveAccountReportGenerationItemWriter vendorActiveAccountReportGenerationItemWriter;
    StepContribution stepContribution;
    ChunkContext chunkContext;
    StepExecution stepExecution;
    StepContext stepContext;
    JobParameters jobParameters;
    JobParameter jobParameter;
    JobExecution jobExecution;
    JobInstance jobInstance;
    List<VendorActiveAccountRecord> summaryList;
    VendorActiveAccountRecord vendorActiveAccountRecord;
    VendorReportGenerator vendorReportGenerator;

    @Before
    public void setUp() {
        String fileName = "file:///MCI.AR.RABC.X.E1234567.D160812.T111135.C001";
        Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
        jobParameter = new JobParameter(fileName, true);
        parameters.put("input.file", jobParameter);
        jobParameters = new JobParameters(parameters);
        jobInstance = new JobInstance(new Long(123), "importRawRecords");
        jobExecution = new JobExecution(jobInstance, jobParameters);
        stepExecution = new StepExecution("loadRawRecords", jobExecution);
        vendorActiveAccountReportGenerationItemWriter = new VendorActiveAccountReportGenerationItemWriter();
        vendorActiveAccountReportGenerationItemWriter.setJobInstanceId(new BigDecimal(0));
        vendorActiveAccountReportGenerationItemWriter.setJobInstanceName("abc");
        vendorActiveAccountReportGenerationItemWriter.setPrevMonthName("jan");
        vendorActiveAccountReportGenerationItemWriter.setStepExecution(stepExecution);
        vendorActiveAccountReportGenerationItemWriter.setVendorName("mno");
    }

    @Test
    public void test() throws Exception {
        Boolean exceptionOccurred = new Boolean(false);
        assertEquals(new BigDecimal(0), vendorActiveAccountReportGenerationItemWriter.getJobInstanceId());
        assertEquals("abc", vendorActiveAccountReportGenerationItemWriter.getJobInstanceName());
        assertEquals("jan", vendorActiveAccountReportGenerationItemWriter.getPrevMonthName());
        assertEquals("mno", vendorActiveAccountReportGenerationItemWriter.getVendorName());
        vendorActiveAccountRecord = new VendorActiveAccountRecord();
        vendorActiveAccountRecord.setActivePANCount(0);
        vendorActiveAccountRecord.setInactivePANCount(0);
        // vendorActiveAccountRecord.setNewPANCount(0);
        vendorActiveAccountRecord.setReceivedPANCount(0);
        vendorActiveAccountRecord.setReportForMonth("");
        vendorActiveAccountRecord.setSummaryDate(new Date(0L));
        vendorActiveAccountRecord.setUniquePANCount(0);
        // vendorActiveAccountRecord.setValidPANCount(0);
        summaryList = new ArrayList<VendorActiveAccountRecord>();
        summaryList.add(vendorActiveAccountRecord);
        vendorReportGenerator = EasyMock.createMock(VendorReportGenerator.class);
        vendorActiveAccountReportGenerationItemWriter.setGenerator(vendorReportGenerator);
        try {
            vendorActiveAccountReportGenerationItemWriter.write(summaryList);
        } catch (Exception e) {
            exceptionOccurred = true;

        }
        assertEquals(false, exceptionOccurred);
    }

}
