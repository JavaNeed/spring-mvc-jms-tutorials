package com.mastercard.ess.eds.test.batch.writer;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.test.util.ReflectionTestUtils;

import com.mastercard.ess.eds.Comparator.PercentageComparator;
import com.mastercard.ess.eds.batch.writer.CPPDetailReportGenerationItemWriter;
import com.mastercard.ess.eds.core.service.CPPReportService;
import com.mastercard.ess.eds.core.util.CPPReportGenerator;
import com.mastercard.ess.eds.domain.CPPReportInfo;


public class CPPDetailReportGenerationItemWriterTest {

	Logger logger = Logger.getLogger(CPPDetailReportGenerationItemWriterTest.class);

	CPPReportGenerator cppReportGenerator;
	PercentageComparator percentageComparator;
	CPPReportInfo cPPReportInfo;
	CPPReportService cppReportService;
	CPPDetailReportGenerationItemWriter cPPDetailReportGenerationItemWriter; 		
	ExecutionContext executionContext;
	List<CPPReportInfo> reportInfos;
	List<CPPReportInfo> reportInfos1;
	CPPReportInfo cPPReportInfo1;
	List<CPPReportInfo> reportInfos2;
	CPPReportInfo cPPReportInfo2;
	List<CPPReportInfo> reportInfos3;
	CPPReportInfo cPPReportInfo3;
	List<CPPReportInfo> reportInfos4;
	CPPReportInfo cPPReportInfo4;
	List<CPPReportInfo> reportInfos5;
	CPPReportInfo cPPReportInfo5;
	List<CPPReportInfo> reportInfos6;
	CPPReportInfo cPPReportInfo6;

	@Before
	public void init()
	{
		logger.setLevel(Level.DEBUG);	
		cPPDetailReportGenerationItemWriter = new CPPDetailReportGenerationItemWriter();
		Map<String, String> distinctPanCountMap =new HashMap<String, String> ();
		distinctPanCountMap.put("executionContext", "1");
		executionContext=new ExecutionContext();
		executionContext.put("distinctPanCountMap", distinctPanCountMap);
		cPPReportInfo = new CPPReportInfo();
		reportInfos = new ArrayList<CPPReportInfo>();
		cPPReportInfo.setCardsCountryPercentage(5);
		cPPReportInfo.getCardsCountryPercentage();
		cPPReportInfo.setCardsUsedCount((long) 9);
		cPPReportInfo.getCardsUsedCount();
		cPPReportInfo.setGroupId(2);
		cPPReportInfo.getGroupId();
		cPPReportInfo.setIssuerCountryCode("INDIA");
		cPPReportInfo.getIssuerCountryCode();
		cPPReportInfo.setLocalTransactionAmount(100000);
		cPPReportInfo.getLocalTransactionAmount();
		cPPReportInfo.setLocationId("222");
		cPPReportInfo.getLocationId();
		cPPReportInfo.setMerchantCountryCode("GERMANY");
		cPPReportInfo.getMerchantCountryCode();
		cPPReportInfo.setMerchantName("ICICI");
		cPPReportInfo.getMerchantName();
		cPPReportInfo.setTransactionChannel("CNP");
		cPPReportInfo.getTransactionChannel();
		reportInfos.add(cPPReportInfo);
		cppReportGenerator = EasyMock.createMock(CPPReportGenerator.class);
		cPPDetailReportGenerationItemWriter.setExecutionContext(executionContext);
		cPPDetailReportGenerationItemWriter.setCppReportGenerator(cppReportGenerator);
	}

	@Test
	public void test() throws Exception {
		logger.setLevel(Level.DEBUG);
		cPPDetailReportGenerationItemWriter.write(reportInfos);
	}

	@Test
	public void test1() throws Exception
	{
		cPPReportInfo1 = new CPPReportInfo();
		reportInfos1 = new ArrayList<CPPReportInfo>();
		cPPReportInfo1.setCardsCountryPercentage(0.01);
		cPPReportInfo1.getCardsCountryPercentage();
		cPPReportInfo1.setCardsUsedCount((long) 9);
		cPPReportInfo1.getCardsUsedCount();
		cPPReportInfo1.setGroupId(0);
		cPPReportInfo1.getGroupId();
		cPPReportInfo1.setIssuerCountryCode("INDIA");
		cPPReportInfo1.getIssuerCountryCode();
		cPPReportInfo1.setLocalTransactionAmount(100000);
		cPPReportInfo1.getLocalTransactionAmount();
		cPPReportInfo1.setLocationId("222");
		cPPReportInfo1.getLocationId();
		cPPReportInfo1.setMerchantCountryCode("GERMANY");
		cPPReportInfo1.getMerchantCountryCode();
		cPPReportInfo1.setMerchantName("ICICI");
		cPPReportInfo1.getMerchantName();
		cPPReportInfo1.setTransactionChannel("CP");
		cPPReportInfo1.getTransactionChannel();
		reportInfos1.add(cPPReportInfo1);
		cppReportGenerator = EasyMock.createMock(CPPReportGenerator.class);
		cPPDetailReportGenerationItemWriter.setCppReportGenerator(cppReportGenerator);
		cPPDetailReportGenerationItemWriter.write(reportInfos1);

	}



	@Test
	public void testJobInstanceName() {
		cPPDetailReportGenerationItemWriter = new CPPDetailReportGenerationItemWriter();
		cPPDetailReportGenerationItemWriter.setJobInstanceName("CPPDetailReportItemWriter");

	}

	@Test
	public void testJobInstanceId() {
		cPPDetailReportGenerationItemWriter = new CPPDetailReportGenerationItemWriter();
		cPPDetailReportGenerationItemWriter.setJobInstanceId(BigDecimal.valueOf(2222));
		cPPDetailReportGenerationItemWriter.setCountryCode("619");
		cPPDetailReportGenerationItemWriter.getCountryCode();
		cPPDetailReportGenerationItemWriter.setExecutionContext(executionContext);
		assertEquals(executionContext,cPPDetailReportGenerationItemWriter.getExecutionContext());

	}

	@Test
	public void testEmptyList() {
		cPPDetailReportGenerationItemWriter = new CPPDetailReportGenerationItemWriter();
		cppReportService = EasyMock.createMock(CPPReportService.class);
		cppReportGenerator = new CPPReportGenerator();
		percentageComparator = new PercentageComparator();
		cPPReportInfo1 = new CPPReportInfo();
		reportInfos1 = new ArrayList<CPPReportInfo>();
		cPPReportInfo1.setCardsCountryPercentage(5);
		cPPReportInfo1.setCardsUsedCount((long) 9);
		cPPReportInfo1.setGroupId(2);
		cPPReportInfo1.setIssuerCountryCode("INDIA");
		cPPReportInfo1.setLocalTransactionAmount(100000);
		cPPReportInfo1.setLocationId("222");
		cPPReportInfo1.setMerchantCountryCode("GERMANY");
		cPPReportInfo1.setMerchantName("ICICI");
		cPPReportInfo1.setTransactionChannel("CNP");
		reportInfos1.add(cPPReportInfo6);
		cPPDetailReportGenerationItemWriter.setJobInstanceId(BigDecimal.valueOf(123));
		cPPDetailReportGenerationItemWriter.setJobInstanceName("CPPDetailReportGenerator");
		cPPDetailReportGenerationItemWriter.setObject(cppReportGenerator);
		cppReportGenerator = EasyMock.createMock(CPPReportGenerator.class);
		cPPDetailReportGenerationItemWriter.setCppReportGenerator(cppReportGenerator);

		ReflectionTestUtils.invokeMethod(cPPDetailReportGenerationItemWriter, "group0ListIsEmpty", reportInfos1, "USA");
	}

	@Test
	public void testIteratorDetails() {
		cPPDetailReportGenerationItemWriter = new CPPDetailReportGenerationItemWriter();
		List<CPPReportInfo> tempList = new ArrayList<CPPReportInfo>();
		List<CPPReportInfo> tempListOne = new ArrayList<CPPReportInfo>();
		CPPReportInfo cPPReportInfo7 = new CPPReportInfo();
		cPPReportInfo7.setCardsUsedCount(5L);
		cPPReportInfo7.setTransactionChannel("CP");
		cPPReportInfo7.setCardsCountryPercentage(5);
		CPPReportInfo cPPReportInfo8 = new CPPReportInfo();
		cPPReportInfo8.setCardsUsedCount(5L);
		cPPReportInfo8.setTransactionChannel("CNP");
		cPPReportInfo8.setCardsCountryPercentage(0);
		tempListOne.add(cPPReportInfo7);
		tempListOne.add(cPPReportInfo8);
		ListIterator<CPPReportInfo> group0ListIterator = tempListOne.listIterator();
		ReflectionTestUtils.invokeMethod(cPPDetailReportGenerationItemWriter, "group0ListIteratorDetails", 100L,100L,group0ListIterator);

	}

}
