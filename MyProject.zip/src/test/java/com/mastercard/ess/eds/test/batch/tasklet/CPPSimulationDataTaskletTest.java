package com.mastercard.ess.eds.test.batch.tasklet;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.tasklet.CPPSimulationDataTasklet;
import com.mastercard.ess.eds.core.service.CPPSimulationService;
import com.mastercard.ess.eds.domain.AuthDebitPanDetailRecord;

public class CPPSimulationDataTaskletTest {
	CPPSimulationDataTasklet cPPSimulationDataTasklet;
	CPPSimulationService cppSimulationService;
	StepContribution stepContribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobExecution jobExecution;
	JobInstance jobInstance;
	ExecutionContext executionContext;
	Set<AuthDebitPanDetailRecord>  authDebitRecord;
	Map<String, Integer> simulationMapCount;
	Logger logger = Logger.getLogger(CPPSimulationDataTaskletTest.class);
	@Before
	public void setUp()
	{
		logger.setLevel(Level.DEBUG);
		jobParameters = new JobParameters();
		jobInstance = new JobInstance(new Long(123), "simulationData");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		executionContext=new ExecutionContext();
		executionContext.put("edsSimSrcId", "eds");
		cPPSimulationDataTasklet=new CPPSimulationDataTasklet();
		cppSimulationService=EasyMock.createMock(CPPSimulationService.class);
		cPPSimulationDataTasklet.setCppSimulationService(cppSimulationService);
		AuthDebitPanDetailRecord authDebitRecord=new AuthDebitPanDetailRecord();
		authDebitRecord.setCppRuleId(new BigDecimal(123));
		authDebitRecord.setRawPan("12");
		AuthDebitPanDetailRecord authDebitRecord1=new AuthDebitPanDetailRecord();
		authDebitRecord1.setCppRuleId(new BigDecimal(123));
		authDebitRecord1.setRawPan("14");
		Map<String, Integer> simulationMapCount = new HashMap<>();
		simulationMapCount.put("authDebitRecord", 1);
		Set<AuthDebitPanDetailRecord> simulationSet= new HashSet<>();
		simulationSet.add(authDebitRecord);
		simulationSet.add(authDebitRecord1);
		executionContext.put("cppSimulationSet",simulationSet);
		jobExecution.setExecutionContext(executionContext);
		stepExecution = new StepExecution("simulationData", jobExecution);
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		stepContribution = new StepContribution(stepExecution);
	}
	@Test
	public void executeTest() throws Exception
	{
		cPPSimulationDataTasklet.execute(stepContribution, chunkContext);
		
	}
}