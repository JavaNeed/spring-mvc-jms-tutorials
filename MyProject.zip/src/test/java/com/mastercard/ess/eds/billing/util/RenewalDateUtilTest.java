package com.mastercard.ess.eds.billing.util;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.mastercard.ess.eds.billing.dao.BillDataDAO;
import com.mastercard.ess.eds.billing.service.BillingService;
import com.mastercard.ess.eds.billing.vo.BillDataVO;
import com.mastercard.ess.eds.billing.vo.FileItemVO;

public class RenewalDateUtilTest {

    BillDataDAO billDataDao;
    FileItemVO fileItemVO;
    RenewalDateUtil renewalDateUtil;
    List<String> billableICAs;
    String location = "..";
    String filePrefix = "JunitTestFileDTF.GB.TZU6.C.";
    List<BillDataVO> billDataVOList;
    BillDataVO billDataVO;
    CSVWriterUtils cSVWriterUtils;
    BillingService billingService;
    private Logger logger = Logger.getLogger(CSVWriterUtils.class);

    @Test
    public void test() {
        logger.setLevel(Level.DEBUG);
        cSVWriterUtils = new CSVWriterUtils();
    }

    @Test
    public void testRenewalDate() {
        Calendar updatedRenewalDate = Calendar.getInstance();
        updatedRenewalDate.setTime(new Date(0L));
        updatedRenewalDate.add(Calendar.DAY_OF_MONTH, 365);
        List<Map<String, Object>> childParentMapList = new ArrayList<Map<String, Object>>();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("CRTE_DT", new Date(0L));
        map.put("RNWL_DT", null);
        map.put("ICA_NUM", new BigDecimal(3));
        map.put("CRTE_USER_ID", "E07474");

        childParentMapList.add(map);
        billDataDao = EasyMock.createMock(BillDataDAO.class);
        renewalDateUtil = EasyMock.createMock(RenewalDateUtil.class);

        EasyMock.expect(billDataDao.updateRenewalDate(updatedRenewalDate, new BigDecimal(3), "billGenerationJob"))
                .andReturn(1);
        EasyMock.replay(billDataDao);
        RenewalDateUtil renewalDateUtil = new RenewalDateUtil(location, billDataDao, fileItemVO);
        ReflectionTestUtils.invokeMethod(renewalDateUtil, "updateRenewalDate", childParentMapList, "billGenerationJob");
    }

    @Test
    public void testUpdateRenewalDateAsNull() {
        Calendar updatedRenewalDate = Calendar.getInstance();
        updatedRenewalDate.setTime(new Date(0L));
        updatedRenewalDate.add(Calendar.DAY_OF_MONTH, 365);

        List<Map<String, Object>> childParentMapListOne = new ArrayList<Map<String, Object>>();
        Map<String, Object> mapOne = new HashMap<String, Object>();
        mapOne.put("CRTE_DT", new Date(0L));
        mapOne.put("RNWL_DT", null);
        mapOne.put("ICA_NUM", new BigDecimal(3));
        mapOne.put("CRTE_USER_ID", "custMassOnboarding");

        childParentMapListOne.add(mapOne);
        renewalDateUtil = EasyMock.createMock(RenewalDateUtil.class);
        billDataDao = EasyMock.createMock(BillDataDAO.class);

        RenewalDateUtil renewalDateUtil = new RenewalDateUtil(location, billDataDao, fileItemVO);
        ReflectionTestUtils.invokeMethod(renewalDateUtil, "updateRenewalDate", childParentMapListOne,
                "billGenerationJob");
    }

    @Test
    public void testUpdateRenewalDateForCustMassOnboarding() {
        Calendar updatedRenewalDate = Calendar.getInstance();
        updatedRenewalDate.setTime(new Date(0L));
        updatedRenewalDate.add(Calendar.DAY_OF_MONTH, 365);

        List<Map<String, Object>> childParentMapListOne = new ArrayList<Map<String, Object>>();
        Map<String, Object> mapOne = new HashMap<String, Object>();
        mapOne.put("CRTE_DT", new Date(0L));
        mapOne.put("RNWL_DT", updatedRenewalDate.getTime());
        mapOne.put("ICA_NUM", new BigDecimal(3));
        mapOne.put("CRTE_USER_ID", "custMassOnboarding");

        childParentMapListOne.add(mapOne);
        renewalDateUtil = EasyMock.createMock(RenewalDateUtil.class);
        billDataDao = EasyMock.createMock(BillDataDAO.class);

        RenewalDateUtil renewalDateUtil = new RenewalDateUtil(location, billDataDao, fileItemVO);
        ReflectionTestUtils.invokeMethod(renewalDateUtil, "updateRenewalDate", childParentMapListOne,
                "billGenerationJob");
    }

    @Test
    public void test1() throws IOException {
        logger.setLevel(Level.DEBUG);
        fileItemVO = new FileItemVO();
        billableICAs = new ArrayList<String>();
        billableICAs.add("abc");
        billDataDao = EasyMock.createMock(BillDataDAO.class);
        EasyMock.expect(billDataDao.getBillableICAList(null)).andReturn(billableICAs);
        EasyMock.replay(billDataDao);
        billingService = EasyMock.createMock(BillingService.class);
        EasyMock.expect(billingService.icaIsInTrailPeriod(EasyMock.anyLong())).andReturn(false);
        EasyMock.replay(billingService);

        CSVWriterUtils cSVWriterUtils = new CSVWriterUtils(location, filePrefix, billDataDao, fileItemVO,
                renewalDateUtil, billingService);

        BillDataVO billDataVO = new BillDataVO();

        billDataVO.setIcaNum(8693);
        billDataVO.setPanNum(12345);
        billDataVO.setPriceCatid(1);

        billDataVOList = new ArrayList<BillDataVO>();
        billDataVOList.add(billDataVO);
        cSVWriterUtils.createBillDataCSVFile(billDataVOList, null, "billGenerationJob");
        cSVWriterUtils.createICABillingFile(billableICAs);
        checkFileDeletion();
    }

    @Test
    public void test2() {
        billableICAs = new ArrayList<String>();
        fileItemVO = new FileItemVO();

        billableICAs.add("abc");
        billDataDao = EasyMock.createMock(BillDataDAO.class);
        EasyMock.expect(billDataDao.getBillableICAList(null)).andReturn(billableICAs);
        EasyMock.replay(billDataDao);

        CSVWriterUtils cSVWriterUtils = new CSVWriterUtils(location, filePrefix, billDataDao, fileItemVO,
                renewalDateUtil, billingService);

        billDataVO = new BillDataVO();

        billDataVO.setIcaNum(8693);
        billDataVO.setPanNum(12345);
        billDataVO.setPriceCatid(1);

        cSVWriterUtils.createICABillingFile(billableICAs);
        checkFileDeletion();
    }

    public void checkFileDeletion() {
        try {
            File[] dirFiles = new File("..").listFiles();
            // Search Through the list
            for (int i = 0; i < dirFiles.length; i++) { // If the Files starts with the word "$JunitTestFileDTF"

                if (dirFiles[i].getName().startsWith("JunitTestFileDTF", 0))
                    // Delete This file
                    try {
                        File file = new File("..\\".concat(dirFiles[i].getName()));

                        if (file.delete()) {
                        } else {
                            File file1 = new File("../".concat(dirFiles[i].getName()));
                            file1.delete();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
