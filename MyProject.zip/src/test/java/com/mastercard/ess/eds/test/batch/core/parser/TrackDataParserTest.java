package com.mastercard.ess.eds.test.batch.core.parser;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.LinkedHashMap;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.core.parser.TrackDataParser;
import com.mastercard.ess.eds.core.parser.VendorPayloadTokens;
import com.mastercard.ess.eds.domain.RawRecord;
/**
 * Class to test TrackDataParser
 * @author E075766
 */
public class TrackDataParserTest {
	private static Logger logger = Logger.getLogger(TrackDataParserTest.class);
	private TrackDataParser trackDataParser=new TrackDataParser();
	private RawRecord rawRecord=new RawRecord();
	private static final String Y = "Y";
	private static final String TRACK2 = "Track2";
	private static final String TRACK1 = "Track1";

	@Before
	public void init() {
		logger.setLevel(Level.DEBUG);
		rawRecord.setPayload(new LinkedHashMap<>());
	}

	@Test
	public void testParseTrack1Data1() {
		try {
			rawRecord=trackDataParser.parseTrack1Data("B2222222222222222^DOEDOEA JANEJANE/MARIA^21012010000000942000000", rawRecord);

			assertEquals(rawRecord.getRawPan(),"2222222222222222");
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.RAW_DATA.getDesc()),"{\"name\":\"Y\",\"expDt\":\"Y\",\"extServCd\":\"Y\"}");
		} catch (Exception e) {
			logger.error("Error while converting rawDataTxtMap to json string", e);		

		}
	}

	@Test
	public void testParseTrack1Data2() {
		try {
			rawRecord=trackDataParser.parseTrack1Data("2222222222222222^DOEDOEA JANEJANE/MARIA^****2010000000942000000", rawRecord);

			assertEquals(rawRecord.getRawPan(),"2222222222222222");
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.CWID.getDesc()),TRACK1);
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.RAW_DATA.getDesc()),"{\"name\":\"Y\",\"extServCd\":\"Y\"}");
		} catch (Exception e) {
			logger.error("Error while converting rawDataTxtMap to json string", e);
		}
	}

	@Test
	public void testParseTrack1Data3() {
		try {
			rawRecord=trackDataParser.parseTrack1Data("B2222222222222222^DOEDOEA JANEJANE/MARIA^2101***0000000942000000", rawRecord);

			assertEquals(rawRecord.getRawPan(),"2222222222222222");
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.CWID.getDesc()),TRACK1);
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.RAW_DATA.getDesc()),"{\"name\":\"Y\",\"expDt\":\"Y\"}");
		} catch (Exception e) {
			logger.error("Error while converting rawDataTxtMap to json string", e);
		}
	}
	@Test
	public void testParseTrack1Data4() {
		try {
			rawRecord=trackDataParser.parseTrack1Data("B2222222222222222^DOEDOEA JANEJANE/MARIA^^^^^2010000000942000000", rawRecord);
			assertEquals(rawRecord.getRawPan(),"2222222222222222");
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.CWID.getDesc()),TRACK1);
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.RAW_DATA.getDesc()),"{\"name\":\"Y\",\"extServCd\":\"Y\"}");
		} catch (Exception e) {
			logger.error("Error while converting rawDataTxtMap to json string", e);
		}
	}

	@Test
	public void testParseTrack1Data5() {
		try {
			rawRecord=trackDataParser.parseTrack1Data("B2222222222222222^DOEDOEA JANEJANE/MARIA^2101^^^0000000942000000", rawRecord);

			assertEquals(rawRecord.getRawPan(),"2222222222222222");
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.CWID.getDesc()),TRACK1);
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.RAW_DATA.getDesc()),"{\"name\":\"Y\",\"expDt\":\"Y\"}");
		} catch (Exception e) {
			logger.error("Error while converting rawDataTxtMap to json string", e);
		}
	}

	@Test
	public void testParseTrack1Data6() {
		try {
			rawRecord=trackDataParser.parseTrack1Data("B2222222222222222^DOEDOEA JANEJANE/MARIA^^^^^^^^0000000942000000", rawRecord);

			assertEquals(rawRecord.getRawPan(),"2222222222222222");
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.CWID.getDesc()),TRACK1);
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.RAW_DATA.getDesc()),"{\"name\":\"Y\"}");
		} catch (Exception e) {
			logger.error("Error while converting rawDataTxtMap to json string", e);
		}}

	@Test
	public void testParseTrack1Data7() {
		try {
			rawRecord=trackDataParser.parseTrack1Data(null, rawRecord);

			assertEquals(rawRecord.getRawPan(),"");
			assertEquals(rawRecord.getPayload(),new HashMap<>());
		} catch (Exception e) {
			logger.error("Error while converting rawDataTxtMap to json string", e);
		}}

	@Test
	public void testParseTrack2Data1() {
		try {
			rawRecord=trackDataParser.parseTrack2Data("5555555555555555=21012010000000942000000", rawRecord);

			assertEquals(rawRecord.getRawPan(),"5555555555555555");
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.RAW_DATA.getDesc()),"{\"expDt\":\"Y\",\"extServCd\":\"Y\"}");
		} catch (Exception e) {
			logger.error("Error while converting rawDataTxtMap to json string", e);
		}}

	@Test
	public void testParseTrack2Data2() {
		try {
			rawRecord=trackDataParser.parseTrack2Data("5555555555555555=****2010000000942000000", rawRecord);

			assertEquals(rawRecord.getRawPan(),"5555555555555555");
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.CWID.getDesc()),TRACK2);
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.RAW_DATA.getDesc()),"{\"extServCd\":\"Y\"}");
		} catch (Exception e) {
			logger.error("Error while converting rawDataTxtMap to json string", e);
		}
	}
	@Test
	public void testParseTrackData3() {
		try {
			rawRecord=trackDataParser.parseTrack2Data("5555555555555555=2101***0000000942000000", rawRecord);

			assertEquals(rawRecord.getRawPan(),"5555555555555555");
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.CWID.getDesc()),TRACK2);
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.RAW_DATA.getDesc()),"{\"expDt\":\"Y\"}");
		} catch (Exception e) {
			logger.error("Error while converting rawDataTxtMap to json string", e);
		}}

	@Test
	public void testParseTrack2Data4() {
		try {
			rawRecord=trackDataParser.parseTrack2Data("5555555555555555=====2010000000942000000", rawRecord);

			assertEquals(rawRecord.getRawPan(),"5555555555555555");
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.CWID.getDesc()),TRACK2);
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.RAW_DATA.getDesc()),"{\"extServCd\":\"Y\"}");
		} catch (Exception e) {
			logger.error("Error while converting rawDataTxtMap to json string", e);
		}}

	@Test
	public void testParseTrack2Data5() {
		try {
			rawRecord=trackDataParser.parseTrack2Data("5555555555555555=2101===0000000942000000", rawRecord);

			assertEquals(rawRecord.getRawPan(),"5555555555555555");
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.CWID.getDesc()),TRACK2);
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.RAW_DATA.getDesc()),"{\"expDt\":\"Y\"}");
		} catch (Exception e) {
			logger.error("Error while converting rawDataTxtMap to json string", e);
		}}

	@Test
	public void testParseTrack2Data6() {
		try {
			rawRecord=trackDataParser.parseTrack2Data("5555555555555555========0000000942000000", rawRecord);

			assertEquals(rawRecord.getRawPan(),"5555555555555555");
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.CWID.getDesc()),TRACK2);
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.RAW_DATA.getDesc()),"{}");
		} catch (Exception e) {
			logger.error("Error while converting rawDataTxtMap to json string", e);
		}}


	@Test
	public void testParseTrack2Data7() {
		try {
			rawRecord=trackDataParser.parseTrack2Data("5555555555555555D21012010000000942000000", rawRecord);

			assertEquals(rawRecord.getRawPan(),"5555555555555555");
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.RAW_DATA.getDesc()),"{\"expDt\":\"Y\",\"extServCd\":\"Y\"}");
		} catch (Exception e) {
			logger.error("Error while converting rawDataTxtMap to json string", e);
		}}

	@Test
	public void testParseTrack2Data8() {
		try {
			rawRecord=trackDataParser.parseTrack2Data("5555555555555555D****2010000000942000000", rawRecord);
			assertEquals(rawRecord.getRawPan(),"5555555555555555");
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.CWID.getDesc()),TRACK2);
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.RAW_DATA.getDesc()),"{\"extServCd\":\"Y\"}");
		} catch (Exception e) {
			logger.error("Error while converting rawDataTxtMap to json string", e);
		}}

	@Test
	public void testParseTrackData9() {
		try {
			rawRecord=trackDataParser.parseTrack2Data("5555555555555555D2101***0000000942000000", rawRecord);

			assertEquals(rawRecord.getRawPan(),"5555555555555555");
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.CWID.getDesc()),TRACK2);
			assertEquals(rawRecord.getPayload().get(VendorPayloadTokens.RAW_DATA.getDesc()),"{\"expDt\":\"Y\"}");
		} catch (Exception e) {
			logger.error("Error while converting rawDataTxtMap to json string", e);
		}}


}
