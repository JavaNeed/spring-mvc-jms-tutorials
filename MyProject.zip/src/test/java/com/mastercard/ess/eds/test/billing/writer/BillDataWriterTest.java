package com.mastercard.ess.eds.test.billing.writer;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbcp.BasicDataSource;
import org.easymock.EasyMock;
import org.junit.Test;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.mastercard.ess.eds.billing.dao.BillDataDAO;
import com.mastercard.ess.eds.billing.util.CSVWriterUtils;
import com.mastercard.ess.eds.billing.vo.BillDataVO;
import com.mastercard.ess.eds.billing.vo.FileItemVO;
import com.mastercard.ess.eds.billing.writer.BillDataWriter;
import com.mastercard.ess.eds.domain.FileDetails;

public class BillDataWriterTest {
	List<BillDataVO> billDataVOList;
	BillDataWriter billDataWriter;
	FileItemVO fileItemVO;
	CSVWriterUtils csvWriterUtils;
	BillDataDAO billDataDao;
	JdbcTemplate jdbcTemplate;
	BillDataVO billDataVO;
	ExecutionContext executionContext;

	@Test
	public void test() throws Exception {
		fileItemVO = new FileItemVO();
		billDataVO = new BillDataVO();
		csvWriterUtils = EasyMock.createMock(CSVWriterUtils.class);
		fileItemVO.setJob_instnce_id(123);
		fileItemVO.setCrte_user_id("");
		fileItemVO.setLst_updt_user_id("");
		fileItemVO.setFile_loc_txt("");
		billDataVO.setPanNum(123);
		billDataVO.setPriceCatid(3);
		billDataVOList = new ArrayList<BillDataVO>();
		billDataVOList.add(billDataVO);
		billDataWriter = new BillDataWriter(csvWriterUtils, fileItemVO, null);
		List<Map<String, Object>> icaList = new ArrayList<Map<String, Object>>();
		executionContext = new ExecutionContext();
		executionContext.put("listOfEligibleIca", icaList);
		List<FileDetails> fileDetails = new ArrayList<>();
		executionContext.put("fileStatusList", fileDetails);
		billDataWriter.setExecutionContext(executionContext);
		EasyMock.expect(csvWriterUtils.createBillDataCSVFile(billDataVOList, icaList , "billGenerationJob"))
		.andReturn(fileItemVO);
		EasyMock.expect(csvWriterUtils.getBillingFileName()).andReturn("filename");
		EasyMock.replay(csvWriterUtils);
		billDataWriter.setJobInstanceId(new BigDecimal(0));
		billDataWriter.setJobInstanceName("billGenerationJob");
		billDataWriter.write(billDataVOList);
		
		billDataWriter = new BillDataWriter(csvWriterUtils, null, null);
		billDataWriter.setJobInstanceId(new BigDecimal(0));
		billDataWriter.setJobInstanceName("billGenerationJob");
		billDataWriter.setExecutionContext(executionContext);
		billDataWriter.write(billDataVOList);
	}

	
	@Test
	public void test1() {
		billDataWriter = new BillDataWriter(csvWriterUtils, fileItemVO,
				new BillDataDAO(new BasicDataSource()));
		billDataWriter.beforeWrite(billDataVOList);
	}

	@Test
	public void test2() {

		billDataWriter = new BillDataWriter(csvWriterUtils, fileItemVO,
				new BillDataDAO(new BasicDataSource()));
		billDataWriter.onWriteError(new Exception(), billDataVOList);

	}

	@Test
	public void test3() {
		fileItemVO = new FileItemVO();
		billDataVO = new BillDataVO();

		/* fileItemVO.setJob_instnce_id(); */
		fileItemVO.setCrte_user_id("");
		fileItemVO.setLst_updt_user_id("");
		fileItemVO.setFile_loc_txt("");
		billDataVO.setPanNum(123);
		billDataVO.setPriceCatid(3);
		billDataVOList = new ArrayList<BillDataVO>();
		billDataVOList.add(billDataVO);
		billDataDao = EasyMock.createMock(BillDataDAO.class);
		billDataWriter = new BillDataWriter(csvWriterUtils, fileItemVO,
				billDataDao);
		billDataWriter.getJobInstanceName();
		billDataWriter.setJobInstanceId(new BigDecimal(0));
		billDataWriter.afterWrite(billDataVOList);

	}
	
	@Test
	public void testExecutionContext() {
		billDataWriter = new BillDataWriter(csvWriterUtils, fileItemVO, billDataDao);
		billDataWriter.setExecutionContext(executionContext);
		assertEquals(executionContext, billDataWriter.getExecutionContext());
	}
	
	
}