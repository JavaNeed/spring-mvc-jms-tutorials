package com.mastercard.ess.eds.test.batch.processor;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.batch.processor.ADCNotificationProcessor;
import com.mastercard.ess.eds.core.dao.ADCNotificationDao;
import com.mastercard.ess.eds.core.service.ADCNotificationService;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.ProcessedRecord;

public class ADCNotificationProcessorTest {

	ADCNotificationService adcNotificationService;
	ADCNotificationDao adcNotificationDao;
	ADCNotificationProcessor adcNotificationProcessor;

	EDSRecord edsRecord;
	ProcessedRecord processedRecord;
	
	Logger logger;

	@Before
	public void init() {
		logger = Logger.getLogger(ADCNotificationProcessor.class);
		logger.setLevel(Level.DEBUG);
		adcNotificationDao = EasyMock.createMock(ADCNotificationDao.class);
		adcNotificationService = new ADCNotificationService(adcNotificationDao);
		adcNotificationProcessor = new ADCNotificationProcessor(adcNotificationService);
		processedRecord = new ProcessedRecord();
		processedRecord.setPan(new BigDecimal("625421221662123727"));
		edsRecord = new EDSRecord();
		edsRecord.setProcRecord(processedRecord);
	}

	@Test
	public void testprocess() {
		EasyMock.expect(adcNotificationDao.isAccountADCNotified(processedRecord.getPan())).andReturn("Y");
		EasyMock.replay(adcNotificationDao);
		try {
			EDSRecord record = adcNotificationProcessor.process(edsRecord);
			assertEquals("Y",record.getProcRecord().getIsAccountADCNotified());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
}
