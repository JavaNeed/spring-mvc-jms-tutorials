package com.mastercard.ess.eds.test.batch.scheduler;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.mastercard.ess.eds.batch.scheduler.CPPReportGenerationScheduler;
import com.mastercard.ess.eds.batch.scheduler.CPPRulesExecutionScheduler;
import com.mastercard.ess.eds.core.util.GlobalConstants;

public class CPPRulesExecutionSchedulerTest {
	@Autowired
	ApplicationContext context;
	@Autowired
	JobLauncher joLauncher;
	@Autowired
	Job job;
	@Autowired
	JobExecution jobExecution;
	private Logger logger = Logger.getLogger(CPPReportGenerationScheduler.class);
	CPPRulesExecutionScheduler cppRulesExecutionScheduler = new CPPRulesExecutionScheduler();
	private String cppSrcName;
	
	@Before
	public void init(){
		job=Mockito.mock(Job.class);
		context = Mockito.mock(ApplicationContext.class);
		joLauncher =Mockito.mock(JobLauncher.class);
	}
		
	@Before
	public void init1() throws JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException {
		job=Mockito.mock(Job.class);
		context = Mockito.mock(ApplicationContext.class);
		joLauncher =Mockito.mock(JobLauncher.class);
		
		JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
		SimpleDateFormat datetimeFormat = new SimpleDateFormat(GlobalConstants.DATE_TIME_FORMAT);
		String timestamp = datetimeFormat.format(new Date());
		
		Date date = new Date();  
	    SimpleDateFormat formatter = new SimpleDateFormat("dd_MMM_yyyy_hh_mm_ss");
	    String strDate= formatter.format(date);
		
	    String cppSrc = cppSrcName + strDate ;
	    
		jobParametersBuilder.addString("currentDateTime", timestamp);
		jobParametersBuilder.addString("cppSrcName", cppSrc);
		
		logger.info("currentDateTime : " + timestamp);
		logger.info("cppSrcName : " + cppSrc);
		
		JobParameters jobParameters = jobParametersBuilder.toJobParameters();
		
		logger.info("jobParameters : " + jobParameters);
		
		cppRulesExecutionScheduler.setCppSrcName("cppRuleJob");
		cppRulesExecutionScheduler.setJob(job);
		cppRulesExecutionScheduler.setContext(context);
		cppRulesExecutionScheduler.setJoLauncher(joLauncher);
		
		Mockito.when(context.getBean("cppReportGenerationJob")).thenReturn(job);
		Mockito.when(joLauncher.run(job, jobParameters)).thenReturn(jobExecution);
	}
	
	@Test
	public void runTest(){
		cppRulesExecutionScheduler.setCppSrcName("cppRuleJob");
		cppRulesExecutionScheduler.setJob(job);
		cppRulesExecutionScheduler.setContext(context);
		cppRulesExecutionScheduler.setJoLauncher(joLauncher);
		cppRulesExecutionScheduler.run();
	}
	
	@Test
	public void runTest1(){
		cppRulesExecutionScheduler.setCppSrcName("cppRuleJob");
		cppRulesExecutionScheduler.setJob(job);
		cppRulesExecutionScheduler.setContext(context);
		cppRulesExecutionScheduler.setJoLauncher(joLauncher);
		cppRulesExecutionScheduler.run();
	}
	
	@Test
	public void splunkLoggerTest() {
		cppRulesExecutionScheduler.splunkLogger(new JobExecutionException("CPP Rule Job Execution Failed"));
	}
	

}
