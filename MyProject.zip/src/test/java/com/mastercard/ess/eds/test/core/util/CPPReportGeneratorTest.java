package com.mastercard.ess.eds.test.core.util;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.core.dao.CPPReportStausDAO;
import com.mastercard.ess.eds.core.service.CPPReportService;
import com.mastercard.ess.eds.core.util.CPPReportGenerator;
import com.mastercard.ess.eds.core.util.PreProcessingPANStatusManager;
import com.mastercard.ess.eds.domain.CPPReportInfo;

public class CPPReportGeneratorTest {
	CPPReportGenerator cPPReportGenerator;
	CPPReportInfo cPPReportInfo;
	CPPReportInfo cPPReportInfo1;
	CPPReportService cPPReportService;
	CPPReportStausDAO cPPReportStausDAO;
	List<CPPReportInfo> cppReportInfos = new ArrayList<CPPReportInfo>();
	List<CPPReportInfo> cppReportInfos1 = new ArrayList<CPPReportInfo>();
	String reportType;
	BigDecimal jobInstanceId;
	CPPReportStausDAO cppReportStausDAO;
	String jobInstanceName;
	String cppDetailReportPath = "..";
	String cppSummaryReportPath = "..";
	String filePath = "/tmp/CPPReport/CPPDetailReport_20/10/2016.xlsx";
	private Logger logger = Logger.getLogger(CPPReportGenerator.class);

	@Before
	public void init() {
		logger.setLevel(Level.DEBUG);
		
		cppReportStausDAO = EasyMock.createMock(CPPReportStausDAO.class);
		cPPReportService = new CPPReportService(cppReportStausDAO);
		

	}

	@Test
	public void test() {
		logger.setLevel(Level.DEBUG);
		cPPReportInfo = new CPPReportInfo();
		cPPReportInfo.setCardsCountryPercentage(0.01);
		cPPReportInfo.setCardsUsedCount((long) 9);
		cPPReportInfo.setGroupId(2);
		cPPReportInfo.setIssuerCountryCode("INDIA");
		cPPReportInfo.setLocalTransactionAmount(100000);
		cPPReportInfo.setLocationId("222");
		cPPReportInfo.setMerchantCountryCode("GERMANY");
		cPPReportInfo.setMerchantName("ICICI");
		cPPReportInfo.setTransactionChannel("CNP");
		cppReportInfos.add(cPPReportInfo);
		reportType = "details";
		jobInstanceId = BigDecimal.valueOf(1324);
		jobInstanceName = "CPPReportGenerator";
		// cPPReportService = new CPPReportService();
		cPPReportGenerator = new CPPReportGenerator(cppDetailReportPath,
				cppSummaryReportPath, cPPReportService);
		cPPReportGenerator.writeToCPPReport(cppReportInfos, reportType,
				jobInstanceId, jobInstanceName, "INDIA");

	}

	@Test
	public void test1() {
		logger.setLevel(Level.DEBUG);
		cPPReportInfo = new CPPReportInfo();
		cPPReportInfo.setCardsCountryPercentage(0.01);
		cPPReportInfo.setCardsUsedCount((long) 9);
		cPPReportInfo.setGroupId(2);
		cPPReportInfo.setIssuerCountryCode("INDIA");
		cPPReportInfo.setLocalTransactionAmount(100000);
		cPPReportInfo.setLocationId("222");
		cPPReportInfo.setMerchantCountryCode("GERMANY");
		cPPReportInfo.setMerchantName("ICICI");
		cPPReportInfo.setTransactionChannel("CNP");
		cppReportInfos.add(cPPReportInfo);
		reportType = "summary";
		jobInstanceId = BigDecimal.valueOf(1324);
		jobInstanceName = "CPPReportGenerator";
		cPPReportGenerator = new CPPReportGenerator(cppDetailReportPath,
				cppSummaryReportPath, cPPReportService);
		cPPReportGenerator.writeToCPPReport(cppReportInfos, reportType,
				jobInstanceId, jobInstanceName, "INDIA");
	}

	@Test
	public void test2() {
		logger.setLevel(Level.DEBUG);
		cPPReportInfo1 = new CPPReportInfo();
		cPPReportInfo1.setCardsCountryPercentage(0.01);
		cPPReportInfo1.setCardsUsedCount((long) 9);
		cPPReportInfo1.setGroupId(2);
		cPPReportInfo1.setIssuerCountryCode("INDIA");
		cPPReportInfo1.setLocalTransactionAmount(100000);
		cPPReportInfo1.setLocationId("222");
		cPPReportInfo1.setMerchantCountryCode("GERMANY");
		cPPReportInfo1.setMerchantName("ICICI");
		cPPReportInfo1.setTransactionChannel("CP");
		cppReportInfos1.add(cPPReportInfo1);
		reportType = "summary";
		jobInstanceId = BigDecimal.valueOf(1324);
		jobInstanceName = "CPPReportGenerator";
		cPPReportGenerator = new CPPReportGenerator(cppDetailReportPath,
				cppSummaryReportPath, cPPReportService);
		cPPReportGenerator.writeToCPPReport(cppReportInfos1, reportType,
				jobInstanceId, jobInstanceName, "INDIA");
	}
	@Test
	public void test3() {
		cPPReportGenerator = new CPPReportGenerator();
		logger.setLevel(Level.DEBUG);
		cPPReportInfo1 = new CPPReportInfo();
		cPPReportInfo1.setCardsCountryPercentage(0.01);
		cPPReportInfo1.setCardsUsedCount((long) 9);
		cPPReportInfo1.setGroupId(2);
		cPPReportInfo1.setIssuerCountryCode("INDIA");
		cPPReportInfo1.setLocalTransactionAmount(100000);
		cPPReportInfo1.setLocationId("222");
		cPPReportInfo1.setMerchantCountryCode("GERMANY");
		cPPReportInfo1.setMerchantName("ICICI");
		cPPReportInfo1.setTransactionChannel("CP");
		cppReportInfos1.add(cPPReportInfo1);
		reportType = "details";
		jobInstanceId = BigDecimal.valueOf(1324);
		jobInstanceName = "CPPReportGenerator";
		cPPReportGenerator = new CPPReportGenerator(cppDetailReportPath,
				cppSummaryReportPath, cPPReportService);
		cPPReportGenerator.writeToCPPReport(cppReportInfos1, reportType,
				jobInstanceId, jobInstanceName, "INDIA");
	}
	
	@After
	public void checkFileDeletion()
	{
		try{
			File[] dirFiles = new File(".").listFiles();
			//Search Through the list
			for (int i=0; i<dirFiles.length; i++)
			{          //If the Files start

				if (dirFiles[i].getName().startsWith("..",0))
					try{
			    		File file = new File(dirFiles[i].getName());

			    		if(file.delete()){
			    			
			    		}else{
				    		File file1 = new File(dirFiles[i].getName());
				    		file1.delete();
			    		}

			    	}catch(Exception e){

			    		e.printStackTrace();

			    	}

			}

    	}catch(Exception e){

    		e.printStackTrace();

    	}
	}
}
