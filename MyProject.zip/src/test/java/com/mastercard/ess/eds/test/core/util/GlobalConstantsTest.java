package com.mastercard.ess.eds.test.core.util;

import static org.junit.Assert.assertNotNull;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.junit.Assert;
import org.junit.Test;

import com.mastercard.ess.eds.core.util.GlobalConstants;

public class GlobalConstantsTest {

	@Test
	public void testgetDateTimeFormatField(){
		
		Assert.assertEquals("dd-MM-yyyy HH:mm:ss",GlobalConstants.getDateTimeFormatField());
		
	}
	
	@Test
	public void testGlobalConstants(){
		
		Constructor<GlobalConstants> c = null;
		GlobalConstants u = null;
		try {
			c = GlobalConstants.class.getDeclaredConstructor();
		} catch (NoSuchMethodException | SecurityException e1) {
		}
		c.setAccessible(true);
		try {
			 u = c.newInstance();
		} catch (InstantiationException | IllegalAccessException | IllegalArgumentException
				| InvocationTargetException e) {
		}
		assertNotNull(u);
	}
}
