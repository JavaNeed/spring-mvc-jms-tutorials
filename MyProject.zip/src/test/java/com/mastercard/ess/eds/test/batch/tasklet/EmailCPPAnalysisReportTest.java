package com.mastercard.ess.eds.test.batch.tasklet;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameters;
import org.springframework.core.io.FileSystemResource;

import com.mastercard.ess.eds.batch.tasklet.EmailCPPAnalysisReport;
import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;

public class EmailCPPAnalysisReportTest {
	private Logger logger = Logger.getLogger(EmailCPPAnalysisReport.class);
	EventPublisher eventPublisher;
	NotificationEventVO notificationEventVO;
	FileSystemResource summaryFileSystemResource;
	FileSystemResource detailFileSystemResource;
    EmailCPPAnalysisReport emailCPPAnalysisReport;	
    JobExecution jobExecution;
    JobInstance jobInstance;
    JobParameters jobParameters;
    public String cppSummaryReportPath = "tmp/CPPReport/CPPSummaryReport_";
    public String cppDetailReportPath ="/tmp/CPPReport/CPPDetailReport_";
    @Before
    
	public void init(){
    	logger.setLevel(Level.DEBUG);
    	emailCPPAnalysisReport = new EmailCPPAnalysisReport();
		Calendar now = Calendar.getInstance();
		String currentDate = (now.get(Calendar.MONTH) + 1) + "-" + now.get(Calendar.DATE) + "-"
				+ now.get(Calendar.YEAR);
		String summaryFile = cppSummaryReportPath + currentDate + ".xlsx";
		
		String detailFile = cppDetailReportPath + currentDate + ".xlsx";
	    notificationEventVO = new NotificationEventVO();
		Map<String, String> jobParams = new HashMap<String, String>();
		
		jobParams.put("summaryFile", summaryFile);
		jobParams.put("detailFile",  detailFile);
		
		notificationEventVO.setEventName("CPP REPORT FILE GENERATED");
		notificationEventVO.setJobParams(jobParams);
		notificationEventVO.setJobName("cppReportGenerationJob");
		notificationEventVO.setJobID(new BigDecimal(123));
		
		summaryFileSystemResource = new FileSystemResource(summaryFile);
		detailFileSystemResource = new FileSystemResource(detailFile);
		
		jobInstance = new JobInstance(new Long(123), "cppReportGenerationJob");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		eventPublisher = EasyMock.createMock(EventPublisher.class);
		
		
	}
	@Test
	public void afterJobTest() {
		logger.setLevel(Level.DEBUG);
    try {
		emailCPPAnalysisReport = new EmailCPPAnalysisReport(eventPublisher);
		jobExecution = new JobExecution(jobInstance, jobParameters);
		emailCPPAnalysisReport.afterJob(jobExecution);
		emailCPPAnalysisReport.beforeJob(jobExecution);
		
    }
    catch (Exception e) {
	//	e.printStackTrace();
	}
}
}
