package com.mastercard.ess.eds.test.batch.validator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.repeat.RepeatStatus;

import com.mastercard.ess.eds.batch.validator.PreProcessor;
import com.mastercard.ess.eds.core.util.SecurityUtils;

public class PreProcessorTest {

	PreProcessor preProcessor;

	StepContribution stepContribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	SecurityUtils securityUtils;

	Logger logger;

	@Before
	public void init() {
		logger = Logger.getLogger(PreProcessor.class);
		logger.setLevel(Level.DEBUG);
		preProcessor = new PreProcessor();
		preProcessor.setUnzipLocation("");
		String fileName = "file:///MCI.AR.RABC.X.E1234567.D160812.T111135.C001";

		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();

		jobParameter = new JobParameter(fileName, true);
		parameters.put("input.file", jobParameter);
		
		jobParameters = new JobParameters(parameters);

		jobInstance = new JobInstance(new Long(123), "importRawRecords");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		Properties propertyFile = new Properties();
		propertyFile.put("wrapped.key.filename", "session.key");
		propertyFile.put("datafile.name", "payload.csv");
		jobExecution.getExecutionContext().put("vendorProperties", propertyFile);
		stepExecution = new StepExecution("loadRawRecords", jobExecution);

		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);

		stepContribution = new StepContribution(stepExecution);
	}

	@After
	public void destroy() {
		File file = new File("MCI.AR.RABC.X.E1234567.D160812.T111135.C001");
		if (file.exists()) {
			file.delete();
		}
	}

	@Test
	public void checkKeyFilePresentTest() {

		preProcessor.setDataFileName("payload.csv");
		preProcessor.setSessionKeyFile("session.key");
		List<String> filesInsideZip = new ArrayList<String>();
		filesInsideZip.add("payload.csv");
		filesInsideZip.add("session.key");
		assertTrue(preProcessor.checkKeyFilePresent(filesInsideZip));
	}

	@Test
	public void checkKeyFileNotPresentTest() {
		preProcessor.setDataFileName("payload.csv");
		List<String> filesInsideZip = new ArrayList<String>();
		filesInsideZip.add("payload.csv");
		filesInsideZip.add("session.key");
		assertFalse(preProcessor.checkKeyFilePresent(filesInsideZip));
	}

	@Test
	public void readWrappedSessionKeyTest() {
		ClassLoader classLoader = getClass().getClassLoader();

		File keyFile = new File(classLoader
				.getResource("keystore/password.txt").getFile());
		assertEquals("ch@nge1t", preProcessor.readWrappedSessionKey(keyFile));
	}

	@Test
	public void readWrappedSessionInvalidKeyTest() {
		ClassLoader classLoader = getClass().getClassLoader();

		File keyFile = new File(classLoader.getResource("keystore").getFile());
		assertNull(preProcessor.readWrappedSessionKey(keyFile));
	}
	

	@Test
	public void testExecute() throws Exception {
		assertEquals(RepeatStatus.FINISHED,
				preProcessor.execute(stepContribution, chunkContext));
	}

	@Test
	public void test() throws FileNotFoundException {
		securityUtils = EasyMock.createMock(SecurityUtils.class);
		EasyMock.expect(securityUtils.getSessionKey("")).andReturn(null);
		EasyMock.replay(securityUtils);
		preProcessor.setSecurityUtils(securityUtils);
        assertEquals(null,preProcessor.unwrapSessionKey(""));
	}

}
