package com.mastercard.ess.eds.test.core.service;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Test;

import com.mastercard.ess.eds.core.dao.EDSRecordDao;
import com.mastercard.ess.eds.core.service.EDSRecordWriterService;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.RawRecord;

public class EDSRecordWriterServiceTest {
	EDSRecordDao edsRecordDao;

	EDSRecordWriterService eDSRecordWriterService;
	List<EDSRecord> list;
	RawRecord rawRecord;
	List<String> listOne = new ArrayList<String>();
	
	@Test
	public void test() {
		eDSRecordWriterService = new EDSRecordWriterService();
		edsRecordDao = EasyMock.createMock(EDSRecordDao.class);
		eDSRecordWriterService = new EDSRecordWriterService(edsRecordDao);
		EasyMock.expect(edsRecordDao.ifReportableRecordsExist()).andReturn(true);
		//EasyMock.replay(edsRecordDao);

		EasyMock.replay(edsRecordDao);

		
		Boolean retVal = eDSRecordWriterService.ifReportableRecordsExist();
		assertEquals(retVal,true);
	}
	
	@Test
	public void test1()
	{
		edsRecordDao = EasyMock.createMock(EDSRecordDao.class);
		eDSRecordWriterService = new EDSRecordWriterService(edsRecordDao);
		eDSRecordWriterService.updateRecordStatusPostFileGeneration("",new BigDecimal(1234), new ArrayList<EDSRecord>(),new HashMap<BigDecimal, String>(),0);
		
	}
	
	@Test
	public void testWriteRecord() {
		edsRecordDao = EasyMock.createMock(EDSRecordDao.class);
		eDSRecordWriterService = new EDSRecordWriterService(edsRecordDao);
		eDSRecordWriterService.writeRecord(new ArrayList<EDSRecord>(), new BigDecimal(1234));
	}
	
   @Test
   public void testUpdateStatusOfFaultyInputRecords() {
	   edsRecordDao = EasyMock.createMock(EDSRecordDao.class);
		eDSRecordWriterService = new EDSRecordWriterService(edsRecordDao);
		eDSRecordWriterService.updateStatusOfFaultyInputRecords(rawRecord);
   }
   
   @Test
   public void testupdateRecordStatusPostProcessing() {
	   edsRecordDao = EasyMock.createMock(EDSRecordDao.class);
		eDSRecordWriterService = new EDSRecordWriterService(edsRecordDao);
		eDSRecordWriterService.setJobInstanceName("");
		eDSRecordWriterService.updateRecordStatusPostProcessing(new ArrayList<EDSRecord>(), "",new BigDecimal(1234));
   }
   
}
