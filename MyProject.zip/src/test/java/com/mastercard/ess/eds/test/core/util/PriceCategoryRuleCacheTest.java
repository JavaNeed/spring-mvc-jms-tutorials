package com.mastercard.ess.eds.test.core.util;
	import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
	import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;

	import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.mastercard.ess.eds.core.dao.PriceCategoryDAO;
import com.mastercard.ess.eds.core.rule.PriceCategoryRule;
import com.mastercard.ess.eds.core.util.PriceCategoryRuleCache;
	

	public class PriceCategoryRuleCacheTest {
		

		private Logger logger = Logger.getLogger(PriceCategoryRuleCache.class);
		private PriceCategoryRuleCache priceCategoryRuleCache = new PriceCategoryRuleCache();
		
		@Mock
		PriceCategoryDAO priceCategoryDao;
		
		@Before
	    public void setUp() throws Exception {
			logger.setLevel(Level.DEBUG);
			MockitoAnnotations.initMocks(this);
			priceCategoryRuleCache.setPriceCategoryDAO(priceCategoryDao);
			Mockito.when(priceCategoryRuleCache.getCache()).thenReturn(new ArrayList<PriceCategoryRule>());
		}

		 	@Test
		    public void testGetCache(){
		         logger.setLevel(Level.DEBUG);
		         priceCategoryRuleCache.setPriceCategoryDAO(priceCategoryDao);
		 		assertEquals(new ArrayList<PriceCategoryRule>(),priceCategoryRuleCache.getCache());
		 		priceCategoryRuleCache.getPriceCategoryMap();
		 		List<PriceCategoryRule> ruleList = new ArrayList<PriceCategoryRule>();
		 		ruleList.add(new PriceCategoryRule());
		 		priceCategoryRuleCache.getNewList(ruleList);
		 		
		    }
	}


