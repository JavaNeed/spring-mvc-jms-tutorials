package com.mastercard.ess.eds.test.batch.scheduler;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.mastercard.ess.eds.batch.scheduler.CPPAnalysisScheduler;
import com.mastercard.ess.eds.core.util.GlobalConstants;

public class CPPAnalysisSchedulerTest {

	@Autowired
	ApplicationContext context;
	@Autowired
	JobLauncher joLauncher;
	@Autowired
	Job job;
	@Autowired
	JobExecution jobExecution;
	
	CPPAnalysisScheduler cppAnalysisScheduler = new CPPAnalysisScheduler();
	
	@Before
	public void init(){
		job=Mockito.mock(Job.class);
		context = Mockito.mock(ApplicationContext.class);
		joLauncher =Mockito.mock(JobLauncher.class);
	}
		
	@Before
	public void init1() throws JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException {
		job=Mockito.mock(Job.class);
		context = Mockito.mock(ApplicationContext.class);
		joLauncher =Mockito.mock(JobLauncher.class);
		
		JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
		SimpleDateFormat datetimeFormat = new SimpleDateFormat(GlobalConstants.DATE_TIME_FORMAT);
		String timestamp = datetimeFormat.format(new Date());
		jobParametersBuilder.addString("currentDateTime", timestamp);
		JobParameters jobParameters = jobParametersBuilder.toJobParameters();
		
		cppAnalysisScheduler.setJob(job);
		cppAnalysisScheduler.setContext(context);
		cppAnalysisScheduler.setJoLauncher(joLauncher);
		
		Mockito.when(context.getBean("cppAnalysis")).thenReturn(job);
		Mockito.when(joLauncher.run(job, jobParameters)).thenReturn(jobExecution);
	}
	
	@Test
	public void runTest() throws JobExecutionAlreadyRunningException{
		cppAnalysisScheduler.setJob(job);
		cppAnalysisScheduler.setContext(context);
		cppAnalysisScheduler.setJoLauncher(joLauncher);
		cppAnalysisScheduler.run();
	}
	
	@Test
	public void runTest1() throws JobExecutionAlreadyRunningException{
		cppAnalysisScheduler.setJob(job);
		cppAnalysisScheduler.setContext(context);
		cppAnalysisScheduler.setJoLauncher(joLauncher);
		cppAnalysisScheduler.run();
	}
	
	@Test
	public void splunkLoggerTest() {
		cppAnalysisScheduler.splunkLogger(new JobExecutionException("cppAnalysis job Failed"));
	}

}
