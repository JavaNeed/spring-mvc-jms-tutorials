package com.mastercard.ess.eds.test.batch.listener;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Level; 
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.file.FlatFileParseException;

import com.mastercard.ess.eds.batch.listener.FlatFileParseExceptionListener;
import com.mastercard.ess.eds.core.dao.EDSSourceDao;
import com.mastercard.ess.eds.core.service.EDSSourceService;

public class FlatFileParseExceptionListenerTest {
	FlatFileParseExceptionListener flatFileParseExceptionListener;
	EDSSourceService edsSourceService;
	EDSSourceDao edsSourceDao;
	StepExecution stepExecution;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	FlatFileParseException flatFileParseException;
	Logger logger;
	
	
	@Before
	public void init(){
		
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		String fileName = "test.txt";
		jobInstance = new JobInstance(new Long(123), "importRawRecords");
		jobParameter = new JobParameter(fileName, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("loadRawRecords", jobExecution);
		flatFileParseException = new FlatFileParseException("flatFileParseException", "", 4);
		edsSourceDao = EasyMock.createMock(EDSSourceDao.class);
		edsSourceService = new EDSSourceService(edsSourceDao);
		flatFileParseExceptionListener = new FlatFileParseExceptionListener(edsSourceService);
		flatFileParseExceptionListener.setErrFileLoc("");
		logger = Logger.getLogger(FlatFileParseExceptionListener.class);
	} 
	
	@After
	public void destroy(){
		File file = new File("test.txt.err");
		if (file.exists()) {
			file.delete();
		}
	}
	
	@Test
	public void onReadError() {
		logger.setLevel(Level.DEBUG);
		flatFileParseExceptionListener.beforeStep(stepExecution);
		flatFileParseExceptionListener.onReadError(flatFileParseException);
		assertEquals("test.txt", flatFileParseExceptionListener.getFileName());

	}
	
	@Test
	public void testAfterStep() {
		FlatFileParseExceptionListener ffpe = new FlatFileParseExceptionListener();
		StepExecution stepExecution = null;
		assertEquals(null, ffpe.afterStep(stepExecution));
	}

}
