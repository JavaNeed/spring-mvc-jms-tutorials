package com.mastercard.ess.eds.test.batch.listener;


import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import com.mastercard.ess.eds.batch.listener.VendorActiveAccountReportMailListener;
import com.mastercard.ess.eds.core.events.EventPublisher;

public class VendorActiveAccountReportMailListenerTest {
	EventPublisher eventPublisher;
	String activeVendorAccountReportPath;
	private Logger logger;
	StepContribution stepContribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	VendorActiveAccountReportMailListener vendorActiveAccountReportMailListener;
	@Before
	public void init()
	{
		logger = Logger.getLogger(VendorActiveAccountReportMailListener.class);
		logger.setLevel(Level.DEBUG);
		String fileName = "file:///MCI.AR.RABC.X.E1234567.D160812.T111135.C001";
		Map<String, JobParameter> parameters = new LinkedHashMap<String, JobParameter>();
		jobParameter = new JobParameter(fileName, true);
		parameters.put("input.file", jobParameter);
		jobParameters = new JobParameters(parameters);
		jobInstance = new JobInstance(new Long(123), "importRawRecords");
		jobExecution = new JobExecution(jobInstance, jobParameters);
	}
	@Test
	public void test() throws Exception {
		vendorActiveAccountReportMailListener = new VendorActiveAccountReportMailListener();
		vendorActiveAccountReportMailListener.afterJob(jobExecution);
		vendorActiveAccountReportMailListener.beforeJob(null);
		vendorActiveAccountReportMailListener.execute(stepContribution,chunkContext);
	}

}
