package com.mastercard.ess.eds.test.core.service;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;

import org.apache.commons.dbcp.BasicDataSource;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.mastercard.ess.eds.billing.dao.BillDataDAO;
import com.mastercard.ess.eds.core.dao.CustomerPanReportDao;
import com.mastercard.ess.eds.core.service.CustomerFileReportService;

public class CustomerFileReportServiceTest {
	CustomerFileReportService customerFileReportService;
	CustomerPanReportDao customerPanReportDao;
	BillDataDAO billDataDAO;

	@Before
	public void setUp() {
		customerFileReportService = new CustomerFileReportService(
				new CustomerPanReportDao(new BasicDataSource()));
		customerPanReportDao = EasyMock.createMock(CustomerPanReportDao.class);
		customerFileReportService = new CustomerFileReportService(
				customerPanReportDao);
	}

	
	@Test
	public void test() {
		EasyMock.expect(
				customerPanReportDao.createGeneratedFileRecord("",new BigDecimal(1),
						"", 0)).andReturn(0);
		EasyMock.replay(customerPanReportDao);

		int response = customerFileReportService.createGeneratedFileRecord("",new BigDecimal(1),
				"", 0);
		assertEquals(response, 0);
	}

	@Test
	public void test1() {
		new CustomerFileReportService(new CustomerPanReportDao(
				new BasicDataSource()));
	}

	@Test
	public void test2() {
		customerFileReportService = new CustomerFileReportService();
		billDataDAO = EasyMock.createMock(BillDataDAO.class);
		customerFileReportService = new CustomerFileReportService(billDataDAO);
		customerFileReportService.updateCustomerFileStatus("", 0, "",
				new BigDecimal(0), "");

	}

	@Test
	public void testcreateCustomerPanReportRecord() {
		billDataDAO = EasyMock.createMock(BillDataDAO.class);
		customerFileReportService = new CustomerFileReportService(billDataDAO);
		customerFileReportService.createCustomerPanReportRecord(new BigDecimal(0), "", "", "", 
				"", new BigDecimal(0));

	}
}
