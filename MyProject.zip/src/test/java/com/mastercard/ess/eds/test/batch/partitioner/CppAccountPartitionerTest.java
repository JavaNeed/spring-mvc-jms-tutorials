package com.mastercard.ess.eds.test.batch.partitioner;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.partitioner.CppAccountPartitioner;
import com.mastercard.ess.eds.core.dao.CPPAccountDAO;
import com.mastercard.ess.eds.core.service.CPPAccountService;
import com.mastercard.ess.eds.domain.CPPRecord;

public class CppAccountPartitionerTest {

	CPPAccountService cppAccountService;
	CppAccountPartitioner cppAccountPartitioner;
	CPPAccountDAO cppAccountDAO;
	Logger logger;
	List<CPPRecord> cppRecordList;
	
	@Before
	public void init() {
		logger = Logger.getLogger(CppAccountPartitioner.class);
		cppAccountDAO = EasyMock.createMock(CPPAccountDAO.class);
		cppAccountService = new CPPAccountService();
		cppAccountService.setCppAccountDAO(cppAccountDAO);
		cppAccountPartitioner = new CppAccountPartitioner();
		cppAccountPartitioner.setCppAccountService(cppAccountService);
		cppAccountPartitioner.getCppAccountService();
		cppAccountPartitioner.setRecordsPerPartitionsLimit(999);
		cppAccountPartitioner.getRecordsPerPartitionsLimit();
		Date createDate = new Date(1/3/2017);
		
		CPPRecord cppRecord = new CPPRecord();
		cppRecord.setPan(new BigDecimal("5002010000001004"));
		cppRecord.setCreateDate(createDate);
		CPPRecord cppRecord1 = new CPPRecord();
		cppRecord1.setPan(new BigDecimal("5002030000001002"));
		cppRecord1.setCreateDate(createDate);
		CPPRecord cppRecord2 = new CPPRecord();
		cppRecord2.setPan(new BigDecimal("5002049280910252"));
		cppRecord2.setCreateDate(createDate);
		CPPRecord cppRecord3 = new CPPRecord();
		cppRecord3.setPan(new BigDecimal("5002049280911111"));
		cppRecord3.setCreateDate(createDate);
		
		cppRecordList= new ArrayList<>();
		cppRecordList.add(cppRecord);cppRecordList.add(cppRecord1);cppRecordList.add(cppRecord2);cppRecordList.add(cppRecord3);
		
		EasyMock.expect(cppAccountDAO.fetchVendorProvidedAccounts()).andReturn(cppRecordList);
		EasyMock.replay(cppAccountDAO);
		
	}
	
	@Test
	public void testpartition() {
		logger.setLevel(Level.DEBUG);
		ExecutionContext executionContext = new ExecutionContext();
		String panList = "'5002010000001004','5002030000001002','5002049280910252'";
		executionContext.put("panList", panList);
		
		ExecutionContext executionContext1 = new ExecutionContext();
		String panList1 = "'5002049280911111'";
		executionContext1.put("panList", panList1);
		
		Map<String, ExecutionContext> partitionMapExpected = new HashMap<String, ExecutionContext>();
		partitionMapExpected.put("Thread --1", executionContext);
		partitionMapExpected.put("Thread --2", executionContext1);
		
		Map<String, ExecutionContext> partitionMap = cppAccountPartitioner.partition(3);
		
		assertEquals(3,partitionMap.size());

	}
	
	@Test
	public void testpartition2() {
		logger.setLevel(Level.DEBUG);
		cppAccountDAO = EasyMock.createMock(CPPAccountDAO.class);
		cppAccountService = new CPPAccountService();
		cppAccountService.setCppAccountDAO(cppAccountDAO);
		cppAccountPartitioner = new CppAccountPartitioner();
		cppAccountPartitioner.setCppAccountService(cppAccountService);
		cppAccountPartitioner.getCppAccountService();
		cppAccountPartitioner.setRecordsPerPartitionsLimit(999);
		cppAccountPartitioner.getRecordsPerPartitionsLimit();
		Date createDate = new Date(1/3/2017);
		
		CPPRecord cppRecord = new CPPRecord();
		cppRecord.setPan(new BigDecimal("5002010000001004"));
		cppRecord.setCreateDate(createDate);
		CPPRecord cppRecord1 = new CPPRecord();
		cppRecord1.setPan(new BigDecimal("5002030000001002"));
		cppRecord1.setCreateDate(createDate);
		CPPRecord cppRecord2 = new CPPRecord();
		cppRecord2.setPan(new BigDecimal("5002049280910252"));
		cppRecord2.setCreateDate(createDate);
		CPPRecord cppRecord3 = new CPPRecord();
		cppRecord3.setPan(new BigDecimal("5002049280911111"));
		cppRecord3.setCreateDate(createDate);
		
		cppRecordList= new ArrayList<>();
		cppRecordList.add(cppRecord);cppRecordList.add(cppRecord1);cppRecordList.add(cppRecord2);cppRecordList.add(cppRecord3);
		
		
		EasyMock.expect(cppAccountDAO.fetchVendorProvidedAccounts()).andReturn(null);
		EasyMock.replay(cppAccountDAO);

		Map<String, ExecutionContext> partitionMap = cppAccountPartitioner.partition(2);
		assertEquals(0,partitionMap.size());
	}
	
	@Test
	public void testpartition3() {
		
		logger.setLevel(Level.DEBUG);
		cppAccountDAO = EasyMock.createMock(CPPAccountDAO.class);
		cppAccountService = new CPPAccountService();
		cppAccountService.setCppAccountDAO(cppAccountDAO);
		cppAccountPartitioner = new CppAccountPartitioner();
		cppAccountPartitioner.setCppAccountService(cppAccountService);
		cppAccountPartitioner.getCppAccountService();
		cppAccountPartitioner.setRecordsPerPartitionsLimit(999);
		cppAccountPartitioner.getRecordsPerPartitionsLimit();
		Date createDate = new Date(1/3/2017);
		
		EasyMock.expect(cppAccountDAO.fetchVendorProvidedAccounts()).andReturn(cppRecordList);
		EasyMock.replay(cppAccountDAO);
		
		CPPRecord cppRecord4 = new CPPRecord();
		cppRecord4.setPan(new BigDecimal("5002010000001004"));
		cppRecord4.setCreateDate(createDate);
		CPPRecord cppRecord5 = new CPPRecord();
		cppRecord5.setPan(new BigDecimal("5002030000001002"));
		cppRecord5.setCreateDate(createDate);
		
		cppRecordList.add(cppRecord4);cppRecordList.add(cppRecord5);
		
		
		
		
		
		ExecutionContext executionContext = new ExecutionContext();
		String panList = "'5002010000001004','5002030000001002','5002049280910252'";
		executionContext.put("panList", panList);
		
		ExecutionContext executionContext1 = new ExecutionContext();
		String panList1 = "'5002049280911111'";
		executionContext1.put("panList", panList1);
		
		Map<String, ExecutionContext> partitionMapExpected = new HashMap<String, ExecutionContext>();
		partitionMapExpected.put("Thread --1", executionContext);
		partitionMapExpected.put("Thread --2", executionContext1);


		Map<String, ExecutionContext> partitionMap = cppAccountPartitioner.partition(1);
		assertEquals(1,partitionMap.size());
	}
	
}
