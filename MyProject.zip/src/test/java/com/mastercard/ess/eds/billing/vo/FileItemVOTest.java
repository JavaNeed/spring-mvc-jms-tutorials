package com.mastercard.ess.eds.billing.vo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.Test;
import org.springframework.test.context.TestExecutionListeners;

import com.mastercard.ess.eds.billing.vo.FileItemVO;


	public class FileItemVOTest {
		FileItemVO fileItemVO = new FileItemVO();
		@Test
		public void testGetJob_instnce_id(){
			fileItemVO.setJob_instnce_id(123);
			assertEquals(123, fileItemVO.getJob_instnce_id());
				
		}
		@Test
		public void testGetEds_gen_rpt_id(){
			fileItemVO.setEds_gen_rpt_id(1234);
			assertEquals(1234, fileItemVO.getEds_gen_rpt_id());
				
		}
		@Test
		public void testGetEds_rpt_type_id(){
			fileItemVO.setEds_rpt_type_id(12345);
			assertEquals(12345, fileItemVO.getEds_rpt_type_id());
				
		}
		@Test
		public void testGetCust_mstr_id(){
			fileItemVO.setCust_mstr_id(12345);
			assertEquals(12345, fileItemVO.getCust_mstr_id());
				
		}
		@Test
		public void testGetIca_num(){
			fileItemVO.setIca_num("2641");
			assertEquals("2641", fileItemVO.getIca_num());
				
		}
		@Test
		public void testGetFile_nam(){
			fileItemVO.setFile_nam("MCI.AR.RABC.X.E1234567.D161225.T111135.C001");
			assertEquals("MCI.AR.RABC.X.E1234567.D161225.T111135.C001", fileItemVO.getFile_nam());
				
		}
		@Test
		public void testGetFile_loc_txt(){
			fileItemVO.setFile_loc_txt("/<root>/tmp/MCI.AR.RABC.X.E1234567.D161225.T111135.C001");
			assertEquals("/<root>/tmp/MCI.AR.RABC.X.E1234567.D161225.T111135.C001", fileItemVO.getFile_loc_txt());
				
		}
		@Test
		public void testGetStat_cd(){
			fileItemVO.setStat_cd(1);
			assertEquals(1, fileItemVO.getStat_cd());
				
		}
		@Test
		public void testGetCrte_user_id(){
			fileItemVO.setCrte_user_id("PanProcessJob");
			assertEquals("PanProcessJob", fileItemVO.getCrte_user_id());
				
		}
		@Test
		public void testGetCrte_dt(){
			fileItemVO.setCrte_dt(new Date());
			assertNotNull(fileItemVO.getCrte_dt());
				
		}
		@Test
		public void testGetLst_updt_user_id(){
			fileItemVO.setLst_updt_user_id("PanProcessJob");
			assertEquals("PanProcessJob", fileItemVO.getLst_updt_user_id());
				
		}
		@Test
		public void testGetLst_updt_dt(){
			fileItemVO.setLst_updt_dt(new Date());
			assertNotNull(fileItemVO.getLst_updt_dt());
				
		}
		
		
	}

