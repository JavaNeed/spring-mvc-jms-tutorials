package com.mastercard.ess.eds.test.batch.tasklet;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.tasklet.UpdateCPPRulesExecutionStatus;
import com.mastercard.ess.eds.core.service.EDSCPPRulesService;

public class UpdateCPPRulesExecutionStatusTest {
	UpdateCPPRulesExecutionStatus updateCPPRulesExecutionStatus;
	EDSCPPRulesService edsCPPRulesService;
	StepContribution stepContribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;

	ExecutionContext executionContext;
	private Logger logger = Logger
			.getLogger(UpdateCPPRulesExecutionStatus.class);

	@Before
	public void init() {
		logger.setLevel(Level.DEBUG);
		edsCPPRulesService = EasyMock.createMock(EDSCPPRulesService.class);
		jobInstance = new JobInstance(new Long(123),"updateCPPRulesExecutionStatus");
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("updateCPPRulesExecutionStatus",jobExecution);
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		stepContribution = new StepContribution(stepExecution);
	}

	@Test
	public void test() throws Exception {
		updateCPPRulesExecutionStatus = new UpdateCPPRulesExecutionStatus();
		
		List<String> cppRuleIdList =new ArrayList<>();
		cppRuleIdList.add("1");
		cppRuleIdList.add("2");
		cppRuleIdList.add("3");
		cppRuleIdList.add("4");
		
		executionContext=new ExecutionContext();
		executionContext.put("failedCPPRuleIds", cppRuleIdList);
		
		
		updateCPPRulesExecutionStatus.testService(edsCPPRulesService);
		updateCPPRulesExecutionStatus.setExecutionContext(executionContext);
		updateCPPRulesExecutionStatus.getExecutionContext();
		updateCPPRulesExecutionStatus.execute(stepContribution, chunkContext);
		
		updateCPPRulesExecutionStatus.setJobInstanceName("updateCPPRulesExecutionStatus");
		updateCPPRulesExecutionStatus.getJobInstanceName();
		updateCPPRulesExecutionStatus.setCppSrcName("CPPRules");
		updateCPPRulesExecutionStatus.getCppSrcName();
		
		updateCPPRulesExecutionStatus.setJobInstanceId(BigDecimal.valueOf(1234));
		updateCPPRulesExecutionStatus.getJobInstanceId();
		updateCPPRulesExecutionStatus.setStatus(1);
		updateCPPRulesExecutionStatus.getStatus();
	}

}
