package com.mastercard.ess.eds.test.batch.tasklet;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;

import com.mastercard.ess.eds.batch.tasklet.FraudUnsubscribedBeforeCountTasklet;
import com.mastercard.ess.eds.core.service.FraudReportService;

public class FraudUnsubscribedBeforeCountTaskletTest {

	private FraudUnsubscribedBeforeCountTasklet  fraudUnsubscribedBeforeCountTasklet;
	private FraudReportService fraudReportService;
	StepContribution contribution;
	ChunkContext chunkContext;
	StepExecution stepExecution;
	StepContext stepContext;
	JobParameters jobParameters;
	JobParameter jobParameter;
	JobExecution jobExecution;
	JobInstance jobInstance;
	Map<String, String> map;
	private Logger logger = Logger.getLogger(FraudUnsubscribedBeforeCountTasklet.class);
	
	@Before
	public void setUp() throws Exception {
		logger.setLevel(Level.DEBUG);
		
		jobParameters = new JobParameters();
		jobExecution = new JobExecution(jobInstance, jobParameters);
		stepExecution = new StepExecution("fraud", jobExecution);
		
		stepContext = new StepContext(stepExecution);
		chunkContext = new ChunkContext(stepContext);
		contribution = new StepContribution(stepExecution);
		
		map = new HashMap<>();
		map.put("UNSUBSCRIBED_BEFORE_COUNT", "20");
		
		fraudReportService = EasyMock.createMock(FraudReportService.class);
		
		EasyMock.expect(fraudReportService.getBeforeCountunSubscribedICA()).andReturn(map );
		
	}

	@Test
	public void testExecute() throws Exception {
		fraudUnsubscribedBeforeCountTasklet = new FraudUnsubscribedBeforeCountTasklet();
		fraudUnsubscribedBeforeCountTasklet = new FraudUnsubscribedBeforeCountTasklet(fraudReportService);
		fraudUnsubscribedBeforeCountTasklet.execute(contribution, chunkContext);
	}

}
