package com.mastercard.ess.eds.billing.vo;

//import junit.framework.Assert;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;





import java.util.Date;

import org.junit.Test;

import com.mastercard.ess.eds.billing.vo.BillDataVO;

public class BillDataVOTest {

	
	BillDataVO billDataVO = new BillDataVO();
	@Test
	public void testGetBrndPrdctCd(){
		billDataVO.setBrndPrdctCd("123");
		assertEquals("123", billDataVO.getBrndPrdctCd());
			
	}
	@Test
	public void testGetCardBinNum(){
		billDataVO.setCardBinNum(123456L);
		assertEquals(123456L, billDataVO.getCardBinNum());
	}
	@Test
	public void testGetCidNum(){
		billDataVO.setCidNum(123456L);
		assertEquals(123456L, billDataVO.getCidNum());
	}
	@Test
	public void testGetCnfdncScrNum(){
		billDataVO.setCnfdncScrNum(12345L);
		assertEquals(12345L, billDataVO.getCnfdncScrNum());
	}
	@Test
	public void testGetCrteDt(){
		billDataVO.setCrteDt(new Date(0L));
		assertEquals(new Date(0L), billDataVO.getCrteDt());
	}
	
	@Test
	public void testGetCrteUserid(){
		billDataVO.setCrteUserid("panprocessjob");
		assertEquals("panprocessjob", billDataVO.getCrteUserid());
	}
	
	@Test
	public void testGetCustPanRptid(){
		billDataVO.setCustPanRptid("panprocessjob");
		assertEquals("panprocessjob", billDataVO.getCustPanRptid());
	}
	@Test
	public void testGetDaysSinceLstActvyCnt(){
		billDataVO.setDaysSinceLstActvyCnt(1234L);
		assertEquals(1234L, billDataVO.getDaysSinceLstActvyCnt());
	}
	@Test
	public void testGetEdsPrcssDataid(){
		billDataVO.setEdsPrcssDataid(3969L);
		assertEquals(3969L, billDataVO.getEdsPrcssDataid());
	}
	@Test
	public void testGetEdsSrcDataid(){
		billDataVO.setEdsSrcDataid(4281L);
		assertEquals(4281L, billDataVO.getEdsSrcDataid());
	}
	@Test
	public void testGetIcaNum(){
		billDataVO.setIcaNum(2641L);
		assertEquals(2641L, billDataVO.getIcaNum());
	}
	@Test
	public void testGetIsAcctActvsw(){
		billDataVO.setIsAcctActvsw("Y");
		assertEquals("Y", billDataVO.getIsAcctActvsw());
	}
	@Test
	public void testGetIsAcctValidsw(){
		billDataVO.setIsAcctValidsw("Y");
		assertEquals("Y", billDataVO.getIsAcctValidsw());
	}
	@Test
	public void testGetIsAdcNotifsw(){
		billDataVO.setIsAdcNotifsw("N");
		assertEquals("N", billDataVO.getIsAdcNotifsw());
	}
	@Test
	public void testGetIsFraudRptsw(){
		billDataVO.setIsFraudRptsw("N");
		assertEquals("N", billDataVO.getIsFraudRptsw());
	}
	@Test
	public void testGetIsPanDupsw(){
		billDataVO.setIsPanDupsw("N");
		assertEquals("N", billDataVO.getIsPanDupsw());
	}
	@Test
	public void testGetIsRptsw(){
		billDataVO.setIsRptsw("N");
		assertEquals("N", billDataVO.getIsRptsw());
	}
	
	@Test
	public void testGetLstActvyDt(){
		billDataVO.setLstActvyDt(new Date(0L));
	    assertEquals(new Date(0L), billDataVO.getLstActvyDt());
	}
	
	@Test
	public void testGetlstUpdDt(){
		billDataVO.setLstUpdDt(new Date(0L));
	    assertEquals(new Date(0L), billDataVO.getLstUpdDt());
	}
	
	
	@Test
	public void testGetLstUpdDt(){
		billDataVO.setLstActvyDt(new Date(0L));
	    assertEquals(new Date(0L), billDataVO.getLstActvyDt());
	}
	
	@Test
	public void testGetLstUpdtUserid(){
		billDataVO.setLstUpdtUserid("panprocessjob");
		assertEquals("panprocessjob", billDataVO.getLstUpdtUserid());
	}
	@Test
	public void testGetPanNum(){
		billDataVO.setPanNum(12345678L);
		assertEquals(12345678L, billDataVO.getPanNum());
	}
	@Test
	public void testGetPriceCatid(){
		billDataVO.setPriceCatid(1L);
		assertEquals(1L, billDataVO.getPriceCatid());
	}
	@Test
	public void testGetRptDt(){
		billDataVO.setRptDt(new Date(0L));
		assertEquals(new Date(0L), billDataVO.getRptDt());
	}
	@Test
	public void testGetRtnCd(){
		billDataVO.setRtnCd(810002913L);
		assertEquals(810002913L, billDataVO.getRtnCd());
	}
	@Test
	public void testGetStatCd(){
		billDataVO.setStatCd(1L);
		assertEquals(1L, billDataVO.getStatCd());
	}
	
}
