package com.mastercard.ess.eds.core.service;

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.billing.dao.BillDataDAO;
import com.mastercard.ess.eds.billing.vo.FileItemVO;
import com.mastercard.ess.eds.core.dao.CustomerPanReportDao;
import com.mastercard.ess.eds.core.dao.EDSGenerationReportDAO;
import com.mastercard.ess.eds.core.util.EDSProcessStatus;

/*
 * Service for handling Customer file tracking,
 * uses CustomerPanReportDao
 */
@Component
public class CustomerFileReportService {

	@Autowired
	private CustomerPanReportDao customerPanReportDao;

	@Autowired
	private BillDataDAO billDataDAO;

	@Autowired
	private EDSGenerationReportDAO edsGenerationReportDAO ;

	public CustomerFileReportService(BillDataDAO billDataDAO) {
		super();
		this.billDataDAO = billDataDAO;

	}

	private static Logger logger = Logger
			.getLogger(CustomerFileReportService.class);

	public CustomerFileReportService() {
		super();
	}

	public CustomerFileReportService(CustomerPanReportDao customerPanReportDao) {
		super();
		this.customerPanReportDao = customerPanReportDao;
	}

	public void createCustomerPanReportRecord(BigDecimal custMasterId,
			String ica, String generatedFileName, String location,
			String jobName, BigDecimal jobId) {
		FileItemVO item = new FileItemVO();
		item.setCust_mstr_id(custMasterId.intValue());
		item.setIca_num(ica);
		item.setFile_nam(generatedFileName);
		item.setStat_cd(EDSProcessStatus.GENERATED.getStatusCode());
		item.setFile_loc_txt(location);
		item.setLst_updt_user_id(jobName);
		item.setJob_instnce_id(jobId.intValue());
		item.setCrte_user_id(jobName);
		item.setCustAtRiskRpt(true);
		billDataDAO.insertFileDetails(item);

	}

	public void updateCustomerFileStatus(String fileName, int status,
			String jobInstanceName,  BigDecimal jobId, String location) {
		logger.info("Inside service of Customer file report for updating details");
		FileItemVO item = new FileItemVO();
		item.setFile_nam(fileName);
		item.setStat_cd(status);
		item.setLst_updt_user_id(jobInstanceName);
		item.setCrte_user_id(jobInstanceName);
		item.setFile_loc_txt(location);
		item.setJob_instnce_id(jobId.intValue());
		billDataDAO.updateEvents(item);
	}

	public int createGeneratedFileRecord(String fileName, BigDecimal jobInstanceId, String jobName, int reportType) {
		 return customerPanReportDao.createGeneratedFileRecord(fileName, jobInstanceId, jobName, reportType);
	}
	
	/**
	 *  This method gets the ICA from file name from EDS_GNRT_RPT table.
	 * @param fileName
	 * @param jobName
	 * @return
	 */
	public String getICAFromFileName( String fileName, String jobName){
		String icaNum = null ;
		List<FileItemVO> items = edsGenerationReportDAO.getFileItemsFromFileName(fileName, jobName);
		if(items!=null && !items.isEmpty()){
			icaNum = items.get(0).getIca_num();
		}
		logger.debug("ICA for the file Name =" + fileName + " is " + icaNum);
		return icaNum ;
	}
	
	
}
