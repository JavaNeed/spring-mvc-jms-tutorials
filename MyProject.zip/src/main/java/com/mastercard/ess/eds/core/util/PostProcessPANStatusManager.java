package com.mastercard.ess.eds.core.util;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.mastercard.ess.eds.core.service.EDSSourceService;

/**
 * This Tasklet just delegates the request to update status of file/records after processing to concerned service.
 * @author e067588
 *
 */
public class PostProcessPANStatusManager implements Tasklet{
	
	private Logger logger = Logger
			.getLogger(PostProcessPANStatusManager.class);
	
	@Autowired
	EDSSourceService edsSourcerService;
	
	@Value("#{jobParameters['queuedFileName']}")
	public String fileName;

	private String jobInstanceName;
	
	
	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}
	
	
	//for JUnit test
	public void setEDSSourceService(EDSSourceService edsSourceService){
		this.edsSourcerService = edsSourceService;
	}
	
	public PostProcessPANStatusManager() {
		super();
	}

	/* (non-Javadoc)
	 * @see org.springframework.batch.core.step.tasklet.Tasklet#execute(org.springframework.batch.core.StepContribution, org.springframework.batch.core.scope.context.ChunkContext)
	 */
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : execute ");
		}
		edsSourcerService.setFileName(fileName);
		edsSourcerService.setJobInstanceName(jobInstanceName);
		edsSourcerService.updateFileStatusPostProcessing();		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : execute ");
		}
		return RepeatStatus.FINISHED;
	}
}
