package com.mastercard.ess.eds.billing.vo;

import java.util.Date;

import org.springframework.stereotype.Component;
@Component
public class BatchJobRunVO {

	private int eds_lst_bat_job_run_id;
	private String lst_run_bat_job_nam;
	private Date lst_run_dt;

	public int getEds_lst_bat_job_run_id() {
		return eds_lst_bat_job_run_id;
	}

	public void setEds_lst_bat_job_run_id(int eds_lst_bat_job_run_id) {
		this.eds_lst_bat_job_run_id = eds_lst_bat_job_run_id;
	}

	public String getLst_run_bat_job_nam() {
		return lst_run_bat_job_nam;
	}

	public void setLst_run_bat_job_nam(String lst_run_bat_job_nam) {
		this.lst_run_bat_job_nam = lst_run_bat_job_nam;
	}

	public Date getLst_run_dt() {
		return lst_run_dt;
	}

	public void setLst_run_dt(Date lst_run_dt) {
		this.lst_run_dt = lst_run_dt;
	}

}
