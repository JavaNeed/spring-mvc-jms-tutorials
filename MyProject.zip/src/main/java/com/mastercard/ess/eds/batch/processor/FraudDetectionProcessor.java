package com.mastercard.ess.eds.batch.processor;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.batch.exception.EDSCoreException;
import com.mastercard.ess.eds.core.service.FraudDetectionService;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.ProcessedRecord;
import com.mastercard.ess.eds.domain.RawRecord;

/**
 * @author e067588 This processor ascertains if a fraud has been reported
 *         already for a PAN account
 *
 */
public class FraudDetectionProcessor implements ItemProcessor<EDSRecord, EDSRecord> {

	private static Logger logger = Logger.getLogger(FraudDetectionProcessor.class);

	@Autowired
	FraudDetectionService fraudDetectionService;

	/**
	 * this method processes EDSRecord to ascertain if a PAN has been already
	 * reported for fraud.
	 * 
	 * @param EDSRecord
	 * @return EDSRecord
	 * @throws EDSCoreException 
	 */
	@Override
	public EDSRecord process(EDSRecord edsRecord) throws EDSCoreException {

			logger.info("Enter in method : process ");

		boolean isFraudReported = false;
		ProcessedRecord processedRecord = edsRecord.getProcRecord();
		RawRecord rawRecord = edsRecord.getRawRecord();

		String pan = rawRecord.getRawPan();

		if (null != pan && !("".equals(pan))) {
			isFraudReported = fraudDetectionService.isFraudReported(pan);
			logger.info("isFraudReported"+ isFraudReported);
		}
		if (isFraudReported) {
			processedRecord.setIsFraudReported("Y");
		} else {
			processedRecord.setIsFraudReported("N");
		}

		edsRecord.setProcRecord(processedRecord);

			logger.info("Exit from method : process ");
		return edsRecord;
	}
	
	//for Junit

	public void setService(FraudDetectionService fraudDetectionService) {
		this.fraudDetectionService = fraudDetectionService;
		
	}

}
