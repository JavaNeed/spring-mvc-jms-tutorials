package com.mastercard.ess.eds.batch.processor;

import org.apache.log4j.Logger;
import org.springframework.batch.item.validator.ValidatingItemProcessor;
import com.mastercard.ess.eds.batch.validator.RawRecordValidator;
import com.mastercard.ess.eds.domain.RawRecord;

/**
 * This class validates input against validation criterion. JSR-303 has been used for validation here.
 * @author e067588
 *
 */
public class ValidatingRawRecordItemProcessor extends ValidatingItemProcessor<RawRecord>{

	private static Logger logger = Logger.getLogger(ValidatingRawRecordItemProcessor.class);
	
	private RawRecordValidator validator;
	
	public RawRecordValidator getValidator() {
		return validator;
	}

	/**
	 * set validator for our custom validator as well as super type
	 * @param validator
	 */
	public void setValidator(RawRecordValidator validator) {
		super.setValidator(validator);
		this.validator = validator;
	}

	/* (non-Javadoc)
	 * @see org.springframework.batch.item.validator.ValidatingItemProcessor#process(java.lang.Object)
	 */
	@Override
	public RawRecord process(RawRecord rawRecord) {
		
		logger.info("Processing started for srcDataKy = " + rawRecord.getSrc_data_ky());
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : process ");
		}
	
		super.process(rawRecord);
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : process ");
		}
		return rawRecord;
	
	}

}
