package com.mastercard.ess.eds.core.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.mastercard.ess.eds.billing.vo.FileItemVO;

/**
 * Maps columns from EDS_GNRT_RPT table to fields in EDS File Item domain object. 
 *
 */
public class EDSFileGenerationMapper implements RowMapper<FileItemVO> {
	
	private static Logger logger = Logger.getLogger(EDSFileGenerationMapper.class);

	@Override
	public FileItemVO mapRow(ResultSet paramResultSet, int paramInt) throws SQLException {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : mapRow ");
		}
		
		FileItemVO fileItemVO = new FileItemVO();
		
		fileItemVO.setEds_gen_rpt_id(paramResultSet.getInt("EDS_GNRT_RPT_ID"));
		fileItemVO.setEds_rpt_type_id(paramResultSet.getInt("EDS_RPT_TYPE_ID"));
		fileItemVO.setCust_mstr_id(paramResultSet.getInt("CUST_MSTR_ID"));
		fileItemVO.setIca_num(paramResultSet.getString("ICA_NUM"));
		fileItemVO.setFile_nam(paramResultSet.getString("FILE_NAM"));
		fileItemVO.setFile_loc_txt(paramResultSet.getString("FILE_LOC_TXT"));
		fileItemVO.setStat_cd(paramResultSet.getInt("STAT_CD"));
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : mapRow ");
		}
		
		return fileItemVO;
	}

}
