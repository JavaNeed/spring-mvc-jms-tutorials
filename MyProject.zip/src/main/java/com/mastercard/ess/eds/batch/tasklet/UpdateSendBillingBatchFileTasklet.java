package com.mastercard.ess.eds.batch.tasklet;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;

import com.mastercard.ess.eds.batch.config.FileStatus;
import com.mastercard.ess.eds.domain.FileDetails;

public class UpdateSendBillingBatchFileTasklet implements Tasklet, InitializingBean{

	private static Logger logger = Logger.getLogger(UpdatePurgeFileStatusTasklet.class);


	@Value("${billingfiles.directory}")
	private String location;
	
	@Override
	public void afterPropertiesSet() throws Exception {
		// NOOP
	}

	@Override
	public RepeatStatus execute(StepContribution arg0, ChunkContext chunkContext)
			throws Exception {
		logger.info("Enter into the method UpdateSendBillingBatchFileTasklet:execute ");
		Set<String> billingFileNames = new HashSet<>();
		List<FileDetails> fileStatusList = new ArrayList<>();
		
		File folder = new File(location);

		for (File file : folder.listFiles()) {
			FileDetails fileDetails = new FileDetails();
			fileDetails.setFileName(file.getName());
			fileDetails.setStatus( FileStatus.GFT_FAILURE.getStatus());
			fileStatusList.add(fileDetails);
			billingFileNames.add(file.getName());
		}
		
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("billingFileNames", billingFileNames);
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("fileStatusList", fileStatusList);
		
		logger.info("Exit into the method UpdateSendBillingBatchFileTasklet:execute ");
		
		return RepeatStatus.FINISHED;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
	

}
