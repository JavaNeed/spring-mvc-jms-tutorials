package com.mastercard.ess.eds.core.service;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.dao.ADCNotificationDao;


@Component
public class ADCNotificationService {
	
	public ADCNotificationService(ADCNotificationDao adcNotificationDao) {
		super();
		this.adcNotificationDao = adcNotificationDao;
	}

	@Autowired
	ADCNotificationDao adcNotificationDao;

	public String isAccountADCNotified(BigDecimal pan) {
		
		return adcNotificationDao.isAccountADCNotified(pan);
	}
	
}
