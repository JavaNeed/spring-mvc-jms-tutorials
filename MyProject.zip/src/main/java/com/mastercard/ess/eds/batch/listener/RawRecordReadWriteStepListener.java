package com.mastercard.ess.eds.batch.listener;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;

import com.mastercard.ess.eds.core.service.EDSSourceService;

/**
 * This class is responsible for updating eds source table with queued when
 * parsing of input file is completed
 *
 */
public class RawRecordReadWriteStepListener implements StepExecutionListener {

	private static Logger logger = Logger.getLogger(RawRecordReadWriteStepListener.class);
	private static final String INPUT_FILE = "input.file";
	
	@Autowired
	private EDSSourceService edsSourceService;

	private BigDecimal jobInstanceId;

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}

	public RawRecordReadWriteStepListener() {
		super();
	}

	public RawRecordReadWriteStepListener(EDSSourceService edsSourceService) {
		super();
		this.edsSourceService = edsSourceService;
	}

	
	@Override
	public void beforeStep(StepExecution stepExecution) {
		//NOOP
	}

	/*
	 * this method is called after input file is parsed. eds source table is
	 * updated with status Queued after data persisted into eds source data
	 * table Returns exit status of the step
	 */
	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : afterStep ");
		}

		if ("loadRawRecords".equals(stepExecution.getStepName())
				&& BatchStatus.COMPLETED.equals(stepExecution.getStatus())) {

			String fullyQualifiedfileName = stepExecution.getJobParameters().getString(INPUT_FILE);

			FileSystemResource fileSystemResource = new FileSystemResource(fullyQualifiedfileName);

			String fileName = fileSystemResource.getFile().getName();

			edsSourceService.updateSourceStatus(fileName, jobInstanceId);

		}

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : afterStep ");
		}

		return ExitStatus.COMPLETED;
	}

}
