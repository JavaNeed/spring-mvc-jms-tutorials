package com.mastercard.ess.eds.renewal.vo;

import java.util.Date;

public class BillIcaLimitVO {
	public BillIcaLimitVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	private int limitId;
	private int prntIca;
	private Date startDate;
	private int icaLimit;
	
	

	public BillIcaLimitVO(int prntIca, Date startDate, int icaLimit) {
		super();
		this.prntIca = prntIca;
		this.startDate = startDate;
		this.icaLimit = icaLimit;
	}

	public int getLimitId() {
		return limitId;
	}

	public void setLimitId(int limitId) {
		this.limitId = limitId;
	}

	public int getPrntIca() {
		return prntIca;
	}

	public void setPrntIca(int prntIca) {
		this.prntIca = prntIca;
	}

	public int getIcaLimit() {
		return icaLimit;
	}

	public void setIcaLimit(int icaLimit) {
		this.icaLimit = icaLimit;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

}
