package com.mastercard.ess.eds.batch.tasklet;

import java.io.IOException;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;

public class ExecuteCPPRules implements Tasklet {

	private Logger logger = Logger.getLogger(ExecuteCPPRules.class);
	
	@Value("${subsequent.cpprulerun}")
	private String runCppRuleForDays;
	
	@Value("${cpp.taskdir}")
	private String jobDIR;
	
	public void setJobDIR(String jobDIR) {
		this.jobDIR = jobDIR;
	}

	public void setRunCppRuleForDays(String runCppRuleForDays) {
		this.runCppRuleForDays = runCppRuleForDays;
	}

	private ExecutionContext executionContext;
	
	public ExecutionContext getExecutionContext() {
		return executionContext;
	}

	public void setExecutionContext(ExecutionContext executionContext) {
		this.executionContext = executionContext;
	}
	
	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext)
			throws Exception {
		
		final String cppRuleExecJob = "cppRuleExec.dxj";

		ProcessBuilder procBuilder = new ProcessBuilder("Exec_DMXJob.sh", "-a", jobDIR, "-j", cppRuleExecJob);
		
		String srcId = this.executionContext.get("edsSrcId").toString();
		
		Map<String, String> env = procBuilder.environment();
		env.put("EDS_SRC_ID", srcId); 
		env.put("runCppRuleForDays", runCppRuleForDays);
		
		try {
			Process proc = procBuilder.start();
			int exitStatus = proc.waitFor();

			logger.info("Process Builder completed with exit status --" + exitStatus);
			if (0 == exitStatus) {
				logger.info("Exec_DMXJob.sh successfully executed for job - " + cppRuleExecJob);
			}
			else {
				logger.info("Exec_DMXJob.sh could not be successfuly executed for job - " + cppRuleExecJob);

			}

		} catch (InterruptedException | IOException ie) {
			logger.error("Process executing Exec_DMXJob.sh interrupted/IOException occured " + ie);
			stepContribution.setExitStatus(new ExitStatus("FAILED"));
		}
		return RepeatStatus.FINISHED;
	}
	
}
