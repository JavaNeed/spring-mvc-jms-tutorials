package com.mastercard.ess.eds.batch.tasklet;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.dao.CustomerPanReportDao;
import com.mastercard.ess.eds.core.util.EDSProcessStatus;

public class UpdatePurgeFileStatusTasklet implements Tasklet, InitializingBean{

	private static Logger logger = Logger.getLogger(UpdatePurgeFileStatusTasklet.class);
 
	@Autowired
	private CustomerPanReportDao customerPanReportDao;

	@Override
	public void afterPropertiesSet() throws Exception {
		//NOOP
	}

	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
		logger.debug("Enter into the method UpdatePurgeFileStatusTasklet");
		String fileName = (String) chunkContext.getStepContext()
				.getJobParameters().get("input.file");
		
		customerPanReportDao.updateCustomerFileStatusInBulk(fileName, EDSProcessStatus.PURGED.getStatusCode(), "purgeJob"); 
	
		logger.debug("Exit into the method UpdatePurgeFileStatusTasklet"); 
		return RepeatStatus.FINISHED;
	}
	
	//for junit

	public void setCustomerPanReportDao(CustomerPanReportDao customerPanReportDao) {
		this.customerPanReportDao = customerPanReportDao;
	}
}
