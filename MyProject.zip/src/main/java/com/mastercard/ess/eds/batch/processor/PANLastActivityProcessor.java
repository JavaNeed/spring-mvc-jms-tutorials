package com.mastercard.ess.eds.batch.processor;

import java.sql.Date;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.service.PANLastActivityService;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.ProcessedRecord;

/**
 * This processor is chained in the job to ascertain the number of days since
 * last activity on PAN Account.
 * 
 * @author e067588
 *
 */
public class PANLastActivityProcessor implements ItemProcessor<EDSRecord, EDSRecord> {

	private Logger logger = Logger.getLogger(PANLastActivityProcessor.class);

	@Autowired
	PANLastActivityService panLastActivityService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.batch.item.ItemProcessor#process(java.lang.Object)
	 */


	// For Junit
	public void setService(PANLastActivityService panLastActivityService) {
		this.panLastActivityService = panLastActivityService;

	}

	@Override
	public EDSRecord process(EDSRecord edsRecord) {

		logger.info("Enter in method : process ");
		long startTime = System.currentTimeMillis();
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : process ");
		}
		ProcessedRecord processedRecord = edsRecord.getProcRecord();
		if (processedRecord.getPan() != null) {
			String pan = processedRecord.getPan().toString();
			java.util.Date createDate = edsRecord.getRawRecord().getCreateDate();

			long authStartTime = System.currentTimeMillis();	
			Date authDate = panLastActivityService.getAuthRecord(pan, createDate);
			logger.info("PANLastActivityProcessor auth exec time = " + ((System.currentTimeMillis() - authStartTime)));
			
			long debitStartTime = System.currentTimeMillis();
			Date debitDate = panLastActivityService.getDebitRecord(pan, createDate);
			logger.info("PANLastActivityProcessor debit exec time = " + ((System.currentTimeMillis() - debitStartTime)));			
			
			long clearStartTime = System.currentTimeMillis();
			Date clearingDate = panLastActivityService.getClearingRecord(pan, createDate);
			logger.info("PANLastActivityProcessor clear exec time = " + ((System.currentTimeMillis() - clearStartTime)));	
			
			logger.info("Dates from DW for pan=" + getMaskedAccountNumber(""+processedRecord.getPan()) + ", authDate =" + authDate
					+", debitDate=" + debitDate + ", clearingDate=" + clearingDate);
			
			/* Previous to this 999 value, dw txns were searched with no bound on how far back we searched for txns.
			 * This resulted in poor query performance and so now the search is restricted to last 90 days
			 * which means the query returns null for txn dates > 90, To correctly assign price category, days variable
			 * is being initialized to 999 so that it applies categories 2,4, and 6 if other conditions match */
			int days = 999;
			
			Date mostRecentActivityDate = getMostRecentDate(authDate, debitDate, clearingDate);
			if (null != mostRecentActivityDate) {
				days = getDaysSinceLastActivity(mostRecentActivityDate, new Date(createDate.getTime()));
			}
			processedRecord.setDaysSinceLastActivity(days);
			processedRecord.setDateOfLastActivity(mostRecentActivityDate);

			logger.info("For pan=" + getMaskedAccountNumber(""+processedRecord.getPan())  + ",set daysSinceLastActivity =" + days
					+", dateOfLastActivity=" + mostRecentActivityDate );

			edsRecord.setProcRecord(processedRecord);
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : process ");
		}

		logger.info("PANLastActivityProcessor total exec time = " + ((System.currentTimeMillis() - startTime)));
		logger.info("Exit from method : process ");
		return edsRecord;	
	}

	/*
	 * this method calculates days since last activity
	 */
	public int getDaysSinceLastActivity(Date mostRecentActivityDate, Date createDate) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : getDaysSinceLastActivity ");
		}
		long givenTime = mostRecentActivityDate.getTime();
		long currentTime = createDate.getTime();
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : getDaysSinceLastActivity ");
		}
		int numberOfMilliSecondsInADay = 1000 * 60 * 60 * 24;

		// this code gives correct diff only for dates where difference is
		// greater than 1 day i.e. 24 hours, i.e. 10PM today and 5AM of next day
		// wont give diff of 1 day.
		return ((int) ((currentTime - givenTime) / (numberOfMilliSecondsInADay)));

	}

	/*
	 * this method gives the most recent date
	 */
	public Date getMostRecentDate(Date authDate, Date debitDate, Date clearingDate) {

		Date outputDate = null;

		if (authDate != null && debitDate != null && clearingDate != null) {
			outputDate = getDates(authDate, debitDate, clearingDate);
		}

		outputDate = getLatestDateFromTwoDates(authDate, debitDate,
				clearingDate, outputDate);

		outputDate = getLatestDateFromOneDate(authDate, debitDate,
				clearingDate, outputDate);

		return outputDate;
	}

	private Date getLatestDateFromOneDate(Date authDate, Date debitDate,
			Date clearingDate, Date outputDate) {
		if (debitDate != null && clearingDate == null && authDate == null) {
			outputDate = debitDate;
		}

		if (debitDate == null && clearingDate != null && authDate == null) {
			outputDate = clearingDate;
		}

		if (debitDate == null && clearingDate == null && authDate != null) {
			outputDate = authDate;
		}
		return outputDate;
	}

	private Date getLatestDateFromTwoDates(Date authDate, Date debitDate,
			Date clearingDate, Date outputDate) {
		if (authDate != null && debitDate != null && clearingDate == null) {
			outputDate = getLatestDate(authDate,debitDate);
		}

		if (authDate != null && clearingDate != null && debitDate == null) {
			outputDate = getLatestDate(authDate, clearingDate);
		}

		if (debitDate != null && clearingDate != null && authDate == null) {
			outputDate = getLatestDate(debitDate, clearingDate);
		}
		return outputDate;
	}



	private Date getDates(Date authDate, Date debitDate, Date clearingDate) {
		if (authDate.after(debitDate)) {
			return getLatestDate(authDate,clearingDate);

		} else {
			return getLatestDate(debitDate,clearingDate);

		}
	}

	private Date getLatestDate(Date firstDate, Date secondDate) {
		if (firstDate.after(secondDate)) {
			return firstDate;
		} else {
			return secondDate;
		}
	}

	public static String getMaskedAccountNumber(String accountNumber)
	{
		String result = null;

		if (accountNumber != null)
		{
			int accountNumberLength = accountNumber.length();
			if (accountNumberLength > 6)
			{
				StringBuilder buf = new StringBuilder();
				buf.append(accountNumber.substring(0, 6));

				String last4 = accountNumber.substring(accountNumberLength - 4);
				for (int i=6; i<accountNumberLength-4; i++)
				{
					buf.append("X");
				}
				buf.append(last4);
				result = buf.toString();
			}
			else
			{
				result = accountNumber;
			}
		}
		return result;
	}



}
