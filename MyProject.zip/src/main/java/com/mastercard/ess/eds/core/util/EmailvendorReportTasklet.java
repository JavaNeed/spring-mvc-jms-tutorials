package com.mastercard.ess.eds.core.util;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;

import com.mastercard.ess.eds.core.dao.EDSSourceTypeDao;
import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.domain.EDSSourceType;
import com.mastercard.ess.eds.notification.util.NotificationEventConstants;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;

public class EmailvendorReportTasklet implements Tasklet {

	private static Logger logger = Logger.getLogger(EmailvendorReportTasklet.class);

	@Autowired
	EventPublisher eventPublisher;

	@Autowired
	EDSSourceTypeDao edsSourceTypeDao;

	private static final String JOB_NAME = "jobName" ;
	
	//for junit
	public EmailvendorReportTasklet(EDSSourceTypeDao edsSourceTypeDao) {
		this.edsSourceTypeDao = edsSourceTypeDao;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter method : execute : EmailvendorReportTasklet ");
		}
		logger.info("Enter method : execute : EmailvendorReportTasklet ");
		List<EDSSourceType> edsSourceTypes = edsSourceTypeDao.getListOfVendors();
		if (null != edsSourceTypes) {
			logger.info("Got list of vendors of size --" + edsSourceTypes.size());
		} else
			logger.info("vendor list was null");

		for (EDSSourceType edsSourceType : edsSourceTypes) {
			String vendorPath = edsSourceType.getProvider().trim() + "_path" ;
			String vendorReportFile = (String) chunkContext.getStepContext().getStepExecution().getJobExecution()
					.getExecutionContext().get(vendorPath);
			logger.info(" *******vendorPath "+vendorPath);
			String vendorName = (String) chunkContext.getStepContext().getStepExecution().getJobExecution()
					.getExecutionContext().get(edsSourceType.getProvider().trim());
			logger.info("******* vendorReportFile =" + vendorReportFile + ", ********* vendorName =" + vendorName);
			if (null != vendorReportFile && null != vendorName) {

				NotificationEventVO notificationEventVO = new NotificationEventVO();
				Map<String, String> jobParams = new HashMap<>();

				// get month name from report name
				String month = "";
				if (null != vendorReportFile && !"".equals(vendorReportFile.trim())) {
					int startIndex = vendorReportFile.lastIndexOf('_');
					int endIndex = vendorReportFile.lastIndexOf('.');
					month = vendorReportFile.substring(startIndex + 1, endIndex);
				}
				jobParams.put("summaryFile", vendorReportFile);
				jobParams.put("vendor", edsSourceType.getProvider());
				jobParams.put("defaultMailId", edsSourceType.getDefaultNotificationEmailAddress());
				jobParams.put("month", month);
				jobParams.put(JOB_NAME, chunkContext.getStepContext().getStepExecution().getJobExecution().getJobInstance().getJobName());
				
				notificationEventVO.setEventName(NotificationEventConstants.NOTIF_EVT_VENDOR_REPORT_FILE_GENERATED);
				notificationEventVO.setJobParams(jobParams);
				notificationEventVO.setJobName(chunkContext.getStepContext().getStepExecution().getJobExecution()
						.getJobInstance().getJobName());
				notificationEventVO.setJobID(BigDecimal
						.valueOf(chunkContext.getStepContext().getStepExecution().getJobExecution().getJobId()));

				FileSystemResource vendorReportFileSystemResource = new FileSystemResource(vendorReportFile);

				if (logger.isDebugEnabled()) {
					logger.debug("Exit from method : execute : EmailvendorReportTasklet ");
				}
				logger.info("Exit from method : execute : EmailvendorReportTasklet ");
				
				if (vendorReportFileSystemResource.exists()) {
					logger.info("placing notification event for vendor report generation ");
					eventPublisher.placeEvent(notificationEventVO);
				}
			}
		}

		return null;
	}

}
