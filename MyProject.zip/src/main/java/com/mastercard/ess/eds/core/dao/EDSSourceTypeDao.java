package com.mastercard.ess.eds.core.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.mapper.EDSSourceTypeRowMapper;
import com.mastercard.ess.eds.domain.EDSSourceType;
import com.mastercard.ess.eds.domain.ProcessedRecord;

@Component
public class EDSSourceTypeDao {

	private static final String FETCH_VENDOR_LIST = "SELECT DISTINCT PRVDR_NAM FROM EDS_SRC_TYPE WHERE EXTRL_SW = 'Y' and VNDR_SW = 'Y'";
	private Logger logger = Logger.getLogger(EDSSourceTypeDao.class);
	@Autowired
	private JdbcTemplate jdbcTemplate;

	/**
	 * @param endPointReceived
	 *            : end point fetched from file name
	 * @return : checks in EDS_SOURCE_TYPE table to verify end point is valid or
	 *         not
	 */
	public EDSSourceType getEDSSourceType(String endPointReceived) {

		String edsSOurceTypeQuery = "SELECT * FROM EDS_SRC_TYPE WHERE LOC_INFO_TXT = ?";
		EDSSourceType edsSourceType;
		try {
			edsSourceType = jdbcTemplate.queryForObject(edsSOurceTypeQuery,
					new Object[] { endPointReceived },
					new EDSSourceTypeRowMapper());
		} catch (EmptyResultDataAccessException e) {
			logger.error("Error occured while accessing empty result data" + e);
			return null;
		}
		return edsSourceType;
	}

	public List<String> getVendorList() {
		return jdbcTemplate.queryForList(FETCH_VENDOR_LIST, String.class);
	}

	public List<EDSSourceType> getListOfVendors() {
		EDSSourceTypeRowMapper edsSourceTypeRowMapper = new EDSSourceTypeRowMapper();
		return this.jdbcTemplate.query(
				"Select * from EDS_SRC_TYPE WHERE EXTRL_SW = 'Y'",
				edsSourceTypeRowMapper);
	}

	/**
	 * returns eds source type checking for provider name
	 */
	public EDSSourceType getEDSSourceTypeFromProvider(String provider) {
		String edsSOurceTypeQuery = "SELECT * FROM EDS_SRC_TYPE WHERE PRVDR_NAM = ?";
		EDSSourceType edsSourceType;
		try {
			edsSourceType = jdbcTemplate.queryForObject(edsSOurceTypeQuery,
					new Object[] { provider }, new EDSSourceTypeRowMapper());
		} catch (EmptyResultDataAccessException e) {
			logger.error("Error occured while accessing empty result data" + e);
			return null;
		}
		return edsSourceType;
	}

	public EDSSourceType getEDSSourceTypeFromRule(ProcessedRecord processedRecord) {
		logger.info("Enter the method getEDSSourceTypeFromRule(processedRecord)");
		EDSSourceType eDSSourceType = new EDSSourceType();
		EDSSourceTypeRowMapper edsSourceTypeRowMapper = new EDSSourceTypeRowMapper();
		String edssourceTypeQueryForRule = "select * from EDS_SRC_TYPE where DERIV_SW= ? and EXTRL_SW= ? order by EDS_SRC_TYPE_ID asc";
		logger.info("is derived " + processedRecord.getIsDerived() + "is external " + processedRecord.getIsExternal() );
		List<EDSSourceType> edsSourceTypes = jdbcTemplate.query(edssourceTypeQueryForRule,new Object[] { processedRecord.getIsDerived(), processedRecord.getIsExternal()}, edsSourceTypeRowMapper );
		if(eDSSourceType!= null && !edsSourceTypes.isEmpty()){
			logger.info("eDSSourceType" + eDSSourceType);
			for(EDSSourceType sourceTypeFromDB :edsSourceTypes ){
				eDSSourceType  = sourceTypeFromDB ;
				logger.info("eDSSourceType" + eDSSourceType.getSourceTypeId());
				break ;
			}
		}

		logger.info("Exit the method getEDSSourceTypeFromRule(processedRecord)");
		return eDSSourceType;

	}
}
