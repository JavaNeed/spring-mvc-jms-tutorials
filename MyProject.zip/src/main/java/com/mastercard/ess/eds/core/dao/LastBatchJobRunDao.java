package com.mastercard.ess.eds.core.dao;

import java.util.Date;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class LastBatchJobRunDao {

	private final static String UPDATE_LST_BAT_JOB_RUN_QUERY = "UPDATE EDS_LST_BAT_JOB_RUN SET LST_RUN_DT = ? WHERE JOB_NAM = ?";

	private JdbcTemplate jdbcTemplate;

	private static Logger logger = Logger.getLogger(LastBatchJobRunDao.class);

	public LastBatchJobRunDao(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public void updateLastBatchJobRun(String jobInstanceName) {
		logger.info("updating the last run date in EDS_LST_BAT_JOB_RUN table for " + jobInstanceName);

		jdbcTemplate.update(UPDATE_LST_BAT_JOB_RUN_QUERY, new Date(), jobInstanceName);
	}

}
