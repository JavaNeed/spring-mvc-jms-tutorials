package com.mastercard.ess.eds.batch.exception;

/**
 * This exception is thrown during processing a PAN, in case the PAN is derived from CPP and does not have a src-rule mapping.
 * @author e076119
 */
public class InvalidCPPRecordException extends Exception{

	public InvalidCPPRecordException (String message) {

		super(message);
	}
}
