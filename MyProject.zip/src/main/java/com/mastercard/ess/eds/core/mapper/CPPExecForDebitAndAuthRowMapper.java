package com.mastercard.ess.eds.core.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.mastercard.ess.eds.domain.AuthDebitPanDetailRecord;
import com.mastercard.ess.eds.domain.CPPRecord;
import com.mastercard.ess.eds.domain.CPPRuleRecord;

public class CPPExecForDebitAndAuthRowMapper implements RowMapper<AuthDebitPanDetailRecord> {

	private static Logger logger = Logger.getLogger(CPPExecForDebitAndAuthRowMapper.class);

	@Override
	public AuthDebitPanDetailRecord mapRow(ResultSet paramResultSet, int paramInt) throws SQLException {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : mapRow | CPPAccountsViewRowMapper ");
		}

		AuthDebitPanDetailRecord authDebitPanDetailRecord = new AuthDebitPanDetailRecord();
		authDebitPanDetailRecord.setRawPan(paramResultSet.getString("PAN_NUM"));
		return authDebitPanDetailRecord;
	}

}
