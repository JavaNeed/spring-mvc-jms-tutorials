package com.mastercard.ess.eds.batch.tasklet;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;

import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.notification.util.NotificationEventConstants;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;

public class EmailCPPAnalysisReport implements JobExecutionListener {

	@Autowired
	EventPublisher eventPublisher;
	
	@Value("${cppDetailReport.path}")
	private String cppDetailReportPath;
	
	@Value("${cppSummaryReport.path}")
	private String cppSummaryReportPath;
	
	private static final String JOB_NAME = "jobName" ;
	
	 
	public EmailCPPAnalysisReport()
	{
		super();
	}
	
	public EmailCPPAnalysisReport(EventPublisher eventPublisher)
	{
		this.eventPublisher = eventPublisher;
	}

	private static final Logger logger = Logger.getLogger(EmailCPPAnalysisReport.class);
	
	@Override
	public void afterJob(JobExecution jobExecution) {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : afterJob : EmailCPPAnalysisReport ");
		}
		Calendar now = Calendar.getInstance();
		String currentDate = (now.get(Calendar.MONTH) + 1) + "-" + now.get(Calendar.DATE) + "-"
				+ now.get(Calendar.YEAR);
		
		String summaryFile = cppSummaryReportPath + currentDate + ".xlsx";
		
		String detailFile = cppDetailReportPath + currentDate + ".xlsx";
		
		
		NotificationEventVO notificationEventVO = new NotificationEventVO();
		Map<String, String> jobParams = new HashMap<String, String>();
		
		jobParams.put("summaryFile", summaryFile);
		jobParams.put("detailFile",  detailFile);
		jobParams.put(JOB_NAME, jobExecution.getJobInstance().getJobName());
		
		notificationEventVO.setEventName(NotificationEventConstants.NOTIF_EVT_CPP_FILE_GENERATED);
		notificationEventVO.setJobParams(jobParams);
		notificationEventVO.setJobName(jobExecution.getJobInstance().getJobName());
		notificationEventVO.setJobID(new BigDecimal(jobExecution.getJobId()));
		
		FileSystemResource summaryFileSystemResource = new FileSystemResource(summaryFile);
		FileSystemResource detailFileSystemResource = new FileSystemResource(detailFile);
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : afterJob : EmailCPPAnalysisReport ");
		}
		if(summaryFileSystemResource.exists() || detailFileSystemResource.exists()){
			eventPublisher.placeEvent(notificationEventVO);
		}
	}

	@Override
	public void beforeJob(JobExecution jobExecution) {
		
		logger.info("EmailCPPAnalysisreport | beforeJob");
		
	}

}
