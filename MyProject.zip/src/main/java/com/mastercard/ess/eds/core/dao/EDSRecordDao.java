package com.mastercard.ess.eds.core.dao;

import static com.mastercard.ess.eds.constant.SQLConstants.BIN;
import static com.mastercard.ess.eds.constant.SQLConstants.BRND_PRDCT_CD;
import static com.mastercard.ess.eds.constant.SQLConstants.CID;
import static com.mastercard.ess.eds.constant.SQLConstants.CONF_SCORE;
import static com.mastercard.ess.eds.constant.SQLConstants.CRTE_DT;
import static com.mastercard.ess.eds.constant.SQLConstants.CRTE_USER_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.DAYS;
import static com.mastercard.ess.eds.constant.SQLConstants.EDS_PRCSS_DATA;
import static com.mastercard.ess.eds.constant.SQLConstants.EDS_PRCSS_DATA_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.EDS_SRC_DATA_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.HIST_FLAG;
import static com.mastercard.ess.eds.constant.SQLConstants.ICA;
import static com.mastercard.ess.eds.constant.SQLConstants.ICA_NUM;
import static com.mastercard.ess.eds.constant.SQLConstants.IS_ACCT_ACTIVE;
import static com.mastercard.ess.eds.constant.SQLConstants.IS_ACCT_VALID;
import static com.mastercard.ess.eds.constant.SQLConstants.IS_ADC_NOTIFIED;
import static com.mastercard.ess.eds.constant.SQLConstants.IS_FRAUD_REPORTED;
import static com.mastercard.ess.eds.constant.SQLConstants.IS_PAN_DUP_SW;
import static com.mastercard.ess.eds.constant.SQLConstants.IS_RPT_SW;
import static com.mastercard.ess.eds.constant.SQLConstants.JOB_INSTNCE_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.LST_ACTVY_DT;
import static com.mastercard.ess.eds.constant.SQLConstants.PAN;
import static com.mastercard.ess.eds.constant.SQLConstants.PRICE_CAT;
import static com.mastercard.ess.eds.constant.SQLConstants.RTN;
import static com.mastercard.ess.eds.constant.SQLConstants.STAT_CD;
import static com.mastercard.ess.eds.constant.SQLQueries.DUPLICATE_PAN_CHECK;
import static com.mastercard.ess.eds.constant.SQLQueries.EDS_PROCESS_DATA_ID_QUERY;
import static com.mastercard.ess.eds.constant.SQLQueries.FETCH_MAX_MIN_EDS_SRC_DATA_QUERY;
import static com.mastercard.ess.eds.constant.SQLQueries.FETCH_SRC_RULE_DATA;
import static com.mastercard.ess.eds.constant.SQLQueries.ICAS_HIST_FLAG_FOR_FILE_GEN_QUERY;
import static com.mastercard.ess.eds.constant.SQLQueries.PAN_REPORTED_CHECK;
import static com.mastercard.ess.eds.constant.SQLQueries.UPDATE_DUPLICATE_AND_STATUS;
import static com.mastercard.ess.eds.constant.SQLQueries.UPDATE_DUPLICATION;
import static com.mastercard.ess.eds.constant.SQLQueries.UPDATE_FAULTY_INPUT_RECORD_STATUS_QUERY;
import static com.mastercard.ess.eds.constant.SQLQueries.UPDATE_INPUT_RECORD_STATUS_QUERY;
import static com.mastercard.ess.eds.constant.SQLQueries.UPDATE_RECORD_STATUS_POST_PROCESSING_QUERY;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.batch.config.CommonCacheTokens;
import com.mastercard.ess.eds.core.util.CPPRuleIdHolder;
import com.mastercard.ess.eds.core.util.EDSProcessStatus;
import com.mastercard.ess.eds.domain.EDSCustomer;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.ProcessedRecord;
import com.mastercard.ess.eds.domain.RawRecord;

/**
 * This DAO class inserts data into EDS_SOURCE_PROC_DATA table after processing.
 * 
 * @author e067588
 *
 */
@Component
public class EDSRecordDao {
	
	private static Logger logger = Logger.getLogger(EDSRecordDao.class);
	
	private String jobInstanceName;

	private BigDecimal jobInstanceId;

	
	private SimpleJdbcInsert edsRecordsInsert;

	private JdbcTemplate jdbcTemplate;

	@Autowired
	private CustomerPanReportDao customerPanReportDao;
	
	public EDSRecordDao(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
		edsRecordsInsert = new SimpleJdbcInsert(dataSource).withTableName(EDS_PRCSS_DATA).usingColumns(PAN, BIN,
				CONF_SCORE, DAYS, ICA_NUM, IS_ACCT_VALID, LST_ACTVY_DT, IS_ACCT_ACTIVE, IS_ADC_NOTIFIED, CID,
				EDS_PRCSS_DATA_ID, EDS_SRC_DATA_ID, PRICE_CAT, RTN, BRND_PRDCT_CD,
				IS_PAN_DUP_SW, CRTE_USER_ID, CRTE_DT, IS_FRAUD_REPORTED, IS_RPT_SW, JOB_INSTNCE_ID, STAT_CD);

		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;

	}


	/**
	 * After read step data will be persisted in eds source data table in this
	 * method . Records come in form of List of object and stored in DB
	 * 
	 * @param jobInstanceId
	 * 
	 * @param rawRecords
	 *            : list of records fetched from input file
	 */
	public void writeRecord(List<? extends EDSRecord> edsRecords, BigDecimal jobInstanceId) {
		for (EDSRecord edsRecord : edsRecords) {

			if (logger.isDebugEnabled()) {
				logger.debug("Enter in method : writeRecord ");
			}
			if (edsRecord != null) {

				ProcessedRecord procRecord = edsRecord.getProcRecord();
				RawRecord rawRecord = edsRecord.getRawRecord();
				if (null != procRecord && null != rawRecord) {
					saveProcRecord(procRecord, rawRecord, jobInstanceId);
				}
			}

			if (logger.isDebugEnabled()) {
				logger.debug("Exit from method : writeRecord ");
			}
		}

	}

	/**
	 * @param procRecord
	 * @param jobInstanceId
	 */
	private void saveProcRecord(ProcessedRecord procRecord, RawRecord rawRecord, BigDecimal jobInstanceId) {
		String isAccountValid = "N";
		if (procRecord.isAccountValid()) {
			isAccountValid = "Y";
		}

		logger.info("check pan availability");
		String result = procRecord.getCacheResult(); //SENT, NOTSENTVENDOR, NOTSENTCPP, null
		String provider = rawRecord.getProviderName();

		if (null == result) {
			procRecord.setIsDuplicate("N");
		} else if ("Y".equalsIgnoreCase(procRecord.getIsFraudReported()) || (null != result && "CPP".equals(provider))  //isPANAlreadyReported(procRecord.getPan())
				|| "N".equals(procRecord.getIsAccountActive()) || "N".equals(isAccountValid)) {
			procRecord.setIsDuplicate("Y");
		} else if ( ! "CPP".equals(provider) && "NOTSENTCPP".equals(result)) {
			String isDuplicate = confidenceScoreCheck(procRecord);
			procRecord.setIsDuplicate(isDuplicate);
		} else { //In all cases other that result = null, the pan already exists in table.
			procRecord.setIsDuplicate("Y");
		}


		BigDecimal eventTransId = jdbcTemplate.queryForObject(EDS_PROCESS_DATA_ID_QUERY, BigDecimal.class);
		logger.info("eventTransId in PRocess Data" + eventTransId);

		MapSqlParameterSource parameterSource = new MapSqlParameterSource();
		parameterSource.addValue(PAN, procRecord.getPan()).addValue(IS_ACCT_VALID, isAccountValid)
		.addValue(IS_ACCT_ACTIVE, procRecord.getIsAccountActive()).addValue(EDS_PRCSS_DATA_ID, eventTransId)
		.addValue(IS_ADC_NOTIFIED, procRecord.getIsAccountADCNotified())
		.addValue(EDS_SRC_DATA_ID, procRecord.getProcRawRecordKey())
		.addValue(LST_ACTVY_DT, procRecord.getDateOfLastActivity())
		.addValue(CRTE_USER_ID, procRecord.getCreatedBy()).addValue(CRTE_DT, procRecord.getCreateDate())
		.addValue(PRICE_CAT, procRecord.getPriceCategory())
		.addValue(CONF_SCORE, procRecord.getConfidenceScore()).addValue(CID, procRecord.getCid())
		.addValue(RTN, procRecord.getRtnId()).addValue(ICA_NUM, procRecord.getIca())
		.addValue(BRND_PRDCT_CD, procRecord.getBrandProductCode())
		.addValue(IS_FRAUD_REPORTED, procRecord.getIsFraudReported()).addValue(IS_RPT_SW, "N")
		.addValue(IS_PAN_DUP_SW, procRecord.getIsDuplicate()).addValue(JOB_INSTNCE_ID, jobInstanceId)
		.addValue(STAT_CD, EDSProcessStatus.PROCESSED.getStatusCode());
		if (procRecord.getDaysSinceLastActivity() != -1) {
			parameterSource.addValue(DAYS, procRecord.getDaysSinceLastActivity());
		}

		edsRecordsInsert.execute(parameterSource);
	}

	private String confidenceScoreCheck(ProcessedRecord procRecord) {
		logger.info("Enter check for confidence core" + getMaskedAccountNumber("" + procRecord.getPan()));
		String duplicatePan = "N";
		List<Map<String, Object>> isDuplicatePan = jdbcTemplate.queryForList(DUPLICATE_PAN_CHECK, procRecord.getPan(),
				procRecord.getPan());

		if (isDuplicatePan != null && isDuplicatePan.size() > 0) {
			int cnfdncScrNum = ((BigDecimal) isDuplicatePan.get(0).get("CNFDNC_SCR_NUM")).intValue();
			int priceCatId = ((BigDecimal) isDuplicatePan.get(0).get("PRICE_CAT_CD")).intValue();
			logger.info("confidence core no" + cnfdncScrNum + "and price cat" + priceCatId);
			if (cnfdncScrNum < procRecord.getConfidenceScore()) {
				logger.info("Inside First IF confidence score is less than existing");
				Timestamp timestamp = new java.sql.Timestamp(System.currentTimeMillis());
				jdbcTemplate.update(UPDATE_DUPLICATION, "Y",jobInstanceName, timestamp, procRecord.getPan());
			} else {
				logger.info("Inside First IF confidence score is greater than existing");
				duplicatePan = "Y";
			}
		}
		logger.info("exit check for confidence core pan" + duplicatePan);
		return duplicatePan;
	}

	/**
	 * Updates status of faulty/invalid records in EDS_SOURCE_DATA table
	 * 
	 * @param rawRecord
	 */
	public void updateStatusOfFaultyInputRecords(RawRecord rawRecord) {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : updateStatusOfFaultyInputRecords ");
		}

		int status = EDSProcessStatus.ERROR.getStatusCode();
		BigDecimal srcDataKey = rawRecord.getSrc_data_ky();
		java.sql.Timestamp date = new java.sql.Timestamp(System.currentTimeMillis());
		jdbcTemplate.update(UPDATE_FAULTY_INPUT_RECORD_STATUS_QUERY, status, date, jobInstanceName, jobInstanceId,
				srcDataKey);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : updateStatusOfFaultyInputRecords ");
		}
	}

	/**
	 * Updates status of records including LST_UPDT_USER_ID and LST_UPDT_DT in
	 * EDS_SOURCE_DATA table
	 * 
	 * @param edsRecords
	 */
	public void updateRecordStatusPostProcessing(List<? extends EDSRecord> edsRecords, String jobInstanceName,
			BigDecimal jobInstanceId) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : updateRecordStatusPostProcessing ");
		}
		for (EDSRecord edsRecord : edsRecords) {

			BigDecimal srcDataKey = edsRecord.getRawRecord().getSrc_data_ky();
			int status = EDSProcessStatus.PROCESSED.getStatusCode();
			java.sql.Timestamp date = new java.sql.Timestamp(System.currentTimeMillis());
			jdbcTemplate.update(UPDATE_RECORD_STATUS_POST_PROCESSING_QUERY, status, date, jobInstanceName,
					jobInstanceId, srcDataKey);

		}

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : updateRecordStatusPostProcessing ");
		}

	}

	public boolean ifReportableRecordsExist() {

		String ifexists = jdbcTemplate.queryForObject(
				"select case when exists (select 1 from EDS_PRCSS_DATA EDS where EDS.RPT_SW = ?) then 'Y' else 'N' end from dual",
				new Object[] { "N" }, String.class);

		if ("Y".equals(ifexists)) {
			return true;
		} else {
			return false;
		}
	}

	public void updateRecordStatusPostFileGeneration(String jobInstanceName, BigDecimal jobInstanceId ,List<EDSRecord> listOfAllRecordsToUpdate,
			Map<BigDecimal, String> recordToFileMap, int status) {
		logger.info("listOfAllRecordsToUpdate with size -" + listOfAllRecordsToUpdate.size() + " received for update");

		ArrayList<String> files = new ArrayList<>();
		HashSet<String> uniqueFiles;
		recordsToAddFile(recordToFileMap, files);

		Map<String, BigDecimal> filePKMap = customerPanReportDao.fileToPKMap(files);

		jdbcTemplate.batchUpdate(
				"UPDATE EDS_PRCSS_DATA SET RPT_SW = ?, LST_UPDT_USER_ID = ?, JOB_INSTNCE_ID = ?, RPT_DT = ?, LST_UPDT_DT = ?, CUST_PAN_RPT_ID = ?, STAT_CD = ? WHERE EDS_PRCSS_DATA_ID =?",
				new BatchPreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						EDSRecord edsRecord = listOfAllRecordsToUpdate.get(i);
						if (!("Y".equals(edsRecord.getProcRecord().getIsFiltered())) && (StringUtils.isBlank(edsRecord.getProcRecord().getToBeSentFlag()) ||
								edsRecord.getProcRecord().getToBeSentFlag().equalsIgnoreCase("Y"))) {
							edsRecordNotFiltered(jobInstanceName, jobInstanceId, recordToFileMap, status, filePKMap, ps, edsRecord);
						} else {
							edsRecordFiltered(jobInstanceName,  jobInstanceId, status, ps, edsRecord);
						}

						getFilePK(recordToFileMap, filePKMap, ps, edsRecord);

					}

					/**
					 * @param jobInstanceName
					 * @param status
					 * @param ps
					 * @param edsRecord
					 * @throws SQLException
					 */
					private void edsRecordFiltered(String jobInstanceName, BigDecimal jobInstanceId ,int status, PreparedStatement ps,
							EDSRecord edsRecord) throws SQLException {
						ps.setString(1, "N");
						ps.setString(2, jobInstanceName);
						ps.setBigDecimal(3, jobInstanceId);
						ps.setNull(4, java.sql.Types.TIMESTAMP);
						ps.setTimestamp(5, new java.sql.Timestamp(System.currentTimeMillis()));
						logger.debug("4. Updating CUST_PAN_RPT_ID as empty string");
						ps.setString(6, "");
						ps.setInt(7, status);
						ps.setBigDecimal(8, edsRecord.getProcRecord().getProcRecordKey());
					}

					/**
					 * @param jobInstanceName
					 * @param recordToFileMap
					 * @param status
					 * @param filePKMap
					 * @param ps
					 * @param edsRecord
					 * @throws SQLException
					 */
					private void edsRecordNotFiltered(String jobInstanceName,  BigDecimal jobInstanceId , Map<BigDecimal, String> recordToFileMap,
							int status, Map<String, BigDecimal> filePKMap, PreparedStatement ps, EDSRecord edsRecord)
									throws SQLException {
						if (("N").equals(edsRecord.getProcRecord().getIsDuplicate())) {
							ps.setTimestamp(4, new java.sql.Timestamp(System.currentTimeMillis()));
							if (null != recordToFileMap && null != recordToFileMap.get(edsRecord.getProcRecord().getProcRecordKey())) {
								BigDecimal filePK = filePKMap
										.get(recordToFileMap.get(edsRecord.getProcRecord().getProcRecordKey()));
								logger.debug("1. Updating CUST_PAN_RPT_ID with file ID"+ filePK);
								ps.setBigDecimal(6, filePK);
							} else {
								logger.debug("1. Updating CUST_PAN_RPT_ID as empty string");
								ps.setString(6, "");
							}

						} else {

							ps.setNull(4, java.sql.Types.TIMESTAMP);
							logger.debug("2. Updating CUST_PAN_RPT_ID as empty string");
							ps.setString(6, "");
						}
						ps.setString(1, "Y");
						ps.setString(2, jobInstanceName);
						ps.setBigDecimal(3, jobInstanceId);
						ps.setTimestamp(5, new java.sql.Timestamp(System.currentTimeMillis()));
						ps.setInt(7, status);
						ps.setBigDecimal(8, edsRecord.getProcRecord().getProcRecordKey());
					}

					/**
					 * @param recordToFileMap
					 * @param filePKMap
					 * @param ps
					 * @param edsRecord
					 * @throws SQLException
					 */
					private void getFilePK(Map<BigDecimal, String> recordToFileMap, Map<String, BigDecimal> filePKMap,
							PreparedStatement ps, EDSRecord edsRecord) throws SQLException {
						getProcRecordDetails(recordToFileMap, filePKMap, ps, edsRecord);
					}

					/**
					 * @param recordToFileMap
					 * @param filePKMap
					 * @param ps
					 * @param edsRecord
					 * @throws SQLException
					 */

					@Override
					public int getBatchSize() {
						return listOfAllRecordsToUpdate.size();
					}

				});

	}

	/**
	 * @param recordToFileMap
	 * @param files
	 */
	private void recordsToAddFile(Map<BigDecimal, String> recordToFileMap, ArrayList<String> files) {
		HashSet<String> uniqueFiles;
		if (null != recordToFileMap) {
			logger.info("recordToFileMap with size -" + recordToFileMap.size() + " received for update");
			uniqueFiles = new HashSet<>(recordToFileMap.values());
			files.addAll(uniqueFiles);
		}
	}

	private void getProcRecordDetails(Map<BigDecimal, String> recordToFileMap, Map<String, BigDecimal> filePKMap,
			PreparedStatement ps, EDSRecord edsRecord) throws SQLException {
		if (edsRecord != null && edsRecord.getProcRecord() != null) {
			String jobName = "customerFileGenerationJob";
			if (recordToFileMap != null && recordToFileMap.get(edsRecord.getProcRecord().getProcRecordKey()) != null) {
				if (jobName.equalsIgnoreCase(edsRecord.getProcRecord().getLastUpdatedUser())) {
					BigDecimal filePK = filePKMap
							.get(recordToFileMap.get(edsRecord.getProcRecord().getProcRecordKey()));
					logger.debug("Updating CUST_PAN_RPT_ID with file ID =" + filePK);
					ps.setBigDecimal(6, filePK);
				}
			} else {
				logger.debug("Updating CUST_PAN_RPT_ID as empty string");
				ps.setString(6, "");
			}
		}
	}


	/**
	 * Method will return ICA and Hist_FLAG for that flag.
	 * @return
	 */
	public List<EDSCustomer> getICAsWithHistFlagForFileGeneration() {

		logger.info(" Enter in method getICAsToHistFlagForFileGeneration ");

		List<EDSCustomer> listOfIcaToHistFlagMap =new ArrayList<EDSCustomer>();

		List<Map<String, Object>> rows = jdbcTemplate.queryForList( ICAS_HIST_FLAG_FOR_FILE_GEN_QUERY );

		for (Map<String, Object> row : rows) {

			EDSCustomer edsCustomer = new EDSCustomer();

			if( row.get(ICA_NUM) instanceof BigDecimal) {
				BigDecimal icaNum = (BigDecimal) row.get(ICA_NUM);
				edsCustomer.setIca( icaNum.longValue() );
			} 

			edsCustomer.setHistFlag( (String) row.get(HIST_FLAG));
			listOfIcaToHistFlagMap.add( edsCustomer );
		}

		logger.info(" Exit from method getICAsToHistFlagForFileGeneration ");

		return listOfIcaToHistFlagMap;

	}

	public String getMaskedAccountNumber(String accountNumber) {
		String result = null;

		if (accountNumber != null) {
			int accountNumberLength = accountNumber.length();
			if (accountNumberLength > 6) {
				StringBuilder buf = new StringBuilder();
				buf.append(accountNumber.substring(0, 6));

				String last4 = accountNumber.substring(accountNumberLength - 4);
				for (int i = 6; i < accountNumberLength - 4; i++) {
					buf.append("X");
				}
				buf.append(last4);
				result = buf.toString();
			} else {
				result = accountNumber;
			}
		}
		return result;
	}

	public Map<String, Object> getIndexesForEDSSrcDataId() {

		logger.info("Enter in method : getIndexesForEDSSrcDataId ");

		Map<String, Object> map = new HashMap<String, Object>();
		Object[] parameters = new Object[] { new Integer(EDSProcessStatus.UNPROCESSED.getStatusCode()) };
		SqlRowSet srs = jdbcTemplate.queryForRowSet(FETCH_MAX_MIN_EDS_SRC_DATA_QUERY, parameters);
		while (srs.next()) {
			logger.info("startIndex = " + srs.getString(CommonCacheTokens.START_INDEX.getDesc()) + " - endIndex = " + srs.getString(CommonCacheTokens.END_INDEX.getDesc()));
			map.put(CommonCacheTokens.START_INDEX.getDesc(), srs.getString(CommonCacheTokens.START_INDEX.getDesc()));
			map.put(CommonCacheTokens.END_INDEX.getDesc(), srs.getString(CommonCacheTokens.END_INDEX.getDesc()));
		}
		logger.info("Exit from method : getIndexesForEDSSrcDataId ");
		return map;
	}

	private boolean isPANAlreadyReported(BigDecimal pan) {

		String isPanReported = jdbcTemplate.queryForObject(PAN_REPORTED_CHECK, String.class, pan);
		logger.info("pan = " + getMaskedAccountNumber("" + pan) + ", already reported = " + isPanReported);
		if ("Y".equals(isPanReported)) {
			return true;
		} else {
			return false;
		}
	}

	public BigDecimal getJobInstanceId() {
		return jobInstanceId;
	}

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}

	/**
	 * Updates status of input records in EDS_SOURCE_DATA table
	 * 
	 * @param rawRecord
	 */
	public void updateRawRecordStatus(BigDecimal srcDataKey, int status, String error, String jobInstanceName,
			BigDecimal jobInstanceId) {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : updateRawRecordStatus ");
		}
		Timestamp timestamp = new java.sql.Timestamp(System.currentTimeMillis());

		jdbcTemplate.update(UPDATE_INPUT_RECORD_STATUS_QUERY, status, jobInstanceName, jobInstanceId, error, timestamp,
				srcDataKey);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : updateRawRecordStatus ");
		}
	}

	/**
	 * Fetching the source rules data based on start and end Index
	 * 
	 * @param startIndex
	 *            Min(EDSSourceDataID)
	 * @param endIndex
	 *            Max(EDSSourceDataID)
	 * @return List of CPPRuleIdHolder
	 */
	public List<CPPRuleIdHolder> getEDSSrcRuleData(Long startIndex, Long endIndex) {
		Object[] parameters = new Object[] { startIndex, endIndex };
		List<CPPRuleIdHolder> srcRuleData = jdbcTemplate.query(FETCH_SRC_RULE_DATA,parameters, new RowMapper<CPPRuleIdHolder>() {
			public CPPRuleIdHolder mapRow(ResultSet rs, int rowNum) throws SQLException {
				CPPRuleIdHolder holder = new CPPRuleIdHolder();
				Long cppRuleId = rs.getLong("cppruleid");
				Long srcDataId = rs.getLong("srcdataid");
				String categoryCode = rs.getString("categoryCode");

				holder.setCppRuleId(cppRuleId);
				holder.setSrcDataKey(srcDataId);
				holder.setCategoryCode(categoryCode);
				return holder;
			}

		});
		return srcRuleData;
	}

	/**
	 * This method updates the PAN_DUP_SW in eds_prcss_data table to 'Y' and status code as invalid(8) for the pans in listOfDupRecords.
	 * @param jobInstanceName
	 * @param listOfDupRecords
	 */
	public void updateSwforDupRecords(String jobInstanceName, BigDecimal jobInstanceId, List<EDSRecord> listOfDupRecords){
		logger.info("Enter updateSwforDupRecords() ");

		jdbcTemplate.batchUpdate(UPDATE_DUPLICATE_AND_STATUS,
				new BatchPreparedStatementSetter() {

			/**
			 * For each item in listOfDupRecords, values are set in the update statements and the batch is updated once. 
			 */
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				EDSRecord edsRecord = listOfDupRecords.get(i);
				logger.info("Updating duplicate flag to 'Y' fro eds_pcss_Data_Id : " + edsRecord.getProcRecord().getProcRecordKey());
				ps.setString(1, "Y");
				ps.setInt(2, EDSProcessStatus.INVALID.getStatusCode());
				ps.setString(3, jobInstanceName);
				ps.setTimestamp(4, new java.sql.Timestamp(System.currentTimeMillis()));
				ps.setBigDecimal(5, jobInstanceId);
				ps.setBigDecimal(6, edsRecord.getProcRecord().getProcRecordKey());
			}

			@Override
			public int getBatchSize() {
				return listOfDupRecords.size();
			}

		});
		logger.info("Exit updateSwforDupRecords() ");
	}

}
