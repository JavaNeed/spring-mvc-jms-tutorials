package com.mastercard.ess.eds.billing.writer;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.mastercard.ess.eds.batch.config.FileStatus;
import com.mastercard.ess.eds.billing.dao.BillDataDAO;
import com.mastercard.ess.eds.billing.util.CSVWriterUtils;
import com.mastercard.ess.eds.billing.vo.BatchJobRunVO;
import com.mastercard.ess.eds.billing.vo.BillDataVO;
import com.mastercard.ess.eds.billing.vo.FileItemVO;
import com.mastercard.ess.eds.domain.FileDetails;

public class BillDataWriter implements ItemWriter<BillDataVO>,
		ItemWriteListener<BillDataVO> {
	private static final String JOB_NAM = "billDataBatchJob";
	
	private static Logger logger = Logger.getLogger(BillDataWriter.class);
	
	@Autowired
	private FileItemVO fileItemVO;
	@Autowired
	private BatchJobRunVO batchJobRunVO;

	@Autowired
	private BillDataDAO billDataDao;
	@Autowired
	private CSVWriterUtils csvWriterUtils;
	
	private ExecutionContext executionContext;
	
	@Value("${billingfiles.directory}")
	private String location;

	
	private BigDecimal jobInstanceId;
	
	private String jobInstanceName ;
	
	private List<FileDetails> fileStatusList = null ;
	
	private List<Map<String, Object>> childParentMapList = new ArrayList<>();

	// for junit
		public BillDataWriter(CSVWriterUtils csvWriterUtils, FileItemVO fileItemVO,
				BillDataDAO billDataDao) {
			this.csvWriterUtils = csvWriterUtils;
			this.fileItemVO = fileItemVO;
			this.billDataDao = billDataDao;
		}

	public ExecutionContext getExecutionContext() {
		return executionContext;
	}

	public void setExecutionContext(ExecutionContext executionContext) {
		this.executionContext = executionContext;
	}

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;

	}
	

	@Override
	public void afterWrite(List<? extends BillDataVO> billDataVOList) {
		logger.info("BillDataWriter | afterWrite | Enter in method");

		logger.info("writer entered");
		fileItemVO.setJob_instnce_id(jobInstanceId.intValue());
		fileItemVO.setCrte_user_id(JOB_NAM);
		fileItemVO.setFile_loc_txt(location);
		fileItemVO.setCustAtRiskRpt(false); //Set to false, since this is billing report.
		billDataDao.insertFileDetails(fileItemVO);
		fileItemVO.setLst_updt_user_id(JOB_NAM);
		
		if (null != billDataVOList) {
			int noOfUpdateCalls = (billDataVOList.size() / 999) + 1;

			for(int i=0; i < noOfUpdateCalls; i++){
				int startLimit = i * 999;
				int endLimit = startLimit + 999;
				if(endLimit > billDataVOList.size()) {
					endLimit = billDataVOList.size();
				}
				StringBuilder edsPrcssDataIds = buildEDSProcessDataIds(billDataVOList.subList(startLimit, endLimit));
				if(edsPrcssDataIds!=null) {
					updateEDSProcessData(edsPrcssDataIds);
				}
			}
		} else {
			logger.info("BillDataWriter | billDAtaVOList is null");
		}
		//updating renewal date
		logger.info("BillDataWriter | afterWrite | Exit from method");
		
		
	}

	/**
	 * @param billDataVOList
	 * @param edsPrcssDataIds
	 * @param billDataIndex
	 * @param noOfUpdateCalls
	 * @return
	 */
	private StringBuilder buildEDSProcessDataIds(List<? extends BillDataVO> billDataVOList) {

		StringBuilder processIds = new StringBuilder("(");
		for (int i = 0; i < billDataVOList.size(); i++) {

			if (billDataVOList.size() - 1 != i) {
				processIds.append(billDataVOList.get(i)
						.getPanNum() + ",");
			} else {
				processIds.append(billDataVOList.get(i)
						.getPanNum());
			}

		}
		processIds.append(")");

		return processIds;
	}

	/**
	 * @param edsPrcssDataIds
	 */
	private void updateEDSProcessData(StringBuilder edsPrcssDataIds) {
		try {
			logger.info("executing update query");
			billDataDao.updateFileStatus(edsPrcssDataIds.toString());
			logger.info("executed update query");
		} catch (SQLException e) {
			logger.error("exception inside | BilldataWriter : ", e);

		}
	}

	@Override
	public void write(List<? extends BillDataVO> billDataVOList)
			throws Exception {
		logger.info("BillDataWriter | Write | Enter the method");
		Set<String> billingFileNames;
		String billingFileName;
		if(null != executionContext) {
			childParentMapList = (List<Map<String, Object>>) executionContext.get("listOfEligibleIca");
		}
		else {
			logger.info("BillDataWriter | Write | executionContext is null");
		}
		if (null != fileItemVO) {
			this.fileItemVO = csvWriterUtils
					.createBillDataCSVFile(billDataVOList, childParentMapList ,jobInstanceName);
			logger.info("BillDataWriter | write(List<? extends BillDataVO> billDataVOList)|  CSV file creation initiated");
			billingFileName = csvWriterUtils.getBillingFileName();
			logger.info("***** billingFileName ***** " + billingFileName);
			
			FileDetails fileDetails=new FileDetails();
			try
			{
				fileStatusList=getFileStatus();
				fileDetails.setFileName(billingFileName);
				fileDetails.setStatus(FileStatus.GEN_SUCCESS.getStatus());
				
				logger.info("Billing file was created successfully !!!");
				
				if(executionContext != null  && StringUtils.isNotBlank(billingFileName)){
					if(executionContext.get("billingFileNames") == null) {
						billingFileNames = new HashSet<String>();
						billingFileNames.add(billingFileName);
						executionContext.put("billingFileNames", billingFileNames);
					} else {
						billingFileNames = (Set<String>) executionContext.get("billingFileNames");
						billingFileNames.add(billingFileName);
						executionContext.put("billingFileNames", billingFileNames);
					}
				}
			}
			catch (Exception e) {
				fileDetails.setErrorDetails(e.getMessage());
				fileDetails.setStatus(FileStatus.GEN_FAILURE.getStatus());
				fileDetails.setFileName(null);
				logger.error("Exception occured while creating a file" + e.getMessage());
			}
			
			fileStatusList.add(fileDetails);
		} else {
			logger.info("BillDataWriter | csv file creation cannot be innitiated as fileItemVO is null");

		}
		
		this.executionContext.put("fileStatusList", fileStatusList );
		
		logger.info("BillDataWriter | Write | Exit from method");

	}

	@Override
	public void beforeWrite(List<? extends BillDataVO> items) {
		/*
		 * It is not yet, or never will be, supported. In this case an UnsupportedOperationException should be thrown. 
		 */


	}

	@Override
	public void onWriteError(Exception exception,
			List<? extends BillDataVO> items) {

		logger.error("Error while creating billing file");
		update();

	}

	void update() {
		billDataDao.updateEvents(fileItemVO); 

	}
	
	
	@SuppressWarnings("unchecked")
	private synchronized List<FileDetails> getFileStatus() {
		fileStatusList = (List<FileDetails>) this.getExecutionContext().get("fileStatusList");
		
		if(fileStatusList==null ){
			fileStatusList = new CopyOnWriteArrayList<>();
		}
		return fileStatusList;
	}

	public String getJobInstanceName() {
		return jobInstanceName;
	}

	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}

}
