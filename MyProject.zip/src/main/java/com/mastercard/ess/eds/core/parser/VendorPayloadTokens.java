package com.mastercard.ess.eds.core.parser;
/**
 * Enum for all payload tokens
 * @author E076119
 */
public enum VendorPayloadTokens {

	CWID ("cwid"),
	URL ("url"),
	VALUE ("value"),
	RAW_DATA("rawdata"),
	NAME ("name"),
	EXP_DT ("expDt"),
	EXT_SERVICE_CODE ("extServCd"),
	SESSION_KEY ("session.key"),
	PAYLOAD_PARSER ("payload.parser"),
	ENC_LEVEL ("enc.level"),
	ENC_FIELDS ("enc.fields"),
	ENC_TYPE ("enc.type"),
	ENC_TRANSFORM ("enc.transform"),
	PAYLOAD_TOKENS ("payload.tokens"),
	DATAFILE_NAME ("datafile.name"),
	WRAPPED_KEY_FILENAME ("wrapped.key.filename"),
	FIELD ("field"),
	LINE ("line");

	private String desc;

	public String getDesc() {
		return desc;
	}

	private VendorPayloadTokens(String desc){
		this.desc = desc;
	}

}
