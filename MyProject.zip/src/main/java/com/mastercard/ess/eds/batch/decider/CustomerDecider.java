package com.mastercard.ess.eds.batch.decider;

import org.apache.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;

import com.mastercard.ess.eds.constant.BatchConstants;

/**
 *  This decider class return flow execution status based on the run mode from the context
 *  GFT_FAILURE - This mode is used to resend the files through GFT which are failed in previous run
 *  FILE_GENERATION - This is default mode when the job runs without a parameter. It creates the file for
 *  				  each eligible ICA and sends them using GFT.
 * @author e070836
 * @version 1.0
 * @date : Mar 9 2018
 *
 */
public class CustomerDecider implements JobExecutionDecider {

	private Logger logger = Logger.getLogger(CustomerDecider.class);
	
	/**
	 *  This override method set the flow execution status based context.
	 *  @param  jobExecution , stepExecutionStatus
	 *  @return FlowExecutionStatus
	 */
	@Override
	public FlowExecutionStatus decide(JobExecution jobExecution, StepExecution stepExecutionStatus) {
		String customerRunMode = (String) jobExecution.getExecutionContext().get("customerRunMode");
		
		if(null != customerRunMode && customerRunMode.equalsIgnoreCase(BatchConstants.MODE_GFT_FAILURE)){
			logger.info("Customer File generation job is executed in mode = " + customerRunMode );
			return new FlowExecutionStatus(BatchConstants.MODE_GFT_FAILURE) ;
		}
		logger.info("Customer File generation job is executed in default mode");
		return new FlowExecutionStatus(BatchConstants.MODE_FILE_GENERATION) ;
	}

}