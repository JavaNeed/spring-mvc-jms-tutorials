package com.mastercard.ess.eds.core.dao;

import static com.mastercard.ess.eds.constant.SQLQueries.FETCH_MERCH_NAME_BY_LOCATIONID;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.batch.config.DatabaseUtil;

/**
 * This DAO class finds the Merchant Name using locationId
 * @author e075834
 * @version 1.0
 */

@Component
public class LocationDAO {
	private static Logger logger = Logger.getLogger(LocationDAO.class);

	private JdbcTemplate jdbcTemplate;

	public LocationDAO(DatabaseUtil databaseUtil) {
		jdbcTemplate = databaseUtil.buildDWJdbcTemplate();
	}

	/**
	 * 
	 * @param locationId
	 * @return
	 */
	public String getMerchantNameByLocationId(int locationId) {
		String merchantName = null;
		List<String> merchantNames = jdbcTemplate.queryForList(FETCH_MERCH_NAME_BY_LOCATIONID, String.class, new Object[]{locationId});
		if(merchantNames.size() > 0){
			merchantName = merchantNames.get(0);
		}
		return merchantName;
	}

}

