package com.mastercard.ess.eds.core.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Component
public class DevUtil implements EnvironmentUtil{

	@Value("${keystore.path}")
	private String keyStorePath;	
	
	public void setKeyStorePath(String keyStorePath) {
		this.keyStorePath = keyStorePath;
	}

	@Override
	public String getKeyStorePath() {
		return keyStorePath;
	}
	
	@Override
	public String getEnv() {
		return "dev";
	}

}
