package com.mastercard.ess.eds.batch.processor;

import java.util.List;

import org.apache.log4j.Logger;
import org.easyrules.api.RulesEngine;
import org.easyrules.core.RulesEngineBuilder;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.dao.PriceCategoryDAO;
import com.mastercard.ess.eds.core.rule.PriceCategoryRule;
import com.mastercard.ess.eds.core.util.PriceCategoryRuleCache;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.ProcessedRecord;

/**
 * This ItemProcessor registers an easy rule engine, gets rules from cache and
 * fires the rules to determine the pricing category and confidence score of the
 * PANs
 * 
 * @author E068303
 *
 */
public class PriceCategoryProcessor implements ItemProcessor<EDSRecord, EDSRecord> {

	@Autowired
	private PriceCategoryDAO priceCategoryDao;

	@Autowired
	PriceCategoryRuleCache priceCategoryRuleCache;

	private int srcKey;

	private static Logger logger = Logger.getLogger(PriceCategoryProcessor.class);

	/*
	 * This function is for JUNIT Purpose
	 */
	public PriceCategoryProcessor(PriceCategoryRuleCache priceCategoryRuleCache, PriceCategoryDAO priceCategoryDao) {
		this.priceCategoryRuleCache = priceCategoryRuleCache;
		this.priceCategoryDao = priceCategoryDao;
	}

	/**
	 * process function of itemProcessor class is overridden here, and we fetch
	 * the data from cache and fire the rules.
	 * 
	 */
	@Override
	public EDSRecord process(EDSRecord edsRecord) throws Exception { 
		if (logger.isDebugEnabled()) {
			logger.debug("PriceCategoryProcessor | process | Enter in method ");
		}

		if (edsRecord != null) {
			
			ProcessedRecord processedRecord = edsRecord.getProcRecord();
			if ("Y".equals(processedRecord.getIsAccountActive()) && (true == processedRecord.isAccountValid())
					&& ("N".equals(processedRecord.getIsFraudReported()))) {

				List<PriceCategoryRule> priceCategoryRuleList = priceCategoryRuleCache.getCache();

				processedRecord = edsRecord.getProcRecord();

				RulesEngine rulesEngine = RulesEngineBuilder.aNewRulesEngine().build();

				this.srcKey = (processedRecord.getProcRawRecordKey()).intValue();

				processingPriceCategoryList(processedRecord,
						priceCategoryRuleList, rulesEngine);

				rulesEngine.fireRules();
			}
			if (logger.isDebugEnabled()) {
				logger.debug("PriceCategoryProcessor | process | Exit from method ");
			}
			return edsRecord;
		}

		else {

			logger.error("PriceCategoryProcessor | process | Exit from method as eds data is null ");
			return null;

		}
	}

	/**
	 * @param processedRecord
	 * @param priceCategoryRuleList
	 * @param rulesEngine
	 */
	private void processingPriceCategoryList(ProcessedRecord processedRecord,
			List<PriceCategoryRule> priceCategoryRuleList,
			RulesEngine rulesEngine) {
		for (PriceCategoryRule rule : priceCategoryRuleList) {

			rule.setInputToRule(processedRecord);
			/*
			 * checks if the rule is valid before registering the rule
			 * by calling the validateRule method
			 */
			if (rule.validateRule(rule)) {

				rulesEngine.registerRule(rule);
			}
		}
	}

}
