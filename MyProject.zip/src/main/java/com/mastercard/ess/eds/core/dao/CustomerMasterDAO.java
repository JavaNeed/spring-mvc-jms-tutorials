package com.mastercard.ess.eds.core.dao;

import static com.mastercard.ess.eds.constant.SQLConstants.EMAIL_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.ICA_NUM;
import static com.mastercard.ess.eds.constant.SQLConstants.YES;
import static com.mastercard.ess.eds.constant.SQLQueries.ACTIVE_CUSTOMER;
import static com.mastercard.ess.eds.constant.SQLQueries.ENROLLED_CUSTOMER;
import static com.mastercard.ess.eds.constant.SQLQueries.GET_EMAIL_AND_ICAS;
import static com.mastercard.ess.eds.constant.SQLQueries.SELECT_CUST_MASTER_QUERY;
import static com.mastercard.ess.eds.constant.SQLQueries.UN_ENROLLED_CUSTOMER;
import static com.mastercard.ess.eds.constant.SQLQueries.UPDATE_HIST_FLAG;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/*
 * DAO for dealing with Customer master data
 */
@Component
public class CustomerMasterDAO {
	
	private static Logger logger = Logger.getLogger(CustomerMasterDAO.class);

	private JdbcTemplate jdbcTemplate;
	



	public CustomerMasterDAO(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public Map<String, Object> getCustomerInfoFromICA(String ica) {
		
		Map<String, Object> custInfo = jdbcTemplate.queryForMap(SELECT_CUST_MASTER_QUERY, ica, YES);
		return custInfo;
	}
	

	public List<Map<String, Object>> getEnrolledCustomerDetail() {
		List<Map<String, Object>> enrolledCustomerDetail = jdbcTemplate.queryForList(ENROLLED_CUSTOMER);
		return enrolledCustomerDetail;
	}

	public List<Map<String, Object>> getUnEnrolledCustomerDetail() {
		List<Map<String, Object>> UnEnrolledCustomerDetail = jdbcTemplate.queryForList(UN_ENROLLED_CUSTOMER);
		return UnEnrolledCustomerDetail;
	}
	
	public List<Map<String, Object>> getActiveCustomerDetail() {
		List<Map<String, Object>> ActiveCustomerDetail = jdbcTemplate.queryForList(ACTIVE_CUSTOMER);
		return ActiveCustomerDetail;
	}

	
	/**
	 * Update History flag for inputed ICA.
	 * @param ica
	 * @param histFlag
	 */
	public void updateHistFlag(String ica, String histFlag) {

		logger.info(" Enter in method updateHistFlag ");

		int rows = jdbcTemplate.update( UPDATE_HIST_FLAG , histFlag , ica );

		logger.info( " Update ICA's = " + ica +" HIST_FLAG = "+ histFlag + " Update Row = " +rows );

		logger.info("Exit from method updateHistFlag ");
	}
	
	/**
	 *  This method update the history for list of icas.
	 * @param icas
	 * @param historyFlag
	 */
	public void updateHistoryFlagForIcas(List<String> icas , String historyFlag , String jobInstanceName ){
		
		jdbcTemplate.batchUpdate(
				"UPDATE EDS_CUST_MSTR SET HIST_SW = ? , LST_UPDT_USER_ID = ?, LST_UPDT_DT = ? WHERE ICA_NUM = ? and ACTV_SW = 'Y'",
				new BatchPreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, historyFlag);
						ps.setString(2, jobInstanceName);
						ps.setTimestamp(3, new java.sql.Timestamp(System.currentTimeMillis()));
						ps.setString(4, icas.get(i));
						
					}				
					@Override
					public int getBatchSize() {
						return icas.size();
					}
				});
	}
	/**
	 * The method returns the notification subscribed list of emailIds for the day
	 * @return
	 */
	public Map<String, List<Integer>> getSubscribtionEmailWithICA() {
		logger.debug("Enter into the method getSubscribtionEmailWithICA");
		List<Map<String, Object>> emailIdwithICA  =  jdbcTemplate.queryForList(GET_EMAIL_AND_ICAS);
		 
		Map<String, List<Integer>> emailWithIcas = new HashMap<>();
		
		String email_id = null;
		Integer ica_num = 0;
		
		if (emailIdwithICA != null && !emailIdwithICA.isEmpty()) {
			for (Map<String, Object> row : emailIdwithICA) {
				
				List<Integer> icas = new ArrayList<>();

				if ((String) row.get(EMAIL_ID) != null) {
					email_id = ((String) (row.get(EMAIL_ID)));
				}
				if ((BigDecimal) row.get(ICA_NUM) != null) {
					ica_num = ((BigDecimal) row.get(ICA_NUM)).intValueExact() ;
				}
				
				if(emailWithIcas.get(email_id)!=null){
					icas = emailWithIcas.get(email_id);
				} 
				icas.add(ica_num);
				emailWithIcas.put(email_id, icas);
			}
		} else {
			logger.info("No New ICA's is onboard");
		}
		logger.debug("Exit from the method getSubscribtionEmailWithICA");
		return emailWithIcas ;
		
	}

}
