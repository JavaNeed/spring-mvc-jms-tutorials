package com.mastercard.ess.eds.batch.tasklet;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.service.FraudReportService;

public class FraudUnsubscribedAfterCountTasklet implements Tasklet  {

	private static Logger logger = Logger.getLogger(FraudUnsubscribedAfterCountTasklet.class);
	private static String UNSUBSCRIBED_AFTER_COUNT = "UNSUBSCRIBED_AFTER_COUNT" ;
	
	@Autowired
	private FraudReportService fraudReportService;
	
	
	//required for writing junit
	public FraudUnsubscribedAfterCountTasklet() {
		//NOOP
	}

	//required for writing junit
	public FraudUnsubscribedAfterCountTasklet(  FraudReportService fraudReportService) {
		this.fraudReportService = fraudReportService;
	}
	
	@Override
	public RepeatStatus execute(StepContribution arg0, ChunkContext chunkContext)
			throws Exception {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : FraudUnsubscribedAfterCountTasklet - execute ");
		}
		
		Map<String, Integer>  afterUnSubsFraudCt = fraudReportService.getAfterCountUnSubscribedICA();
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(UNSUBSCRIBED_AFTER_COUNT, afterUnSubsFraudCt);		
		
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit in method : FraudUnsubscribedAfterCountTasklet - execute ");
		}
		return RepeatStatus.FINISHED;
	}

}
