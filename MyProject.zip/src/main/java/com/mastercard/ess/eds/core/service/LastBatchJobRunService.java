package com.mastercard.ess.eds.core.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.dao.LastBatchJobRunDao;

@Component
public class LastBatchJobRunService {

	@Autowired
	LastBatchJobRunDao lastBatchJobRunDao;

	public LastBatchJobRunService(LastBatchJobRunDao lastBatchJobRunDao) {
		this.lastBatchJobRunDao=lastBatchJobRunDao;
	}

	public void updateLastBatchJobRun(String jobInstanceName) {

		lastBatchJobRunDao.updateLastBatchJobRun(jobInstanceName);

	}

}
