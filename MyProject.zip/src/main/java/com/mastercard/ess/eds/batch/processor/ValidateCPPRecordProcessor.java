package com.mastercard.ess.eds.batch.processor;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.batch.exception.InvalidCPPRecordException;
import com.mastercard.ess.eds.core.util.EDSSourceRuleDataCache;
import com.mastercard.ess.eds.core.util.RuleCatCdRecord;
import com.mastercard.ess.eds.domain.RawRecord;

/**
 * This processor validates if the PAN is derived from CPP has a src-rule mapping. If there is no mapping found, an InvalidCPPRecordException is thrown.
 * @author e076119
 *
 */
@Component
public class ValidateCPPRecordProcessor implements ItemProcessor<RawRecord, RawRecord> {
	
	@Autowired
	private EDSSourceRuleDataCache eDSSourceRuleDataCache;
	
	private Logger logger = Logger.getLogger(ValidateCPPRecordProcessor.class);
	
	@Override
	public RawRecord process(RawRecord rawRecord) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter method ValidateCPPRecordProcessor | process() ");
		}
		if("Y".equalsIgnoreCase(rawRecord.getDerivedSw())){
			RuleCatCdRecord ruleCatCdRecord = null;
			if(null != eDSSourceRuleDataCache){
				ruleCatCdRecord = eDSSourceRuleDataCache.getResult(rawRecord.getSrc_data_ky().longValue());
			}
			if( null == ruleCatCdRecord ) {
				logger.info("Derived reocrd found with no mapping.");
				throw new InvalidCPPRecordException("Source data key = " +rawRecord.getSrc_data_ky() + " not found in eDSSourceRuleDataCache.");
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Exit method ValidateCPPRecordProcessor | process() ");
		}
		return rawRecord;
	}
	
	public void seteDSSourceRuleDataCache(
			EDSSourceRuleDataCache eDSSourceRuleDataCache) {
		this.eDSSourceRuleDataCache = eDSSourceRuleDataCache;
	}

}
