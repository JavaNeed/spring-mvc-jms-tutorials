package com.mastercard.ess.eds.core.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.dao.EDSSourceTypeDao;
import com.mastercard.ess.eds.domain.EDSSourceType;

@Component
public class EDSSourceTypeService {

	@Autowired
	EDSSourceTypeDao edsSourceTypeDao;

	public EDSSourceType getEDSSourceType(String endPointReceived) {
		return edsSourceTypeDao.getEDSSourceType(endPointReceived);
	}

	public EDSSourceTypeService(EDSSourceTypeDao edsSourceTypeDao) {
		super();
		this.edsSourceTypeDao = edsSourceTypeDao;
	}

	public EDSSourceTypeService() {
		// TODO Auto-generated constructor stub
	}

	public List<String> getVendorList() {
		return edsSourceTypeDao.getVendorList();
	}

	public void setEdsSourceTypeDao(EDSSourceTypeDao edsSourceTypeDao) {
		this.edsSourceTypeDao= edsSourceTypeDao;
	}

	public EDSSourceType getEDSSourceTypeFromProvider(String provider) {
		return edsSourceTypeDao.getEDSSourceTypeFromProvider(provider);
	}

}
