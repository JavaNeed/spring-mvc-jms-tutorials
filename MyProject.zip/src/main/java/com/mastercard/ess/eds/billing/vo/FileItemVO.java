package com.mastercard.ess.eds.billing.vo;

import java.util.Date;

import org.springframework.stereotype.Component;
@Component
public class FileItemVO {
	private int eds_gen_rpt_id;
	private int eds_rpt_type_id;
	private int cust_mstr_id;
	private String ica_num;
	private String file_nam;
	private String file_loc_txt;
	private int stat_cd;
	private String crte_user_id;
	private Date crte_dt;
	private String lst_updt_user_id;
	private Date lst_updt_dt;
	private int job_instnce_id;
	boolean isCustAtRiskRpt = false;

	public boolean isCustAtRiskRpt() {
		return isCustAtRiskRpt;
	}

	public void setCustAtRiskRpt(boolean isCustAtRiskRpt) {
		this.isCustAtRiskRpt = isCustAtRiskRpt;
	}

	public int getJob_instnce_id() {
		return job_instnce_id;
	}

	public void setJob_instnce_id(int job_instnce_id) {
		this.job_instnce_id = job_instnce_id;
	}

	public int getEds_gen_rpt_id() {
		return eds_gen_rpt_id;
	}

	public void setEds_gen_rpt_id(int eds_gen_rpt_id) {
		this.eds_gen_rpt_id = eds_gen_rpt_id;
	}

	public int getEds_rpt_type_id() {
		return eds_rpt_type_id;
	}

	public void setEds_rpt_type_id(int eds_rpt_type_id) {
		this.eds_rpt_type_id = eds_rpt_type_id;
	}

	public int getCust_mstr_id() {
		return cust_mstr_id;
	}

	public void setCust_mstr_id(int cust_mstr_id) {
		this.cust_mstr_id = cust_mstr_id;
	}

	public String getIca_num() {
		return ica_num;
	}

	public void setIca_num(String ica_num) {
		this.ica_num = ica_num;
	}

	public String getFile_nam() {
		return file_nam;
	}

	public void setFile_nam(String file_nam) {
		this.file_nam = file_nam;
	}

	public String getFile_loc_txt() {
		return file_loc_txt;
	}

	public void setFile_loc_txt(String file_loc_txt) {
		this.file_loc_txt = file_loc_txt;
	}

	public int getStat_cd() {
		return stat_cd;
	}

	public void setStat_cd(int stat_cd) {
		this.stat_cd = stat_cd;
	}

	public String getCrte_user_id() {
		return crte_user_id;
	}

	public void setCrte_user_id(String crte_user_id) {
		this.crte_user_id = crte_user_id;
	}

	public Date getCrte_dt() {
		return crte_dt;
	}

	public void setCrte_dt(Date crte_dt) {
		this.crte_dt = crte_dt;
	}

	public String getLst_updt_user_id() {
		return lst_updt_user_id;
	}

	public void setLst_updt_user_id(String lst_updt_user_id) {
		this.lst_updt_user_id = lst_updt_user_id;
	}

	public Date getLst_updt_dt() {
		return lst_updt_dt;
	}

	public void setLst_updt_dt(Date lst_updt_dt) {
		this.lst_updt_dt = lst_updt_dt;
	}

}
