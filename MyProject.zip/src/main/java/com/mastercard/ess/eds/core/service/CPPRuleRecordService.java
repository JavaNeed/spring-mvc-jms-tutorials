package com.mastercard.ess.eds.core.service;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.dao.EDSSourceDataDAO;
import com.mastercard.ess.eds.core.dao.EDSSourceRuleDAO;
import com.mastercard.ess.eds.domain.AuthDebitPanDetailRecord;

@Component
public class CPPRuleRecordService {
	private static Logger logger = Logger.getLogger(CPPRuleRecordService.class);

	@Autowired
	private EDSSourceDataDAO edsSourceDataDAO;

	@Autowired
	private EDSSourceRuleDAO edsSourceRuleDAO;

	public CPPRuleRecordService(EDSSourceDataDAO edsSourceDataDAO,
			EDSSourceRuleDAO edsSourceRuleDAO) {
		super();
		this.edsSourceDataDAO = edsSourceDataDAO;
		this.edsSourceRuleDAO = edsSourceRuleDAO;
	}

	public void saveRecord(List<? extends AuthDebitPanDetailRecord> authDebitPanDetailRecords, String jobInstanceName, String srcId, BigDecimal jobInstanceId,
			ConcurrentHashMap<String, Set> panRuleMap) {
		if (logger.isDebugEnabled()) {
			logger.debug("In method saveRecord for srcId ="+srcId);
		}

		try {
			long startTime = System.currentTimeMillis();
			for (AuthDebitPanDetailRecord cppRule : authDebitPanDetailRecords) {
				Integer edsSrcDataId = edsSourceDataDAO.saveSourceData(cppRule,
						jobInstanceName, srcId, jobInstanceId);
				/* Add the edsSrcDataId in the panRuleMap for the corresponding pan*/
				addRuleSetInPanRuleMap(panRuleMap, edsSrcDataId,cppRule.getRawPan());
			}
			logger.info("saveRecord exec time = " + ((System.currentTimeMillis() - startTime)));

		} catch (Exception e) {
			logger.error(e);
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method saveRecord for srcId ="+srcId);
		}
	}

	/**
	 * Method to add edsSrcDataId in the 0th index in the set of rule ids for a PAN.
	 * @param panRuleMap : Contains the set of rule ids corresponding to each pan
	 * @param edsSrcDataId : The source data id for the PAN passed in parameter
	 * @param pan : The PAN for which the edsSrcDataId needs to be added in the panRuleMap
	 */
	private synchronized void addRuleSetInPanRuleMap(ConcurrentHashMap<String, Set> panRuleMap, int edsSrcDataId, String pan){
		long startTime = System.currentTimeMillis();
		CopyOnWriteArraySet<BigDecimal> ruleSet = new CopyOnWriteArraySet(new LinkedHashSet<BigDecimal>());
		if(!panRuleMap.isEmpty() && panRuleMap.containsKey(pan)){
			ruleSet.addAll(panRuleMap.get(pan));
		}
		panRuleMap.put(pan, addSRCDataIdInRuleSet(ruleSet, edsSrcDataId));
		logger.info("addRuleSetInPanRuleMap exec time = " + ((System.currentTimeMillis() - startTime)));
	}

	/**
	 * Method to add edsSrcDataId in the 0th index in the set of rule ids for a PAN.
	 * @param ruleSet : Contains the set of rule ids for a PAN
	 * @param edsSrcDataId : The source data id for a particular PAN
	 * @return
	 */
	private synchronized Set addSRCDataIdInRuleSet(CopyOnWriteArraySet<BigDecimal> ruleSet, int edsSrcDataId){
		/**
		 * The first element in the set will be the src_data_id for this particular pan.
		 * Adding the src_data_id in index 0 and then adding rule ids.
		 */
		long startTime = System.currentTimeMillis();
		CopyOnWriteArraySet<BigDecimal> syncRuleSet = new CopyOnWriteArraySet(new LinkedHashSet<BigDecimal>());
		syncRuleSet.add(new BigDecimal(edsSrcDataId));
		if(!ruleSet.isEmpty()){
			syncRuleSet.addAll(ruleSet);

		}
		logger.info("addSRCDataIdInRuleSet exec time = " + ((System.currentTimeMillis() - startTime)));
		return syncRuleSet;
	}

	/**
	 * Method to save the rule mapping. The first element in the set is the src data id, and rest of them are rule ids corresponding that pan.
	 * @param panRuleMap
	 * @param srcId
	 * @param jobInstanceName
	 */
	public synchronized void saveRuleMap(ConcurrentHashMap<String, Set> panRuleMap, String srcId, String jobInstanceName) {
		if (logger.isDebugEnabled()) {
			logger.debug("In method saveRuleMap for srcId = "+srcId);
		}
		long startTime = System.currentTimeMillis();
		if(null != panRuleMap) {
			for (Entry<String, Set> entry : panRuleMap.entrySet()) {

				Set<BigDecimal> syncRuleSet = Collections.synchronizedSet(new LinkedHashSet<BigDecimal>(entry.getValue())); 
				if(null != syncRuleSet) {

					Iterator i = syncRuleSet.iterator(); 
					int edsSrcDataId = Integer.parseInt(i.next().toString());
					while (i.hasNext()){
						edsSourceRuleDAO.saveSourceRuleData(new BigDecimal(i.next().toString()), edsSrcDataId, srcId, jobInstanceName);
					}
				}
			}
		}
		logger.info("saveRuleMap exec time = " + ((System.currentTimeMillis() - startTime)));
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method saveRuleMap for srcId = "+srcId);
		}
	}
}
