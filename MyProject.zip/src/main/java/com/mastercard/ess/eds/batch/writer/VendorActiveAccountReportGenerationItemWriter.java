package com.mastercard.ess.eds.batch.writer;

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.util.VendorReportGenerator;
import com.mastercard.ess.eds.domain.VendorActiveAccountRecord;

public class VendorActiveAccountReportGenerationItemWriter implements ItemWriter<VendorActiveAccountRecord> {

	@Autowired
	VendorReportGenerator vendorReportGenerator;
	
	private static Logger logger = Logger.getLogger(VendorActiveAccountReportGenerationItemWriter.class);
	
	private String vendorName;
	private String prevMonthName;
	
	private BigDecimal jobInstanceId;
	private String jobInstanceName;
	
	private StepExecution stepExcecution;

	//for Junit
	public void setGenerator(VendorReportGenerator vendorReportGenerator) {
		this.vendorReportGenerator = vendorReportGenerator;
		
	}
	
	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getPrevMonthName() {
		return prevMonthName;
	}

	public void setPrevMonthName(String prevMonthName) {
		this.prevMonthName = prevMonthName;
	}

	public BigDecimal getJobInstanceId() {
		return jobInstanceId;
	}

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}

	public String getJobInstanceName() {
		return jobInstanceName;
	}

	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}

	@BeforeStep
	public void setStepExecution(StepExecution stepExecution) {
	    this.stepExcecution = stepExecution;
	}
	
	@Override
	public void write(List<? extends VendorActiveAccountRecord> summaryList) throws Exception {
		logger.info("Received Vendor report list for writing =" + summaryList);
		
		//calculate the total for the month and pass it as a separate object
		VendorActiveAccountRecord monthlySummary = new VendorActiveAccountRecord();
		
		for(VendorActiveAccountRecord daySummary : summaryList) {
			
			monthlySummary.setActivePANCount(monthlySummary.getActivePANCount() + daySummary.getActivePANCount());
			monthlySummary.setInactivePANCount(monthlySummary.getInactivePANCount() + daySummary.getInactivePANCount());
			monthlySummary.setUniquePANCount(monthlySummary.getUniquePANCount() + daySummary.getUniquePANCount());
			monthlySummary.setReceivedPANCount(monthlySummary.getReceivedPANCount() + daySummary.getReceivedPANCount());
			
		}
		
		vendorReportGenerator.writeToVendorReport(this.stepExcecution, summaryList, monthlySummary, jobInstanceId, jobInstanceName, vendorName, prevMonthName);
		
	}

	

}