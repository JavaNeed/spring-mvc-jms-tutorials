package com.mastercard.ess.eds.batch.processor;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.mastercard.ess.eds.constant.BatchConstants;
import com.mastercard.ess.eds.core.service.EDSCPPRulesService;
import com.mastercard.ess.eds.core.util.DeDupeCPPUtil;
import com.mastercard.ess.eds.domain.AuthDebitPanDetailRecord;
import com.mastercard.ess.eds.domain.CPPRuleRecord;

/** It will take list of CPPRuleRecord provided from reader and create queries for Auth related module 
 * and records fetch from Auth DW database will be send to writer*/

public class AuthRecordProcessor implements ItemProcessor<CPPRuleRecord,List<AuthDebitPanDetailRecord>> {

	private static final String FAILED_CPP_RULE_IDS = "failedCPPRuleIds";

	private static Logger logger = Logger.getLogger(DebitRecordProcessor.class);

	@Autowired
	EDSCPPRulesService  edsCPPRulesService;

	@Value("${subsequent.cpprulerun}")
	private String runCppRuleForDays;

	private ExecutionContext executionContext;
	
	private String cppRunMode ;
	

	public String getCppRunMode() {
		return cppRunMode;
	}

	public void setCppRunMode(String cppRunMode) {
		this.cppRunMode = cppRunMode;
	}

	public String getRunCppRuleForDays() {
		return runCppRuleForDays;
	}

	public void setRunCppRuleForDays(String runCppRuleForDays) {
		this.runCppRuleForDays = runCppRuleForDays;
	}
	// Added for JUnit
	public EDSCPPRulesService getEdsCPPRulesService() {
		return edsCPPRulesService;
	}

	public void setEdsCPPRulesService(EDSCPPRulesService edsCPPRulesService) {
		this.edsCPPRulesService = edsCPPRulesService;
	}


	public ExecutionContext getExecutionContext() {
		return executionContext;
	}

	public void setExecutionContext(ExecutionContext executionContext) {
		this.executionContext = executionContext;
	}
	
	/** It will take rule id and will fetch auth records on the basis of rule id.
	 * @param cPPRuleRecord :Rules will be applied on basis of cppRuleRecord object.
	 * @return panList:It will return list of pans which satisfies cpprules.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<AuthDebitPanDetailRecord> process(CPPRuleRecord cPPRuleRecord) throws Exception {
		List<AuthDebitPanDetailRecord> panList=new LinkedList<>();
		try {
			if (logger.isDebugEnabled()) {
				logger.debug("Enter in AuthRecordProcessor method : process cPPRuleRecord with cPPRuleRecordId ="+cPPRuleRecord.getCppRuleId());
			}
			logger.info("Enter in AuthRecordProcessor method : process cPPRuleRecord with cPPRuleRecordId ="+cPPRuleRecord.getCppRuleId());

			panList = edsCPPRulesService.getAuthRecordsByRule(cPPRuleRecord,runCppRuleForDays);
			
			if(!BatchConstants.SIMULATION.equalsIgnoreCase(cppRunMode)){
				panList = DeDupeCPPUtil.filterDuplicates(this.executionContext, panList);
			}else{
				if(panList.isEmpty()){
					AuthDebitPanDetailRecord authDebitPanDetailRecord  = new AuthDebitPanDetailRecord();
					authDebitPanDetailRecord.setCppRuleId(cPPRuleRecord.getCppRuleId());
					authDebitPanDetailRecord.setdWSource(BatchConstants.DW_AUTH);
					panList.add(authDebitPanDetailRecord);
				}
			}
			if (logger.isDebugEnabled()) {
				logger.debug("Exit from AuthRecordProcessor method : process cPPRuleRecord with cPPRuleRecordId ="+cPPRuleRecord.getCppRuleId());
			}
			logger.info("panList"+ panList);

		}catch (Exception e) {

			/**If we get any exception while executing rule then we are addign that rule to list in context and 
			  at time of updating FW_FLAG we will modify rules from 'Y' to 'N',by excluding failed cpp rules . */ 

			logger.info("In AuthRecordProcessor Catch block");
			List<String> cppRuleIdList =new ArrayList<>();

			if (this.executionContext != null && this.executionContext.get(FAILED_CPP_RULE_IDS)!= null) {
				cppRuleIdList =	(List<String>) this.executionContext.get(FAILED_CPP_RULE_IDS);
			}
			cppRuleIdList.add("'"+cPPRuleRecord.getCppRuleId().toString()+"'");
			if (this.executionContext !=null) {
				this.executionContext.put(FAILED_CPP_RULE_IDS, cppRuleIdList);
			}
			logger.info("Failed CPPRule Id Added  = "+cPPRuleRecord.getCppRuleId().toString());
			logger.error("Error description in auth processor",e);
		}
		return panList;
	}
}
