package com.mastercard.ess.eds.core.icatopanmapping;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.batch.exception.EDSCoreException;

/**
 * Class will validate ICA's set to PAN's received for customer-file generation.
 * 
 * @author e075766
 *
 */
public class PanVerificationUsingICAToRangeMapping {

	private Logger logger = Logger.getLogger(PanVerificationUsingICAToRangeMapping.class);

	private ExecutionContext executionContext;

	private static final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

	public ExecutionContext getExecutionContext() {
		return executionContext;
	}

	public void setExecutionContext(ExecutionContext executionContext) {
		this.executionContext = executionContext;
	}
	/**
	 * Method will verify whether PANs are mapped to correct ICA or not.
	 * @param panList :We will verify pans in this list whether it is mapped to right ICA or not
	 * @param ica :ICA to which pans are mapped
	 * @param fileName :FileName to which we will write incorrect pans
	 * @return
	 * @throws Exception 
	 */
	public List<BigInteger> validatePansToIcas(Map<String, Map<ICAAccountRange, ICAAccountRange>> icaToRangeCache ,List<BigInteger> panList,String ica) throws EDSCoreException {

		logger.debug(" Enter In Class : PanVerificationUsingICAToRangeMapping Method: validatePansToIcas ");
		lock.readLock().lock();

		List<BigInteger> invalidPanList = new ArrayList<BigInteger>();

		try {
			if (null != panList && ! panList.isEmpty() && null != icaToRangeCache && ! icaToRangeCache.isEmpty()) {

				Map<ICAAccountRange, ICAAccountRange> icaAcctRangeMap = icaToRangeCache.get(ica);
				if ( null != icaAcctRangeMap && ! icaToRangeCache.isEmpty() ) {

					logger.info("Find ICA = " + ica + " Under ICAToRangeCache Cache");
					for (BigInteger pan : panList) {

						boolean isValid = false;

						for (Map.Entry<ICAAccountRange, ICAAccountRange> entryRange : icaAcctRangeMap.entrySet()) {

							ICAAccountRange icaAccountRangeFromCache = entryRange.getValue();
							BigInteger paddedPan = new BigInteger(StringUtils.rightPad(pan.toString(), 19, '0'));
						
							if ((0 <= paddedPan.compareTo(icaAccountRangeFromCache.getStart()))&&
									((0 >= paddedPan.compareTo(icaAccountRangeFromCache.getEnd())))) {
								isValid = true;
								break;
							}
						}
						
						/*If pan is invalid we will add it to invalidPanList list.*/
						if (!isValid) {
							invalidPanList.add(pan);
						}
					}
				}
				else {
					logger.error("ICA is not found = " + ica + " Under ICAToRangeCache Cache");
					throw new EDSCoreException(" ICA = " + ica + " not found under ICAToRangeCache Cache. ");				}
			}
		}
		finally {
			lock.readLock().unlock();
		}
		logger.debug(" Exit from Class : PanVerificationUsingICAToRangeMapping Method: validatePansToIcas");
		return invalidPanList;
	}

	/**
	 * Method will return masked PANs
	 * @param paddedPan
	 * @return
	 */
	public static String getMaskedAccountNumber(BigInteger paddedPan)
	{
		String result = null;
		String accountNumber = null;
		if (null != paddedPan) {
			accountNumber = paddedPan.toString();
		} 

		if (accountNumber != null)
		{
			int accountNumberLength = accountNumber.length();
			if (accountNumberLength > 6)
			{
				StringBuilder buf = new StringBuilder();
				buf.append(accountNumber.substring(0, 6));

				String last4 = accountNumber.substring(accountNumberLength - 4);
				for (int i=6; i<accountNumberLength-4; i++)
				{
					buf.append("X");
				}
				buf.append(last4);
				result = buf.toString();
			}
			else
			{
				result = accountNumber;
			}
		}
		return result;
	}
}
