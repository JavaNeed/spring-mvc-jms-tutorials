package com.mastercard.ess.eds.batch.partitioner;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.mastercard.ess.eds.core.service.CPPAccountService;
import com.mastercard.ess.eds.domain.CPPRecord;

/**
 * 
 * this class creates partitions of records fetched from CPP_ACCOUNTS_VIEW
 * and stores the pans in executionContext of each partition
 * @author e058825
 *
 */
public class CppAccountPartitioner implements Partitioner{

	@Autowired
	CPPAccountService cppAccountService;
	
	@Value("${recordsPerPartitionsLimit}")
	private int recordsPerPartitionsLimit;

		
	private static Logger logger = Logger.getLogger(CppAccountPartitioner.class);

	public void setCppAccountService(CPPAccountService cppAccountService) {
		this.cppAccountService = cppAccountService;
	}
	
	public int getRecordsPerPartitionsLimit() {
		return recordsPerPartitionsLimit;
	}

	public void setRecordsPerPartitionsLimit(int recordsPerPartitionsLimit) {
		this.recordsPerPartitionsLimit = recordsPerPartitionsLimit;
	}
	
	public CPPAccountService getCppAccountService() {
		return cppAccountService;
	}


	/* 
	 * receives the partitionSize from configuration file and creates partition
	 * of the partitionSize
	 */
	@Override
	public Map<String, ExecutionContext> partition(int threadCount) {

		logger.debug("Enter in method partition : CppAccountPartitioner ");

		List<CPPRecord> cppRecords = cppAccountService.fetchVendorProvidedAccounts();
		
		logger.info("Enter in method partition : CppAccountPartitioner with threadCount "+threadCount);
		Map<String, ExecutionContext> partitionMap = new LinkedHashMap<String, ExecutionContext>();

		int recordNum=0;
		recordNum=cppRecords!=null && !cppRecords.isEmpty()? cppRecords.size():0;
		logger.info("Records found for EDSCPPRule List size is = "+recordNum);

		if( 0 == recordNum ) {
			return partitionMap;
		}
		int partitionSize = 1; //can't initialize with 0 due to divide by zero exception
		int countAfterPartition ;
		int numberOfPartition;
		countAfterPartition = recordNum / threadCount;
		if (countAfterPartition<recordsPerPartitionsLimit) {
			numberOfPartition=threadCount;
			partitionSize = countAfterPartition;
			
			logger.info("countAfterPartition"+ countAfterPartition + "numberOfPartition" + numberOfPartition + "recordNum" + recordNum );
			if(countAfterPartition == 0){
				logger.info("Inside IF condition");
				numberOfPartition = 1;
				partitionSize = recordNum ;
			} else if (  recordNum % partitionSize != 0) {
				numberOfPartition = numberOfPartition + 1;
			}
		}
		else {
			partitionSize=recordsPerPartitionsLimit;
			numberOfPartition=recordNum/recordsPerPartitionsLimit;
			
			numberOfPartition=recordNum % partitionSize != 0?numberOfPartition + 1:0;
		}
		logger.info("threadCount is = "+threadCount+" numberOfPartition = "+ numberOfPartition+" partitionSize ="+ partitionSize+ " recordsPerPartitionsLimit = "+recordsPerPartitionsLimit);

		buildPartitionMap(cppRecords, partitionMap, recordNum, partitionSize,
				numberOfPartition);

		logger.debug("Exit from method partition : CppAccountPartitioner ");
		return partitionMap;
	}

	private void buildPartitionMap(List<CPPRecord> cppRecords,
			Map<String, ExecutionContext> partitionMap, int recordNum,
			int partitionSize, int numberOfPartition) {
		int lastPanIndex = 0;
		for(int i = 1 ; i <= numberOfPartition ; i++){


			StringBuilder panNum = new StringBuilder("");
			int j;
			for(j = lastPanIndex ; j < recordNum && j < lastPanIndex + partitionSize ; j++){
				panNum=j == lastPanIndex ? panNum.append("'").append((cppRecords.get(j).getPan().toString())).append("'") : 
					panNum.append( ",").append("'").append((cppRecords.get(j).getPan().toString())).append("'");
			}
			lastPanIndex = j;
			
			ExecutionContext executionContext = new ExecutionContext();
			executionContext.put("panList", panNum.toString());
			partitionMap.put("Partition = " + i, executionContext);
		}
	}

}
