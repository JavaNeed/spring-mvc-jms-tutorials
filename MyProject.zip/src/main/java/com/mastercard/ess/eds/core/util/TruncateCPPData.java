package com.mastercard.ess.eds.core.util;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.dao.CPPDAO;

public class TruncateCPPData implements Tasklet{
	
	@Autowired
	CPPDAO cppDao;
	
	private Logger logger = Logger.getLogger(TruncateCPPData.class);

	public void setTruncateCPPData(CPPDAO cppDao) {
		this.cppDao = cppDao;
	}

	/* 
	 * this method is executed in cleanCPPTableStep to truncate
	 * EDS_CPP_TRAN and EDS_CPP_TRAN_SUMM both tables
	 */
	@Override
	public RepeatStatus execute(StepContribution paramStepContribution,
			ChunkContext paramChunkContext) throws Exception {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : execute | TruncateCPPData ");
		}
		cppDao.truncateCPPData();
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : execute | TruncateCPPData ");
		}
		
		return RepeatStatus.FINISHED;
	}
	
	

}
