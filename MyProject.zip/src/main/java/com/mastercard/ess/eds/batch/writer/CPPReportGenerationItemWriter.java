package com.mastercard.ess.eds.batch.writer;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.Comparator.PercentageComparator;
import com.mastercard.ess.eds.core.util.CPPReportGenerator;
import com.mastercard.ess.eds.domain.CPPReportInfo;

public class CPPReportGenerationItemWriter implements ItemWriter<CPPReportInfo> {

	private static Logger logger = Logger.getLogger(CPPReportGenerationItemWriter.class);
	
	@Autowired
	private CPPReportGenerator cppReportGenerator;
	
	private BigDecimal jobInstanceId;
	private String jobInstanceName;
	private String countryCode;
	private static final String UNDERSCORE = "_";
	private static final String CP = "CP";
	private static final String CNP = "CNP";
	private ExecutionContext executionContext;
		
	//for Junit
	
	public ExecutionContext getExecutionContext()
	  {
	    return this.executionContext;
	  }
	  
	  public void setExecutionContext(ExecutionContext executionContext)
	  {
	    this.executionContext = executionContext;
	  }
	  
	  public String getCountryCode()
	  {
	    return this.countryCode;
	  }
	  
	  public void setCountryCode(String countryCode)
	  {
	    this.countryCode = countryCode;
	  }
	  
	  public void setObject(CPPReportGenerator cppReportGenerator)
	  {
	    this.cppReportGenerator = cppReportGenerator;
	  }
	  
	  public void setJobInstanceId(BigDecimal jobInstanceId)
	  {
	    this.jobInstanceId = jobInstanceId;
	  }
	  
	  public void setJobInstanceName(String jobInstanceName)
	  {
	    this.jobInstanceName = jobInstanceName;
	  }


	@Override
	public void write(List<? extends CPPReportInfo> reportInfos) throws Exception {

		logger.info("Enter in the write method of CPPDetailReportGenerationItemWriter ");
	    if ((reportInfos == null) || (reportInfos.isEmpty()))
	    {
	      logger.info("No records for writing in Details Records");
	      return;
	    }
	    long totalUniquePANCountCP = 0L;
	    long totalUniquePANCountCNP = 0L;
	    
	    List<CPPReportInfo> group1List = new CopyOnWriteArrayList();
	    List<CPPReportInfo> tempPercentageList = new CopyOnWriteArrayList();
	    
	    ListIterator groupListIterator = reportInfos.listIterator();
	    while (groupListIterator.hasNext())
	    {
	      CPPReportInfo cppReportInfo = (CPPReportInfo)groupListIterator.next();
	      if (1 == cppReportInfo.getGroupId()) {
	        group1List.add(cppReportInfo);
	      }
	    }
	    logger.info("group1List" + group1List);
	    ListIterator<CPPReportInfo> group1ListIterator = group1List.listIterator();
	    
	    Map<String, String> distinctPanCountMap = (Map)this.executionContext.get("distinctPanCountMap");
	    if (distinctPanCountMap != null)
	    {
	      totalUniquePANCountCP = Long.valueOf(StringUtils.isBlank((String)distinctPanCountMap.get(this.countryCode + UNDERSCORE + CP)) ? "0" : (String)distinctPanCountMap.get(this.countryCode + UNDERSCORE + CP)).longValue();
	      totalUniquePANCountCNP = Long.valueOf(StringUtils.isBlank((String)distinctPanCountMap.get(this.countryCode + UNDERSCORE + CNP)) ? "0" : (String)distinctPanCountMap.get(this.countryCode + UNDERSCORE+ CNP)).longValue();
	    }
	    logger.info("totalUniquePANCountCP" + totalUniquePANCountCP);
	    logger.info("totalUniquePANCountCNP" + totalUniquePANCountCNP);
	    logger.info("group1ListIterator" + group1ListIterator);
	    
	    populateCardPercentageForDetailReport(totalUniquePANCountCP, totalUniquePANCountCNP, group1ListIterator);
	    for (CPPReportInfo cppReportInfo : group1List) {
	      addCppReportInfo(tempPercentageList, cppReportInfo);
	    }
	    group1List.removeAll(tempPercentageList);
	    
	    group1ListIsEmpty(group1List ,this.countryCode);

	}


	/**
	 * @param group1List
	 */
	private void group1ListIsEmpty(List<CPPReportInfo> group1List , String countyCode) {
		logger.info("group1List" + group1List);
		if (!group1List.isEmpty()) {
			logger.info("Going to write Summary report");
			Collections.sort(group1List,new PercentageComparator());
			cppReportGenerator.writeToCPPReport(group1List, "summary", jobInstanceId, jobInstanceName , countyCode);
		}
	}

	/**
	 * @param tempPercentageList
	 * @param cppReportInfo
	 */
	private void addCppReportInfo(List<CPPReportInfo> tempPercentageList,
			CPPReportInfo cppReportInfo) {
		logger.info("cppReportInfo.getCardsCountryPercentage()" + cppReportInfo.getCardsCountryPercentage());
		logger.info("cppReportInfo.getCardsUsedCount()" + cppReportInfo.getCardsUsedCount());
		if(cppReportInfo.getCardsCountryPercentage() < 2 || cppReportInfo.getCardsUsedCount() < 10){
		   tempPercentageList.add(cppReportInfo); 
		}
	}

	/**
	 * @param totalUniquePANCountCP
	 * @param totalUniquePANCountCNP
	 * @param group1ListIterator
	 * @param tempList
	 */
	private void populateCardPercentageForDetailReport(long totalUniquePANCountCP,
			long totalUniquePANCountCNP,
			ListIterator<CPPReportInfo> group1ListIterator) {
		while (group1ListIterator.hasNext()) {
			CPPReportInfo cppReportInfo = group1ListIterator.next();
			if ("CP".equals(cppReportInfo.getTransactionChannel())) {
				if (totalUniquePANCountCP == 0) {
					cppReportInfo.setCardsCountryPercentage(0); //For SONAR
				}
				else {
					cppReportInfo.setCardsCountryPercentage(
							(cppReportInfo.getCardsUsedCount() * 100) / totalUniquePANCountCP);
					}
			} else if ("CNP".equals(cppReportInfo.getTransactionChannel())) {
				if (totalUniquePANCountCNP == 0) {
					cppReportInfo.setCardsCountryPercentage(0); //For SONAR
				}else {
					cppReportInfo.setCardsCountryPercentage(
							(cppReportInfo.getCardsUsedCount() * 100) / totalUniquePANCountCNP);
				}
			} 

		}
	}

}
