package com.mastercard.ess.eds.core.mapper;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.mastercard.ess.eds.domain.CPPTxnInfo;

public class CPPDebitTxnInfoRowMapper implements RowMapper<CPPTxnInfo>{

	private static Logger logger = Logger.getLogger(CPPDebitTxnInfoRowMapper.class);
	
	@Override
	public CPPTxnInfo mapRow(ResultSet paramResultSet, int paramInt) throws SQLException {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : mapRow | CPPDebitTxnInfoRowMapper ");
		}
		CPPTxnInfo cppTxnInfo = new CPPTxnInfo();
		cppTxnInfo.setPan(new BigDecimal(paramResultSet.getString("PAN")));
		cppTxnInfo.setTransactionAmount(paramResultSet.getBigDecimal("LOC_TXN_AMT").toString());
		cppTxnInfo.setLocationId(paramResultSet.getLong("LOC_ID"));
		cppTxnInfo.setSequenceNumber(paramResultSet.getLong("SEQ_NBR"));
		cppTxnInfo.setMerchantName(paramResultSet.getString("MERCH_NAM"));
		cppTxnInfo.setIssuerCountryCode(paramResultSet.getString("ISSR_CNTRY_CD"));
		cppTxnInfo.setMerchantCountryCode(paramResultSet.getString("MERCH_CNTRY_CD"));
		cppTxnInfo.setTransactionChannel(paramResultSet.getString("TRAN_CHNL"));
		cppTxnInfo.setSource("DEBIT");
		
		return cppTxnInfo;
	}

}
