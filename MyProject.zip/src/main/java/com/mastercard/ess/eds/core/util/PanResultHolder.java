package com.mastercard.ess.eds.core.util;

public class PanResultHolder {
	
	private String pan;
	private String result;

	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	
}
