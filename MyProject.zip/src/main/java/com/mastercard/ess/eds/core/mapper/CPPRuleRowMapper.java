package com.mastercard.ess.eds.core.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.mastercard.ess.eds.domain.CPPRuleRecord;

/**
 * Maps columns from EDS_OWNER.EDS_CPP_RULE table to fields in CPPRuleRowMapper domain object. Required by reader while
 * parsing data and returning a populated object.
 * @author e067588
 *
 */
public class CPPRuleRowMapper implements RowMapper<CPPRuleRecord> {

	private static final String LST_UPDT_USER_ID = "LST_UPDT_USER_ID";
	private static final String LST_UPDT_DT = "LST_UPDT_DT";
	private static final String CRTE_USER_ID = "CRTE_USER_ID";
	private static final String CRTE_DT = "CRTE_DT";
	private static final String VAL_TM_CNT = "VAL_TM_CNT";
	private static final String VAL_MERCH_LOC_ID = "VAL_MERCH_LOC_ID";
	private static final String VAL_LOC_TRAN_AMT = "VAL_LOC_TRAN_AMT";
	private static final String VAL_ISSR_CNTRY_ID = "VAL_ISSR_CNTRY_ID";
	private static final String UNIT_TM_CNT = "UNIT_TM_CNT";
	private static final String FIRST_RUN_SW = "FIRST_RUN_SW";
	private static final String EDS_CPP_RULE_ID = "EDS_CPP_RULE_ID";
	private static final String CLS_MERCH_LOC_ID = "CLS_MERCH_LOC_ID";
	private static final String CLS_LOC_TRAN_AMT = "CLS_LOC_TRAN_AMT";
	private static final String CLS_ISSR_CNTRY_ID = "CLS_ISSR_CNTRY_ID";
	private static final String CAT_CD = "CAT_CD";
	private static final String ACTV_SW = "ACTV_SW";
	private static Logger logger = Logger.getLogger(CPPRuleRowMapper.class);

	/* (non-Javadoc)
	 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
	 */
	@Override
	public CPPRuleRecord mapRow(ResultSet paramResultSet, int paramInt) throws SQLException {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter in CPPRuleRowMapper method : mapRow ");
		}


		CPPRuleRecord cppRuleRecord = new CPPRuleRecord();
		cppRuleRecord.setActiveSW(paramResultSet.getString(ACTV_SW));
		cppRuleRecord.setCatCD(paramResultSet.getString(CAT_CD));
		cppRuleRecord.setClsIssrCntry(paramResultSet.getString(CLS_ISSR_CNTRY_ID));
		cppRuleRecord.setClsLocTranAmt(paramResultSet.getString(CLS_LOC_TRAN_AMT));
		cppRuleRecord.setClsMerchant(paramResultSet.getString(CLS_MERCH_LOC_ID));
		cppRuleRecord.setCppRuleId(paramResultSet.getBigDecimal(EDS_CPP_RULE_ID));
		cppRuleRecord.setFirstRunSW(paramResultSet.getString(FIRST_RUN_SW));
		cppRuleRecord.setUnitTmCount(paramResultSet.getString(UNIT_TM_CNT));
		cppRuleRecord.setValIssrCntry(paramResultSet.getString(VAL_ISSR_CNTRY_ID));
		cppRuleRecord.setValLocTranAmt(paramResultSet.getBigDecimal(VAL_LOC_TRAN_AMT));
		cppRuleRecord.setValMerchant(paramResultSet.getInt(VAL_MERCH_LOC_ID));
		cppRuleRecord.setValTmCount(paramResultSet.getInt(VAL_TM_CNT));
		cppRuleRecord.setCreateDate(paramResultSet.getDate(CRTE_DT));
		cppRuleRecord.setCreatedBy(paramResultSet.getString(CRTE_USER_ID));
		cppRuleRecord.setLastUpdateDate(paramResultSet.getDate(LST_UPDT_DT));
		cppRuleRecord.setLastUpdatedBy(paramResultSet.getString(LST_UPDT_USER_ID));

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from CPPRuleRowMapper method : mapRow ");
		}

		return cppRuleRecord;
	}

}
