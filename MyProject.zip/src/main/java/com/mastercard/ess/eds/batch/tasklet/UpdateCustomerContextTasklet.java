package com.mastercard.ess.eds.batch.tasklet;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;

public class UpdateCustomerContextTasklet implements Tasklet{

	private static Logger logger = Logger
			.getLogger(UpdateCustomerContextTasklet.class);

	private String customerRunMode ;

	private ExecutionContext executionContext;

	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext){
		
		logger.info("Customer generation Job is executing with runMode = " + customerRunMode);
		
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("customerRunMode", customerRunMode);
		
		return RepeatStatus.FINISHED;
	}
	

	public String getCustomerRunMode() {
		return customerRunMode;
	}

	public void setCustomerRunMode(String customerRunMode) {
		this.customerRunMode = customerRunMode;
	}

	public ExecutionContext getExecutionContext() {
		return executionContext;
	}

	public void setExecutionContext(ExecutionContext executionContext) {
		this.executionContext = executionContext;
	}
}