package com.mastercard.ess.eds.batch.listener;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;

import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.notification.util.NotificationEventConstants;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;

public class VendorActiveAccountReportMailListener implements Tasklet, JobExecutionListener {

	@Autowired
	EventPublisher eventPublisher;

	@Value("${activeVendorAccountReport.path}")
	private String activeVendorAccountReportPath;

	private static final Logger logger = Logger.getLogger(VendorActiveAccountReportMailListener.class);

	@Override
	public RepeatStatus execute(StepContribution arg0, ChunkContext arg1) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : afterJob : EmailCPPAnalysisReport ");
		}
		logger.info("Enter in method : afterJob : EmailCPPAnalysisReport ");
		
		Calendar now = Calendar.getInstance();
		String currentDate = (now.get(Calendar.MONTH) + 1) + "-" + now.get(Calendar.DATE) + "-"
				+ now.get(Calendar.YEAR);

		String vendorReportFile = activeVendorAccountReportPath + currentDate + ".xlsx";
		logger.info("**********vendorReportFile========== "+ vendorReportFile);
		NotificationEventVO notificationEventVO = new NotificationEventVO();
		Map<String, String> jobParams = new HashMap<String, String>();

		jobParams.put("summaryFile", vendorReportFile);

		notificationEventVO.setEventName(NotificationEventConstants.NOTIF_EVT_VENDOR_REPORT_FILE_GENERATED);
		notificationEventVO.setJobParams(jobParams);
		notificationEventVO.setJobName(jobExecution.getJobInstance().getJobName());
		notificationEventVO.setJobID(new BigDecimal(jobExecution.getJobId()));

		FileSystemResource vendorReportFileSystemResource = new FileSystemResource(vendorReportFile);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : afterJob : EmailCPPAnalysisReport ");
		}
		logger.info("Exit from method : afterJob : EmailCPPAnalysisReport ");
		
		if (vendorReportFileSystemResource.exists()) {
			eventPublisher.placeEvent(notificationEventVO);
		}

	}

	@Override
	public void beforeJob(JobExecution arg0) {
		// TODO Auto-generated method stub

	}

}
