package com.mastercard.ess.eds.core.util;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
public class KnownPanCacheLoader {
	
	private static final String KNOWN_PAN_QUERY = "select pan, max(result) as result from (SELECT pd.pan_num AS pan, "+ 
       "CASE WHEN EXISTS (SELECT 1 FROM dual WHERE pd.RPT_SW = 'Y') THEN 'SENT' WHEN EXISTS (SELECT 1 FROM eds_src_type TYPE, " +                        
       "eds_src_data sd, eds_src src WHERE pd.eds_src_data_id = sd.eds_src_data_id AND src.eds_src_id = sd.eds_src_id " +
       "AND TYPE.eds_src_type_id = src.eds_src_type_id AND pd.RPT_SW = 'N' AND TYPE.prvdr_nam != 'CPP') THEN 'NOTSENTVENDOR' "+
       "ELSE 'NOTSENTCPP' END AS result FROM eds_prcss_data pd) group by pan";
	
	@Autowired
	private KnownPanCache cache;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public KnownPanCacheLoader(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@PostConstruct
	public void populateKnownPanCache() {
		
		List<PanResultHolder> pans = jdbcTemplate.query(KNOWN_PAN_QUERY, new RowMapper<PanResultHolder>() { 
			public PanResultHolder mapRow(ResultSet rs, int rowNum) throws SQLException {
				PanResultHolder holder = new PanResultHolder();
				String pan = rs.getString("pan");
				String result = rs.getString("result");

				holder.setPan(pan.toString()); 
				holder.setResult(result);

				return holder;
				}

				});
		
		cache.bulkInsert(pans);
	}
}


