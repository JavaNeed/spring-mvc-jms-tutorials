package com.mastercard.ess.eds.batch.mapper;

import org.apache.log4j.Logger;
import org.springframework.util.Assert;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.beans.factory.InitializingBean;

import com.mastercard.ess.eds.domain.RawRecord;

public class RawRecordLineMapper implements LineMapper<RawRecord>,
		InitializingBean {
	private LineTokenizer tokenizer;
	private RawRecordFieldSetMapper fieldSetMapper;
	private static Logger logger = Logger.getLogger(RawRecordLineMapper.class);
	public RawRecord mapLine(String line, int lineNumber) throws Exception {
		logger.info("Enter RawRecordLineMapper | mapLine()");
		try {
			RawRecord rawRecord = fieldSetMapper.mapFieldSet(tokenizer
					.tokenize(line));
			rawRecord.setLineNumber(lineNumber);
			logger.info("Exit RawRecordLineMapper | mapLine()");
			return rawRecord;
		} catch (Exception ex) {
			throw new FlatFileParseException("Parsing error at line: "
					+ lineNumber + ", input=[" + line + "]", ex, line,
					lineNumber);
		}
	}

	public void setLineTokenizer(LineTokenizer tokenizer) {
		this.tokenizer = tokenizer;
	}

	public void setFieldSetMapper(RawRecordFieldSetMapper fieldSetMapper) {
		this.fieldSetMapper = fieldSetMapper;
	}

	public void afterPropertiesSet() {
		Assert.notNull(tokenizer, "The LineTokenizer must be set");
		Assert.notNull(fieldSetMapper, "The FieldSetMapper must be set");
	}

}
