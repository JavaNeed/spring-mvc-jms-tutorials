package com.mastercard.ess.eds.batch.tasklet;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.mastercard.ess.eds.core.service.CPPRuleRecordService;
import com.mastercard.ess.eds.core.util.DeDupeTokens;

public class SavePanRuleMappingTasklet implements Tasklet{

	@Autowired
	private CPPRuleRecordService cppRuleRecordService;

	@Value("#{jobParameters['edsSrcId']}")
	public String srcId;

	private ExecutionContext executionContext;
	private String jobInstanceName;

	private static Logger logger = Logger.getLogger(SavePanRuleMappingTasklet.class);

	public ExecutionContext getExecutionContext() {
		return executionContext;
	}

	public void setExecutionContext(ExecutionContext executionContext) {
		this.executionContext = executionContext;
	}
	
	public String getJobInstanceName() {
		return jobInstanceName;
	}

	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}

	/**
	 * This method saves the pan-rule mapping. The map stored in the execution context contains pan as the key and set of rule ids as value.
	 * The first element in the set is the src data id, and rest of them are rule ids corresponding that pan.
	 */
	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext){
		logger.info("Enter in SavePanRuleMappingTasklet");
		if(this.executionContext.get("edsSrcId")!=null) {
			srcId = this.executionContext.get("edsSrcId").toString();
			logger.info("srcId - " + srcId);
		}
		ConcurrentHashMap<String, Set> panRuleMap = (ConcurrentHashMap<String, Set>)executionContext.get(DeDupeTokens.PAN_RULE_MAP.getDesc());
		cppRuleRecordService.saveRuleMap(panRuleMap, srcId, jobInstanceName);

		logger.info("Exit from SavePanRuleMappingTasklet");

		return RepeatStatus.FINISHED;
	}
	
	public void setCppRuleRecordService(CPPRuleRecordService cppRuleRecordService) {
		this.cppRuleRecordService = cppRuleRecordService;
	}

}
