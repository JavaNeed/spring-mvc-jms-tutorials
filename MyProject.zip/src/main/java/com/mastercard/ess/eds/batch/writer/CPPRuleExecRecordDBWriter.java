package com.mastercard.ess.eds.batch.writer;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.mastercard.ess.eds.core.service.CPPRuleRecordService;
import com.mastercard.ess.eds.core.util.DeDupeTokens;
import com.mastercard.ess.eds.domain.AuthDebitPanDetailRecord;

/**
 * It will take Auth and Debit related records contains PAN and CPPRule ID details and save them 
 * in EDS_SRC_RULE_DATA and EDS_SRC_DATA tables
 * */
public class CPPRuleExecRecordDBWriter implements ItemWriter<List<AuthDebitPanDetailRecord>> {


	private static Logger logger = Logger.getLogger(CPPRuleExecRecordDBWriter.class);

	@Autowired
	private CPPRuleRecordService cppRuleRecordService;

	@Value("#{jobParameters['edsSrcId']}")
	public String srcId;
	private String jobInstanceName;
	private BigDecimal jobInstanceId;

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}

	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}

	public BigDecimal getJobInstanceId() {
		return jobInstanceId;
	}

	// Added for JUnit
	public String getJobInstanceName(){
		return jobInstanceName;
	}

	public CPPRuleRecordService getCppRuleRecordService() {
		return cppRuleRecordService;
	}

	public void setCppRuleRecordService(CPPRuleRecordService cppRuleRecordService) {
		this.cppRuleRecordService = cppRuleRecordService;
	}

	public CPPRuleExecRecordDBWriter() {
		super();
	}
	// Added for JUnit
	public CPPRuleExecRecordDBWriter(CPPRuleRecordService cppRuleRecordService) {
		this.cppRuleRecordService=cppRuleRecordService;
	}
	private ExecutionContext executionContext;

	public ExecutionContext getExecutionContext() {
		return executionContext;
	}

	public void setExecutionContext(ExecutionContext executionContext) {
		this.executionContext = executionContext;
	}

	/*
	 * After process step data will be persisted in EDS_OWNER.EDS_SRC_DATA  and EDS_OWNER.eds_src_rule_data 
	 *  table in his method . Records come in form of List of object and stored in DB
	 */
	@Override
	public void write(List<? extends List<AuthDebitPanDetailRecord>> authDebitPanDetailRecords) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in CPPRuleExecRecordDBWriter method : write srcId is ="+srcId);
		}
		if(this.executionContext.get("edsSrcId")!=null)
		{
			srcId = this.executionContext.get("edsSrcId").toString();
		}
		ConcurrentHashMap<String, Set> panRuleMap = (ConcurrentHashMap<String, Set>)executionContext.get(DeDupeTokens.PAN_RULE_MAP.getDesc());
		if (authDebitPanDetailRecords !=null && authDebitPanDetailRecords.size()>0) {

			for (List<AuthDebitPanDetailRecord> authDebitlist : authDebitPanDetailRecords) {
				if (logger.isDebugEnabled()) {
					logger.debug("Enter in Second loop for Auth/Debit Records List Size is = "+authDebitlist.size()+" JobInstanceId is ="+jobInstanceId+" edsSrcId="+srcId);			
				}
				cppRuleRecordService.saveRecord(authDebitlist, jobInstanceName, srcId, jobInstanceId, panRuleMap);
			}
		}
		executionContext.put(DeDupeTokens.PAN_RULE_MAP.getDesc(), panRuleMap);
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from CPPRuleExecRecordDBWriter method : write "+" JobInstanceId is ="+jobInstanceId);
		}
	}

}
