package com.mastercard.ess.eds.core.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.domain.CIDInfo;


@Component
public class CidDAO {
	
	private static Logger logger = Logger.getLogger(CidDAO.class);

	private JdbcTemplate jdbcTemplate;
	
	private static String FETCH_CID_ICACODE = "SELECT ICA_CODE, MEMBER_ID AS CID, CAST(COUNTRY_CODE AS VARCHAR2(3)),"
			+ "CAST(BUSINESS_REGION_CODE AS VARCHAR2(2)), LEGAL_NAME FROM MBR_HIER, LCN_CUST "
			+ "where MEMBER_ID = MASTERCARD_ID(+) AND LEVEL_NUMBER = 20 and ICA_CODE is not null "
			+ "and MEMBER_ID is not null and (end_date is null or end_date > sysdate)";
	
	
	public CidDAO( @Autowired @Qualifier("rdsDataSource") DataSource datasource) {
		jdbcTemplate = new JdbcTemplate(datasource);
	}
	
	/**
	 *  this method fetch ICA_CODE , CID , BUSINESS_REGION_CODE and LEGAL_NAME from MBR_HIER
	 *  and LCN_CUST
	 */
	public TreeMap<String, CIDInfo> getCidCache() {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : getCidCache ");
		}
		
		TreeMap<String, CIDInfo> cidCache = new TreeMap<String, CIDInfo>();
		
		List<Map<String, Object>> listOfCid = jdbcTemplate.queryForList(FETCH_CID_ICACODE); 
		
		if (null != listOfCid && !listOfCid.isEmpty() ){
			
			for (Map<String, Object> row : listOfCid) {
				
				CIDInfo cidInfo = new CIDInfo();
				cidInfo.setCid((BigDecimal)row.get("CID"));
				cidInfo.setIcaCode((BigDecimal)row.get("ICA_CODE"));
				cidInfo.setCountryCode((String)row.get("COUNTRY_CODE"));
				cidInfo.setBusinessRegionCode((String)row.get("BUSINESS_REGION_CODE"));
				cidInfo.setLegalName((String)row.get("LEGAL_NAME"));
				
				cidCache.put(cidInfo.getIcaCode().toString(), cidInfo);
				
			}
			
		}
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : getCidCache ");
		}
		
		return cidCache;
		
	}

}
