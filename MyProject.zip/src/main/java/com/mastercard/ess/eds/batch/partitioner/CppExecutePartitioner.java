package com.mastercard.ess.eds.batch.partitioner;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.mastercard.ess.eds.core.service.EDSCPPRulesService;

/*It will fetch list of CPPRules from EDS_CPP_RULE table and according to countCPPRules we will create threads 
 *and will save cppRuleIds details in executionContext and these ruleIds will be used to fetch auth and debit related records from DB database.
 */

public class CppExecutePartitioner implements Partitioner{

	private static Logger logger = Logger.getLogger(CppExecutePartitioner.class);

	@Autowired
	private EDSCPPRulesService edsCPPRulesService;

	private String cppRunMode;

	@Value("${recordsPerPartitionsLimit}")
	private int recordsPerPartitionsLimit;

	public EDSCPPRulesService getEdsCPPRulesService() {
		return edsCPPRulesService;
	}

	public void setEdsCPPRulesService(EDSCPPRulesService edsCPPRulesService) {
		this.edsCPPRulesService = edsCPPRulesService;
	}

	public int getRecordsPerPartitionsLimit() {
		return recordsPerPartitionsLimit;
	}

	public void setRecordsPerPartitionsLimit(int recordsPerPartitionsLimit) {
		this.recordsPerPartitionsLimit = recordsPerPartitionsLimit;
	}


	public String getCppRunMode() {
		return cppRunMode;
	}

	public void setCppRunMode(String cppRunMode) {
		this.cppRunMode = cppRunMode;
	}



	@Override
	public Map<String, ExecutionContext> partition(int threadCount) {

		logger.info(" Enter in method partition : CppExecutePartitioner with threadCount =  "+threadCount + "CPP Run Mode = " + cppRunMode );
		Map<String, ExecutionContext> partitionMap = new LinkedHashMap<String, ExecutionContext>();
		int cppRuleIdCount = 0;

		List<Integer> cppRuleIds = edsCPPRulesService.getCPPRuleIds(cppRunMode);
		int recordNum=0;
		if ( null != cppRuleIds && 0< cppRuleIds.size() ) {
			logger.info( " Records found for EDSCPPRule List size is = " + cppRuleIdCount );
			recordNum = cppRuleIds.size();
		}

		if( 0 == recordNum ) {
			return partitionMap;
		}
		int partitionSize = 1; //can't initialize with 0 due to divide by zero exception
		int countAfterPartition ;
		int numberOfPartition;
		countAfterPartition = recordNum / threadCount;

		if ( countAfterPartition < recordsPerPartitionsLimit ) {

			numberOfPartition=threadCount;
			if ( countAfterPartition <= 2 ) {
				partitionSize = countAfterPartition + 1;
			}
			else {
				partitionSize = countAfterPartition;
			}
			if ( recordNum % threadCount != 0 ) {
				numberOfPartition = numberOfPartition + 1;
			}
		}
		else {
			partitionSize= recordsPerPartitionsLimit;
			numberOfPartition= recordNum/recordsPerPartitionsLimit;

			if (recordNum % partitionSize != 0) {
				numberOfPartition = numberOfPartition + 1;
			}
		}
		logger.info("threadCount is = "+threadCount+" numberOfPartition = "+ numberOfPartition+" partitionSize ="+ partitionSize+ " recordsPerPartitionsLimit = "+recordsPerPartitionsLimit);

		buildPartitionMap(partitionMap, cppRuleIds, recordNum, partitionSize,
				numberOfPartition);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method partition : CppExecutePartitioner ");
		}
		return partitionMap;
	}

	/**
	 * Method will build a Map according to partitionSize and numberOfPartition
     * @param partitionMap
	 * @param cppRuleIds
	 * @param recordNum
	 * @param partitionSize
	 * @param numberOfPartition
	 */
	private void buildPartitionMap(Map<String, ExecutionContext> partitionMap,List<Integer> cppRuleIds, int recordNum, int partitionSize,	int numberOfPartition) {

		int lastPanIndex = 0;
		for(int i = 1 ; i <= numberOfPartition ; i++){

			StringBuilder ruleIds = new StringBuilder("");
			int j;
			for(j = lastPanIndex ; j < recordNum && j <= lastPanIndex + partitionSize ; j++){

				if( j == lastPanIndex ){
					ruleIds.append("'").append( cppRuleIds.get(j) ).append("'");
				}else{
					ruleIds.append( ",").append("'").append( cppRuleIds.get(j) ).append("'");
				}
			}
			lastPanIndex = j;

			if ( StringUtils.isNotBlank( ruleIds.toString() ) ) {

				logger.info( " Partition = " + i+  " , IN QUERY IS =  "+ ruleIds );
				ExecutionContext executionContext = new ExecutionContext();
				executionContext.put( "cppRuleIds" , ruleIds );
				partitionMap.put(" Partition = " + i, executionContext );
			}
		}
	}

}
