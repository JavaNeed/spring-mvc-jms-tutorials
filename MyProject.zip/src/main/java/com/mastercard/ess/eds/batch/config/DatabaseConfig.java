package com.mastercard.ess.eds.batch.config;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import oracle.jdbc.pool.OracleDataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.mastercard.risk.common.userinfo.MCUserInfo;
import com.mastercard.risk.common.userinfo.MCUserInfoFactory;

@Configuration
@Component
@PropertySource("classpath:database.properties")
public class DatabaseConfig {

	private static Logger logger = Logger.getLogger(DatabaseConfig.class);

	@Value("${jdbc.url}")
	private String edsurl;
	 
	@Value("${jdbc.driverClassName}")
	private String className;
	
	@Value("${rds.jdbc.url}")
	private String rdsurl;
	
	@Value("${dw.jdbc.url1}")
	private String primaryDWUrl ;
	
	@Value("${dw.jdbc.url2}")
	private String secondaryDWUrl;
 
	@Value("${safe.jdbc.url}")
	private String safeurl;
	
	@Value("${eds.label}")
	private String edsLabel;
	
	@Value("${rds.label}")
	private String rdsLabel;
	
	@Value("${dw.label}")
	private String dwLabel;
	
	@Value("${safe.label}")
	private String safeLabel;
	
	@Value("${jdbc.minPoolSize}")
	private Integer minPoolSize;
	
	@Value("${jdbc.maxPoolSize}")
	private Integer maxPoolSize;
	
	private String MIN_LIMIT = "MinLimit";
	
	private String MAX_LIMIT = "MaxLimit";
	
	@Bean(name = "edsDataSource")
	public DataSource batchEDSDataSource() throws IOException {

		logger.info("Enter into BatchEDSDataSource method");
		
		OracleDataSource ds = null;
		MCUserInfoFactory userInfoFactory = new MCUserInfoFactory();
		try {
			MCUserInfo userInfo = userInfoFactory.getMCUserInfo(edsLabel);
			if (userInfo != null) {
				ds = getDataSource(userInfo, edsurl);
			}

		} catch (Exception e) {
			logger.error("Exception occured while initializing the EDS datatsource" + e);
			throw new IOException("Exception occured while initializing the EDS datatsource", e);
		}
		
		logger.info("Exit into BatchEDSDataSource method");
		
		return ds;
	}

	

	@Bean(name = "batchDataSource")
	@Primary
	public DataSource batchDataSource() throws IOException {

		logger.info("Enter into batchDataSource method");
		
		OracleDataSource ds = null;
		MCUserInfoFactory userInfoFactory = new MCUserInfoFactory();
		try {
			MCUserInfo userInfo = userInfoFactory.getMCUserInfo(edsLabel);
			if (userInfo != null) {
				ds = getDataSource(userInfo, edsurl);
			}

		} catch (Exception e) {
			logger.error("Exception occured while initializing the EDS Batch datatsource" + e);
			throw new IOException("Exception occured while initializing the EDS Batch datatsource", e);
		}
		
		logger.info("Exit into batchDataSource method");
		
		return ds;
	}
	
	@Bean(name = "rdsDataSource")
	public DataSource batchRDSDataSource() throws IOException {

		logger.info("Enter into batchRDSDataSource method");

		OracleDataSource ds = null;
		MCUserInfoFactory userInfoFactory = new MCUserInfoFactory();
		try {
			MCUserInfo userInfo = userInfoFactory.getMCUserInfo(rdsLabel);
			if (userInfo != null) {
				ds = getDataSource(userInfo, rdsurl);
			}

		} catch (Exception e) {
			logger.error("Exception occured while initializing the RDS datatsource" + e);
			throw new IOException("Exception occured while initializing the RDS datatsource", e);
		}
		 
		logger.info("Exit into batchRDSDataSource method");
		
		return ds;
	} 
	
	
	@Bean(name = "primaryDWDataSource")
	public DataSource primaryDWDataSource() throws IOException {

		logger.info("Enter into primaryDWDataSource method");

		OracleDataSource ds = null;
		MCUserInfoFactory userInfoFactory = new MCUserInfoFactory();
		try {
			MCUserInfo userInfo = userInfoFactory.getMCUserInfo(dwLabel);
			if (userInfo != null) {
				ds = getDataSource(userInfo, primaryDWUrl);
			}

		} catch (Exception e) {
			logger.error("Exception occured while initializing the Primary DW datatsource" + e);
			throw new IOException("Exception occured while initializing the Primary DW datatsource", e);
		}
		
		logger.info("Exit into primaryDWDataSource method");
		return ds;
	}
	
	@Bean(name = "secondaryDWDataSource")
	public DataSource secondaryDWDataSource() throws IOException {

		logger.info("Enter into secondaryDWDataSource method");

		OracleDataSource ds = null;
		MCUserInfoFactory userInfoFactory = new MCUserInfoFactory();
		try {
			MCUserInfo userInfo = userInfoFactory.getMCUserInfo(dwLabel);
			if (userInfo != null) {
				ds = getDataSource(userInfo, secondaryDWUrl);
			}

		} catch (Exception e) {
			logger.error("Exception occured while initializing the Secondary DW datatsource" + e);
			throw new IOException("Exception occured while initializing the Secondary DW datatsource", e);
		}
		logger.info("Exit into secondaryDWDataSource method");
		return ds;
	}
		
	@Bean(name = "safeDataSource")
	public DataSource batchSafeDataSource() throws IOException {

		logger.info("Enter into batchSafeDataSource method");

		OracleDataSource ds = null;
		MCUserInfoFactory userInfoFactory = new MCUserInfoFactory();
		try {
			MCUserInfo userInfo = userInfoFactory.getMCUserInfo(safeLabel);
			if (userInfo != null) {
				ds = getDataSource(userInfo, safeurl);
			}

		} catch (Exception e) {
			logger.error("Exception occured while initializing the Safe datatsource" + e);
			throw new IOException("Exception occured while initializing the Safe datatsource", e);
		}
		logger.info("Exit into batchSafeDataSource method");
		
		return ds;
	}

	private OracleDataSource getDataSource(MCUserInfo userInfo , String url)
			throws SQLException {
		OracleDataSource ds = new OracleDataSource();
		ds.setURL(url);
		ds.setUser(userInfo.getUserid());
		ds.setPassword(userInfo.getPassword());
		Properties properties = new Properties();
		properties.setProperty(MIN_LIMIT, minPoolSize.toString());
		properties.setProperty(MAX_LIMIT, maxPoolSize.toString());
		ds.setConnectionCacheProperties(properties);
		return ds;
	}
	
	public void setClassName(String className) {
		this.className = className;
	}
	
	public void setEdsLabel(String edsLabel) {
		this.edsLabel = edsLabel;
	}
	 
	public void setEdsurl(String edsurl) {
		this.edsurl = edsurl;
	}

	public void setMinPoolSize(Integer minPoolSize) {
		this.minPoolSize = minPoolSize;
	}

	public void setMaxPoolSize(Integer maxPoolSize) {
		this.maxPoolSize = maxPoolSize;
	}
}
