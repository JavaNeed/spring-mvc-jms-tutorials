package com.mastercard.ess.eds.core.parser;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.crypto.SecretKey;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.batch.item.file.transform.FieldSet;

import com.mastercard.ess.eds.domain.RawRecord;

/**
 * Class to parse Terbium payload data
 * @author E076119
 */
public class TerbiumParser implements EDSParser {

	private final String RAWDATASEPARATOR = "::";
	private static Logger logger = Logger.getLogger(EDSParser.class);

	/**
	 * @param fieldSet : fieldSet object containing the tokenized values
	 * @param key : key used to decrypt the encrypted value
	 * @param transform  : the algorithm for decryption
	 * @param fieldsToDecrypt : string which contains comma separated fields to be decrypted
	 * @return RawRecord
	 * @throws Exception 
	 */
	@Override
	public RawRecord parseAndDecrypt(FieldSet fieldSet, SecretKey key, String transform, String fieldsToDecrypt) throws Exception {
		logger.info("Enter TerbiumParser | parseAndDecrypt()");
		RawRecord rawRecord = new RawRecord(new HashMap<String, String>());
		rawRecord.addPayloadEntry(VendorPayloadTokens.CWID.getDesc(), fieldSet.readString(VendorPayloadTokens.CWID.getDesc()));
		rawRecord.addPayloadEntry(VendorPayloadTokens.URL.getDesc(), fieldSet.readString(VendorPayloadTokens.URL.getDesc()));

		Map<String,String> decryptedData = ParserUtil.decryptValues(fieldSet, key, transform, fieldsToDecrypt);
		String rawData = decryptedData.get(VendorPayloadTokens.VALUE.getDesc());
		if (null != rawData && rawData.contains(RAWDATASEPARATOR)) {

			rawRecord = mapRawData(rawData, rawRecord );
		} else {
			rawRecord.setRawPan(rawData);
		}
		logger.info("Exit TerbiumParser | parseAndDecrypt()");
		return rawRecord;
	}

	public RawRecord mapRawData(String rawData, RawRecord rawRecord) throws IOException{

		String[] rawDatas = rawData.split(RAWDATASEPARATOR);
		rawRecord.setRawPan(rawDatas[0]);
		String rawDataText = rawDatas[1].substring(1, rawDatas[1].length()-1);
		Map<String, String> rawDataTxtMap = new LinkedHashMap<String, String>();
		String[] indicators = rawDataText.split(",");
		for(String indicator : indicators){
			rawDataTxtMap.put(indicator, "Y");
		}
		try {
			rawRecord.addPayloadEntry(VendorPayloadTokens.RAW_DATA.getDesc() , new ObjectMapper().writeValueAsString(rawDataTxtMap));
		} catch (IOException e) {
			logger.error("Error while converting rawDataMap to string ", e);		
			throw new IOException(e.getMessage());
		}
		return rawRecord;
	}

}
