package com.mastercard.ess.eds.core.dao;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Component;
import static com.mastercard.ess.eds.constant.SQLConstants.*;
import static com.mastercard.ess.eds.constant.SQLQueries.*;

import com.mastercard.ess.eds.core.util.EDSProcessStatus;

/*
 * Dao that tracks customer file generation and delivery
 */

@Component
public class CustomerPanReportDao {

	private static Logger logger = Logger.getLogger(CustomerPanReportDao.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private DataSource dataSource;
	
	private SimpleJdbcInsert fileGenRptInsert;
	
	public CustomerPanReportDao(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemplate = new JdbcTemplate(dataSource);
		fileGenRptInsert = new SimpleJdbcInsert(dataSource).withTableName(EDS_GNRT_RPT).usingColumns(EDS_GNRT_RPT_ID, FILE_NAM, FILE_LOC_TXT, 
					STAT_CD, EDS_RPT_TYPE_ID, CRTE_USER_ID, CRTE_DT,JOB_INSTNCE_ID);
	}
	
	public int createGeneratedFileRecord(String fileName, BigDecimal jobInstanceId, String jobName, int reportType) {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : createGeneratedFileRecord ");
		}

		Path location = Paths.get(fileName).getParent();
		Path fileAbsoluteName = Paths.get(fileName).getFileName();
		
		int fileId = jdbcTemplate.queryForObject(EDS_GRNT_RPT_ID_SEQ, Integer.class);
		
		
		MapSqlParameterSource parameterSource = new MapSqlParameterSource();
		parameterSource.addValue(FILE_NAM, fileAbsoluteName.toString()).addValue(FILE_LOC_TXT, location.toString()).addValue(EDS_GNRT_RPT_ID, fileId)
				.addValue(STAT_CD, EDSProcessStatus.GENERATED.getStatusCode()).addValue(EDS_RPT_TYPE_ID, reportType)
				.addValue(CRTE_USER_ID, jobName).addValue(CRTE_DT, new Date()).addValue(JOB_INSTNCE_ID, jobInstanceId);
		
		int rowsUpdated = -1;
		
		try {
			rowsUpdated = fileGenRptInsert.execute(parameterSource); 
		} catch (DataAccessException e) {
			logger.error("DataAccessException while creating Generated file record" + e);
		}

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : createGeneratedFileRecord ");
		}
		
		return rowsUpdated;
	}
	
	public void updateCustomerFileStatus(String fileName, int status, String jobInstanceName) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : updateCustomerFileStatus ");
		}

		try {	
			jdbcTemplate.update(UPDATE_QUERY, status, jobInstanceName, new Date(), fileName);
		} catch (DataAccessException e) {
			logger.error("DataAccessException while creating Customer Pan report record" + e);
		}

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : updateCustomerFileStatus ");
		}
	}
	
	public Map<String, BigDecimal> fileToPKMap(List<String> files) {
		
		Map<String, BigDecimal> filePKMap = new HashMap<>();
		
		if(!files.isEmpty()) {
			String idList = files.toString();
			String csv = idList.substring(1, idList.length() - 1).replace(", ", "','");
			
			String sql = "Select FILE_NAM, EDS_GNRT_RPT_ID FROM EDS_GNRT_RPT where FILE_NAM IN ('" + csv + "')";
			
			logger.debug("generated sql = " + sql);
			
			List<Map<String, Object>> fileKeys = jdbcTemplate.queryForList(sql);
			if (null != fileKeys) {
				for (Map<String, Object> row : fileKeys) {
					filePKMap.put(((String) row.get("FILE_NAM")),
							((BigDecimal) row.get("EDS_GNRT_RPT_ID")));
				}
	
			}
		}
		return filePKMap;
	}

	public void updateCustomerFileStatusInBulk(String fileName, int statusCode,
			String jobInstanceName) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : updateCustomerFileStatusInBulk ");
		}
		try {	
			fileName = fileName.replace(",", "','");
			StringBuilder sqlBuilder=new StringBuilder("");
			sqlBuilder=sqlBuilder.append("UPDATE EDS_GNRT_RPT SET STAT_CD =  ").append(statusCode).append( ", LST_UPDT_USER_ID = '").append(jobInstanceName)
					.append("' , LST_UPDT_DT = SYSDATE where FILE_NAM IN ('" + fileName + "')");
			jdbcTemplate.update(sqlBuilder.toString());
		} catch (DataAccessException e) {
			logger.error("DataAccessException while updating Customer Pan report record" + e);
		}

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : updateCustomerFileStatusInBulk ");
		}
	}
	
	

}
