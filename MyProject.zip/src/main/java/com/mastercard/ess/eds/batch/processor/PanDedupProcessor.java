package com.mastercard.ess.eds.batch.processor;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.util.KnownPanCache;
import com.mastercard.ess.eds.domain.RawRecord;

@Component
public class PanDedupProcessor implements ItemProcessor<RawRecord, RawRecord> {

	
	private static Logger logger = Logger.getLogger(PanDedupProcessor.class);
	
	@Autowired
	private KnownPanCache panCache;

	@Override
	public RawRecord process(RawRecord rawRecord) {
		
		String provider = rawRecord.getProviderName();
		rawRecord.setRawPan(rawRecord.getRawPan().replace(" ", ""));
		String result = panCache.getResult(rawRecord.getRawPan());
		rawRecord.setCacheResult(result);
		
		//If pan is already sent or unsent pan exists which came from vendor, do not process this record

		if(null != result && ("SENT".equals(result) || "NOTSENTVENDOR".equals(result))) {
			
			logger.info("Filtering out current pan as found existing pan in prcss_data for src_data_ky = " + rawRecord.getSrc_data_ky() + ", result = " + result);
			 throw new ValidationException("duplicatePan");
		} else if (null != result && ("NOTSENTCPP".equals(result))) { //If existing Pan is from CPP try to process this
			
			if("CPP".equals(provider)) {   // If the current record's provider is CPP, do not bother to process
				logger.info("Filtering out current *CPP* pan as found existing pan in prcss_data for src_data_ky = " + rawRecord.getSrc_data_ky() + ", result = " + result);
				throw new ValidationException("duplicatePan");
			}
			
		} else if (null == result) {  //We have not seen this pan earlier, so update the cache and process further
			
			String thisResult = "";
			if(null != provider && "CPP".equals(provider)) {
				thisResult = "NOTSENTCPP";
			} else {
				thisResult = "NOTSENTVENDOR";
			}
			
			panCache.insert(rawRecord.getRawPan(), thisResult);
			rawRecord.setCacheResult(result);
			logger.info("Updated pan cache for src_data_ky = " + rawRecord.getSrc_data_ky());
		}
		
		return rawRecord;
	}

	public void setPanCache(KnownPanCache panCache) {
		this.panCache = panCache;
	}
	
}
