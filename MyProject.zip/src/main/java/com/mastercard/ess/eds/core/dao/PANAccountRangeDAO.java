package com.mastercard.ess.eds.core.dao;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.icatopanmapping.ICAAccountRange;
import com.mastercard.ess.eds.domain.PANAccountRange;



/**
 * This DAO class validates a PAN against a PAN range from MPS_AUTH_ACCT_RNG mview
 * @author e067588
 *
 */
@Component
public class PANAccountRangeDAO {

private static Logger logger = Logger.getLogger(PANAccountRangeDAO.class);

	private JdbcTemplate jdbcTemplate;
	
	private final static String FETCH_CNTRY_ACCT_GRPS_AND_CNTRY_CODES = "SELECT  mar.STRT_ACCT_RNG_NUM, mar.ENDNG_ACCT_RNG_NUM," +
	        " mar.BRND_PRDCT_CD, mpsMbr.NUM_CNTRY_CD, mar.STAT_CD, mpsMbr.MBR_ID, mar.PRDCT_CAT_CD, mar.AUTH_ACCT_RNG_ID" +
            " FROM MPS_AUTH_ACCT_RNG mar INNER JOIN MPS_MBR mpsMbr" +
            " on mar.MBR_ID = mpsMbr.MBR_ID";
	
	private final static String FETCH_ICA_TO_RANGE_MAPPING="SELECT mar.mbr_id AS MBR_ID, mar.strt_acct_rng_num AS START_ACT_RANGE, mar.endng_acct_rng_num AS END_ACT_RANGE FROM mps_auth_acct_rng mar WHERE mar.stat_cd = 'A'";
	
	/**
	 * Get all MPS_AUTH_ACCT_RNG and their corresponding issuerCntryCodes.S
	 * This query will be executed in different background thread.
	 * @return 
	 */
	
	public PANAccountRangeDAO(@Autowired @Qualifier("rdsDataSource")DataSource datasource) {		
		jdbcTemplate = new JdbcTemplate(datasource);		
	}
	
	/**
	 * Get all details of the range within which PAN lies
	 * @return
	 */
	public Map<PANAccountRange,PANAccountRange> getPANAccountRangeCache() {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : getAllCntrctActGrpsAndCntryCodes ");
		}

		//Map has object key to be able to search by MpsRange
		Map<PANAccountRange,PANAccountRange> countryCodeCache = new TreeMap<PANAccountRange, PANAccountRange>();


		
		
		logger.info("PANAccountRange query starts--"+System.currentTimeMillis());
		List<Map<String, Object>> listOfPANs = jdbcTemplate.queryForList(FETCH_CNTRY_ACCT_GRPS_AND_CNTRY_CODES); 
		logger.info("PANAccountRange query ends--"+System.currentTimeMillis());
		
		//No need to check for null because the DB columns are not nullable.
			if (null != listOfPANs && !listOfPANs.isEmpty() ){
			
			for (Map<String, Object> row : listOfPANs) {
			PANAccountRange range = new PANAccountRange((BigDecimal)row.get("STRT_ACCT_RNG_NUM"),(BigDecimal)row.get("ENDNG_ACCT_RNG_NUM"));
			range.setCountryCode((String)row.get("NUM_CNTRY_CD"));
			range.setMbrId((String)row.get("MBR_ID"));
			range.setPrdctCatCd((String)row.get("PRDCT_CAT_CD"));
			range.setStatus((String)row.get("STAT_CD"));
			range.setId(((BigDecimal) row.get("AUTH_ACCT_RNG_ID")).longValue());
			range.setBrandProductCode((String)row.get("BRND_PRDCT_CD"));
			
			if (countryCodeCache.put(range, range) != null){
				//logger.warn("Overlapping Account Range detected in MPS_MBR: " + range);
			}
		}    	
		
	}
			if (logger.isDebugEnabled()) {
				logger.debug("Exit from method : getAllCntrctActGrpsAndCntryCodes ");
			}
			return countryCodeCache;
		}
	
	/**
	 * Method will return Map of PANAccountRange contains ICA,StartRange and EndRange for stat_cd = 'A'
	 * @return
	 */
	public Map<String, Map<ICAAccountRange, ICAAccountRange>> getICAToRangeMapping() {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : getICAToRangeMapping ");
		}

		Map<String, Map<ICAAccountRange,ICAAccountRange>>  icaToRangeCache = new HashMap<String, Map<ICAAccountRange,ICAAccountRange>>();
		logger.info("ICAToRangeMapping query start time = "+System.currentTimeMillis());

		List<Map<String, Object>> icaToRangeMap =jdbcTemplate.queryForList(FETCH_ICA_TO_RANGE_MAPPING);

		for (Map<String, Object>  icaToRangeMapping : icaToRangeMap) {

			ICAAccountRange icaAccountRange = new ICAAccountRange();
			icaAccountRange.setEnd(((BigDecimal) icaToRangeMapping.get("END_ACT_RANGE")).toBigInteger());
			icaAccountRange.setStart(((BigDecimal) icaToRangeMapping.get("START_ACT_RANGE")).toBigInteger());
			icaAccountRange.setMbrId((String)icaToRangeMapping.get("MBR_ID"));

			String mbrId = (String) icaToRangeMapping.get("MBR_ID");

			if ( null != icaToRangeCache.get(mbrId)) {
				logger.debug("ICA = " +mbrId+" is already present in icaToRangeCache");
				Map<ICAAccountRange, ICAAccountRange> existingRangeCache = icaToRangeCache.get(mbrId);
				existingRangeCache.put(icaAccountRange, icaAccountRange);
			} else {
				Map<ICAAccountRange, ICAAccountRange> rangeMap = new HashMap<ICAAccountRange, ICAAccountRange>();
				logger.debug("We are going to add MbrId to cache for ICA first time: "+mbrId);
				rangeMap.put(icaAccountRange, icaAccountRange);
				icaToRangeCache.put(mbrId, rangeMap);
			}
		}
		
		logger.info("ICAToRangeMapping query end time = "+System.currentTimeMillis());


		if (null != icaToRangeCache && ! icaToRangeCache.isEmpty() ) {
			logger.info("IcaToRangeCache size = " + icaToRangeCache.size());
		}
		return icaToRangeCache;
	}
	}
