package com.mastercard.ess.eds.core.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.dao.CustomerMasterDAO;

/*
 * Service for handling Customer file tracking,
 * uses CustomerPanReportDao
 */
@Component
public class CustomerMasterService {

    @Autowired
    CustomerMasterDAO customerMasterDAO;

    public CustomerMasterService() {
        super();
    }

    public CustomerMasterService(CustomerMasterDAO customerMasterDAO) {
        super();
        this.customerMasterDAO = customerMasterDAO;
    }

    public Map<String, Object> getCustomerInfo(String ica) {
        return customerMasterDAO.getCustomerInfoFromICA(ica);
    }

    public List<Map<String, Object>> getEnrolledCustomerDetail() {
        return customerMasterDAO.getEnrolledCustomerDetail();
    }

    public List<Map<String, Object>> getUnEnrolledCustomerDetail() {
        return customerMasterDAO.getUnEnrolledCustomerDetail();
    }

    public List<Map<String, Object>> getActiveCustomerDetail() {
        return customerMasterDAO.getActiveCustomerDetail();
    }

    /**
     * 
     * @param ica
     * @param string
     */
    public void updateHistFlag(String ica, String histFlag) {
        customerMasterDAO.updateHistFlag(ica, histFlag);

    }

    /**
     * The method returns the notification subscribed list of emailIds for the day
     * @return
     */
    public Map<String, List<Integer>> getSubscribtionEmailWithICA() {

        return customerMasterDAO.getSubscribtionEmailWithICA();

    }

    public void updateHistoryFlagForIcas(List<String> icas, String historyFlag, String jobInstanceName) {
        customerMasterDAO.updateHistoryFlagForIcas(icas, historyFlag, jobInstanceName);
    }

    // for junit

    public void setCustomerMasterDAO(CustomerMasterDAO customerMasterDAO) {
        this.customerMasterDAO = customerMasterDAO;
    }
}
