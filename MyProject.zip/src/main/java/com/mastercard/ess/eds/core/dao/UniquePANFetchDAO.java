package com.mastercard.ess.eds.core.dao;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class UniquePANFetchDAO {

	private Logger logger = Logger.getLogger(UniquePANFetchDAO.class);
	private JdbcTemplate jdbcTemplate;
	
	private static final String UNIQUE_PAN_SQL = "SELECT  ISSR_CNTRY_CD || '_' || TRAN_CHNL_CD AS CNTRY_TRAN_CD, sum(UNQ_PAN_CNT) as UNQ_PAN_CNT FROM EDS_CPP_TRAN_SUMM "+
												"WHERE GRP_ID = ? and TRAN_CHNL_CD in ('CP', 'CNP')  GROUP BY ISSR_CNTRY_CD || '_' || TRAN_CHNL_CD ";
	  
	public UniquePANFetchDAO(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public void truncate() {

		final String truncateSql = "DELETE FROM EDS_CPP_TRAN_TEMP";
		int rows = jdbcTemplate.update(truncateSql);
		logger.info("EDS_CPP_TRAN_TEMP truncated. Total number of rows deleted -" + rows);

	}
	
	 public Map<String, String> fetchPANCountByCountryAndChannel(BigDecimal groupType)
	  {
	    Map<String, String> groupCount = new HashMap<>();
	    List<Map<String, Object>> groupList = this.jdbcTemplate.queryForList(UNIQUE_PAN_SQL, new Object[] { groupType });
	    if ((groupList != null) && (!groupList.isEmpty())) {
	      for (Map<String, Object> uniquePan : groupList)
	      {
	        String countryChannel = String.valueOf(uniquePan.get("CNTRY_TRAN_CD"));
	        String count = String.valueOf(uniquePan.get("UNQ_PAN_CNT"));
	        groupCount.put(countryChannel, count);
	      }
	    }
	    return groupCount;
	  }

}
