package com.mastercard.ess.eds.batch.partitioner;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.service.CPPReportService;

public class CppDetailReportGenerationPartitioner implements Partitioner {

	@Autowired
	CPPReportService cppReportService;

	@SuppressWarnings("unused")
	private Logger logger = Logger.getLogger(CppDetailReportGenerationPartitioner.class);

	public CppDetailReportGenerationPartitioner() {
		super();
	}

	@Override
	public Map<String, ExecutionContext> partition(int arg0) {

		int i = 0;
		List<String> countrycodes = cppReportService.getListOfMerchantCountries();

		Map<String, ExecutionContext> partitionMap = new HashMap<String, ExecutionContext>();

		for (String merchCntryCode : countrycodes) {
			ExecutionContext ctxMap = new ExecutionContext();
			ctxMap.putString("merch_cntry_cd", merchCntryCode);
			partitionMap.put("CPPDetailReportGenerationThread -" + i, ctxMap);
			++i;
		}
		return partitionMap;
	}

	public void setCppDetailReportService(CPPReportService cPPReportService2) {
		this.cppReportService = cPPReportService2;
		
		
	}

}
