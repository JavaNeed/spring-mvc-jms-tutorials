package com.mastercard.ess.eds.billing.util;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.billing.dao.BillDataDAO;
import com.mastercard.ess.eds.billing.vo.FileItemVO;
import com.mastercard.ess.eds.domain.FileDetails;

/**
 * This class will update renewal date while execution of billing job.
 * @author e075766
 *
 */
@Component
public class RenewalDateUtil {

	@Autowired
	public FileItemVO fileItemVO;

	@Autowired
	public BillDataDAO billDataDao;

	@Autowired
	public CSVWriterUtils csvWriterUtils;

	@Value("${billingfiles.directory}")
	public String location;

	@Value("${billing.trialPeriodInMonths}")
	public int trialPeriod;

	public BigDecimal jobInstanceId;
	public ExecutionContext executionContext;
	public String jobInstanceName;
	public List<FileDetails> fileStatusList = new ArrayList<FileDetails>() ;

	private static final String CRTE_USER_ID = "CRTE_USER_ID";

	private static final String ICA_NUM = "ICA_NUM";

	private static final String RNWL_DT = "RNWL_DT";

	private static final String CRTE_DT = "CRTE_DT";

	private static final String CUST_MASS_ONBOARDING = "custMassOnboarding";

	private static Logger logger = Logger.getLogger(RenewalDateUtil.class);


	public RenewalDateUtil() {
		
	}
	
	// For Junit
		public RenewalDateUtil(String location, BillDataDAO billDataDao, FileItemVO fileItemVO ) {
			this.location = location;
			this.billDataDao  = billDataDao;
			this.fileItemVO = fileItemVO;
		}

	/**
	 * In updateRenewalDate we will update renewable date as below:
	 * A)If createUsetId is 'custMassOnboarding' 
	 * 1)If renewalDate is null     : Then renewabledate will be ( createDate + trial period (2 months) ) 
	 * 2)If renewalDate is not null : Then renewabledate will be ( renewabledate + 365 ) 
	 * 
	 * B)If createUsetId  is not 'custMassOnboarding'
	 * 1)If renewalDate is null     : Then renewabledate will be ( createDate + 365 )   
	 * 2)If renewalDate is not null : Then renewabledate will be ( renewabledate + 365 )   
	 * 
	 * @param childParentMapList
	 * @param jobName
	 */
	public void updateRenewalDate( List<Map<String, Object>> childParentMapList , String jobName ) {

		if(childParentMapList!= null) {

			logger.info(" UpdateRenewalDateUtil | updateRenewalDate | updateRenewalDate starts ");

			for (Map<String, Object> m : childParentMapList) {

				Date createDate = (Date) m.get(CRTE_DT);	
				Date renewalDate = (Date) m.get(RNWL_DT);
				BigDecimal ica = (BigDecimal) m.get(ICA_NUM);
				String createUsetId = (String) m.get(CRTE_USER_ID);

				if (renewalDate == null) {

					logger.info("csvWriterUtils | updateRenewalDate | renewal date is null ");
					Calendar updatedRenewalDate = Calendar.getInstance();
					updatedRenewalDate.setTime(createDate);

					logger.info(" CREATEUSERID = " + createUsetId + " For ICA = " + ica + " trialPeriod = " + trialPeriod );

					if (StringUtils.isNotEmpty( createUsetId) && CUST_MASS_ONBOARDING.equalsIgnoreCase(createUsetId) ) {

						updatedRenewalDate.add(Calendar.MONTH, trialPeriod );
					}
					else {

						updatedRenewalDate.add(Calendar.DAY_OF_MONTH, 365);
					}

					billDataDao.updateRenewalDate(updatedRenewalDate, ica , jobName);
				}
				else {
					logger.info("csvWriterUtils | updateRenewalDate | renewal date is not null ");
					Calendar updatedRenewalDate = Calendar.getInstance();
					updatedRenewalDate.setTime(renewalDate);
					updatedRenewalDate.add(Calendar.DAY_OF_MONTH, 365);

					billDataDao.updateRenewalDate(updatedRenewalDate, ica , jobName );
				}
			}
			logger.info("UpdateRenewalDateUtil | updateRenewalDate | updateRenewalDate Ends");

		}


	}
}