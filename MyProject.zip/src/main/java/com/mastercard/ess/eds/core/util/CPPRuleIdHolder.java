package com.mastercard.ess.eds.core.util;


public class CPPRuleIdHolder {
	
	Long cppRuleId;
	
	Long srcDataKey;
	
	String categoryCode;
	
	public Long getCppRuleId() {
		return cppRuleId;
	}
	public void setCppRuleId(Long cppRuleId) {
		this.cppRuleId = cppRuleId;
	}
	public String getCategoryCode() {
		return categoryCode;
	}
	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}
	public Long getSrcDataKey() {
		return srcDataKey;
	}
	public void setSrcDataKey(Long srcDataKey) {
		this.srcDataKey = srcDataKey;
	}
	

}
