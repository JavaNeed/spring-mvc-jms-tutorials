package com.mastercard.ess.eds.batch.processor;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;

import com.mastercard.ess.eds.domain.EDSRecord;

/**
 * This ItemProcessor defines an interface to accept and return a edsRecord only.
 * @author e067588
 *
 */
public class RawRecordToEDSRecordTransformProcessor implements ItemProcessor<EDSRecord,EDSRecord> {

	private static Logger logger = Logger.getLogger(RawRecordToEDSRecordTransformProcessor.class);
	
	/* (non-Javadoc)
	 * @see org.springframework.batch.item.ItemProcessor#process(java.lang.Object)
	 */
	@Override
	public EDSRecord process(EDSRecord edsRecord) {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : process ");
		}
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : process ");
		}
		
		return edsRecord;
	}
	

}
