package com.mastercard.ess.eds.core.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.dao.CPPSimulationDataDAO;
import com.mastercard.ess.eds.core.dao.CPPSimulationSourceDAO;
import com.mastercard.ess.eds.core.dao.EDSCPPRulesDao;
import com.mastercard.ess.eds.core.dao.LocationDAO;
import com.mastercard.ess.eds.domain.CPPRuleRecord;

/**
 *  This service class calls the DAO method for CRUD operation for EDS_CPP_SIM_SRC and EDS_CPP_SIM_DATA tables.
 * @author e070836
 * @version 1.0
 * @date : Dec 29, 2017
 */

@Component
public class CPPSimulationService {

	private static Logger logger = Logger.getLogger(CPPSimulationService.class);

	public static final String P = "P";
	
	@Autowired
	private CPPSimulationSourceDAO cppSimulationSourceDAO;

	@Autowired
	private CPPSimulationDataDAO cppSimulationDataDAO;
	
	@Autowired
	private EDSCPPRulesDao edscppRulesDao;
	
	@Autowired
	private LocationDAO locationDAO;
	
	public CPPSimulationService() {
		super();
	}

	public CPPSimulationService(CPPSimulationSourceDAO cppSimulationSourceDAO , CPPSimulationDataDAO cppSimulationDataDAO) {
		super();
		this.cppSimulationSourceDAO = cppSimulationSourceDAO ;
		this.cppSimulationDataDAO = cppSimulationDataDAO ;
	}

	/**
	 *  This method calls the DAO method to create the simulation source in EDS_CPP_SIM_SRC table.
	 * @param fileName
	 * @param jobName
	 * @param jobInstanceID
	 * @param status
	 * @return
	 */
	public String createSimulationSource(String fileName, String jobName, BigDecimal jobInstanceID, int status) {
		return cppSimulationSourceDAO.createSimulationSource(fileName, jobName, jobInstanceID, status);
	}

	/**
	 *  This method calls the DAO method to store the simulation results in EDS_CPP_SIM_DATA table.
	 * @param simulationMapCount
	 * @param jobInstanceId
	 * @param jobInstanceName
	 * @param simSrcId
	 */
	public void saveSimulationResults(Map<String, Integer> simulationMapCount, BigDecimal jobInstanceId, String jobInstanceName, String simSrcId) {
		logger.info("Enter into the method CPPSimulationService:saveSimulationResults with  source Id ="+simSrcId);
		
		Set<String> simulationSet = simulationMapCount.keySet();
		
		for (String cppRuleId : simulationSet) {
			if(StringUtils.isNotBlank(cppRuleId)){		
				CPPRuleRecord cppRuleRecord = edscppRulesDao.getCPPRulesByRuleId(P,Integer.valueOf(cppRuleId));
				int locationId = cppRuleRecord.getValMerchant();
				String merchantName  = locationDAO.getMerchantNameByLocationId(locationId);
				if(StringUtils.isBlank(merchantName)){
					merchantName = "UNKNOWN MERCHANT";
				}
				cppSimulationDataDAO.saveSimulationData(merchantName,cppRuleId, simulationMapCount.get(cppRuleId), jobInstanceName , jobInstanceId ,simSrcId);
			}
		}
		
		logger.info("Exit from the method CPPSimulationService:saveSimulationResults");		
	}
	
	/**
	 *  This method fetch the simulation record from EDS_CPP_SIM_DATA table.
	 * @param simSrcId 
	 *  @return List<CPPRuleRecord>
	 */
	public List<CPPRuleRecord> fetchSimulationResults(String simSrcId){
		return cppSimulationDataDAO.fetchSimulationReport(simSrcId) ;
	}

	/**
	 *  This method updates the status in EDS_CPP_SIM_SRC table.
	 * @param cppSrcName
	 * @param jobInstanceName
	 * @param status
	 */
	public void updateSimulationSourcePostProcessing(String cppSrcName , String jobInstanceName,
			int status) {
		cppSimulationSourceDAO.updateSimulationSourcePostProcessing(cppSrcName ,jobInstanceName, status);
		
	}
	
	public String getSimulationSrcId(String srcName) {
		return cppSimulationSourceDAO.getSimulationSrcId(srcName);
	}
	
	/**
	 *  This method deletes the CPP simulation data from EDS_CPP_SIM_DATA tables.
	*/
	
	public void truncateCPPSimulationData() {
		cppSimulationDataDAO.truncateCPPSimulationData();
		
	}
	
	public void setCppSimulationSourceDAO(
			CPPSimulationSourceDAO cppSimulationSourceDAO) {
		this.cppSimulationSourceDAO = cppSimulationSourceDAO;
	}

	public void setCppSimulationDataDAO(CPPSimulationDataDAO cppSimulationDataDAO) {
		this.cppSimulationDataDAO = cppSimulationDataDAO;
	}

	public void setLocationDAO(LocationDAO locationDAO) {
		this.locationDAO = locationDAO;
	}
	
	public void setEdscppRulesDao(EDSCPPRulesDao edscppRulesDao) {
		this.edscppRulesDao = edscppRulesDao;
	}
}
