package com.mastercard.ess.eds.core.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.domain.PANAccountRange;

@Component
public class DAAcctRangeDAO {

	private static Logger logger = Logger.getLogger(DAAcctRangeDAO.class);

	private JdbcTemplate jdbcTemplate;

	private static String FETCH_RTN_AND_CNTRY_CODES = "SELECT FROM_RANGE, TO_RANGE, CARD_BIN_LEN,"
			+ "COUNTRY_CODE,MEMBER_ID FROM DA_MBR_HIER where END_DATE IS NULL and LEVEL_NUMBER = 30"
			+ "and FROM_RANGE is not null and TO_RANGE is not null order by FROM_RANGE, TO_RANGE DESC";

	public DAAcctRangeDAO(@Autowired @Qualifier("edsDataSource") DataSource datasource) {
		jdbcTemplate = new JdbcTemplate(datasource);
	}

	/**
	 * Get all details of the range within which PAN lies
	 * COUNTRY_CODE , RTN_ID fetched from DA_MBR_HIER
	 * @return
	 */
	public TreeMap<PANAccountRange, PANAccountRange> getRtnCache() {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : getRtnCache ");
		}

		TreeMap<PANAccountRange, PANAccountRange> rtnCache = new TreeMap<PANAccountRange, PANAccountRange>();

		List<Map<String, Object>> listOfPANs = jdbcTemplate
				.queryForList(FETCH_RTN_AND_CNTRY_CODES);

		if (null != listOfPANs && !listOfPANs.isEmpty()) {

			for (Map<String, Object> row : listOfPANs) {
				PANAccountRange range = new PANAccountRange(
						(BigDecimal) row.get("FROM_RANGE"),
						(BigDecimal) row.get("TO_RANGE"));
				range.setBinLength(((BigDecimal) row.get("CARD_BIN_LEN")).intValue());
				range.setCountryCode((String) row.get("COUNTRY_CODE"));
				range.setMbrId(((BigDecimal) row.get("MEMBER_ID")).toString().substring(1));
				
				rtnCache.put(range, range);
			}

		}
		return rtnCache;
	}

}
