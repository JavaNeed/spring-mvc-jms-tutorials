package com.mastercard.ess.eds.core.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.batch.exception.EDSCoreException;
import com.mastercard.ess.eds.core.dao.FraudReportDao;
import com.mastercard.ess.eds.domain.FraudReportRecord;

@Component
public class FraudReportService {

	private static Logger logger = Logger.getLogger(FraudReportService.class);

	@Autowired
	private FraudReportDao fraudReportDao;

	// for JUnit test
	public FraudReportService(FraudReportDao fraudReportDao) {
		super();
		this.fraudReportDao = fraudReportDao;
	}

	public Map<String, String> getBeforeCountSubscribedICA() {
		Map<String, String> beforeCountMap = new HashMap<>();
		List<Map<String, Object>> beforeCountMaps = fraudReportDao.getBeforeCountSubscribedICA();

		if (beforeCountMaps != null && !beforeCountMaps.isEmpty()) {

			for (Map<String, Object> beforeCount : beforeCountMaps) {
				String month = String.valueOf(beforeCount.get("create_date"));
				String count = String.valueOf(beforeCount.get("subscribed_count"));
				beforeCountMap.put(month, count);
			}
		}

		return beforeCountMap;
	}

	public Map<String, String> getBeforeCountunSubscribedICA() {
		Map<String, String> beforeCountMap = new HashMap<>();
		List<Map<String, Object>> beforeCountMaps = fraudReportDao
				.getBeforeCountUnSubscribedICA();

		if (beforeCountMaps != null && !beforeCountMaps.isEmpty()) {

			for (Map<String, Object> beforeCount : beforeCountMaps) {
				String month = String.valueOf(beforeCount.get("create_date"));
				String count = String.valueOf(beforeCount.get("unsubscribed_count"));
				beforeCountMap.put(month, count);
			}
		}

		return beforeCountMap;
	}

	public Map<String, Integer> getAfterCountSubscribedICA() throws EDSCoreException {
		return fraudReportDao.getAfterCountSubscribedICA();
	}

	public Map<String, Integer> getAfterCountUnSubscribedICA() throws EDSCoreException {
		return fraudReportDao.getAfterCountUnSubscribedICA();
	}

	public List<FraudReportRecord> wrapFraudReport(
			Map<String, String> beforeSubsFraudCt,
			Map<String, String> beforeUnSubsFraudCt,
			Map<String, Integer> afterSubsFraudCt,
			Map<String, Integer> afterUnSubsFraudCt) {
		logger.debug("Enter into wrapFraudReport method");
		List<FraudReportRecord> fraudReportRecords = new ArrayList<>();

		populateBeforeSubscribedCount(fraudReportRecords, beforeSubsFraudCt);
		populateBeforeUnsubscribedCount(fraudReportRecords, beforeUnSubsFraudCt);
		populateAfterSubscribedCount(fraudReportRecords, afterSubsFraudCt);
		populateAfterUnsubscribedCount(fraudReportRecords, afterUnSubsFraudCt);
		logger.debug("Exit into wrapFraudReport method");
		return fraudReportRecords;
	}

	private void populateBeforeSubscribedCount(
			List<FraudReportRecord> fraudReportRecords,
			Map<String, String> beforeSubsFraudCt) {

		if (!beforeSubsFraudCt.isEmpty()) {
			buildBeforeSubscribedCount(fraudReportRecords, beforeSubsFraudCt);
		}

	}

	private void populateBeforeUnsubscribedCount(
			List<FraudReportRecord> fraudReportRecords,
			Map<String, String> beforeUnSubsFraudCt) {

		if (!beforeUnSubsFraudCt.isEmpty()) {
			buildBeforeUnsubscribedCount(fraudReportRecords,
					beforeUnSubsFraudCt);
		}

	}

	private void populateAfterSubscribedCount(
			List<FraudReportRecord> fraudReportRecords,
			Map<String, Integer> afterSubsFraudCt) {

		if (!afterSubsFraudCt.isEmpty()) {
			buildAfterSubscribedCount(fraudReportRecords, afterSubsFraudCt);
		}

	}

	private void populateAfterUnsubscribedCount(
			List<FraudReportRecord> fraudReportRecords,
			Map<String, Integer> afterUnSubsFraudCt) {

		if (!afterUnSubsFraudCt.isEmpty()) {
			buildAfterUnSubscribedCount(fraudReportRecords, afterUnSubsFraudCt);
		}

	}

	private void buildBeforeSubscribedCount(
			List<FraudReportRecord> fraudReportRecords,
			Map<String, String> beforeSubsFraudCt) {

		List<String> beforeMonths = new ArrayList<>(beforeSubsFraudCt.keySet());
		for (String beforeMonth : beforeMonths) {
			boolean beforeFraudFound = false;
			for (FraudReportRecord fraudReportRecord : fraudReportRecords) {
				if (fraudReportRecord.getMonth().equalsIgnoreCase(beforeMonth)) {
					beforeFraudFound = true;
					fraudReportRecord.setSubscribedBeforeCt(Integer.valueOf(beforeSubsFraudCt.get(beforeMonth)));
					break;
				}
			}

			if (!beforeFraudFound) {
				FraudReportRecord fraudReportRecord = new FraudReportRecord();
				fraudReportRecord.setMonth(beforeMonth);
				fraudReportRecord.setSubscribedBeforeCt(Integer.valueOf(beforeSubsFraudCt.get(beforeMonth)));
				fraudReportRecords.add(fraudReportRecord);
			}
		}

	}

	private void buildBeforeUnsubscribedCount(
			List<FraudReportRecord> fraudReportRecords,
			Map<String, String> beforeUnSubsFraudCt) {

		
		List<String> beforeMonths = new ArrayList<>(beforeUnSubsFraudCt.keySet());
		for (String beforeMonth : beforeMonths) {
			boolean beforeFraudFound = false;
			for (FraudReportRecord fraudReportRecord : fraudReportRecords) {
				if (fraudReportRecord.getMonth().equalsIgnoreCase(beforeMonth)) {
					beforeFraudFound = true;
					fraudReportRecord.setUnsubscribedBeforeCt(Integer.valueOf(beforeUnSubsFraudCt.get(beforeMonth)));
					break;
				}
			}

			if (!beforeFraudFound) {
				FraudReportRecord fraudReportRecord = new FraudReportRecord();
				fraudReportRecord.setMonth(beforeMonth);
				fraudReportRecord.setUnsubscribedBeforeCt(Integer.valueOf(beforeUnSubsFraudCt.get(beforeMonth)));
				fraudReportRecords.add(fraudReportRecord);
			}
		}

	}

	private void buildAfterSubscribedCount(
			List<FraudReportRecord> fraudReportRecords,
			Map<String, Integer> afterSubsFraudCt) {
		
		List<String> afterMonths = new ArrayList<>(afterSubsFraudCt.keySet());
		for (String afterMonth : afterMonths) {
			boolean afterFraudFound = false;
			for (FraudReportRecord fraudReportRecord : fraudReportRecords) {
				if (fraudReportRecord.getMonth().equalsIgnoreCase(afterMonth)) {
					afterFraudFound = true;
					fraudReportRecord.setSubscribedAfterCt(afterSubsFraudCt.get(afterMonth));
					break;
				}
			}

			if (!afterFraudFound) {
				FraudReportRecord fraudReportRecord = new FraudReportRecord();
				fraudReportRecord.setMonth(afterMonth);
				fraudReportRecord.setSubscribedAfterCt(afterSubsFraudCt.get(afterMonth));
				fraudReportRecords.add(fraudReportRecord);
			}
		}

	}

	private void buildAfterUnSubscribedCount(
			List<FraudReportRecord> fraudReportRecords,
			Map<String, Integer> afterUnSubsFraudCt) {
		
		List<String> afterMonths = new ArrayList<>(
				afterUnSubsFraudCt.keySet());
		for (String afterMonth : afterMonths) {
			boolean afterFraudFound = false;
			for (FraudReportRecord fraudReportRecord : fraudReportRecords) {
				if (fraudReportRecord.getMonth().equalsIgnoreCase(afterMonth)) {
					afterFraudFound = true;
					fraudReportRecord.setUnsubscribedAfterCt(afterUnSubsFraudCt.get(afterMonth));
					break;
				}
			}

			if (!afterFraudFound) {
				FraudReportRecord fraudReportRecord = new FraudReportRecord();
				fraudReportRecord.setMonth(afterMonth);
				fraudReportRecord.setUnsubscribedAfterCt(afterUnSubsFraudCt.get(afterMonth));
				fraudReportRecords.add(fraudReportRecord);
			}
		}

	}
	
	//for junit
	public void setFraudReportDao(FraudReportDao fraudReportDao) {
		this.fraudReportDao = fraudReportDao;
	}


}
