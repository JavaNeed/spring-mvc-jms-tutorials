package com.mastercard.ess.eds.core.dao;

import java.math.BigDecimal;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Component;

/**
 *  this class is responsible to check a pan reported by eds
 *         is already notified in ADC or not
 */
@Component
public class ADCNotificationDao {

	
	private static Logger logger = Logger.getLogger(ADCNotificationDao.class);

	private JdbcTemplate jdbcTemplate;

	public ADCNotificationDao( @Autowired @Qualifier("safeDataSource") DataSource datasource) {
		jdbcTemplate = new JdbcTemplate(datasource);
	}

	/**
	 * Checks if specific pan is notified by in ADC or not if notified returns
	 * true
	 */
	public String isAccountADCNotified(BigDecimal pan) {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : isAccountADCNotified ");
		}
		
		String sql = "select case when exists (select 1 from ADC_OWNER.CMPRMS_ACCT where PAN_NUM = ?) then 'Y' else 'N' end from dual" ;
		
		String isAccountADCNotified = jdbcTemplate.queryForObject(sql,String.class,pan.toString());

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : isAccountADCNotified ");
		}
		
		return isAccountADCNotified;
	}

	 

}
