package com.mastercard.ess.eds.billing.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.billing.dao.BillDataDAO;

@Component
public class BillingService {

    private static final String CRTE_USER_ID = "CRTE_USER_ID";
    private static final String CRTE_DT = "CRTE_DT";
    private static final String CUST_MASS_ONBOARDING = "custMassOnboarding";

    @Value("${billing.trialPeriodInMonths}")
    private int trialPeriod;

    @Autowired
    private BillDataDAO billDataDao;

    /**
     * @return boolean
     * This method checks if ICA is in trial period or not - for mass onboarded ICAs only.
     */
    public boolean icaIsInTrailPeriod(long ica_num) {
        boolean inTrialPeriod = false;
        List<Map<String, Object>> icaList = billDataDao.getICADetailsFromIcaNum(ica_num);

        if (icaList != null && icaList.size() > 0) {

            Map<String, Object> m = icaList.get(0);
            Date createDate = (Date) m.get(CRTE_DT);
            String createUserId = (String) m.get(CRTE_USER_ID);

            if (StringUtils.isNotEmpty(createUserId) && CUST_MASS_ONBOARDING.equalsIgnoreCase(createUserId)) {
                Calendar cal = Calendar.getInstance();
                cal.setTime(createDate);
                cal.add(Calendar.MONTH, trialPeriod);

                if (new Date().compareTo(cal.getTime()) > 0) {
                    return inTrialPeriod;
                } else {
                    inTrialPeriod = true;
                }
            } else {
                return inTrialPeriod;
            }
        }

        return inTrialPeriod;
    }
}
