package com.mastercard.ess.eds.core.util;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.log4j.Logger;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
public class UniqueFileNameFetcherUtils {
	
	private static Logger logger = Logger.getLogger(UniqueFileNameFetcherUtils.class);
	
	private BlockingQueue<String> numbersQueue;
	
	private int size;
	
	private int count = 1;
	
	private AtomicBoolean refill =  new AtomicBoolean(false); 

	public void initQueue() {
		logger.info("numberOfFiles = " + size );
		numbersQueue = new ArrayBlockingQueue<>(size);
		fillQueue(size);
	}

	@Async
	public void fillQueue(int size) {
		numbersQueue = new ArrayBlockingQueue<>(size);
		for (int i = 0 ; i < size ; i++){
			if(!numbersQueue.offer(String.format("%03d", count))){
				break ;
			}
			
			count = (++count > 999) ? 1 : count ;
		}
	}
	
	public String getRandomFileId(){
		String element = null ;
		if(numbersQueue.size() > 0 ){
			element = numbersQueue.poll();
		}  
		
		if(numbersQueue.size() < 100 && refill.compareAndSet(false, true)){
			fillQueue(size - numbersQueue.size());
			refill.set(false);		
		}
		logger.info("Random Id element" + element);
		return  element;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}
	

	public BlockingQueue<String> getNumbersQueue() {
		return numbersQueue;
	}

	public void setNumbersQueue(BlockingQueue<String> numbersQueue) {
		this.numbersQueue = numbersQueue;
	}


}
