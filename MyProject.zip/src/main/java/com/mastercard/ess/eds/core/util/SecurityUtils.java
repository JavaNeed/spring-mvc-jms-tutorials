
package com.mastercard.ess.eds.core.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.google.common.io.BaseEncoding;
import com.mastercard.ess.eds.common.SplunkEvent;
import com.mastercard.ess.eds.common.SplunkEventLogger;
import com.mastercard.risk.common.userinfo.InvalidException;

@Component
public class SecurityUtils {

	private static final String PKCS11 = "PKCS11";

	private static final String AES = "AES";

	private static final String JKS = "JKS";

	private static Logger logger = Logger.getLogger(SecurityUtils.class);

	@Value("${cryptovault.label}")
	private String cryptovaultLabel;

	@Value("${keystore.alias}")
	private String keyStoreAlias;

	@Value("${prodbatch.keypath}")
	private String prodBatchKeyPath;

	@Value("${prodkey.pass}")
	private String prodKeyPass;

	@Value("${prodkey.name}")
	private String prodKeyName;

	private static final String CRYPTOVAULTCOMMAND = "mcgetpw -label ";

	@Autowired
	private EnvironmentUtil envUtil;
	private static final String TRANSFORM = "RSA/ECB/PKCS1Padding";

	private static final String PROD = "prod";
	private static final String DEV = "dev";

	private static Provider provider = null;
	private Cipher keyUnwrapCipher = null;

	public EnvironmentUtil getEnvUtil() {
		return envUtil;
	}
	/**
	 * @param wrappedSessionKey
	 *            : content of key file is wrappedSessionKey used to encrypt the
	 *            value in csv
	 * @return : This method returns SecretKey to decrypt the encrypted data in
	 *         input csv file
	 */
	public SecretKey getSessionKey(String wrappedSessionKey) {

		logger.info("Enter in method : getSessionKey ");

		SecretKey secretKey;
		try {
			Key key = getKey();
			keyUnwrapCipher.init(Cipher.UNWRAP_MODE,
					key);

			logger.info("keyUnwrapCipher initialized ");
			//logger.info("wrappedSessionKey - " + wrappedSessionKey);
			secretKey = (SecretKey) keyUnwrapCipher
					.unwrap(BaseEncoding.base64().decode(wrappedSessionKey),
							AES, Cipher.SECRET_KEY);

			logger.info("secretKey decoded ");

			return secretKey;
		} catch (Exception e) {
			Map<String, String> splunkLogError = new HashMap<String, String>();
			splunkLogError.put("exception", e.getMessage());
			logger.error("exception in obtaining session ley " + e);
			SplunkEventLogger.logEvent(SplunkEvent.KEY_RETRIEVAL_FAILURE, splunkLogError, logger);
		}

		logger.info("Exit from method : getSessionKey ");

		return null;
	}

	public String extractPassword(String systemCmd) throws IOException {
		String pwdLabel = null;

		Process proc = Runtime.getRuntime().exec(systemCmd);
		if (proc != null) {
			InputStreamReader isReader = new InputStreamReader(
					proc.getInputStream());
			BufferedReader inReader = new BufferedReader(isReader);
			pwdLabel = inReader.readLine();

			inReader.close();
		}
		return pwdLabel;
	}

	public void setCryptovaultLabel(String cryptovaultLabel) {
		this.cryptovaultLabel = cryptovaultLabel;
	}

	public void setKeyStoreAlias(String keyStoreAlias) {
		this.keyStoreAlias = keyStoreAlias;
	}

	public void setEnvUtil(EnvironmentUtil envUtil) {
		this.envUtil = envUtil;
	}

	public Key getKey() throws IOException, KeyStoreException, InvalidException, NoSuchAlgorithmException, CertificateException, UnrecoverableKeyException, NoSuchPaddingException  {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter in getKey");
		}

		Key key = null;
		String env = envUtil.getEnv();

		if (null != env && env.equalsIgnoreCase(PROD)) {
			logger.info("####### Environment ########"+env);	

			//This is class provided in Oracle Documentation
			provider = new sun.security.pkcs11.SunPKCS11(prodBatchKeyPath); //NOSONAR

			KeyStore keyStore = KeyStore.getInstance(PKCS11, provider);

			logger.info("keyStore instance retrieved");

			char[] password = getPassword(prodKeyPass).toCharArray();

			keyStore.load(null, password);

			logger.debug("keyStore loaded ");	

			key = keyStore.getKey(prodKeyName, password);

			logger.debug("key received");	

			keyUnwrapCipher = Cipher.getInstance(TRANSFORM,provider);

			logger.debug("keyUnwrapCipher instance retrieved ");	

		} else if (null != env && env.equalsIgnoreCase(DEV)) {
			logger.info("Dev env");
			String keyStorePath = envUtil.getKeyStorePath();

			File keyStoreFile = new File(keyStorePath);
	 
			try ( FileInputStream fis1 = new FileInputStream(keyStoreFile) ){
				KeyStore keyStore = KeyStore.getInstance(JKS);

				String systemCmd = CRYPTOVAULTCOMMAND + cryptovaultLabel;

				logger.debug("Command to get the username and password from cryptovault=" + systemCmd);

				String pwdLabel = extractPassword(systemCmd);
				
				if (pwdLabel != null) {
					keyStore.load(fis1, pwdLabel.toCharArray());
					fis1.close();
					key = keyStore.getKey(keyStoreAlias, pwdLabel.toCharArray());
					keyUnwrapCipher = Cipher.getInstance(TRANSFORM);
				}
			} catch (Exception e) {
				Map<String, String> splunkLogError = new HashMap<String, String>();
				splunkLogError.put("exception", e.getMessage());
				logger.error("exception in retrieving the cryptovault passowrd  : "	+ e);
				SplunkEventLogger.logEvent(SplunkEvent.KEY_RETRIEVAL_FAILURE, splunkLogError, logger);
			}

			logger.debug("Exit from method : getKey ");
		} 

		return key;
	}

	public String getPassword(String label) throws IOException {
		String cmd = "/usr/local/bin/mcgetpw -label " + label.replaceAll("[&/ ]", "");
		Process proc;
		String passphrase;

		try {
			proc = Runtime.getRuntime().exec(cmd);
			InputStreamReader is = new InputStreamReader(proc.getInputStream());
			BufferedReader br = new BufferedReader(is);
			passphrase = br.readLine();
			br.close();
			return passphrase;
		} catch (IOException exp) {
			throw exp;
		}

	}
	
}
