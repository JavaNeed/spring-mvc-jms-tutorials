package com.mastercard.ess.eds.batch.scheduler;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;

import com.mastercard.ess.eds.common.SplunkEvent;
import com.mastercard.ess.eds.common.SplunkEventLogger;
import com.mastercard.ess.eds.core.util.GlobalConstants;

public class CPPRulesExecutionScheduler {
	
	private Logger logger = Logger.getLogger(CPPReportGenerationScheduler.class);
	@Autowired
	private JobLauncher joLauncher;
	@Autowired
	ApplicationContext context;	
	
	@Value("${cpprulesrc.name}")
	private String cppSrcName;
	
	
	private Job job;

	public void run() {
		Job job = (Job) context.getBean("cppRulesExecJob");
		JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
		SimpleDateFormat datetimeFormat = new SimpleDateFormat(GlobalConstants.DATE_TIME_FORMAT);
		String timestamp = datetimeFormat.format(new Date());
		
		Date date = new Date();  
	    SimpleDateFormat formatter = new SimpleDateFormat("dd_MMM_yyyy_hh_mm_ss");
	    String strDate= formatter.format(date);
		
	    String cppSrc = cppSrcName + strDate ;
	    
		jobParametersBuilder.addString("currentDateTime", timestamp);
		jobParametersBuilder.addString("cppSrcName", cppSrc);
		
		logger.info("currentDateTime : " + timestamp);
		logger.info("cppSrcName : " + cppSrc);
		
		JobParameters jobParameters = jobParametersBuilder.toJobParameters();
		
		logger.info("jobParameters : " + jobParameters);
		
		try {	
			joLauncher.run(job, jobParameters);
		} catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException| JobParametersInvalidException e) {
			splunkLogger(e);
		}
	}
	
	public void splunkLogger(JobExecutionException e) {
		Map<String, String> splunkLogError = new HashMap<>();
		splunkLogError.put("exception", e.getMessage());
		splunkLogError.put("job", job.getName());
		SplunkEventLogger.logEvent(SplunkEvent.JOB_LAUNCH_FAILURE, splunkLogError, logger);
		logger.error("CPPRulesExecutionJob failed, exception = " + e);
		
	}

	// for Junit
	public void setContext(ApplicationContext context) {
		this.context =context;		
	}
	// for Junit
	public void setJoLauncher(JobLauncher joLauncher) {
		this.joLauncher = joLauncher;		
	}
	
	// for Junit
	public void setCppSrcName(String cppSrcName) {
		this.cppSrcName = cppSrcName;
	}

	// for Junit
	public void setJob(Job job) {
		this.job = job;
	}

	


}
