package com.mastercard.ess.eds.core.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;

import org.apache.commons.collections.MapUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.item.ExecutionContext;

import com.mastercard.ess.eds.domain.AuthDebitPanDetailRecord;
import com.mastercard.ess.eds.domain.PANMetadataRecord;

public class DeDupeCPPUtil {

	private DeDupeCPPUtil(){
	}

	private static Logger logger = Logger.getLogger(DeDupeCPPUtil.class);

	/**
	 * This method takes a list of pans as input and checks if the pans are available in level local cache, adds unique pans in the current execution to a list and
	 * keeps track of the pan-rule mapping.
	 * 
	 * @param executionContext
	 * @param authDebitlist - list of pans received from CPP rule execution
	 * @return - list of unique pans in current execution, pan-rule mapping is set in execution context
	 */
	@SuppressWarnings("unchecked")
	public static synchronized List<AuthDebitPanDetailRecord> filterDuplicates(ExecutionContext executionContext, List<AuthDebitPanDetailRecord> authDebitlist){
		long startTime = System.currentTimeMillis();
		DeDupePan deDupePan = (DeDupePan) executionContext.get(DeDupeTokens.DE_DUPE_PAN.getDesc());
		/*
		 * panRuleMap contains pan as key and set of rule ids which fetched it as value.
		 */
		Map<String, Set> panRuleMap = (ConcurrentHashMap<String, Set>)executionContext.get(DeDupeTokens.PAN_RULE_MAP.getDesc());
		if( MapUtils.isEmpty(panRuleMap) ){
			panRuleMap = new ConcurrentHashMap<String, Set>();
		}
		Set<AuthDebitPanDetailRecord> uniqueAuthDebitSet = Collections.synchronizedSet(new HashSet<AuthDebitPanDetailRecord>());
		
		PANMetadataRecord panMetadataRecord = new PANMetadataRecord();
		panMetadataRecord.addMetadataEntry(DeDupeTokens.SOURCE.getDesc(), DeDupeTokens.INTERNAL.getDesc());

		if(!authDebitlist.isEmpty()){
			for (AuthDebitPanDetailRecord authDebitPanRecord : authDebitlist) {
				if(null != authDebitPanRecord.getRawPan()) {
					panMetadataRecord.setPan(authDebitPanRecord.getRawPan());
					/*
					 * Check if pan is duplicate, if unique then add in uniqueAuthDebitSet.
					 */
					if(!checkDuplicate(deDupePan, panMetadataRecord)){
						uniqueAuthDebitSet.add(authDebitPanRecord);
					}
					/*
					 * If there is an entry for a given pan in the panRuleMap, initialize the syncRuleSet with the existing mapping.
					 */
					CopyOnWriteArraySet<BigDecimal> syncRuleSet = new CopyOnWriteArraySet(new LinkedHashSet<BigDecimal>());
					if( panRuleMap.containsKey(authDebitPanRecord.getRawPan()) ){
						syncRuleSet = new CopyOnWriteArraySet(panRuleMap.get(authDebitPanRecord.getRawPan()));
					}
					/*
					 * Add the new mapping to the syncRuleSet and update panRuleMap with the new set.
					 */
					if(syncRuleSet.add(authDebitPanRecord.getCppRuleId())){
						panRuleMap.put(authDebitPanRecord.getRawPan(), syncRuleSet);
					}
				}
			}
		}
		executionContext.put(DeDupeTokens.PAN_RULE_MAP.getDesc(), panRuleMap);
		logger.info("Total exec time = " + ((System.currentTimeMillis() - startTime)));
		return new ArrayList<>(uniqueAuthDebitSet);
	}

	/**
	 * Method to check if the pan is duplicate in the level local cache and add to cache if its unique.
	 * @param deDupePan
	 * @param panMetadataRecord
	 * @return
	 */
	private static synchronized boolean checkDuplicate(DeDupePan deDupePan, PANMetadataRecord panMetadataRecord){
		if(!deDupePan.isDuplicate(panMetadataRecord, DeDupeLevels.LEVEL_LOCAL)){
			deDupePan.addPan(panMetadataRecord, DeDupeLevels.LEVEL_LOCAL);
			return false;
		}
		return true;
	}

}
