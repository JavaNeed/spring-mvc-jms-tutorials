package com.mastercard.ess.eds.batch.scheduler;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;

import com.mastercard.ess.eds.batch.config.DatabaseConfig;
import com.mastercard.ess.eds.core.util.EDSProcessStatus;
import com.mastercard.ess.eds.domain.EDSSource;

public class PanProcessJobScheduler {

	private JdbcTemplate jdbcTemplate;
	
	private static final String FETCH_QUEUED_FILES_QUERY = "SELECT EDS_SRC_ID, EDS_SRC_TYPE_ID, SRC_NAM, LOC_TXT, ERR_FILE_NAM, ERR_FILE_LOC_TXT, PURGED_SW, LST_UPDT_USER_ID, LST_UPDT_DT FROM EDS_SRC WHERE STAT_CD = ?";
	
	private Logger logger = Logger.getLogger(PanProcessJobScheduler.class);
	
	public PanProcessJobScheduler() {
		
		Properties prop = new Properties();
		InputStream inputStream = getClass().getResourceAsStream("/database.properties");
		
		DatabaseConfig databaseConfig = new DatabaseConfig();
		
		String edsLabel = "";
		String edsUrl = "";
		String driverClassName = "";
		Integer minPoolSize;
		Integer maxPoolSize;
		
		try {
			if (inputStream != null) {
                prop.load(inputStream);
            } else {
                throw new FileNotFoundException("property file '" + "database.properties" + "' not found in the classpath");
            }
			edsLabel = prop.getProperty("eds.label");
			edsUrl = prop.getProperty("jdbc.url");
			driverClassName = prop.getProperty("jdbc.driverClassName");
			minPoolSize = Integer.parseInt(prop.getProperty("jdbc.minPoolSize"));
			maxPoolSize = Integer.parseInt(prop.getProperty("jdbc.maxPoolSize"));
			
			databaseConfig.setEdsLabel(edsLabel);
			databaseConfig.setEdsurl(edsUrl);
			databaseConfig.setClassName(driverClassName);
			databaseConfig.setMinPoolSize(minPoolSize);
			databaseConfig.setMaxPoolSize(maxPoolSize);
			
			jdbcTemplate = new JdbcTemplate(databaseConfig.batchEDSDataSource());
			inputStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error("exception occured in launching the pan process job : " + e);
		}
	}
	
	public static void main(String[] args) {
		PanProcessJobScheduler jobScheduler = new PanProcessJobScheduler();
		System.out.println(jobScheduler.execute()); //NOSONAR
		
	}
	
	
	public List<EDSSource> execute() {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : [FileProcessJob] execute ");
		}

		List<Map<String, Object>> edsSourceList = null;

		edsSourceList = getQueuedFiles();
		EDSSource edsSourceInstance;
		List<EDSSource> edsSourceInstanceList = new ArrayList<>();
		for (Map<String, Object> row : edsSourceList) {

			edsSourceInstance = populateEDSSourceInstanceList(row);
			edsSourceInstanceList.add(edsSourceInstance);
		}
		return edsSourceInstanceList;
	}
	
	public EDSSource populateEDSSourceInstanceList(Map<String, Object> row) {
		EDSSource edsSourceInstance = new EDSSource();

		try {
			edsSourceInstance.setSrc_ky((BigDecimal) row.get("EDS_SRC_ID"));
			edsSourceInstance.setErrorFile((String) row.get("ERR_FILE_NAM"));
			edsSourceInstance.setErrorFileLocation((String) row.get("ERR_FILE_LOC_TXT"));
			String isPurged = (String) row.get("IS_PURGED_SW");
			if (("N").equalsIgnoreCase(isPurged)) {
				edsSourceInstance.setIsPurged(false);
			} else {
				edsSourceInstance.setIsPurged(true);
			}
			edsSourceInstance.setLastUpdateTimeStamp((Timestamp) row.get("LST_UPDT_DT"));
			edsSourceInstance.setLastUpdatedBy((String) row.get("LST_UPDT_USER_ID"));
			edsSourceInstance.setSrc_type_ky((BigDecimal) row.get("EDS_SRC_TYPE_ID"));
			edsSourceInstance.setName((String) row.get("SRC_NAM"));
		} catch (ClassCastException e) {
			logger.error(e);
		}

		return edsSourceInstance;
	}
	
	public List<Map<String, Object>> getQueuedFiles() {

		return jdbcTemplate.queryForList(FETCH_QUEUED_FILES_QUERY, EDSProcessStatus.QUEUED.getStatusCode());
	}
	
}
