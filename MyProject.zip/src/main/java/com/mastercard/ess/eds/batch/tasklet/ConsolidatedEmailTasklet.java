package com.mastercard.ess.eds.batch.tasklet;

import static com.mastercard.ess.eds.constant.SQLConstants.CUST_NAME;
import static com.mastercard.ess.eds.constant.SQLConstants.EMAILID;
import static com.mastercard.ess.eds.constant.SQLConstants.EMAIL_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.ICA;
import static com.mastercard.ess.eds.constant.SQLConstants.ICA_NUM;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.core.service.EventSubscriptionService;
import com.mastercard.ess.eds.notification.dao.NotificationDAO;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;
/**
 * @author e069468
 *
 */
public class ConsolidatedEmailTasklet implements Tasklet{

	private static Logger logger = Logger.getLogger(ConsolidatedEmailTasklet.class);

	@Autowired
	private EventPublisher eventPublisher;
	
	@Autowired
	private EventSubscriptionService eventSubscriptionService;
	
	@Autowired
	private NotificationDAO notificationDAO;
	
	private Map<String, String> jobParams = new HashMap<>();
	private String jobInstanceName;
	private BigDecimal jobInstanceId;

	@SuppressWarnings("unchecked")
	@Override
	public RepeatStatus execute(StepContribution arg0, ChunkContext chunkContext)
			throws Exception {

		logger.info("Enter From  : ConsolidatedEmailTasklet - execute");

		List<String> icaList = (List<String>) chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get("icas");
		
		if(icaList == null || icaList.isEmpty()){
			return RepeatStatus.FINISHED ; 
		}
		Map<String, String> customerName = (Map<String, String>) chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get("icaName");
		String eventName = (String) chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get("eventName");
		String eventId = (String) chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get("eventId");

		List<String> addIcaList = null;
		List<String> subsIcaList = new ArrayList<>();
		Map<String, Map<String, List<String>>> finalSet = new HashMap<>(); 
		Map<String, List<String>> custNames = null;

		List<Map<String, Object>> subsList = eventSubscriptionService.getEmailIdsUsingICA(eventId, icaList);

		//getting eligible ICAs to send mail
		for(Map<String, Object> ms : subsList){
			subsIcaList.add(String.valueOf(ms.get(ICA_NUM)));
		}

		//getting defaultEmailId and mapping the customer name and ica to it
		for(String ica : icaList){
			if(!subsIcaList.contains(ica)){
				addIcaList = new ArrayList<>();
				custNames = new HashMap<>();
				addIcaList.add(ica);
				custNames.put(customerName.get(ica), addIcaList);
				String emailId = notificationDAO.getCustomerDefaultMail(ica);
				if(finalSet.get(emailId) == null){
					finalSet.put(emailId, custNames);
				} else {
					addValues(customerName, finalSet, emailId, ica);
				}
			}			
		}

		//getting list of email Id's subscribed and mapping the customer name and ica to ti
		for(Map<String, Object> eci : subsList){
			if(finalSet.get(eci.get(EMAIL_ID)) == null){
				addIcaList = new ArrayList<String>();
				custNames = new HashMap<>();
				addIcaList.add(String.valueOf(eci.get(ICA_NUM)));
				custNames.put(customerName.get(String.valueOf(eci.get(ICA_NUM))), addIcaList);
				finalSet.put((String) eci.get(EMAIL_ID), custNames);
			} else {
				String emailId = (String) eci.get(EMAIL_ID);
				String ica = String.valueOf(eci.get(ICA_NUM));
				addValues(customerName, finalSet, emailId, ica);
			}
		}

		//placing event
		for(Map.Entry<String, Map<String, List<String>>> customer: finalSet.entrySet()) {

			for(Map.Entry<String, List<String>> i1 : customer.getValue().entrySet()){
				NotificationEventVO notificationEventVO = new NotificationEventVO();
				Map<String, String> jobParams = new HashMap<>();

				jobParams.put(EMAILID, customer.getKey());
				jobParams.put(CUST_NAME, i1.getKey());
				jobParams.put(ICA, StringUtils.join(i1.getValue(), ","));
				notificationEventVO.setJobName(jobInstanceName);
				notificationEventVO.setJobID(jobInstanceId);
				notificationEventVO.setEventName(eventName);
				notificationEventVO.setJobParams(jobParams);

				logger.info("insideFileGenerator | Event has been triggered for the event "
						+ "with eventName : "
						+ notificationEventVO.getEventName()
						+ "jobName : "
						+ "jobId: "
						+ notificationEventVO.getJobID()
						+ "jobParams : "
						+ notificationEventVO.getJobParams());

				eventPublisher.placeEvent(notificationEventVO);
				
 				
			}
		}

		logger.info("Exit From  : ConsolidatedEmailTasklet - execute");

		return RepeatStatus.FINISHED;
	}

	private void addValues(Map<String, String> customerName,
			Map<String, Map<String, List<String>>> finalSet, String emailId,
			String ica) {
		List<String> addIcaList = null;
		if(finalSet.get(emailId).get(customerName.get(ica))!= null) {
			finalSet.get(emailId).get(customerName.get(ica)).add(ica);
		}
		else {
			addIcaList = new ArrayList<>();
			addIcaList.add(ica);
			finalSet.get(emailId).put(customerName.get(ica), addIcaList);
		}
	}

	public Map<String, String> getJobParams() {
		return jobParams;
	}

	public void setJobParams(Map<String, String> jobParams) {
		this.jobParams = jobParams;
	}

	public String getJobInstanceName() {
		return jobInstanceName;
	}

	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}

	public BigDecimal getJobInstanceId() {
		return jobInstanceId;
	}

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}

	public EventPublisher getEventPublisher() {
		return eventPublisher;
	}

	public void setEventPublisher(EventPublisher eventPublisher) {
		this.eventPublisher = eventPublisher;
	}

	public EventSubscriptionService getEventSubscriptionService() {
		return eventSubscriptionService;
	}

	public void setEventSubscriptionService(
			EventSubscriptionService eventSubscriptionService) {
		this.eventSubscriptionService = eventSubscriptionService;
	}
	// for junit
	public NotificationDAO getNotificationDAO() {
		return notificationDAO;
	}

	public void setNotificationDAO(NotificationDAO notificationDAO) {
		this.notificationDAO = notificationDAO;
	}

}
