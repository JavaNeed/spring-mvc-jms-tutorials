package com.mastercard.ess.eds.core.rule;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.easyrules.core.BasicRule;

import com.mastercard.ess.eds.core.util.BrandExclusionCache;
import com.mastercard.ess.eds.domain.ProcessedRecord;

public class FileGenerationCustomRules extends BasicRule {

	private static Logger logger = Logger.getLogger(FileGenerationCustomRules.class);

	private ProcessedRecord processedRecord;

	private BrandExclusionCache brandExclusionCache;

	private List<String> listExcludedBrands;
	private Map<String, String> icaToIsSilentMap;

	private String isADCNotified;
	private String isFraudReported;
	private boolean isAccountValid;
	private String isAccountActive;
	private String isAlreadyReported;
	private String isDuplicate;

	private String isAccountActiveFlag;

	private String isDuplicateFlag;

	private boolean isAccountValidFlag;
	private String isFraudReportedFlag;
	private String isADCNotifiedFlag;
	private String isAlreadyReportedFlag;
	
	public FileGenerationCustomRules() {
		logger.info("FileGenerationCustomRules Instance created");
	}

	public FileGenerationCustomRules(String name) {
		super(name);
		logger.info("FileGenerationCustomRules Instance created with name --" + name);
	}

	public FileGenerationCustomRules(FileGenerationCustomRules custom) {
		super(custom.getName(), custom.getDescription(), custom.getPriority()); // +
																				// ThreadLocalRandom.current().nextLong()
		this.brandExclusionCache = custom.brandExclusionCache;
		this.listExcludedBrands = custom.listExcludedBrands;
		this.icaToIsSilentMap = custom.icaToIsSilentMap;
		this.isADCNotified = custom.isADCNotified;
		this.isADCNotifiedFlag = custom.isADCNotifiedFlag;
		this.isAccountValid = custom.isAccountValid;
		this.isAccountValidFlag = custom.isAccountValidFlag;
		this.isAlreadyReported = custom.isAlreadyReported;
		this.isAlreadyReportedFlag = custom.isAlreadyReportedFlag;
		this.isDuplicate = custom.isDuplicate;
		this.isDuplicateFlag = custom.isDuplicateFlag;
		this.isFraudReported = custom.isFraudReported;
		this.isFraudReportedFlag = custom.isFraudReportedFlag;
		this.isAccountActive = custom.isAccountActive;
		this.isAccountActiveFlag = custom.isAccountActiveFlag;

	}

	public String getIsAccountActiveFlag() {
		return isAccountActiveFlag;
	}

	public void setIsAccountActiveFlag(String isAccountActiveFlag) {
		logger.info("From DB, isAccountActiveFlag set to --" + isAccountActiveFlag);
		this.isAccountActiveFlag = isAccountActiveFlag;
	}

	public boolean isAccountValidFlag() {
		return isAccountValidFlag;
	}

	public void setAccountValidFlag(boolean isAccountValidFlag) {
		logger.info("From DB, isAccountValidFlag set to --" + isAccountValidFlag);
		this.isAccountValidFlag = isAccountValidFlag;
	}

	public String getIsFraudReportedFlag() {
		return isFraudReportedFlag;
	}

	public void setIsFraudReportedFlag(String isFraudReportedFlag) {
		logger.info("From DB, isFraudReportedFlag set to --" + isFraudReportedFlag);
		this.isFraudReportedFlag = isFraudReportedFlag;
	}

	public String getIsADCNotifiedFlag() {
		return isADCNotifiedFlag;
	}

	public void setIsADCNotifiedFlag(String isADCNotifiedFlag) {
		logger.info("From DB, isADCNotifiedFlag set to --" + isADCNotifiedFlag);
		this.isADCNotifiedFlag = isADCNotifiedFlag;
	}

	public String getIsAlreadyReportedFlag() {
		return isAlreadyReportedFlag;
	}

	public void setIsAlreadyReportedFlag(String isAlreadyReportedFlag) {
		logger.info("From DB, isAlreadyReportedFlag set to --" + isAlreadyReportedFlag);
		this.isAlreadyReportedFlag = isAlreadyReportedFlag;
	}

	public String getIsDuplicateFlag() {
		return isDuplicateFlag;
	}

	public void setIsDuplicateFlag(String isDuplicateFlag) {
		this.isDuplicateFlag = isDuplicateFlag;

	}

	
	public Map<String, String> getIcaToIsSilentMap() {
		return icaToIsSilentMap;
	}

	public void setIcaToIsSilentMap(Map<String, String> icaToIsSilentMap) {
		this.icaToIsSilentMap = icaToIsSilentMap;
	}

	public List<String> getExcludedBrandList() {
		return listExcludedBrands;
	}

	public void setInputToRule(ProcessedRecord processedRecord) {
		this.processedRecord = processedRecord;

		this.isADCNotified = processedRecord.getIsAccountADCNotified();

		this.isFraudReported = processedRecord.getIsFraudReported();

		this.isAccountActive = processedRecord.getIsAccountActive();

		this.isAccountValid = processedRecord.isAccountValid();

		this.isAlreadyReported = processedRecord.getIsReported();

		this.isDuplicate = processedRecord.getIsDuplicate();

	}

	@Override
	public boolean evaluate() {

		String isSilent = icaToIsSilentMap.get(processedRecord.getIca());
		if ("Y".equals(isSilent)) {
			processedRecord.setIsFiltered("Y");
			return false;
		}

		listExcludedBrands = brandExclusionCache.getListOfExcludedBrands();
		if (null != listExcludedBrands && ! listExcludedBrands.isEmpty() && listExcludedBrands.contains(processedRecord.getBrandProductCode())) {
				processedRecord.setIsFiltered("Y");
				return false;
			
		}
		boolean activeCondition = isAccountActiveFlag.equals(isAccountActive);
		boolean validCondition;
		if (isAccountValidFlag == isAccountValid) {
			validCondition = true;
		} else {
			validCondition = false;
		}
	

		return checkCondition(activeCondition,validCondition);
	
	}

	private boolean checkCondition(boolean activeCondition, boolean validCondition) {
		
		boolean fraudReportedCondition = isFraudReportedFlag.equals(isFraudReported);

		boolean isADCNotifiedCondition = isADCNotifiedFlag.equals(isADCNotified);

		boolean isAlreadyReportedCondition = isAlreadyReportedFlag.equals(isAlreadyReported);

		boolean isDuplicateCondition = isDuplicateFlag.equals(isDuplicate);

		if (!(checkActiveValidProcessBoolean(activeCondition,validCondition,fraudReportedCondition) && 
                checkBooleanForReports(isADCNotifiedCondition,isAlreadyReportedCondition,isDuplicateCondition))) {
         processedRecord.setIsFiltered("Y");
         return false;
  }
  

		logger.info("Rules Evaluation Passed | FileGenerationCustomRules");
		return true;
	}
    private boolean checkActiveValidProcessBoolean(boolean activeCondition,boolean validCondition , boolean fraudReportedCondition ){
        
        return  activeCondition && validCondition && fraudReportedCondition;
 }
 
 private boolean checkBooleanForReports(boolean isADCNotifiedCondition,boolean isAlreadyReportedCondition, boolean isDuplicateCondition ){
        
        return isADCNotifiedCondition && isAlreadyReportedCondition && isDuplicateCondition;
 }

	@Override
	public void execute() {

		logger.info("Executing FileGenerationCustomRules");
	}

	public void setExcludedBrandList(List<String> listExcludedBrands) {
		this.listExcludedBrands = listExcludedBrands;

	}

	public void setBrandExclusionCache(BrandExclusionCache brandExclusionCache) {
		this.brandExclusionCache = brandExclusionCache;

	}

	public BrandExclusionCache getBrandExclusionCache() {
		return this.brandExclusionCache;

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime
				* result
				+ ((icaToIsSilentMap == null) ? 0 : icaToIsSilentMap.hashCode());
		result = prime * result
				+ ((isADCNotified == null) ? 0 : isADCNotified.hashCode());
		result = prime
				* result
				+ ((isADCNotifiedFlag == null) ? 0 : isADCNotifiedFlag
						.hashCode());
		result = prime * result
				+ ((isAccountActive == null) ? 0 : isAccountActive.hashCode());
		result = prime
				* result
				+ ((isAccountActiveFlag == null) ? 0 : isAccountActiveFlag
						.hashCode());
		result = prime * result + (isAccountValid ? 1231 : 1237);
		result = prime * result + (isAccountValidFlag ? 1231 : 1237);
		result = prime
				* result
				+ ((isAlreadyReported == null) ? 0 : isAlreadyReported
						.hashCode());
		result = prime
				* result
				+ ((isAlreadyReportedFlag == null) ? 0 : isAlreadyReportedFlag
						.hashCode());
		result = prime * result
				+ ((isDuplicate == null) ? 0 : isDuplicate.hashCode());
		result = prime * result
				+ ((isDuplicateFlag == null) ? 0 : isDuplicateFlag.hashCode());
		result = prime * result
				+ ((isFraudReported == null) ? 0 : isFraudReported.hashCode());
		result = prime
				* result
				+ ((isFraudReportedFlag == null) ? 0 : isFraudReportedFlag
						.hashCode());
		result = prime
				* result
				+ ((listExcludedBrands == null) ? 0 : listExcludedBrands
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		FileGenerationCustomRules other = (FileGenerationCustomRules) obj;
		if (icaToIsSilentMap == null) {
			if (other.icaToIsSilentMap != null)
				return false;
		} else if (!icaToIsSilentMap.equals(other.icaToIsSilentMap))
			return false;
		if (isADCNotified == null) {
			if (other.isADCNotified != null)
				return false;
		} else if (!isADCNotified.equals(other.isADCNotified))
			return false;
		if (isADCNotifiedFlag == null) {
			if (other.isADCNotifiedFlag != null)
				return false;
		} else if (!isADCNotifiedFlag.equals(other.isADCNotifiedFlag))
			return false;
		if (isAccountActive == null) {
			if (other.isAccountActive != null)
				return false;
		} else if (!isAccountActive.equals(other.isAccountActive))
			return false;
		if (isAccountActiveFlag == null) {
			if (other.isAccountActiveFlag != null)
				return false;
		} else if (!isAccountActiveFlag.equals(other.isAccountActiveFlag))
			return false;
		if (isAccountValid != other.isAccountValid)
			return false;
		if (isAccountValidFlag != other.isAccountValidFlag)
			return false;
		if (isAlreadyReported == null) {
			if (other.isAlreadyReported != null)
				return false;
		} else if (!isAlreadyReported.equals(other.isAlreadyReported))
			return false;
		if (isAlreadyReportedFlag == null) {
			if (other.isAlreadyReportedFlag != null)
				return false;
		} else if (!isAlreadyReportedFlag.equals(other.isAlreadyReportedFlag))
			return false;
		if (isDuplicate == null) {
			if (other.isDuplicate != null)
				return false;
		} else if (!isDuplicate.equals(other.isDuplicate))
			return false;
		if (isDuplicateFlag == null) {
			if (other.isDuplicateFlag != null)
				return false;
		} else if (!isDuplicateFlag.equals(other.isDuplicateFlag))
			return false;
		if (isFraudReported == null) {
			if (other.isFraudReported != null)
				return false;
		} else if (!isFraudReported.equals(other.isFraudReported))
			return false;
		if (isFraudReportedFlag == null) {
			if (other.isFraudReportedFlag != null)
				return false;
		} else if (!isFraudReportedFlag.equals(other.isFraudReportedFlag))
			return false;
		if (listExcludedBrands == null) {
			if (other.listExcludedBrands != null)
				return false;
		} else if (!listExcludedBrands.equals(other.listExcludedBrands))
			return false;
		return true;
	}
	
}
