package com.mastercard.ess.eds.core.dao;

import java.math.BigDecimal;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.FileSystemResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.parser.VendorPayloadTokens;
import com.mastercard.ess.eds.domain.RawRecord;
import static com.mastercard.ess.eds.constant.SQLConstants.*;
import static com.mastercard.ess.eds.constant.SQLQueries.*;

@Component
public class RawRecordDBWriterDao {
	
	private static Logger logger = Logger.getLogger(RawRecordDBWriterDao.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	private SimpleJdbcInsert riskRawRecordsInsert;

	public RawRecordDBWriterDao(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
		riskRawRecordsInsert = new SimpleJdbcInsert(dataSource).withTableName(
				EDS_SOURCE_DATA).usingColumns(EDS_SRC_DATA_ID,SRC_KY, ARTIFACT_ID, URL,
				RAW_PAN, RAW_DATA, STAT_CD, CRTE_USER_ID, CRTE_DT, LINE_NUMBER,JOB_INSTNCE_ID,IS_DUP_SW);
	}

	/**
	 * After read step data will be persisted in eds source data table in
	 * this method . Records come in form of List of object and stored in DB
	 * 
	 * @param rawRecords
	 *            : list of records fetched from input file
	 */
	public void writeRecord(List<? extends RawRecord> rawRecords,String edsSrcId, BigDecimal jobInstanceId) {
		
		for (RawRecord rawRecord : rawRecords) {

			if (logger.isDebugEnabled()) {
				logger.debug("Enter in method : writeRecord ");
			}
			String eds_src_data_id_seq = "select EDS_SRC_DATA_ID_SEQ.nextval from dual";
			int fileId = jdbcTemplate.queryForObject(eds_src_data_id_seq, Integer.class);

			MapSqlParameterSource parameterSource = new MapSqlParameterSource();
			parameterSource.addValue(EDS_SRC_DATA_ID, fileId)
					.addValue(SRC_KY, edsSrcId)
					.addValue(ARTIFACT_ID, rawRecord.getPayloadValue(VendorPayloadTokens.CWID.getDesc()))
					.addValue(URL, rawRecord.getPayloadValue(VendorPayloadTokens.URL.getDesc()))
					.addValue(RAW_PAN, rawRecord.getRawPan())
					.addValue(RAW_DATA, rawRecord.getPayloadValue(VendorPayloadTokens.RAW_DATA.getDesc()))
					.addValue(STAT_CD, rawRecord.getStatus())
					.addValue(CRTE_USER_ID, rawRecord.getCreatedBy())
					.addValue(CRTE_DT, rawRecord.getCreateDate())					 
					.addValue(LINE_NUMBER, rawRecord.getLineNumber())
					.addValue(JOB_INSTNCE_ID, jobInstanceId)
					.addValue(IS_DUP_SW, rawRecord.getIsDuplicate());

			riskRawRecordsInsert.execute(parameterSource);

			if (logger.isDebugEnabled()) {
				logger.debug("Exit from method : writeRecord ");
			}
		}

	}

	public String getEdsSrcId(String fullyQualifiedfileName) {
		
		FileSystemResource fileSystemResource = new FileSystemResource(fullyQualifiedfileName);
		
		String srcName = fileSystemResource.getFile().getName();
		
		String edsSrcId = jdbcTemplate.queryForObject(FETCH_EDS_SRC_ID,String.class,srcName);		
		
		return edsSrcId;
	}
}
