package com.mastercard.ess.eds.core.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.mapper.EDSSourceTypeRowMapper;
import com.mastercard.ess.eds.core.rule.PriceCategoryRule;
import com.mastercard.ess.eds.domain.EDSSourceType;

/**
 * * This DAO class will read all records from EDS_price_cat_rule table and
 * convert each row into PriceCategoryRule domain object. After converting all
 * rows it will return this list of rule objects to be cached by
 * PriceCategoryRuleCache.
 * 
 * @author E068303
 */
@Component
public class PriceCategoryDAO {

	private static final String ACTVY_TXT = "ACTVY_TXT";
	private static final String CNFDNC_TXT = "CNFDNC_TXT";
	private JdbcTemplate jdbcTemplate;
	private static String fetchEdsPriceCatRule = "SELECT * from EDS_PRICE_CAT_RULE";
	private static String getSrcKey = "select type.* from eds_src_type type, eds_src src, eds_src_data data where type.eds_src_type_id = src.eds_src_type_id "
		+ " and data.eds_src_id = src.eds_src_id and data.EDS_SRC_DATA_ID = ?";
	private static String IS_EXTERNAL = "EXTRL_SW";
	private static String IS_DERIVED = "DERIV_SW";
	private static String IS_ADC_NOTIFIED = "ADC_NOTIF_SW";
	private static String START_DT = "STRT_DT";
	private static String END_DT = "END_DT";
	private static String OPER_ONE = "OPER_1_TXT";
	private static String OPER_TWO = "OPER_2_TXT";
	private static String VAL_ONE = "VAL_1_NUM";
	private static String VAL_TWO = "VAL_2_NUM";
	private static String CATEGORY = "PRICE_CAT_CD";
	private static String CONFIDENCE_SCORE = "CNFDNC_SCR_NUM";

	private static Logger logger = Logger.getLogger(PriceCategoryDAO.class);

	public PriceCategoryDAO() {
		super();
	}

	public PriceCategoryDAO(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {

		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/*
	 * This method fetches rules data from DB and convert each row into
	 * PriceCategoryRule domain object. It also sets the data to the cache.
	 */

	public List<PriceCategoryRule> loadAllCategoryRules() {
		List<PriceCategoryRule> priceCategoryCache = new ArrayList<PriceCategoryRule>();

		if (logger.isDebugEnabled()) {
			logger.debug("PriceCategoryDAO | loadAllCategoryRules | Enter in method ");
		}
		int ruleNameIncrementer = 0;
		List<Map<String, Object>> priceCategoryData = jdbcTemplate.queryForList(fetchEdsPriceCatRule);
		if (priceCategoryData != null) {
			for (Map<String, Object> row : priceCategoryData) {
				PriceCategoryRule priceCategoryRule = new PriceCategoryRule("Rule_" + ruleNameIncrementer);
				
				setExternalDerivedAdcNotifiedValue(row, priceCategoryRule);
				
				setStartEndDateValue(row, priceCategoryRule);

				setOperandAndOperatorValue(row, priceCategoryRule);
				
				priceCategoryRule.setPriceCategory(((BigDecimal) row.get(CATEGORY)).intValue());
				priceCategoryRule.setConfidenceScore(((BigDecimal) row.get(CONFIDENCE_SCORE)).intValue());
				
				setConfidenceActivityValue(row, priceCategoryRule);

				priceCategoryCache.add(priceCategoryRule);
				logger.info(
						"PriceCategoryDAO | loadAllCategoryRules | priceCategoryRule data from DB related to the cache"
								+ priceCategoryRule);

				ruleNameIncrementer++;
			}

		} else {
			logger.debug("PriceCategoryDAO | null data in priceCategory object ");
		}
		if (logger.isDebugEnabled()) {
			logger.debug("PriceCategoryDAO | loadAllCategoryRules | Exit from method ");
		}

		return priceCategoryCache;

	}

	/**
	 * @param row
	 * @param priceCategoryRule
	 */
	private void setConfidenceActivityValue(Map<String, Object> row,
			PriceCategoryRule priceCategoryRule) {
		if (null != row.get(CNFDNC_TXT)) {
			priceCategoryRule.setConfidenceText((String) row.get(CNFDNC_TXT));
			logger.info("Set the Confidence Text as --" + ((String) row.get(CNFDNC_TXT)));
		}
		if (null != row.get(ACTVY_TXT)) {
			priceCategoryRule.setActivityText((String) row.get(ACTVY_TXT));
			logger.info("Set the Activity Text as --" + ((String) row.get(ACTVY_TXT)));
		}
	}

	/**
	 * @param row
	 * @param priceCategoryRule
	 */
	private void setOperandAndOperatorValue(Map<String, Object> row,
			PriceCategoryRule priceCategoryRule) {
		if ((String) row.get(OPER_ONE) != null) {
			priceCategoryRule.setOperator1((String) row.get(OPER_ONE));
		}

		if ((String) row.get(OPER_TWO) != null) {
			priceCategoryRule.setOperator2((String) row.get(OPER_TWO));
		}

		if ((BigDecimal) row.get(VAL_ONE) != null) {
			priceCategoryRule.setOperand1((BigDecimal) row.get(VAL_ONE));
		}

		if ((BigDecimal) row.get(VAL_TWO) != null) {
			priceCategoryRule.setOperand2((BigDecimal) row.get(VAL_TWO));
		}
	}

	/**
	 * @param row
	 * @param priceCategoryRule
	 */
	private void setStartEndDateValue(Map<String, Object> row,
			PriceCategoryRule priceCategoryRule) {
		if (row.get(START_DT) != null) {
			priceCategoryRule.setStartDate((Date) row.get(START_DT));
		}

		if (row.get(END_DT) != null) {
			priceCategoryRule.setEndDate((Date) row.get(END_DT));
		}
	}

	/**
	 * @param row
	 * @param priceCategoryRule
	 */
	private void setExternalDerivedAdcNotifiedValue(Map<String, Object> row,
			PriceCategoryRule priceCategoryRule) {
		if ((String) row.get(IS_EXTERNAL) != null) {
			priceCategoryRule.setExternal((String) row.get(IS_EXTERNAL));
		}

		if ((String) row.get(IS_DERIVED) != null) {
			priceCategoryRule.setDerived((String) row.get(IS_DERIVED));
		}

		if ((String) row.get(IS_ADC_NOTIFIED) != null) {
			priceCategoryRule.setAdcNotified((String) row.get(IS_ADC_NOTIFIED));
		} else {
			priceCategoryRule.setAdcNotified("");
		}
	}

	/**
	 * This function is to get the key from the table from which the external
	 * and derived values are obtained
	 * 
	 * @param srcKey
	 *            integer
	 * @return List<Map<String, Object>>
	 */

	public EDSSourceType getEDSSourceType(int srcKey) {
		EDSSourceType edsSourceType;

		try {
			edsSourceType = jdbcTemplate.queryForObject(getSrcKey, new Object[] { srcKey },
					new EDSSourceTypeRowMapper());
			if (edsSourceType != null) {

				return edsSourceType;
			}

		} catch (Exception e) {
			logger.error("Exception in PriceCategoryDAO | :" + e);
			return new EDSSourceType();
		}
		return edsSourceType;

	}
}
