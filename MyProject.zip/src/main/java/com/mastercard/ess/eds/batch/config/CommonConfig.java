package com.mastercard.ess.eds.batch.config;

import javax.sql.DataSource;

import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
import org.springframework.batch.core.configuration.annotation.DefaultBatchConfigurer;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * @author e058825
 *
 */

@Configuration
@ComponentScan("com.mastercard.ess.eds")
@EnableBatchProcessing
@EnableScheduling
@PropertySource("classpath:config.properties")
@ImportResource({ "classpath:META-INF/spring/import-raw-records.xml",
        "classpath:META-INF/spring/integration-context.xml", "classpath:META-INF/spring/pan-process-batch-job.xml",
        "classpath:META-INF/spring/customer-file-generation-job.xml",
        "classpath:META-INF/spring/email-integration-context.xml", "classpath:META-INF/spring/cpp-analysis-job.xml",
        "classpath:META-INF/spring/pan_context.xml", "classpath:META-INF/spring/cpp-report-generation-job.xml",
        "classpath:META-INF/spring/pan-unavailability-notification-job.xml",
        "classpath:META-INF/spring/vendor-active-account-report-generation-and-mail-job.xml",
        "classpath:META-INF/spring/cpp-rules-execution-job.xml", "classpath:META-INF/spring/send-welcome-email.xml",
        "classpath:META-INF/spring/purge-job.xml", "classpath:META-INF/spring/send-billing-batch-files.xml",
        "classpath:META-INF/spring/send-customer-batch-files.xml",
        "classpath:META-INF/spring/customer-enrollment-report.xml",
        "classpath:META-INF/spring/customer-internal-delivery-report-generation-and-mail-job.xml",
        "classpath:META-INF/spring/fraud-report-generation-job.xml" })
public class CommonConfig {

    /**
     * To make use of multiple datasources, we must specify our own
     * BatchConfigurer to prevent creation of DefaultBatchConfigurer bean in
     * AbstractBatchConfiguration
     */
    @Bean
    BatchConfigurer configurer(@Qualifier("batchDataSource") DataSource dataSource) {
        return new DefaultBatchConfigurer(dataSource);
    }
}
