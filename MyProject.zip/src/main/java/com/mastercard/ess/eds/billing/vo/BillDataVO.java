package com.mastercard.ess.eds.billing.vo;

import java.util.Date;

/*
 * VO class to map EDS_PROCC_DATA table values
 * 
 */
public class BillDataVO {

	private String brndPrdctCd;
	private long cardBinNum;
	private long cidNum;
	private long cnfdncScrNum;
	private Date crteDt;
	private String crteUserid;
	private String custPanRptid;
	private long daysSinceLstActvyCnt;
	private long edsPrcssDataid;
	private long edsSrcDataid;
	private long icaNum;
	private String isAcctActvsw;
	private String isAcctValidsw;
	private String isAdcNotifsw;
	private String isFraudRptsw;
	private String isPanDupsw;
	private String isRptsw;
	private Date lstActvyDt;
	private Date lstUpdDt;
	private String lstUpdtUserid;
	private long panNum;
	private long priceCatid;
	private Date rptDt;
	private long rtnCd;
	private long statCd;

	public String getBrndPrdctCd() {
		return brndPrdctCd;
	}

	public void setBrndPrdctCd(String brndPrdctCd) {
		this.brndPrdctCd = brndPrdctCd;
	}

	public long getCardBinNum() {
		return cardBinNum;
	}

	public void setCardBinNum(long cardBinNum) {
		this.cardBinNum = cardBinNum;
	}

	public long getCidNum() {
		return cidNum;
	}

	public void setCidNum(long cidNum) {
		this.cidNum = cidNum;
	}

	public long getCnfdncScrNum() {
		return cnfdncScrNum;
	}

	public void setCnfdncScrNum(long cnfdncScrNum) {
		this.cnfdncScrNum = cnfdncScrNum;
	}

	public Date getCrteDt() {
		return crteDt;
	}

	public void setCrteDt(Date crteDt) {
		this.crteDt = crteDt;
	}

	public String getCrteUserid() {
		return crteUserid;
	}

	public void setCrteUserid(String crteUserid) {
		this.crteUserid = crteUserid;
	}

	public String getCustPanRptid() {
		return custPanRptid;
	}

	public void setCustPanRptid(String custPanRptid) {
		this.custPanRptid = custPanRptid;
	}

	public long getDaysSinceLstActvyCnt() {
		return daysSinceLstActvyCnt;
	}

	public void setDaysSinceLstActvyCnt(long daysSinceLstActvyCnt) {
		this.daysSinceLstActvyCnt = daysSinceLstActvyCnt;
	}

	public long getEdsPrcssDataid() {
		return edsPrcssDataid;
	}

	public void setEdsPrcssDataid(long edsPrcssDataid) {
		this.edsPrcssDataid = edsPrcssDataid;
	}

	public long getEdsSrcDataid() {
		return edsSrcDataid;
	}

	public void setEdsSrcDataid(long edsSrcDataid) {
		this.edsSrcDataid = edsSrcDataid;
	}

	public long getIcaNum() {
		return icaNum;
	}

	public void setIcaNum(long icaNum) {
		this.icaNum = icaNum;
	}

	public String getIsAcctActvsw() {
		return isAcctActvsw;
	}

	public void setIsAcctActvsw(String isAcctActvsw) {
		this.isAcctActvsw = isAcctActvsw;
	}

	public String getIsAcctValidsw() {
		return isAcctValidsw;
	}

	public void setIsAcctValidsw(String isAcctValidsw) {
		this.isAcctValidsw = isAcctValidsw;
	}

	public String getIsAdcNotifsw() {
		return isAdcNotifsw;
	}

	public void setIsAdcNotifsw(String isAdcNotifsw) {
		this.isAdcNotifsw = isAdcNotifsw;
	}

	public String getIsFraudRptsw() {
		return isFraudRptsw;
	}

	public void setIsFraudRptsw(String isFraudRptsw) {
		this.isFraudRptsw = isFraudRptsw;
	}

	public String getIsPanDupsw() {
		return isPanDupsw;
	}

	public void setIsPanDupsw(String isPanDupsw) {
		this.isPanDupsw = isPanDupsw;
	}

	public String getIsRptsw() {
		return isRptsw;
	}

	public void setIsRptsw(String isRptsw) {
		this.isRptsw = isRptsw;
	}

	public Date getLstActvyDt() {
		return lstActvyDt;
	}

	public void setLstActvyDt(Date lstActvyDt) {
		this.lstActvyDt = lstActvyDt;
	}

	public Date getLstUpdDt() {
		return lstUpdDt;
	}

	public void setLstUpdDt(Date lstUpdDt) {
		this.lstUpdDt = lstUpdDt;
	}

	public String getLstUpdtUserid() {
		return lstUpdtUserid;
	}

	public void setLstUpdtUserid(String lstUpdtUserid) {
		this.lstUpdtUserid = lstUpdtUserid;
	}

	public long getPanNum() {
		return panNum;
	}

	public void setPanNum(long panNum) {
		this.panNum = panNum;
	}

	public long getPriceCatid() {
		return priceCatid;
	}

	public void setPriceCatid(long priceCatid) {
		this.priceCatid = priceCatid;
	}

	public Date getRptDt() {
		return rptDt;
	}

	public void setRptDt(Date rptDt) {
		this.rptDt = rptDt;
	}

	public long getRtnCd() {
		return rtnCd;
	}

	public void setRtnCd(long rtnCd) {
		this.rtnCd = rtnCd;
	}

	public long getStatCd() {
		return statCd;
	}

	public void setStatCd(long statCd) {
		this.statCd = statCd;
	}

}
