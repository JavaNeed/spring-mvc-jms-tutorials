package com.mastercard.ess.eds.core.rule;

import org.apache.log4j.Logger;
import org.easyrules.core.BasicRule;

import com.mastercard.ess.eds.domain.ProcessedRecord;

public class FileGenerationRules extends BasicRule {

	

	private String isADCNotified;
	private String isFraudReported;
	private boolean isAccountValid;
	private String isAccountActive;
	private String isAlreadyReported;

	private String isAccountActiveFlag;
	private String isDuplicateFlag;

	private boolean isAccountValidFlag;
	private String isFraudReportedFlag;
	private String isADCNotifiedFlag;
	private String isAlreadyReportedFlag;

	private ProcessedRecord processedRecord;
	private Object isDuplicate;

	private static Logger logger = Logger.getLogger(FileGenerationRules.class);
	
	public FileGenerationRules() {
		logger.info("FileGenerationRules Instance created");
	}

	public FileGenerationRules(String name) {
		super(name);
		logger.info("FileGenerationRules Instance created with name --" + name);
	}

	public FileGenerationRules(FileGenerationRules rule) {
		super(rule.getName(), rule.getDescription(), rule.getPriority()); // +
																			// ThreadLocalRandom.current().nextLong()
		this.isADCNotified = rule.isADCNotified;
		this.isADCNotifiedFlag = rule.isADCNotifiedFlag;
		this.isAccountValid = rule.isAccountValid;
		this.isAccountValidFlag = rule.isAccountValidFlag;
		this.isAlreadyReported = rule.isAlreadyReported;
		this.isAlreadyReportedFlag = rule.isAlreadyReportedFlag;
		this.isDuplicate = rule.isDuplicate;
		this.isDuplicateFlag = rule.isDuplicateFlag;
		this.isFraudReported = rule.isFraudReported;
		this.isFraudReportedFlag = rule.isFraudReportedFlag;
		this.isAccountActive = rule.isAccountActive;
		this.isAccountActiveFlag = rule.isAccountActiveFlag;

	}

	public String getIsAccountActiveFlag() {
		return isAccountActiveFlag;
	}

	public void setIsAccountActiveFlag(String isAccountActiveFlag) {
		logger.info("From DB, isAccountActiveFlag set to --" + isAccountActiveFlag);
		this.isAccountActiveFlag = isAccountActiveFlag;
	}

	public boolean isAccountValidFlag() {
		return isAccountValidFlag;
	}

	public void setAccountValidFlag(boolean isAccountValidFlag) {
		logger.info("From DB, isAccountValidFlag set to --" + isAccountValidFlag);
		this.isAccountValidFlag = isAccountValidFlag;
	}

	public String getIsFraudReportedFlag() {
		return isFraudReportedFlag;
	}

	public void setIsFraudReportedFlag(String isFraudReportedFlag) {
		logger.info("From DB, isFraudReportedFlag set to --" + isFraudReportedFlag);
		this.isFraudReportedFlag = isFraudReportedFlag;
	}

	public String getIsADCNotifiedFlag() {
		return isADCNotifiedFlag;
	}

	public void setIsADCNotifiedFlag(String isADCNotifiedFlag) {
		logger.info("From DB, isADCNotifiedFlag set to --" + isADCNotifiedFlag);
		this.isADCNotifiedFlag = isADCNotifiedFlag;
	}

	public String getIsAlreadyReportedFlag() {
		return isAlreadyReportedFlag;
	}

	public void setIsAlreadyReportedFlag(String isAlreadyReportedFlag) {
		logger.info("From DB, isAlreadyReportedFlag set to --" + isAlreadyReportedFlag);
		this.isAlreadyReportedFlag = isAlreadyReportedFlag;
	}

	public String getIsDuplicateFlag() {
		return isDuplicateFlag;
	}

	public void setIsDuplicateFlag(String isDuplicateFlag) {
		this.isDuplicateFlag = isDuplicateFlag;

	}

	public void setInputToRule(ProcessedRecord processedRecord) {
		this.processedRecord = processedRecord;

		this.isADCNotified = processedRecord.getIsAccountADCNotified();

		this.isFraudReported = processedRecord.getIsFraudReported();

		this.isAccountActive = processedRecord.getIsAccountActive();

		this.isAccountValid = processedRecord.isAccountValid();

		this.isAlreadyReported = processedRecord.getIsReported();

		this.isDuplicate = processedRecord.getIsDuplicate();

	}

	@Override
	public boolean evaluate() {
		if (logger.isDebugEnabled()) {
			logger.debug("FileGenerationRules | evaluateRule | Enter in method");
		}

		boolean activeCondition = isAccountActiveFlag.equals(isAccountActive);

		boolean validCondition;
		if (isAccountValidFlag == isAccountValid) {
			validCondition = true;
		} else {
			validCondition = false;
		}

		
		if (logger.isDebugEnabled()) {
			logger.debug(" FileGenerationRules | evaluateRule | Exit from method ");
		}
		
		return checkConditions(processedRecord,activeCondition,validCondition);

	}

	private boolean checkConditions(ProcessedRecord processedRecord,boolean activeCondition,boolean validCondition) {
	
		boolean fraudReportedCondition = isFraudReportedFlag.equals(isFraudReported);

		boolean isADCNotifiedCondition = isADCNotifiedFlag.equals(isADCNotified);

		boolean isAlreadyReportedCondition = isAlreadyReportedFlag.equals(isAlreadyReported);

		boolean isDuplicateCondition = isDuplicateFlag.equals(isDuplicate);

		if (activeCondition && validCondition && fraudReportedCondition)
		{
			if(isADCNotifiedCondition && isAlreadyReportedCondition && isDuplicateCondition) {
			logger.info("Rules Evaluation Passed | FileGenerationRules");
			return true;
			}
			
		}
		else {
			processedRecord.setIsFiltered("Y");
		}
		return false;
	}

	@Override
	public void execute() {

		logger.info("Executing FileGenerationRules");

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((isADCNotified == null) ? 0 : isADCNotified.hashCode());
		result = prime
				* result
				+ ((isADCNotifiedFlag == null) ? 0 : isADCNotifiedFlag
						.hashCode());
		result = prime * result
				+ ((isAccountActive == null) ? 0 : isAccountActive.hashCode());
		result = prime
				* result
				+ ((isAccountActiveFlag == null) ? 0 : isAccountActiveFlag
						.hashCode());
		result = prime * result + (isAccountValid ? 1231 : 1237);
		result = prime * result + (isAccountValidFlag ? 1231 : 1237);
		result = prime
				* result
				+ ((isAlreadyReported == null) ? 0 : isAlreadyReported
						.hashCode());
		result = prime
				* result
				+ ((isAlreadyReportedFlag == null) ? 0 : isAlreadyReportedFlag
						.hashCode());
		result = prime * result
				+ ((isDuplicate == null) ? 0 : isDuplicate.hashCode());
		result = prime * result
				+ ((isDuplicateFlag == null) ? 0 : isDuplicateFlag.hashCode());
		result = prime * result
				+ ((isFraudReported == null) ? 0 : isFraudReported.hashCode());
		result = prime
				* result
				+ ((isFraudReportedFlag == null) ? 0 : isFraudReportedFlag
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		FileGenerationRules other = (FileGenerationRules) obj;
		if (isADCNotified == null) {
			if (other.isADCNotified != null)
				return false;
		} else if (!isADCNotified.equals(other.isADCNotified))
			return false;
		if (isADCNotifiedFlag == null) {
			if (other.isADCNotifiedFlag != null)
				return false;
		} else if (!isADCNotifiedFlag.equals(other.isADCNotifiedFlag))
			return false;
		if (isAccountActive == null) {
			if (other.isAccountActive != null)
				return false;
		} else if (!isAccountActive.equals(other.isAccountActive))
			return false;
		if (isAccountActiveFlag == null) {
			if (other.isAccountActiveFlag != null)
				return false;
		} else if (!isAccountActiveFlag.equals(other.isAccountActiveFlag))
			return false;
		if (isAccountValid != other.isAccountValid)
			return false;
		if (isAccountValidFlag != other.isAccountValidFlag)
			return false;
		if (isAlreadyReported == null) {
			if (other.isAlreadyReported != null)
				return false;
		} else if (!isAlreadyReported.equals(other.isAlreadyReported))
			return false;
		if (isAlreadyReportedFlag == null) {
			if (other.isAlreadyReportedFlag != null)
				return false;
		} else if (!isAlreadyReportedFlag.equals(other.isAlreadyReportedFlag))
			return false;
		if (isDuplicate == null) {
			if (other.isDuplicate != null)
				return false;
		} else if (!isDuplicate.equals(other.isDuplicate))
			return false;
		if (isDuplicateFlag == null) {
			if (other.isDuplicateFlag != null)
				return false;
		} else if (!isDuplicateFlag.equals(other.isDuplicateFlag))
			return false;
		if (isFraudReported == null) {
			if (other.isFraudReported != null)
				return false;
		} else if (!isFraudReported.equals(other.isFraudReported))
			return false;
		if (isFraudReportedFlag == null) {
			if (other.isFraudReportedFlag != null)
				return false;
		} else if (!isFraudReportedFlag.equals(other.isFraudReportedFlag))
			return false;
		return true;
	}

}
