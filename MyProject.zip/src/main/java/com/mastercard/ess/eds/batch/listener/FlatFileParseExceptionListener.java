package com.mastercard.ess.eds.batch.listener;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.listener.ItemListenerSupport;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;

import com.mastercard.ess.eds.core.service.EDSSourceService;
import com.mastercard.ess.eds.domain.RawRecord;

/**
 * This class is responsible for creating error file with file name being parsed
 * if it contains erroneous record . *
 */
public class FlatFileParseExceptionListener extends
		ItemListenerSupport<RawRecord, RawRecord> implements
		StepExecutionListener {
	
	private Logger logger = Logger
			.getLogger(FlatFileParseExceptionListener.class);

	@Autowired
	private EDSSourceService edsSourceService;

	
	@Value("${errorFile.location}")
	private String errFileLoc;
	
	private String fileName;

	public FlatFileParseExceptionListener() {
		super();
	}

	public FlatFileParseExceptionListener(
			EDSSourceService edsSourceService) {
		super();
		this.edsSourceService = edsSourceService;
	}

	public String getErrFileLoc() {
		return errFileLoc;
	}

	public void setErrFileLoc(String errFileLoc) {
		this.errFileLoc = errFileLoc;
	}
	/*
	 * This method will get called before every step of the batch. while invalid
	 * entry encountered in parsing input file and the invalid input is logged
	 * into a error file . eds source table is updated with error file name
	 * and location.
	 */
	@Override
	public void onReadError(Exception e) {

		if (e instanceof FlatFileParseException) {

			if (logger.isDebugEnabled()) {
				logger.debug("Enter in method : onReadError ");
			}

			FlatFileParseException objFlatFileParseException = (FlatFileParseException) e;
			StringBuffer errorMessage = new StringBuffer();
			errorMessage
					.append("An error occured while processing line number -- "
							+ objFlatFileParseException.getLineNumber()
							+ " Below is the faulty input.\n");
			errorMessage.append(objFlatFileParseException.getInput() + "\n");

			edsSourceService.updateErrorDetails(fileName);

			File file = new File(errFileLoc + fileName + ".err");
			if (!file.exists()) {
				try {
					file.createNewFile();
				} catch (IOException ioException) {
					logger.error("Exception in creating error log file"
							+ ioException);
				}
			}
			
			
			try (FileWriter fileWriter  = new FileWriter(file.getAbsoluteFile(), true);
					BufferedWriter bufferedWriter = new BufferedWriter(fileWriter))
			{								
				
				bufferedWriter.write(errorMessage.toString());
				bufferedWriter.flush();
			} catch (IOException ioException) {
				logger.error("Exception in writing into error log file"
						+ ioException);
			}

			if (logger.isDebugEnabled()) {
				logger.debug("Exit from method : onReadError ");
			}
		}
	}

	/*
	 * This method is called before loadRawRecords step is executed it
	 * initializes the file name with the file being parsed
	 */
	@Override
	public void beforeStep(StepExecution stepExecution) {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : beforeStep ");
		}

		String file = stepExecution.getJobParameters().getString("input.file");
		FileSystemResource resource = new FileSystemResource(file);
		fileName = resource.getFile().getName();

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : beforeStep ");
		}
	}

	public String getFileName() {
		return fileName;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {

		return null;
	}

}
