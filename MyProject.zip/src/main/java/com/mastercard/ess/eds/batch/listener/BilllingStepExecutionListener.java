package com.mastercard.ess.eds.batch.listener;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import com.mastercard.ess.eds.batch.config.FileStatus;
import com.mastercard.ess.eds.billing.dao.BillDataDAO;
import com.mastercard.ess.eds.billing.util.CSVWriterUtils;
import com.mastercard.ess.eds.billing.util.RenewalDateUtil;
import com.mastercard.ess.eds.billing.vo.FileItemVO;
import com.mastercard.ess.eds.core.util.EDSProcessStatus;
import com.mastercard.ess.eds.domain.FileDetails;

public class BilllingStepExecutionListener implements StepExecutionListener{

	private static final String CRTE_USER_ID = "CRTE_USER_ID";

	private static final String ICA_NUM = "ICA_NUM";

	private static final String RNWL_DT = "RNWL_DT";

	private static final String CRTE_DT = "CRTE_DT";

	private static final String CUST_MASS_ONBOARDING = "custMassOnboarding";

	private static Logger logger = Logger.getLogger(BilllingStepExecutionListener.class);

	private static final String JOB_NAM = "billDataBatchJob";

	private List<FileDetails> fileStatusList = null ;

	@Autowired
	private FileItemVO fileItemVO;

	@Autowired
	private BillDataDAO billDataDao;

	@Autowired
	private CSVWriterUtils csvWriterUtils;

	@Autowired
	private RenewalDateUtil renewalDateUtil; 

	@Value("${billingfiles.directory}")
	private String location;

	@Value("${billing.trialPeriodInMonths}")
	private int trialPeriod;


	private BigDecimal jobInstanceId;
	private ExecutionContext executionContext;
	private String jobInstanceName;

	// for Junit
	public BilllingStepExecutionListener(BillDataDAO billDataDao , RenewalDateUtil renewalDateUtil) {
		this.billDataDao = billDataDao;
		this.renewalDateUtil=renewalDateUtil;
	}

	public void setCreateCsv(CSVWriterUtils csvWriterUtils) {
		this.csvWriterUtils = csvWriterUtils;

	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		logger.debug("BilllingStepExecutionListener before Step");

	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {

		String billingFileName = null;
		int skipped = stepExecution.getSkipCount();
		List<Map<String, Object>> childParentMapList = (List<Map<String, Object>>) stepExecution.getJobExecution().getExecutionContext().get("listOfEligibleIca");

		//There were no PANs to be billed, check if there are new customers onboraded
		//and generate billing file if needed.
		if(skipped == 0) {
			logger.info("No new PANs to be billed this week, checking new ICAs for renewal");
			List<String> billableICAs = billDataDao.getBillableICAList(childParentMapList);

			if ( !billableICAs.isEmpty()) {
				logger.info("New " + billableICAs.size() +" ICAs for renewal found ");
				billingFileName = csvWriterUtils.createICABillingFile(billableICAs);
				FileDetails fileDetails=new FileDetails();
				try{
					fileStatusList=getFileStatus();
					fileDetails.setFileName(billingFileName);
					fileDetails.setStatus(FileStatus.GEN_SUCCESS.getStatus());
					saveGenReportDetails(billingFileName);
				}catch (Exception e) {
					fileDetails.setErrorDetails(e.getMessage());
					fileDetails.setStatus(FileStatus.GEN_FAILURE.getStatus());
					fileDetails.setFileName(null);
					logger.error("Exception occured while creating a file" + e.getMessage());
				}
				fileStatusList.add(fileDetails);
				this.executionContext.put("fileStatusList", fileStatusList );
			}

			updateRenewalDate(childParentMapList);

		}
		return stepExecution.getExitStatus();
	}

	/**
	 * In updateRenewalDate we will update renewable date as below:
	 * A)If createUsetId is 'custMassOnboarding' 
	 * 1)If renewalDate is null     : Then renewabledate will be ( createDate + trial period (2 months) ) 
	 * 2)If renewalDate is not null : Then renewabledate will be ( renewabledate + 365 ) 
	 * 
	 * B)If createUsetId  is not 'custMassOnboarding'
	 * 1)If renewalDate is null     : Then renewabledate will be ( createDate + 365 )   
	 * 2)If renewalDate is not null : Then renewabledate will be ( renewabledate + 365 )   
	 * 
	 * @param childParentMapList
	 */
	private void updateRenewalDate(List<Map<String, Object>> childParentMapList) {

		if(childParentMapList!= null) {

			logger.info("BilllingStepExecutionListener | updateRenewalDate | updateRenewalDate starts");

			renewalDateUtil.updateRenewalDate( childParentMapList, JOB_NAM );

			logger.info("BilllingStepExecutionListener | updateRenewalDate | updateRenewalDate Ends");

		}
	}

	@SuppressWarnings("unchecked")
	private synchronized List<FileDetails> getFileStatus() {
		fileStatusList = (List<FileDetails>) this.getExecutionContext().get("fileStatusList");

		if(fileStatusList==null ){
			fileStatusList = new CopyOnWriteArrayList<>();
		}
		return fileStatusList;
	}

	@SuppressWarnings("unchecked")
	private void saveGenReportDetails(String billingFileName) {
		Set<String> billingFileNames;
		if (billingFileName != null) {
			fileItemVO.setJob_instnce_id(jobInstanceId.intValue());
			fileItemVO.setCrte_user_id(JOB_NAM);
			fileItemVO.setFile_loc_txt(location);
			fileItemVO.setFile_nam(billingFileName);
			fileItemVO.setStat_cd(EDSProcessStatus.GENERATED.getStatusCode());
			billDataDao.insertFileDetails(fileItemVO);

			if(executionContext != null  && StringUtils.isNotBlank(billingFileName)){
				if(executionContext.get("billingFileNames") == null) {
					billingFileNames = new HashSet<String>();
					billingFileNames.add(billingFileName);
					executionContext.put("billingFileNames", billingFileNames);
				} else {
					billingFileNames = (Set<String>) executionContext.get("billingFileNames");
					billingFileNames.add(billingFileName);
					executionContext.put("billingFileNames", billingFileNames);
				}
			}
		}
	}

	public ExecutionContext getExecutionContext() {
		return executionContext;
	}

	public void setExecutionContext(ExecutionContext executionContext) {
		this.executionContext = executionContext;
	}

	public BigDecimal getJobInstanceId() {
		return jobInstanceId;
	}

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}

	public String getJobInstanceName() {
		return jobInstanceName;
	}

	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}

}
