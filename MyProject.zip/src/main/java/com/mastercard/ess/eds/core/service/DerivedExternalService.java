package com.mastercard.ess.eds.core.service;

import java.math.BigDecimal;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.dao.DerivedExternalDao;
import com.mastercard.ess.eds.core.dao.EDSCPPRulesDao;
import com.mastercard.ess.eds.core.util.EDSSourceRuleDataCache;
import com.mastercard.ess.eds.core.util.RuleCatCdRecord;
import com.mastercard.ess.eds.domain.ProcessedRecord;

@Component
public class DerivedExternalService {

	@Autowired
	DerivedExternalDao derivedExternalDao;

	@Autowired
	private EDSCPPRulesDao eDSCPPRulesDao;

	@Autowired
	private EDSSourceRuleDataCache eDSSourceRuleDataCache;

	private Logger logger = Logger.getLogger(DerivedExternalService.class);

	public DerivedExternalService(DerivedExternalDao derivedExternalDao,EDSCPPRulesDao eDSCPPRulesDao,EDSSourceRuleDataCache eDSSourceRuleDataCache) {
		super();
		this.derivedExternalDao = derivedExternalDao;
		this.eDSCPPRulesDao = eDSCPPRulesDao;
		this.eDSSourceRuleDataCache = eDSSourceRuleDataCache;
	}

	public void updateExternalDerivedForPricingCategory(BigDecimal srcDataKey, ProcessedRecord processedRecord) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in updateExternalDerivedForPricingCategory");
		}
		RuleCatCdRecord ruleCatCdRecord = eDSSourceRuleDataCache.getResult(srcDataKey.longValue());
		logger.info("ruleCatCdRecord.getCppRuleId() = " + ruleCatCdRecord.getCppRuleId() + ", ruleCatCdRecord.getCategoryCode() = " + ruleCatCdRecord.getCategoryCode());
		processedRecord.setIsExternal("Y");
		processedRecord.setIsDerived("Y");
		String catogeryType = ruleCatCdRecord.getCategoryCode();
		if (!(StringUtils.isNotBlank(catogeryType) && catogeryType.equalsIgnoreCase("E"))) {
			processedRecord.setIsExternal("N");
		}

		logger.info("IsDerived = " + processedRecord.getIsDerived() + "IsExternal = " + processedRecord.getIsExternal());

		if (logger.isDebugEnabled()) {
			logger.debug("Exiting updateExternalDerivedForPricingCategory");
		}
	}

}
