package com.mastercard.ess.eds.batch.tasklet;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.dao.CustomerPanReportDao;
import com.mastercard.ess.eds.core.util.EDSProcessStatus;

public class UpdateSendCustomerBatchFileTasklet implements Tasklet, InitializingBean{

	private static Logger logger = Logger.getLogger(UpdatePurgeFileStatusTasklet.class);

	@Autowired
	private CustomerPanReportDao customerPanReportDao;

	@Override
	public void afterPropertiesSet() throws Exception {
		// NOOP
	}

	@Override
	public RepeatStatus execute(StepContribution arg0, ChunkContext chunkContext)
			throws Exception {
		logger.info("Enter into the method UpdateSendCustomerBatchFileTasklet");
		String fileName = (String) chunkContext.getStepContext()
				.getJobParameters().get("input.file");
		String statusCode = (String) chunkContext.getStepContext().getJobParameters().get("input.status");
		logger.info("customer batch file sent to GFT : " + fileName);
		if(statusCode.equals("0")){
			customerPanReportDao.updateCustomerFileStatus(fileName, EDSProcessStatus.SENT.getStatusCode(), "customerFileGenerationJob");
		} else {
			customerPanReportDao.updateCustomerFileStatus(fileName, EDSProcessStatus.FAILED.getStatusCode(), "customerFileGenerationJob");
		}

		logger.info("Exit into the method UpdateSendCustomerBatchFileTasklet"); 
		return RepeatStatus.FINISHED;
	}
	
	//for junit
		public void setCustomerPanReportDao(CustomerPanReportDao customerPanReportDao) {
			this.customerPanReportDao = customerPanReportDao;
		}

}
