package com.mastercard.ess.eds.core.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.mapper.CPPAccountsViewRowMapper;
import com.mastercard.ess.eds.domain.CPPRecord;

@Component
public class CPPAccountDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
	private String FETCH_VENDOR_PROVIDED_ACCOUNTS = "SELECT PRCSS.PAN_NUM, prcss.CRTE_DT FROM EDS_PRCSS_DATA PRCSS,"+
	         " EDS_SRC_DATA SRCDATA, EDS_SRC SRC, EDS_SRC_TYPE TYP WHERE PRCSS.CRTE_DT > (SYSDATE - 28) "+
	         " AND PRCSS.CRTE_DT < (SYSDATE + 1) AND PRCSS.EDS_SRC_DATA_ID = SRCDATA.EDS_SRC_DATA_ID AND PRCSS.PAN_DUP_SW = 'N'"+
	         " AND PRCSS.BRND_PRDCT_CD NOT IN "+
	         "        (SELECT BRND_PRDCT_CD FROM EDS_EXCLD_BRND_PRCT)"+
	         " AND SRCDATA.EDS_SRC_ID = SRC.EDS_SRC_ID AND SRC.EDS_SRC_TYPE_ID = TYP.EDS_SRC_TYPE_ID "
	         + " AND TYP.EXTRL_SW = 'Y' AND PRCSS.ACCT_ACTV_SW = 'Y'";

	public List<CPPRecord> fetchVendorProvidedAccounts() {
		
		CPPAccountsViewRowMapper cppAccountsViewRowMapper = new CPPAccountsViewRowMapper();
		List<CPPRecord> cppRecords = jdbcTemplate.query(FETCH_VENDOR_PROVIDED_ACCOUNTS, cppAccountsViewRowMapper);
		return cppRecords;

	}

}
