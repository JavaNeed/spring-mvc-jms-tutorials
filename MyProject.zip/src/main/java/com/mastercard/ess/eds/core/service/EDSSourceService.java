package com.mastercard.ess.eds.core.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.dao.EDSSourceDao;
import com.mastercard.ess.eds.domain.RawRecord;

@Component
public class EDSSourceService {

	@Autowired
	EDSSourceDao edsSourceDao;

	public EDSSourceService() {
		super();
	}

	public EDSSourceService(EDSSourceDao edsSourceDao) {
		super();
		this.edsSourceDao = edsSourceDao;
	}

	public void createSourceRecord(String fileName, String jobName, BigDecimal jobInstanceID, int status,
			String errorDetails, int srcTypeId) {
		edsSourceDao.createSourceRecord(fileName, jobName, jobInstanceID, status, errorDetails, srcTypeId);
	}

	public void updateErrorDetails(String fileName) {
		edsSourceDao.updateErrorDetails(fileName);

	}

	public void updateSourceStatus(String fileName) {
		edsSourceDao.updateSourceStatus(fileName);

	}

	public void updateFileStatusPreProcessing( BigDecimal jobInstanceId) {
		edsSourceDao.updateFileStatusPreProcessing( jobInstanceId);
	}

	public void updateFileStatusPostProcessing() {
		edsSourceDao.updateFileStatusPostProcessing();
	}

	public void setFileName(String fileName) {
		edsSourceDao.setFileName(fileName);

	}

	public void setJobInstanceName(String jobInstanceName) {
		edsSourceDao.setJobInstanceName(jobInstanceName);

	}

	public List<Map<String, Object>> getQueuedFiles() {

		return edsSourceDao.getQueuedFiles();
	}

	public void updateSourceStatus(String fileName, BigDecimal jobInstanceId) {
		edsSourceDao.updateSourceStatus(fileName, jobInstanceId);

	}

	public void updateSourceForMissingKey(String zipFileName) {
		edsSourceDao.updateSourceForMissingKey(zipFileName);
	}

	public void createSourceRecord(String fileName, String jobName, BigDecimal jobInstanceID, int status,
			String errorDetails, int srcTypeId, String fileLocation) {
		edsSourceDao.createSourceRecord(fileName, jobName, jobInstanceID, status, errorDetails, srcTypeId, fileLocation);
	}

}
