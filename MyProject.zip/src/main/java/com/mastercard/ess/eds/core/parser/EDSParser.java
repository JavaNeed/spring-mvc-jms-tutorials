package com.mastercard.ess.eds.core.parser;

import javax.crypto.SecretKey;


import org.springframework.batch.item.file.transform.FieldSet;

import com.mastercard.ess.eds.domain.RawRecord;
@FunctionalInterface
public interface EDSParser {
	
	public RawRecord parseAndDecrypt(FieldSet fs , SecretKey key, String transform, String fieldsToDecrypt) throws Exception ;
}
