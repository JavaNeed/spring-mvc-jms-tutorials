package com.mastercard.ess.eds.core.util;

public class GlobalConstants {
	
	private GlobalConstants(){
		
	}
	
	
	public static final String DATE_TIME_FORMAT = "dd-MM-yyyy HH:mm:ss";
	public static final String DATE_TIME_FORMAT_PAN_PROCESS = "yyyy-MM-dd:HH:mm:ss";
	
	//added for JUnit
	public static String getDateTimeFormatField(){
		
		return DATE_TIME_FORMAT;
	}

}
