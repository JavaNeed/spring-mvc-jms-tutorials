package com.mastercard.ess.eds.batch.tasklet;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.service.FraudReportService;

public class FraudSubscribedBeforeCountTasklet implements Tasklet  {

	private static Logger logger = Logger.getLogger(FraudSubscribedBeforeCountTasklet.class);
	
	private static String SUBSCRIBED_BEFORE_COUNT = "SUBSCRIBED_BEFORE_COUNT" ;
	
	@Autowired
	private FraudReportService fraudReportService;
	
	
	//required for writing junit
	public FraudSubscribedBeforeCountTasklet() {
		//NOOP
	}

	//required for writing junit
	public FraudSubscribedBeforeCountTasklet(  FraudReportService fraudReportService) {
		this.fraudReportService = fraudReportService;
	}
	
	
	public RepeatStatus execute(StepContribution stepExecution, ChunkContext chunkContext)
			throws Exception {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : FraudSubscribedBeforeCountTasklet - execute ");
		}
		
		
		Map<String, String>  beforeSubsFraudCt = fraudReportService.getBeforeCountSubscribedICA();
		 
		
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(SUBSCRIBED_BEFORE_COUNT, beforeSubsFraudCt);
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit in method : FraudSubscribedBeforeCountTasklet - execute ");
		}
		return RepeatStatus.FINISHED;
	}

}
