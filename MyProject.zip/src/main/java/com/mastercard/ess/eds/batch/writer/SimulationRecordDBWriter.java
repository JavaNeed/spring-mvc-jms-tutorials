package com.mastercard.ess.eds.batch.writer;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemWriter;

import com.mastercard.ess.eds.domain.AuthDebitPanDetailRecord;

/**
 *  This writer class populates the unique sets of AuthDebitPanDetailRecord in context. 
 * @author e070836
 * @version 1.0
 * @date : Dec 29, 2017
 */

public class SimulationRecordDBWriter implements ItemWriter<List<AuthDebitPanDetailRecord>> {


	private static Logger logger = Logger.getLogger(SimulationRecordDBWriter.class);

	private String jobInstanceName;
	private BigDecimal jobInstanceId;
	private ExecutionContext executionContext;
	
	public SimulationRecordDBWriter() {
		super();
	}
	

	/**
	 *  This override method populates the list of authDebitPanDetailRecords in the context by removing duplicates.
	 *  @param  authDebitPanDetailRecords
	 *  @return 
	 *  @exception Exception
	 */
	@Override
	public void write(List<? extends List<AuthDebitPanDetailRecord>> authDebitPanDetailRecords) throws Exception {
		
		logger.info("Enter in SimulationRecordDBWriter write method ");

		if (authDebitPanDetailRecords !=null && !authDebitPanDetailRecords.isEmpty()) {
			Set<AuthDebitPanDetailRecord> simulationSet =   (Set<AuthDebitPanDetailRecord>) this.executionContext.get("cppSimulationSet");
			if(simulationSet == null){
				simulationSet = new HashSet<>();
			}
			for (List<AuthDebitPanDetailRecord> authDebitlist : authDebitPanDetailRecords) {
				if(authDebitlist!=null && !authDebitlist.isEmpty()){
					logger.info("authDebitlist.size" + authDebitlist.size());
					simulationSet.addAll(authDebitlist);
				}
				logger.info("simulationMapCount.size()" + simulationSet.size());
			}
			
			this.executionContext.put("cppSimulationSet", simulationSet );
		}
		 
		logger.info("Exit from SimulationRecordDBWriter write method ");
	}

	
 
	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}

	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}

	public BigDecimal getJobInstanceId() {
		return jobInstanceId;
	}

	// Added for JUnit
	public String getJobInstanceName(){
		return jobInstanceName;
	}
	 
	public ExecutionContext getExecutionContext() {
		return executionContext;
	}

	public void setExecutionContext(ExecutionContext executionContext) {
		this.executionContext = executionContext;
	}


	 

}
