package com.mastercard.ess.eds.core.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.service.CPPReportService;
import com.mastercard.ess.eds.domain.CPPReportInfo;

@Component
public class CPPReportGenerator {

	@Value("${cppDetailReport.path}")
	private String cppDetailReportPath;

	@Value("${cppSummaryReport.path}")
	private String cppSummaryReportPath;

	@Autowired
	CPPReportService cppReportService;

	private static Logger logger = Logger.getLogger(CPPReportGenerator.class);

	public CPPReportGenerator(String cppDetailReportPath2,
			String cppSummaryReportPath2, CPPReportService cPPReportService2) {
		this.cppDetailReportPath = cppDetailReportPath2;
		this.cppReportService = cPPReportService2;
		this.cppSummaryReportPath = cppSummaryReportPath2;
	}

	public CPPReportGenerator() {
		super();
	}

	private FileInputStream getFileInputStream(String filePath)
			throws FileNotFoundException {
		return new FileInputStream(new File(filePath));
	}

	private FileOutputStream getFileoutputStream(String filePath)
			throws FileNotFoundException {
		return new FileOutputStream(new File(filePath));
	}

	private Workbook getWorkbook(FileInputStream fis, boolean fileExists)
			throws IOException, EncryptedDocumentException,
			InvalidFormatException {
		return fileExists ? WorkbookFactory.create(fis) : new XSSFWorkbook();
	}

	private Sheet createSheet(Workbook workbook, String name) {
		return workbook.createSheet(name);
	}

	private Row createRow(Sheet spreadsheet, int rowNum) {
		return spreadsheet.createRow(rowNum);
	}

	private Cell createCellWithValue(Row row, int cellNo, String value,
			Workbook wb) {

		XSSFCellStyle style = (XSSFCellStyle) wb.createCellStyle();
		style.setFillForegroundColor(new XSSFColor(new java.awt.Color(230, 230,
				242)));
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		Font f = wb.createFont();
		f.setBoldweight(Font.BOLDWEIGHT_BOLD);
		f.setFontHeightInPoints((short) 12);
		style.setFont(f);

		XSSFCellStyle style1 = (XSSFCellStyle) wb.createCellStyle();
		style1.setFillForegroundColor(new XSSFColor(new java.awt.Color(202,
				233, 233)));
		style1.setFillPattern(CellStyle.SOLID_FOREGROUND);
		Font f1 = wb.createFont();
		f1.setBoldweight(Font.BOLDWEIGHT_BOLD);
		f1.setFontHeightInPoints((short) 10);
		style1.setFont(f1);

		XSSFCellStyle style2 = (XSSFCellStyle) wb.createCellStyle();
		Font f2 = wb.createFont();
		f2.setBoldweight(Font.BOLDWEIGHT_BOLD);
		f2.setFontHeightInPoints((short) 10);
		style2.setFont(f2);

		Cell c = row.createCell(cellNo);

		String[] styleArray =  { "Location ID", "Merchant Name",
				"Merchant Country", "Issuer Country", "Cards Used",
				"Percent of Cards for Country", "LocalTransactionAmount" };
		List<String> styleList = Arrays.asList(styleArray);

		if (styleList.contains(value)) {
			c.setCellStyle(style1);
		}

		if (value != null && value.contains("Channel")) {
			c.setCellStyle(style);
		}

		if (value != null
				&& (value.contains("Date and time of Report Run")
						|| value.contains("Transaction Date:") || value
							.contains("Vendor data Date:"))) {
			c.setCellStyle(style2);
		}

		c.setCellValue(value);
		return c;
	}

	private static void writeToFile(Workbook workbook, FileOutputStream fos)
			throws IOException {
		workbook.write(fos);

	}

	private Sheet getSheet(Workbook wb, String sheetName, boolean fileExists)
			throws IOException {

		if (fileExists) {
			List<String> sheetNames = new ArrayList<String>();
			for (int i = 0; i < wb.getNumberOfSheets(); i++) {
				sheetNames.add(wb.getSheetName(i));
			}
			if (sheetNames.indexOf(sheetName) == -1) {
				this.createSheet(wb, sheetName);
			}

		} else {
			this.createSheet(wb, sheetName);
		}
		return wb.getSheet(sheetName);

	}

	/**
	 * @param cppReportInfos
	 *            : data to be exported to excel file
	 * @param reportType
	 *            : details report or summary report this method populates the
	 *            data fetched from EDS_CPP_TRAN_SUMM based on grouping
	 * @param jobInstanceName
	 * @param jobInstanceId
	 */
	public synchronized void writeToCPPReport(
			List<? extends CPPReportInfo> cppReportInfos, String reportType,
			BigDecimal jobInstanceId, String jobInstanceName , String countyCode) {

		if (logger.isInfoEnabled()) {
			logger.info("Enter in method : writeToCPPReport | CPPReportGenerator ");
		}
		
		logger.info("countyCode" + countyCode);
		logger.info("cppReportInfos" + cppReportInfos);
		logger.info("reportType" + reportType);
		logger.info("jobInstanceId" + jobInstanceId);
		logger.info("jobInstanceName" + jobInstanceName);
		
		String filePath = "";
		String sheetName = "";
		if ("details".equals(reportType)) {
			filePath = cppDetailReportPath;
			sheetName = countyCode ;
		} else if ("summary".equals(reportType)) {
			filePath = cppSummaryReportPath;
			sheetName = countyCode;
		}

		Calendar now = Calendar.getInstance();
		String currentDate = (now.get(Calendar.MONTH) + 1) + "-"
				+ now.get(Calendar.DATE) + "-" + now.get(Calendar.YEAR);

		now.add(Calendar.DATE, -28);

		String fromVendortDate = (now.get(Calendar.MONTH) + 1) + "-"
				+ now.get(Calendar.DATE) + "-" + now.get(Calendar.YEAR);

		now.add(Calendar.DATE, -32);

		String fromTxnDate = (now.get(Calendar.MONTH) + 1) + "-"
				+ now.get(Calendar.DATE) + "-" + now.get(Calendar.YEAR);

		filePath = filePath + currentDate + ".xlsx";

		File file = null;
		FileInputStream fis = null;
		boolean fileExists = false;
		FileOutputStream fos = null;
		Workbook wb = null;
		Sheet sheet = null;
		Integer keyRow = 0;
		try {

			file = new File(filePath);
			if (file.exists()) {
				fileExists = true;
				fis = getFileInputStream(filePath);
			} else {
				cppReportService.writeCPPReportDetails(filePath, jobInstanceId,
						jobInstanceName);
			}
			wb = getWorkbook(fis, fileExists);
			if (fis != null) {
				fis.close();
			}
			fos = getFileoutputStream(filePath);
			sheet = getSheet(wb, sheetName, fileExists);
			int existingRows = sheet.getPhysicalNumberOfRows();
			// Create row object
			Row row;
			// This data needs to be written (Object[])
			Map<Integer, Object[]> rowEntry = new TreeMap<Integer, Object[]>();

			rowEntry.put(keyRow++, new Object[] {
					"Date and time of Report Run", new Date().toString() });

			rowEntry.put(keyRow++, new Object[] { "Vendor data Date:",
					fromVendortDate, " to ", currentDate });

			rowEntry.put(keyRow++, new Object[] { "Transaction Date:",
					fromTxnDate, " to ", currentDate });

			rowEntry.put(keyRow++, new Object[] { "" });
			rowEntry.put(keyRow++, new Object[] { "" });
			rowEntry.put(keyRow++, new Object[] { "" });

			writeIssuerDetails(cppReportInfos, reportType, sheetName, keyRow,
					rowEntry);

			// Iterate over data and write to sheet
			Set<Integer> keyid = rowEntry.keySet();
			int rowid = existingRows;

			for (Integer key : keyid) {
				row = createRow(sheet, rowid++);
				Object[] objectArr = rowEntry.get(key);
				createCellWithValue(wb, row, objectArr);
			}

			writeToFile(wb, fos);

		} catch (IOException | EncryptedDocumentException
				| InvalidFormatException e) {
			logger.error("Exception : " + e);

		} finally {
			fileClose(fis, fos, wb);
		}

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method :  writeToCPPReport | CPPReportGenerator");
		}

	}

	/**
	 * @param wb
	 * @param row
	 * @param objectArr
	 */
	private void createCellWithValue(Workbook wb, Row row, Object[] objectArr) {
		int cellid = 0;
		for (Object obj : objectArr) {
			if (obj != null) {
				createCellWithValue(row, cellid++, (String) obj, wb);
			} else {
				createCellWithValue(row, cellid++, "", wb);
			}

		}
	}

	/**
	 * @param fis
	 * @param fos
	 * @param wb
	 */
	private void fileClose(FileInputStream fis, FileOutputStream fos,
			Workbook wb) {
		if (null != fis) {
			try {
				fis.close();
			} catch (IOException e) {
				logger.error(e);
			}
		}
		if (null != fos) {
			try {
				fos.flush();
				fos.close();
			} catch (IOException e) {
				logger.error(e);
			}
		}
		if (null != wb) {
			try {
				wb.close();
			} catch (IOException e) {
				logger.error(e);
			}
		}
	}

	/**
	 * @param cppReportInfos
	 * @param reportType
	 * @param sheetName
	 * @param keyRow
	 * @param rowEntry
	 */
	private void writeIssuerDetails(
			List<? extends CPPReportInfo> cppReportInfos, String reportType,
			String sheetName, Integer keyRow, Map<Integer, Object[]> rowEntry) {
		if ("details".equals(reportType)) {
			writeIssuerDetailsToReport(cppReportInfos, sheetName, keyRow,
					rowEntry);
		} else if ("summary".equals(reportType)) {
			writeIssuerDetailsToSummaryReport(cppReportInfos, sheetName,
					keyRow, rowEntry);
		}
	}

	private void writeIssuerDetailsToReport(
			List<? extends CPPReportInfo> cppReportInfos, String sheetName,
			Integer keyRow, Map<Integer, Object[]> rowEntry) {
		rowEntry.put(keyRow++, new Object[] { "Merchant Country=" + sheetName
				+ "| Channel=CP" });

		rowEntry.put(keyRow++, new Object[] { "Location ID", "Merchant Name",
				"Merchant Country", "Issuer Country", "LocalTransactionAmount",
				"Cards Used", "Percent of Cards for Country" });

		for (CPPReportInfo cppReportInfo : cppReportInfos) {

			if ("CP".equals(cppReportInfo.getTransactionChannel())) {
				logger.info("cppReportInfo.getTransactionChannel()  :: "
						+ cppReportInfo.getTransactionChannel());
				rowEntry.put(
						keyRow++,
						new Object[] {
								cppReportInfo.getLocationId(),
								cppReportInfo.getMerchantName(),
								cppReportInfo.getMerchantCountryCode(),
								cppReportInfo.getIssuerCountryCode(),
								Float.toString(cppReportInfo
										.getLocalTransactionAmount()),
								Long.toString(cppReportInfo.getCardsUsedCount()),
								Double.toString(cppReportInfo
										.getCardsCountryPercentage()) + "%" });
			}
		}
		rowEntry.put(keyRow++, new Object[] { "" });
		rowEntry.put(keyRow++, new Object[] { "" });
		rowEntry.put(keyRow++, new Object[] { "" });
		rowEntry.put(keyRow++, new Object[] { "Merchant Country=" + sheetName
				+ "| Channel=CNP" });

		rowEntry.put(keyRow++, new Object[] { "Location ID", "Merchant Name",
				"Merchant Country", "Issuer Country", "LocalTransactionAmount",
				"Cards Used", "Percent of Cards for Country" });

		for (CPPReportInfo cppReportInfo : cppReportInfos) {

			if ("CNP".equals(cppReportInfo.getTransactionChannel())) {
				rowEntry.put(
						keyRow++,
						new Object[] {
								cppReportInfo.getLocationId(),
								cppReportInfo.getMerchantName(),
								cppReportInfo.getMerchantCountryCode(),
								cppReportInfo.getIssuerCountryCode(),
								Float.toString(cppReportInfo
										.getLocalTransactionAmount()),
								Long.toString(cppReportInfo.getCardsUsedCount()),
								Double.toString(cppReportInfo
										.getCardsCountryPercentage()) + "%" });
			}
		}
	}

	private void writeIssuerDetailsToSummaryReport(
			List<? extends CPPReportInfo> cppReportInfos, String sheetName,
			Integer keyRow, Map<Integer, Object[]> rowEntry) {
		rowEntry.put(keyRow++, new Object[] { "Issuer Country=" + sheetName
				+ "| Channel=CP" });

		rowEntry.put(keyRow++, new Object[] { "Location ID", "Merchant Name",
				"Merchant Country", "Issuer Country", "Cards Used",
				"Percent of Cards for Country" });

		for (CPPReportInfo cppReportInfo : cppReportInfos) {

			if ("CP".equals(cppReportInfo.getTransactionChannel())) {
				logger.info("cppReportInfo.getTransactionChannel()  :: "
						+ cppReportInfo.getTransactionChannel());
				rowEntry.put(
						keyRow++,
						new Object[] {
								cppReportInfo.getLocationId(),
								cppReportInfo.getMerchantName(),
								cppReportInfo.getMerchantCountryCode(),
								cppReportInfo.getIssuerCountryCode(),
								Long.toString(cppReportInfo.getCardsUsedCount()),
								Double.toString(cppReportInfo
										.getCardsCountryPercentage()) + "%" });
			}
		}
		rowEntry.put(keyRow++, new Object[] { "" });
		rowEntry.put(keyRow++, new Object[] { "" });
		rowEntry.put(keyRow++, new Object[] { "" });
		rowEntry.put(keyRow++, new Object[] { "Issuer Country=" + sheetName
				+ "| Channel=CNP" });

		rowEntry.put(keyRow++, new Object[] { "Location ID", "Merchant Name",
				"Merchant Country", "Issuer Country", "Cards Used",
				"Percent of Cards for Country" });

		for (CPPReportInfo cppReportInfo : cppReportInfos) {

			if ("CNP".equals(cppReportInfo.getTransactionChannel())) {
				rowEntry.put(
						keyRow++,
						new Object[] {
								cppReportInfo.getLocationId(),
								cppReportInfo.getMerchantName(),
								cppReportInfo.getMerchantCountryCode(),
								cppReportInfo.getIssuerCountryCode(),
								Long.toString(cppReportInfo.getCardsUsedCount()),
								Double.toString(cppReportInfo
										.getCardsCountryPercentage()) + "%" });
			}
		}

	}

}
