package com.mastercard.ess.eds.core.parser;

import java.util.HashMap;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

import org.apache.log4j.Logger;
import org.springframework.batch.item.file.transform.FieldSet;

import com.google.common.io.BaseEncoding;

public class ParserUtil {

	public static final String IV = "iv";
	private static final String SUN_JCE = "SunJCE";
	private static Logger logger = Logger.getLogger(ParserUtil.class);

	public static Map<String,String> decryptValues(FieldSet fieldSet, SecretKey key, String transform, String fieldsToDecrypt) throws Exception{
		String initVector = fieldSet.readString(IV);
		Map<String,String> decryptedData = new HashMap<String, String>();
		if(fieldsToDecrypt != null){
			String[] fields = fieldsToDecrypt.split(",");
			for(String field : fields){
				decryptedData.put(field, decriptValue(key, initVector, fieldSet.readString(field), transform));
			}
		} else {
			decryptedData.put(VendorPayloadTokens.VALUE.getDesc(),
					decriptValue(key, initVector, fieldSet.readString(VendorPayloadTokens.VALUE.getDesc()), transform));
		}
		return decryptedData;
	}

	private static String decriptValue(SecretKey sessionKey, String initVector,
			String encrypted, String transform) throws Exception {

		byte[] decryptedText = null;

		try {
			Cipher aesDecCipher = Cipher.getInstance(transform, SUN_JCE);
			aesDecCipher.init(Cipher.DECRYPT_MODE, sessionKey,new IvParameterSpec(BaseEncoding.base64().decode(initVector)));
			decryptedText = aesDecCipher.doFinal(BaseEncoding.base64().decode(encrypted));

			return new String(decryptedText);
		} catch (Exception ex) {
			logger.error("exception in decryption : " + ex);
			throw new Exception(ex.getMessage());
		}
	}
}
