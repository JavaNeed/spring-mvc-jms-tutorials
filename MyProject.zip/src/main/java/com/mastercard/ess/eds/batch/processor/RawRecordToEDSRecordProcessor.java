package com.mastercard.ess.eds.batch.processor;

import org.springframework.batch.item.ItemProcessor;

import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.RawRecord;

public class RawRecordToEDSRecordProcessor implements ItemProcessor<RawRecord,EDSRecord> {

	@Override
	public EDSRecord process(RawRecord rawRecord) {
		EDSRecord edsRecord = new EDSRecord();
		edsRecord.setRawRecord(rawRecord);
		return edsRecord;
	}

}
