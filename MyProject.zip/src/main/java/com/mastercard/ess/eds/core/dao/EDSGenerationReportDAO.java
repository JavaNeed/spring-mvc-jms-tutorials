package com.mastercard.ess.eds.core.dao;

/**
 *  This dao class is used perfrom CRUD operations from EDS_GNRT_RPT table.
 * @author e070836
 * @version 1.0
 * @date : Mar 9 2018
 *
 */

import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.billing.vo.FileItemVO;
import com.mastercard.ess.eds.constant.SQLQueries;
import com.mastercard.ess.eds.core.mapper.EDSFileGenerationMapper;

@Component
public class EDSGenerationReportDAO {
	
	private static Logger logger = Logger.getLogger(EDSGenerationReportDAO.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public EDSGenerationReportDAO(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	/**
	 *  This gets the records from EDS_GNRT_RPT table based on file Name and Job Name.
	 * @param fileName
	 * @param jobName
	 * @return fileItemVO
	 */
	public List<FileItemVO> getFileItemsFromFileName(String fileName , String jobName) {
		logger.debug("Enter into the getFileItemsFromFileName");
		Object[] parameters = new Object[] { fileName, jobName };
		List<FileItemVO> fileItemVO = jdbcTemplate.query(SQLQueries.FETCH_EDS_GEN_RPT, parameters , new EDSFileGenerationMapper());
		logger.debug("Exit into the getFileItemsFromFileName");
		return fileItemVO;
	}
	
	

}
