package com.mastercard.ess.eds.batch.config;

/**
 * This ENUM contains the status of the customer file generation of an ICA
 * NO_PAN_FOUND - It is set when no PAN is available for the ICA
 * GFT_SUCCESSFUL - It is set when file is created and GFT transfer is successful.
 * GFT_FAILURE - It is set when GFT transfer of file is failed
 * GEN_SUCCESSFUL - It is set when the file generation is successful.
 * GEN_FAILURE - It is set when the file generation is failed.
 * @author e070836
 * @version 1.0
 * @date : Mar 13 2018
 */
public enum FileStatus {

	NO_PAN_FOUND ("NO_PAN_FOUND"),
	GFT_SUCCESS ("GFT_SUCCESSFUL"),
	GFT_FAILURE ("GFT_FAILURE"),
	GEN_SUCCESS("GEN_SUCCESSFUL"),
	GEN_FAILURE("GEN_FAILURE");
	
	private String status;

	public String getStatus() {
		return status;
	}

	private FileStatus(String status) {
		this.status = status;
	}

	 
}
