package com.mastercard.ess.eds.batch.tasklet;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.mastercard.ess.eds.batch.config.FileStatus;
import com.mastercard.ess.eds.constant.BatchConstants;
import com.mastercard.ess.eds.core.dao.CustomerPanReportDao;
import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.core.service.CustomerFileReportService;
import com.mastercard.ess.eds.core.service.CustomerMasterService;
import com.mastercard.ess.eds.core.util.EDSProcessStatus;
import com.mastercard.ess.eds.domain.ICAStatus;
import com.mastercard.ess.eds.notification.util.NotificationEventConstants;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;

/**
 *  This class is executed in GFT failure mode, this files gets all the files from customer folder and tries to send through GFT.
 *  If GFT transfer is successful,it sends a notification to subscribed user.
 * @author e070836
 * @version 1.0
 * @date : Mar 13 2018
 *
 */
public class UpdateGFTSendStatusTasklet implements Tasklet {

	private static Logger logger = Logger
			.getLogger(UpdateGFTSendStatusTasklet.class);

	@Value("${customerfiles.directory}")
	private String location;

	private String jobInstanceName;
	private BigDecimal jobInstanceId;

	@Autowired
	private CustomerFileReportService customerFileReportService;

	@Autowired
	private CustomerPanReportDao customerPanReportDao;

	@Autowired
	private NotificationEventVO notificationEventVO;

	@Autowired
	private EventPublisher eventPublisher;

	@Autowired
	private CustomerMasterService customerMasterService;

	private List<ICAStatus> icastatusList = new ArrayList<ICAStatus>();

	private ExecutionContext executionContext;

	/**
	 *  This method tries to send all the files in the customer location folder through GFT.
	 *   @param  arg0 , chunkContext
	 *  @return RepeatStatus 
	 */
	@Override
	public RepeatStatus execute(StepContribution arg0, ChunkContext chunkContext)
			throws Exception {

		File folder = new File(location);

		for (File file : folder.listFiles()) {
			Instant createTime = Instant.now();
			String fileName = file.getName();
			String icaNum = customerFileReportService.getICAFromFileName(
					fileName, jobInstanceName);
			Map<String, Object> customerInfo = customerMasterService
					.getCustomerInfo(icaNum);
			Object custMasterKey = customerInfo.get("EDS_CUST_MSTR_ID");
			Object custName = customerInfo.get("CUST_NAM");
			String organizationName = (null != custName) ? "" + custName : "";
			logger.info("Customer Master Key=" + custMasterKey
					+ ", for filename =" + fileName);

			sendFilesToGFT(fileName, icaNum, organizationName);

			Instant endTime = Instant.now();
			logger.info("Time to send a file using GFT = "+ (Duration.between(createTime, endTime)));
		}
		this.executionContext.put("icaStatusList", icastatusList);

		return RepeatStatus.FINISHED;
	}

	/**
	 *  This method sends file using GFT.
	 * @param fileName
	 * @param icaNum
	 * @param organizationName
	 */
	private void sendFilesToGFT(String fileName, String icaNum,
			String organizationName) {
		
		int exitStatus = 0;
		Map<String, String> jobParams = new HashMap<>();

		ICAStatus icaStatus = new ICAStatus();
		icaStatus.setIca(icaNum);
		icaStatus.setFileName(fileName);
		icaStatus.setStatus( FileStatus.GFT_FAILURE.getStatus());

		ProcessBuilder procBuilder = new ProcessBuilder("/bin/bash",
				"sendCustomerBatchFiles.sh", fileName);
		try {

			Map<String, String> env = procBuilder.environment();
			env.put("PATH",
					"/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/usr/seos/bin:"
							+ "/opt/nfast/bin:/sys_apps_01/cdunix/ndm/bin:/apps_01/eds/bin");

			// Fix missing CLI variable
			env.put("MCSTAR_HOME", "/apps_01/mcstar");
			env.put("MCSTARINI", "NULL");
			env.put("MCSTARAPP", "EDS");
			env.put("LD_LIBRARY_PATH",
					"/apps_01/mcstar/lib:/sys_apps_01/dmexpress/lib");
			env.put("NDMDIR", "/sys_apps_01/cdunix/ndm");
			env.put("NDMAPICFG",
					"/sys_apps_01/cdunix/ndm/cfg/cliapi/ndmapi.cfg");
			env.put("SRCNODE", "`hostname`");
			env.put("CDRMCFG", "$NDMDIR/cfg/$SRCNODE/initparm.cfg");

			Process proc = procBuilder.start();

			BufferedReader br = new BufferedReader(new InputStreamReader(
					proc.getErrorStream()));
			String line = null;
			logger.info("script output start");
			while ((line = br.readLine()) != null) {
				logger.info(line);
			}
			logger.info("script output end");

			exitStatus = proc.waitFor();

			logger.info("process exit status =" + exitStatus);

			if (0 == exitStatus) {

				// process was successful, update EDS_CUST_PAN_RPT
				int status = EDSProcessStatus.SENT.getStatusCode();
				logger.info("Updating CustomerFileStatus with FileName = "
						+ fileName + " and Status = " + status);

				customerFileReportService.updateCustomerFileStatus(fileName,
						status, jobInstanceName, jobInstanceId, location);

				notificationEventVO
						.setEventName(NotificationEventConstants.NOTIF_EVT_COMPROMISED_PANS_AVL);
				jobParams.put("customerName", organizationName);
				jobParams.put("ica", icaNum);

				notificationEventVO.setJobParams(jobParams);

				// setting the values for event notificationVO
				notificationEventVO.setJobName(jobInstanceName);
				
				notificationEventVO.setJobID(jobInstanceId);

				logger.info("insideFileGenerator | Event has been triggered for the event "
						+ "with eventName : "
						+ notificationEventVO.getEventName()
						+ "jobName : "
						+ notificationEventVO.getJobName()
						+ "jobId: "
						+ notificationEventVO.getJobID()
						+ "jobParams : "
						+ notificationEventVO.getJobParams());
				eventPublisher.placeEvent(notificationEventVO);

				icaStatus.setStatus(FileStatus.GFT_SUCCESS.getStatus());
			}
			icaStatus.setErrorDetails((String.valueOf(exitStatus).equalsIgnoreCase("0") ? BatchConstants.NOT_APPLICABLE : String.valueOf(exitStatus)));

		} catch (IOException | InterruptedException e) {
			logger.error("An exception occurred while running send file process"
					+ e);
			icaStatus.setErrorDetails(e.getMessage());
		}
		
		icastatusList.add(icaStatus);
	}

	// for junit
	public void setCustomerPanReportDao(
			CustomerPanReportDao customerPanReportDao) {
		this.customerPanReportDao = customerPanReportDao;
	}

	public String getJobInstanceName() {
		return jobInstanceName;
	}


	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}

	 

	public BigDecimal getJobInstanceId() {
		return jobInstanceId;
	}

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}

	public ExecutionContext getExecutionContext() {
		return executionContext;
	}

	public void setExecutionContext(ExecutionContext executionContext) {
		this.executionContext = executionContext;
	}
}