package com.mastercard.ess.eds.core.util;

import org.springframework.stereotype.Component;

@Component(value = "envUtil")
public interface EnvironmentUtil {
	
	public String getKeyStorePath();
	public String getEnv();

}
