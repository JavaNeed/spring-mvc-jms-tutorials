package com.mastercard.ess.eds.core.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.service.CustomerFileReportService;
import com.mastercard.ess.eds.domain.VendorActiveAccountRecord;

@Component
public class VendorReportGenerator {

	private static final String DATE = "Date";
	private static final String DETAILS = "Details";
	private static final String INACTIVE = "Inactive";
	private static final String ACTIVE = "Active";
	private static final String VALID = "Valid";
	private static final String NEW = "New";
	private static final String UNIQUE = "Unique";
	private static final String RECEIVED = "Received";
	private static final String MONTH = "Month";
	private static final String SUMMARY = "Summary";
	private static final String REPORT_DURATION = "Report Duration";
	private static final String VENDOR = "Vendor";
	private static final String MONTHLY_ACTIVE_ACCOUNT_REPORT = "Monthly Active Account Report";

	@Autowired
	CustomerFileReportService customerFileReportService;

	@Value("${vendorReport.path}")
	private String vendorReportPath;

	private static Logger logger = Logger.getLogger(VendorReportGenerator.class);

	// Added to fix dependency issues
	public VendorReportGenerator() {
		super();
	}

	// for Junit
	public VendorReportGenerator(String vendorReportPath, CustomerFileReportService customerFileReportService) {
		this.vendorReportPath = vendorReportPath;
		this.customerFileReportService = customerFileReportService;
	}

	private FileOutputStream getFileoutputStream(String filePath) throws FileNotFoundException {
		return new FileOutputStream(new File(filePath));
	}

	private Workbook getWorkbook() throws IOException, InvalidFormatException {
		return new XSSFWorkbook();
	}

	private Row createRow(Sheet spreadsheet, int rowNum) {
		return spreadsheet.createRow(rowNum);
	}

	private Cell createCellWithValue(Row row, int cellNo, Object value, Workbook wb) {

		XSSFCellStyle style = (XSSFCellStyle) wb.createCellStyle();
		Font f = wb.createFont();
		f.setBoldweight(Font.BOLDWEIGHT_BOLD);
		f.setFontHeightInPoints((short) 10);
		style.setFont(f);
		style.setAlignment(CellStyle.ALIGN_CENTER);

		XSSFCellStyle style1 = (XSSFCellStyle) wb.createCellStyle();
		Font f1 = wb.createFont();
		f1.setBoldweight(Font.BOLDWEIGHT_BOLD);
		f1.setFontHeightInPoints((short) 10);

		style1.setFont(f1);

		XSSFCellStyle style2 = (XSSFCellStyle) wb.createCellStyle();
		Font f2 = wb.createFont();
		f2.setBoldweight(Font.BOLDWEIGHT_BOLD);
		f2.setFontHeightInPoints((short) 10);
		style2.setFont(f2);

		Cell c = row.createCell(cellNo);

		setCellWithStyle1(value, style1, c);

		if (DATE.equals(value) || MONTHLY_ACTIVE_ACCOUNT_REPORT.equals(value)) {
			c.setCellStyle(style1);
		}

		if (SUMMARY.equals(value) || DETAILS.equals(value)) {
			c.setCellStyle(style);
		}

		if (value instanceof Integer || value instanceof Double) {
			c.setCellValue(Double.valueOf(value.toString()));
		} else {
			c.setCellValue(value.toString());
		}

		return c;
	}

	/**
	 * @param value
	 * @param style1
	 * @param c
	 */
	private void setCellWithStyle1(Object value, XSSFCellStyle style1, Cell c) {
		if (MONTH.equals(value) || RECEIVED.equals(value) || UNIQUE.equals(value)) {
			c.setCellStyle(style1);
		}
		if (ACTIVE.equals(value) || VENDOR.equals(value)) {
			c.setCellStyle(style1);
		}

		if (INACTIVE.equals(value) || REPORT_DURATION.equals(value)) {
			c.setCellStyle(style1);
		}
	}

	private static void writeToFile(Workbook workbook, FileOutputStream fos) throws IOException {
		workbook.write(fos);

	}

	/**
	 * @param stepExecution
	 * @param summaryList
	 *            : data to be exported to excel file
	 * @param monthlySummary
	 *            : total counts for the month
	 * @param jobInstanceName
	 * @param jobInstanceId
	 *            this method populates the data fetched from EDS_PRCSS_DATA based
	 *            on grouping
	 */
	public synchronized void writeToVendorReport(StepExecution stepExecution,
			List<? extends VendorActiveAccountRecord> summaryList, VendorActiveAccountRecord monthlySummary,
			BigDecimal jobInstanceId, String jobInstanceName, String vendor, String prevMonth) {
		logger.info("writing report for vendor =" + vendor + ", for month =" + prevMonth + ", summaryList size"
				+ summaryList.size());
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : writeToCPPReport | CPPReportGenerator ");
		}

		String filePath = vendorReportPath;
		String sheetName = "summary";

		Calendar now = Calendar.getInstance();

		now.add(Calendar.MONTH, -1);
		now.set(Calendar.DATE, 1);
		Date firstDayofPrevMonth = now.getTime();
		String fromDate = getFormattedDate(firstDayofPrevMonth, "dd-MMM-yyyy");

		now.set(Calendar.DATE, now.getActualMaximum(Calendar.DATE));
		Date lastDateOfPreviousMonth = now.getTime();
		String toDate = getFormattedDate(lastDateOfPreviousMonth, "dd-MMM-yyyy");

		filePath = filePath + vendor + "_" + prevMonth + ".xlsx";

		logger.info("==================filePath" + filePath);

		File file = null;
		FileOutputStream fos = null;
		Workbook wb = null;
		Sheet sheet = null;
		Integer keyRow = 0;

		try {
			file = new File(filePath);
			if (file.exists()) {

				logger.info("file already exists exiting ..");
				return;
			}

			wb = getWorkbook();
			fos = getFileoutputStream(filePath);
			sheet = wb.createSheet(sheetName);
			int existingRows = sheet.getPhysicalNumberOfRows();
			// Create row object
			Row row;
			// This data needs to be written (Object[])
			Map<Integer, Object[]> rowEntry = new TreeMap<Integer, Object[]>();

			mapObjectWithVendorActiveRecord(summaryList, monthlySummary, vendor, prevMonth, fromDate, toDate, sheet,
					keyRow, rowEntry);

			// Iterate over data and write to sheet
			Set<Integer> keyid = rowEntry.keySet();
			int rowid = existingRows;

			for (Integer key : keyid) {
				row = createRow(sheet, rowid++);
				Object[] objectArr = rowEntry.get(key);
				int cellid = 0;
				createCellValue(wb, row, objectArr, cellid);
			}

			for (int i = 0; i < 5; i++) {
				sheet.autoSizeColumn(i);
			}

			writeToFile(wb, fos);
			String vendorPath = vendor + "_path";
			logger.info("==== vendorPath=====" + vendorPath);
			stepExecution.getJobExecution().getExecutionContext().put(vendorPath, filePath);
			logger.info("set vendorReportFile = " + filePath + ", vendor = " + vendor);
			stepExecution.getJobExecution().getExecutionContext().put(vendor, vendor);

			customerFileReportService.createGeneratedFileRecord(filePath, jobInstanceId, jobInstanceName,
					ReportTypeTokens.VENDOR_REPORT.getTypecode());

		} catch (IOException | EncryptedDocumentException | InvalidFormatException e) {
			logger.error("IOException : " + e);

		}

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method :  writeToCPPReport | CPPReportGenerator");
		}

	}

	private void mapObjectWithVendorActiveRecord(List<? extends VendorActiveAccountRecord> summaryList,
			VendorActiveAccountRecord monthlySummary, String vendor, String prevMonth, String fromDate, String toDate,
			Sheet sheet, Integer keyRow, Map<Integer, Object[]> rowEntry) {
		rowEntry.put((keyRow++), new Object[] { MONTHLY_ACTIVE_ACCOUNT_REPORT });
		rowEntry.put((keyRow++), new Object[] { "" });

		rowEntry.put((keyRow++), new Object[] { VENDOR, vendor });
		rowEntry.put((keyRow++), new Object[] { REPORT_DURATION, fromDate + " to " + toDate });
		rowEntry.put((keyRow++), new Object[] { "" });

		rowEntry.put((keyRow++), new Object[] { SUMMARY });
		sheet.addMergedRegion(CellRangeAddress.valueOf("A6:G6"));

		rowEntry.put((keyRow++), new Object[] { MONTH, RECEIVED, UNIQUE, ACTIVE, INACTIVE });
		rowEntry.put((keyRow++),
				new Object[] { prevMonth, monthlySummary.getReceivedPANCount(), monthlySummary.getUniquePANCount(),
						monthlySummary.getActivePANCount(), monthlySummary.getInactivePANCount() });

		rowEntry.put((keyRow++), new Object[] { "" });
		rowEntry.put((keyRow++), new Object[] { "" });

		rowEntry.put((keyRow++), new Object[] { DETAILS });
		sheet.addMergedRegion(CellRangeAddress.valueOf("A11:G11"));

		rowEntry.put((keyRow++), new Object[] { DATE, RECEIVED, UNIQUE, ACTIVE, INACTIVE });

		for (VendorActiveAccountRecord day : summaryList) {
			rowEntry.put((keyRow++),
					new Object[] { getFormattedDate(day.getSummaryDate(), "MM/dd/yyyy"), day.getReceivedPANCount(),
							day.getUniquePANCount(), day.getActivePANCount(), day.getInactivePANCount() });

		}
	}

	/**
	 * @param wb
	 * @param row
	 * @param objectArr
	 * @param cellid
	 */
	private void createCellValue(Workbook wb, Row row, Object[] objectArr, int cell) {
		int cellid = cell;
		for (Object obj : objectArr) {
			if (obj != null) {
				createCellWithValue(row, cellid++, obj, wb);
			} else {
				createCellWithValue(row, cellid++, "", wb);
			}

		}
	}

	public String getFormattedDate(Date date, String format) {
		String formattedDate = "";
		if (null != date) {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			formattedDate = sdf.format(date);
		}
		return formattedDate;
	}
}