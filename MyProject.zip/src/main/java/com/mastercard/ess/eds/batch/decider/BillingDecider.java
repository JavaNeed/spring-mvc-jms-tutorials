package com.mastercard.ess.eds.batch.decider;

import org.apache.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;

import com.mastercard.ess.eds.constant.BatchConstants;

/**
 *  This decider class return flow execution status based on the run mode from the context
 *  GFT_FAILURE - This mode is used to resend the files through GFT which are failed in previous run
 *  FILE_GENERATION - This is default mode when the job runs without a parameter. 
 * @author e075834
 * @version 1.0
 * @date : May 22 2018
 *
 */

public class BillingDecider implements JobExecutionDecider {

	private Logger logger = Logger.getLogger(CustomerDecider.class);
	
	/**
	 *  This override method set the flow execution status based context.
	 *  @param  jobExecution , stepExecutionStatus
	 *  @return FlowExecutionStatus
	 */
	@Override
	public FlowExecutionStatus decide(JobExecution jobExecution, StepExecution stepExecutionStatus) {
		String billRunMode = (String) jobExecution.getExecutionContext().get("billRunMode");
		
		if(null != billRunMode && billRunMode.equalsIgnoreCase(BatchConstants.MODE_GFT_FAILURE)){
			logger.info("Billing job is executed in mode = " + billRunMode );
			return new FlowExecutionStatus(BatchConstants.MODE_GFT_FAILURE) ;
		}
		logger.info("Billing job is executed in default mode");
		return new FlowExecutionStatus(BatchConstants.MODE_FILE_GENERATION) ;
	}

}