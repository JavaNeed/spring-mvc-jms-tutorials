package com.mastercard.ess.eds.core.util;

public enum DeDupeLevels {
	LEVEL_LOCAL,
	LEVEL_SOURCE,
	LEVEL_PROCESS
}
