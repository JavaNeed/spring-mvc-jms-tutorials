package com.mastercard.ess.eds.core.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Component;
import static com.mastercard.ess.eds.constant.SQLQueries.*;
import static com.mastercard.ess.eds.constant.SQLConstants.*;

import com.mastercard.ess.eds.core.util.EDSProcessStatus;

@Component
public class EDSSourceDao {



	private static Logger logger = Logger.getLogger(EDSSourceDao.class);

	private SimpleJdbcInsert edsSourceInsert;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Value("${file.location}")
	private String fileLocation;

	@Value("${errorFile.location}")
	private String errorFileLocation;

	private String fileName;

	private String jobInstanceName;
	
	public EDSSourceDao(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {

		edsSourceInsert = new SimpleJdbcInsert(dataSource).withTableName(EDS_SRC).usingColumns(EDS_SRC_ID,EDS_SRC_TYPE_ID,
				SRC_NAM, STAT_CD, LOC_TXT, ERR_DTL_TXT, IS_PURGED_SW, CRTE_USER_ID, CRTE_DT, JOB_INSTANCE_ID);
	}

	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}

	

	/**
	 * this method is used to store input file information in eds source table
	 * 
	 * @param errorDetails
	 * 
	 * @param stepContribution
	 *            : mutable state to be passed back to update the current step
	 *            execution
	 * @param chunkContext
	 *            : attributes shared between invocations but not between
	 *            restarts
	 */
	public void createSourceRecord(String fileName, String jobName, BigDecimal jobInstanceID, int status,
			String errorDetails, int srcTypeId) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : createSourceRecord ");
		}
		String edsSourceIdSeq = "select EDS_SRC_ID_SEQ.nextval from dual";
		int fileId = jdbcTemplate.queryForObject(edsSourceIdSeq, Integer.class);

		MapSqlParameterSource parameterSource = new MapSqlParameterSource();
		parameterSource.addValue(EDS_SRC_ID, fileId).addValue(EDS_SRC_TYPE_ID, srcTypeId).addValue(SRC_NAM, fileName).addValue(STAT_CD, status)
		.addValue(LOC_TXT, fileLocation).addValue(ERR_DTL_TXT, errorDetails).addValue(IS_PURGED_SW, "N")
		.addValue(CRTE_USER_ID, jobName).addValue(CRTE_DT, new Date()).addValue(LST_UPDT_USER_ID, jobName)
		.addValue(LST_UPDT_DT, new Date()).addValue(JOB_INSTANCE_ID, jobInstanceID);

		edsSourceInsert.execute(parameterSource);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : createSourceRecord ");
		}

	}

	public void updateErrorDetails(String fileName) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : updateErrorDetails ");
		}

		jdbcTemplate.update(UPDATE_ERROR_DETAILS_QUERY, fileName + ".err", errorFileLocation, fileName);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : updateErrorDetails ");
		}
	}

	/**
	 * eds source table is updated with status Queued after data persisted into
	 * eds source data table
	 * 
	 * @param fileName
	 *            : name of file whose status is to be updated
	 */
	public void updateSourceStatus(String fileName) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : updateSourceStatus ");
		}

		jdbcTemplate.update(UPDATE_SOURCE_STATUS_QUERY, EDSProcessStatus.QUEUED.getStatusCode(), fileName);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : updateSourceStatus ");
		}
	}

	/**
	 * Updates status of file in EDS_SOURCE table
	 * @param jobInstanceId 
	 * @param fileName2 
	 */
	public void updateFileStatusPreProcessing(BigDecimal jobInstanceId) {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : updateFileStatusPreProcessing ");
		}

		int wipStatus = EDSProcessStatus.WIP.getStatusCode();
		int queuedStatus = EDSProcessStatus.QUEUED.getStatusCode();

		java.sql.Date date = new java.sql.Date(System.currentTimeMillis());
		jdbcTemplate.update(UPDATE_FILE_STATUS_PRE_PROCESSING_QUERY, wipStatus, date, jobInstanceName, jobInstanceId,  queuedStatus,
				fileName);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : updateFileStatusPreProcessing ");
		}
	}

	/**
	 * Updates status of file in EDS_SOURCE table
	 */
	public void updateFileStatusPostProcessing() {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : updateFileStatusPostProcessing ");
		}

		int processedStatus = EDSProcessStatus.PROCESSED.getStatusCode();
		int wipStatus = EDSProcessStatus.WIP.getStatusCode();
		logger.info("inside updateFileStatusPostProcessing, jobInstanceName =  " + jobInstanceName);
		java.sql.Date date = new java.sql.Date(System.currentTimeMillis());
		jdbcTemplate.update(UPDATE_FILE_STATUS_POST_PROCESSING_QUERY, processedStatus, date, jobInstanceName, wipStatus,
				fileName);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : updateFileStatusPostProcessing ");
		}
	}

	/**
	 * Fetch files with QUEUED status from EDS_SOURCE table
	 */
	public List<Map<String, Object>> getQueuedFiles() {

		return jdbcTemplate.queryForList(FETCH_QUEUED_FILES_QUERY, EDSProcessStatus.QUEUED.getStatusCode());
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;

	}

	public void updateSourceStatus(String fileName, BigDecimal jobInstanceId) {
		jdbcTemplate.update("update EDS_SRC set STAT_CD = ?, JOB_INSTNCE_ID = ? where SRC_NAM = ?",
				EDSProcessStatus.PROCESSED.getStatusCode(), jobInstanceId, fileName);

	}

	public void updateSourceForMissingKey(String zipFileName) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : updateSourceForMissingKey ");
		}
		java.sql.Date date = new java.sql.Date(System.currentTimeMillis());
		jdbcTemplate.update(UPDATE_SOURCE_FOR_KEY_STATUS_QUERY, EDSProcessStatus.ERROR.getStatusCode(),
				"data or sessionkey file is missing", date, jobInstanceName, zipFileName);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : updateSourceForMissingKey ");
		}
	}

	public void createSourceRecord(String fileName, String jobName, BigDecimal jobInstanceID, int status,
			String errorDetails, int srcTypeId, String locTxt) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : createSourceRecord ");
		}
		String edsSourceIdSeq = "select EDS_SRC_ID_SEQ.nextval from dual";
		int fileId = jdbcTemplate.queryForObject(edsSourceIdSeq, Integer.class);

		MapSqlParameterSource parameterSource = new MapSqlParameterSource();
		parameterSource.addValue(EDS_SRC_ID, fileId).addValue(EDS_SRC_TYPE_ID, srcTypeId).addValue(SRC_NAM, fileName).addValue(STAT_CD, status)
		.addValue(LOC_TXT, locTxt).addValue(ERR_DTL_TXT, errorDetails).addValue(IS_PURGED_SW, "N")
		.addValue(CRTE_USER_ID, jobName).addValue(CRTE_DT, new Date()).addValue(LST_UPDT_USER_ID, jobName)
		.addValue(LST_UPDT_DT, new Date()).addValue(JOB_INSTANCE_ID, jobInstanceID);
		edsSourceInsert.execute(parameterSource);
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : createSourceRecord ");
		}
	}

	/*Map contains country code to exponent mapping*/
	public Map<String, Integer> getCountryToExponentMap() {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : getCountryToExponentMap ");
		}
		logger.info("Enter in method : getCountryToExponentMap ");

		Map<String, Integer> countryExponentMap=new HashMap<>();
		List<Map<String, Object>> countryToExponentMap = jdbcTemplate.queryForList(FETCH_COUNTRY_EXPONENT_MAP);
		for (Map<String, Object> row : countryToExponentMap) {
			countryExponentMap.put((String)row.get(ALPHA_CURR_CD),Integer.parseInt(row.get(CURR_EXPNT_NUM).toString()));
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method getCountryToExponentMap ");
		}
		return countryExponentMap;
	}

}
