package com.mastercard.ess.eds.core.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.NoSuchFileException;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;


public class FileDeletingTasklet implements Tasklet, InitializingBean{
	


	private static Logger logger = Logger.getLogger(FileDeletingTasklet.class);

	@Value("${archive.directory}")
	private String archiveDirectory;

	@Value("${input.directory}")
	private String deleteDirectory;

	@Override
	public void afterPropertiesSet() throws Exception {
		//NOOP
	}

	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
		String fullyQualifiedfileName = (String) chunkContext.getStepContext()
				.getJobParameters().get("input.file");
		String[] array = fullyQualifiedfileName.split("/");
		String filename = array[array.length-1];
		FileSystemResource fileSystemResource = new FileSystemResource(fullyQualifiedfileName);

		try {
			FileUtils.moveFile(new File(fileSystemResource.getFile().getPath().substring(5)), new File(archiveDirectory+filename));
			FileUtils.deleteDirectory(new File(deleteDirectory+filename));
		} catch (NoSuchFileException x) {
			logger.info("exception occured while file moving or deleting"+x.getMessage());
		} catch (DirectoryNotEmptyException z) {
			logger.info("exception occured while file moving or deleting"+z.getMessage());
		} catch (IOException e) {
			logger.info("exception occured while file moving or deleting"+e.getMessage());
		}
		return RepeatStatus.FINISHED;
	}
	//fot Junit
	
	public void setArchiveDirectory(String archiveDirectory) {
		this.archiveDirectory = archiveDirectory;
	}

	

	public void setDeleteDirectory(String deleteDirectory) {
		this.deleteDirectory = deleteDirectory;
	}


}
