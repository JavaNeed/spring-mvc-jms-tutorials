package com.mastercard.ess.eds.core.util;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import com.mastercard.ess.eds.constant.BatchConstants;

/**
 * Class to initialize and set DeDupePan object in execution context.
 * @author E076119
 */
public class DeDupeInitTasklet implements Tasklet {

    private static Logger logger = Logger.getLogger(DeDupeInitTasklet.class);

    private String cppRunMode;

    public String getCppRunMode() {
        return cppRunMode;
    }

    public void setCppRunMode(String cppRunMode) {
        this.cppRunMode = cppRunMode;
    }

    /**
     * This method initializes a DeDupePan object and sets it in the ExecutionContext
     */
    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {

        logger.info("Enter DeDupeInitTasklet : execute()");

        if (!BatchConstants.SIMULATION.equalsIgnoreCase(cppRunMode)) {
            chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(
                    DeDupeTokens.DE_DUPE_PAN.getDesc(), DeDupePan.getInstance());
        }
        logger.info("Exit DeDupeInitTasklet : execute()");
        return RepeatStatus.FINISHED;
    }

}
