package com.mastercard.ess.eds.batch.validator;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.core.service.EDSSourceService;
import com.mastercard.ess.eds.core.service.EDSSourceTypeService;
import com.mastercard.ess.eds.core.util.EDSProcessStatus;
import com.mastercard.ess.eds.domain.EDSSourceType;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;
import com.mastercard.ess.eds.notification.util.NotificationEventConstants;
import com.mastercard.ess.eds.common.SplunkEvent;
import com.mastercard.ess.eds.common.SplunkEventLogger;


public class BasicFileValidator implements Tasklet {
	
	private static Logger logger = Logger.getLogger(BasicFileValidator.class);
	@Value("${bulk.id}")
	private String bulkId;

	@Value("${filename.length}")
	private int fileNameLength;

	@Value("${file.size}")
	private int fileSize;

	public static final Map<String, EDSSourceType> endPointMap = new HashMap<String, EDSSourceType>();

	private static final int BULKID_START_POSITION = 7;
	private static final int BULKID_END_POSITION = 11;
	private static final int ENDPOINT_START_POSITION = 14;
	private static final int ENDPOINT_END_POSITION = 22;
	private String endPointReceived;
	public String errorDetails = "";
	private EDSSourceType edsSourceType;
	private File absoluteFile;
	
	public String getErrorDetails() {

		return errorDetails;
	}

	private BigDecimal jobInstanceId;

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}

	@Autowired
	EDSSourceService edsSourceService;
	
	@Autowired
	EventPublisher eventPublisher;
	@Autowired
	NotificationEventVO notificationEventVO;

	public BasicFileValidator(String bulkId, int fileNameLength, int fileSize, EDSSourceService edsSourceService,
			EDSSourceTypeService edsSourceTypeService,NotificationEventVO notificationEventVO, EventPublisher eventPublisher) {
		super();
		this.bulkId = bulkId;
		this.fileNameLength = fileNameLength;
		this.fileSize = fileSize;
		this.edsSourceService = edsSourceService;
		this.edsSourceTypeService = edsSourceTypeService;
		this.notificationEventVO = notificationEventVO;
		this.eventPublisher = eventPublisher;
	}

	@Autowired
	EDSSourceTypeService edsSourceTypeService;

	public BasicFileValidator() {
		super();
	}

	/*
	 * Given the current context in the form of a step contribution, do whatever
	 * is necessary to process this unit inside a transaction. Implementations
	 * return RepeatStatus.FINISHED if finished. If not they return
	 * RepeatStatus.CONTINUABLE. On failure throws an exception.
	 * 
	 * Parameters: stepContribution - mutable state to be passed back to update
	 * the current step execution chunkContext - attributes shared between
	 * invocations but not between restarts
	 * 
	 * Returns: an RepeatStatus indicating whether processing is continuable.
	 */
	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : execute ");
		}
		String fullyQualifiedfileName = (String) chunkContext.getStepContext().getJobParameters().get("input.file");

		FileSystemResource fileSystemResource = new FileSystemResource(fullyQualifiedfileName);

		String fileName = fileSystemResource.getFile().getName();

		String jobName = chunkContext.getStepContext().getJobName();

		int status = EDSProcessStatus.UNPROCESSED.getStatusCode();

		boolean isValidFile = validateFile(fileSystemResource);
		
		// Setting values to a map so as to make these values available in the upcoming steps
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(NotificationEventConstants.TOKEN_FILE_SIZE, String.valueOf(absoluteFile.length()));

		endPointReceived = fileName.substring(ENDPOINT_START_POSITION, ENDPOINT_END_POSITION);
		edsSourceType = edsSourceTypeService.getEDSSourceType(endPointReceived);
		if(null==edsSourceType){
			edsSourceType =  edsSourceTypeService.getEDSSourceTypeFromProvider("unknown");
		}
		
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(NotificationEventConstants.TOKEN_SOURCE_NAME, edsSourceType.getProvider());
		
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(NotificationEventConstants.JOB_ID, jobInstanceId);

		Map <String,String> jobParams=new HashMap<String,String>();
		if (isValidFile == false) {
			logger.info("Not a valid File *******");
			status = EDSProcessStatus.ERROR.getStatusCode();
			
			/*
			 * Key value pair for JsonString is provided
			 * For Invalid File scenarios: Setting params with keys available from NotificationEventConstants File
			 */
			jobParams.put(NotificationEventConstants.TOKEN_ERROR_MESSAGE, errorDetails);
			jobParams.put(NotificationEventConstants.TOKEN_FILE_NAME, fileName);
			jobParams.put(NotificationEventConstants.TOKEN_FILE_SIZE, String.valueOf(absoluteFile.length()));
			jobParams.put(NotificationEventConstants.TOKEN_SOURCE_NAME,edsSourceType.getProvider());
			
			/*
			 * setting the values for notificationEventVO
			 */
			notificationEventVO.setEventName(NotificationEventConstants.NOTIF_EVT_INVALID_SOURCE_FILE_RECEIVED);
			notificationEventVO.setJobParams(jobParams);
			notificationEventVO.setJobName("importRawRecords");
			notificationEventVO.setJobID(jobInstanceId);
			logger.info("inside BasicFileValidator | Event has been triggered for the event : "+notificationEventVO.getEventName());
			eventPublisher.placeEvent(notificationEventVO);
			stepContribution.setExitStatus(new ExitStatus("FAILED"));
		} else {
			/*
			 * load property file corresponding to endpoint
			 */
			loadProperties(endPointReceived, chunkContext);
		}
		
		
		logger.info("Error Input to SRC Table");
		logger.info("fileName = "+ fileName + "jobName = "+ jobName + "jobName = "+ jobName + "status = "+ status + "errorDetails = "+ errorDetails);
		logger.info("edsSourceType.getSourceTypeId() = "+ edsSourceType.getSourceTypeId());

		edsSourceService.createSourceRecord(fileName, jobName, jobInstanceId, status, errorDetails, edsSourceType.getSourceTypeId());

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : execute ");
		}
		
		return RepeatStatus.FINISHED;
	}
	/**
	 * Method to load the property file corresponding to the vendor endpoint received and store the properties in execution context map
	 * @param endPointReceived : the vendor endpoint corresponding to which the property file needs to be loaded
	 * @param chunkContext : context object to set the values from property file
	 * @throws IOException
	 */
	private static void loadProperties(String endPointReceived, ChunkContext chunkContext) throws IOException {
		/*
		 * Loading the property file corresponding to the vendor endpoint received
		 */
		Resource resource = new ClassPathResource( endPointReceived + ".properties");
		Properties propertyFile;
		try {
			propertyFile = PropertiesLoaderUtils.loadProperties(resource );
		} catch (IOException e) {
			Map<String, String> splunkLogError = new HashMap<>();
			splunkLogError.put("exception", e.getMessage());
			splunkLogError.put("job", chunkContext.getStepContext().getJobName());
			logger.error("Exception in BasicFileValidator | loadProperties() = ", e);
			SplunkEventLogger.logEvent(SplunkEvent.PROPERTIES_READ_FAILURE, splunkLogError, logger);
			throw new IOException(e.getMessage());
		}
		
		/*
		 * put values from property file into execution context
		 */
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("vendorProperties", propertyFile);
		
	}

	/**
	 * @param file
	 *            : file received to be validated
	 * @return : returns status of file is valid or not
	 */
	public boolean validateFile(FileSystemResource fileSystemResource) {
		errorDetails = "";
		String fileName = fileSystemResource.getFile().getName();
		String filePath = fileSystemResource.getPath();
		logger.info("fileName = " + fileName +", filePath = " + filePath);
		
		edsSourceService.updateSourceStatus(fileName);

		String[] absoluteFilePath = filePath.split("//");

		absoluteFile = new File(absoluteFilePath[1]);

		edsSourceType = new EDSSourceType();
        logger.info("fileName.length = "+ fileName.length());
		if (fileName.length() != fileNameLength) {
			errorDetails = "Invalid file name";
			if (logger.isInfoEnabled()) {
				logger.info("Invalid file name");
			}
			return false;
		}

		logger.info("bulkId (7 to 11) = "+ bulkId);
		
		if (!(fileName.substring(BULKID_START_POSITION, BULKID_END_POSITION).equals(bulkId))) {
			errorDetails = "Invalid bulkId";
			if (logger.isInfoEnabled()) {
				logger.info("Invalid bulkId");
			}
			return false;
		}

		 endPointReceived = fileName.substring(ENDPOINT_START_POSITION, ENDPOINT_END_POSITION);
		 logger.info("endPointReceived ( 14 to 21) = "+ endPointReceived);

		if (endPointMap.get(endPointReceived) == null) {
			edsSourceType = edsSourceTypeService.getEDSSourceType(endPointReceived);
			logger.info("edsSourceType = "+edsSourceType);
			if (edsSourceType != null) {
				endPointMap.put(endPointReceived, edsSourceType);
			} else {
				logger.info("Inside Invalid Endpoint");
				errorDetails = "Invalid EndPoint";
				return false;
			}
		}

		if (absoluteFile.length() > fileSize) {
			errorDetails = "file size is greater than permissible limit";
			if (logger.isInfoEnabled()) {
				logger.info("file size is greater than permissible limit");
			}
			return false;
		}

		return true;
	}
}
