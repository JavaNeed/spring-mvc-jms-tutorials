package com.mastercard.ess.eds.batch.config;

public enum CommonCacheTokens {

	START_INDEX ("startIndex"),
	END_INDEX ("endIndex");
	
	private String desc;

	public String getDesc() {
		return desc;
	}
	
	private CommonCacheTokens(String desc){
		this.desc = desc;
	}
}
