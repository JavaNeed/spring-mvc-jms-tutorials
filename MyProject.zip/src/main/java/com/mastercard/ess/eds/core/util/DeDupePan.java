package com.mastercard.ess.eds.core.util;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;

import com.mastercard.ess.eds.domain.PANMetadataRecord;

public class DeDupePan {

	private Map<String, Map> uniquePans = new ConcurrentHashMap<>();
	private static DeDupePan deDupePanObj;
	private static Logger logger = Logger.getLogger(DeDupePan.class);

	private DeDupePan(){
	}

	public static DeDupePan getInstance(){
		if(deDupePanObj == null){
			deDupePanObj = new DeDupePan(); 
		}
		return deDupePanObj;
	}

	/**
	 * This method checks for duplicate pans in the given level.
	 * @param panMetadataRecord
	 * @param level
	 * @return
	 */
	public synchronized boolean isDuplicate(PANMetadataRecord panMetadataRecord, DeDupeLevels level){

		boolean isDuplicate = true;
		if(level.equals(DeDupeLevels.LEVEL_LOCAL)){
			isDuplicate = isDuplicateLevelLcl(panMetadataRecord.getPan());
		}	
		return isDuplicate;
	}

	/**
	 * This method checks for duplicate pans in level local.
	 * @param pan
	 * @return
	 */
	private boolean isDuplicateLevelLcl( String pan ) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter DeDupePan : isDuplicateLevelLcl()");
		}
		boolean isDuplicate = false;
		if(uniquePans.containsKey(pan)) {
			isDuplicate = true;
		}

		if (logger.isDebugEnabled()) {
			logger.debug("Exit DeDupePan : isDuplicateLevelLcl()");
		}
		return isDuplicate;
	}

	/**
	 * Method to add pan in the given level.
	 * @param panMetadataRecord
	 * @param level
	 * @return
	 */
	public synchronized void addPan(PANMetadataRecord panMetadataRecord, DeDupeLevels level) {

		if(level.equals(DeDupeLevels.LEVEL_LOCAL)){
			uniquePans.put(panMetadataRecord.getPan(), panMetadataRecord.getMetadata());
		}
	}

	/**
	 * Method to add a list of pans in the cache for the given level.
	 * @param panMetadataRecordList : list of pans to be added to the cache
	 * @param level : level in which the pan has to be added
	 */
	public void addPanInBulk(List<PANMetadataRecord> panMetadataRecordList, DeDupeLevels level) {
		if (null !=panMetadataRecordList && level.equals(DeDupeLevels.LEVEL_LOCAL)){
			addPanInBulkLevelLcl(panMetadataRecordList);
		}
	}

	/**
	 * Method to add pans in the level local cache.
	 * @param panMetadataRecordList
	 */
	private void addPanInBulkLevelLcl(List<PANMetadataRecord> panMetadataRecordList) {
		for (PANMetadataRecord panMetadataRecord : panMetadataRecordList) {
			uniquePans.put(panMetadataRecord.getPan(), panMetadataRecord.getMetadata());
		}
	}

}
