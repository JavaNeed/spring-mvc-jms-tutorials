package com.mastercard.ess.eds.core.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.mastercard.ess.eds.domain.CustomerDeliveryReportRecord;
import com.mastercard.ess.eds.domain.VendorActiveAccountRecord;

public class CustomerDeliveryReportRowMapper  implements RowMapper<CustomerDeliveryReportRecord> {


	private Logger logger = Logger.getLogger(CustomerDeliveryReportRowMapper.class);
	@Override
	public CustomerDeliveryReportRecord mapRow(ResultSet result, int rowNum) throws SQLException {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : mapRow | CustomerDeliveryReportRowMapper ");
		}
		CustomerDeliveryReportRecord customerDeliveryReportRecord = new CustomerDeliveryReportRecord();

		customerDeliveryReportRecord.setCatagoryCode(result.getString("CODE"));
		customerDeliveryReportRecord.setPriceCatagory(result.getInt("PRICE_CAT_CD"));
		customerDeliveryReportRecord.setCreateDate(result.getString("PERIOD"));
		customerDeliveryReportRecord.setPANCount(result.getInt("PAN_COUNT"));

		if (logger.isDebugEnabled()) {
			logger.debug("END in method : mapRow | CustomerDeliveryReportRowMapper ");
		}
		return customerDeliveryReportRecord;
	}


}
