package com.mastercard.ess.eds.core.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class BrandExclusionDAO {

	private JdbcTemplate jdbcTemplate;

	private final String BRAND_EXCLUSION_QUERY = "SELECT BRND_PRDCT_CD FROM EDS_EXCLD_BRND_PRCT";

	private List<String> listOfExcludedBrands;

	public BrandExclusionDAO(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public List<String> getExcludedBrandList() {

		List<Map<String, Object>> excludedBrandNameList = jdbcTemplate.queryForList(BRAND_EXCLUSION_QUERY);

		if (null != excludedBrandNameList) {
			listOfExcludedBrands = new ArrayList<String>();
			for (Map<String, Object> row : excludedBrandNameList) {
				String brandCode = (String) row.get("BRND_PRDCT_CD");
				if (null != brandCode) {
					listOfExcludedBrands.add(brandCode);
				}

			}
		}
		return listOfExcludedBrands;
	}

}
