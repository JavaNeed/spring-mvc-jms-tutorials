package com.mastercard.ess.eds.core.dao;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.batch.config.DatabaseUtil;
import com.mastercard.ess.eds.core.util.CPPExecutionQueries;
import com.mastercard.ess.eds.domain.AuthDebitPanDetailRecord;
import com.mastercard.ess.eds.domain.CPPRuleRecord;

/**
 * this DAO class is responsible to fetch dates of Auth, Debit and Clearing
 * transaction on a PAN Account.
 * 
 * @author e067588
 *
 */
@Component
public class DWDao {


	private static final String DW_DEBIT = "DW_DEBIT";

	private static final String DW_AUTH = "DW_AUTH";

	private JdbcTemplate jdbcTemplate;

	@Value("${chTranxactionType}")
	private String chTranxactionType;

	@Value("${panprocess.lastActivityDays}")
	private int lastActivityDays;

	public String getChTranxactionType() {
		return chTranxactionType;
	}

	public void setChTranxactionType(String chTranxactionType) {
		this.chTranxactionType = chTranxactionType;
	}
	private static Logger logger = Logger.getLogger(DWDao.class);


	public DWDao(DatabaseUtil databaseUtil) {
		jdbcTemplate = databaseUtil.buildDWJdbcTemplate();
	}

	private static final String PAN = "PAN";

	private static final String AUTH_QUERY = "Select Max(A01.BN_DATE_YYMMDD_HDR) as TXN_DATE "
			+ "FROM AUTHOP01_DETAIL A01 "
			+ "INNER JOIN AUTHOP01_DETAIL_ENC AUTH_ENC ON "
			+ "( A01.DW_AUTHOP_SEQ_NBR = AUTH_ENC.DW_AUTHOP_SEQ_NBR AND A01.DW_PROCESS_DATE = AUTH_ENC.DW_PROCESS_DATE ) "
			+ "where A01.RESP_CODE_DE039 in ('00', '08', '10', '87') "
			+ "and AUTH_ENC.ENCRYPT_PAN_DE002 = ? "
			+ "and A01.DW_PROCESS_DATE BETWEEN ? AND ?";

	private static final String DEBIT_QUERY = "Select Max(D01.TRAN_DT_DE013) AS TXN_DATE "
			+ "FROM DEBITMDS01_DETAIL D01 "
			+ "INNER JOIN DEBITMDS01_DETAIL_ENC DEBIT_ENC ON "
			+ "( D01.DW_DB_MDS_SEQ_NUM = DEBIT_ENC.DW_DB_MDS_SEQ_NUM AND D01.DW_PRCSS_DT = DEBIT_ENC.DW_PRCSS_DT ) "
			+ "where D01.ISO_RESP_CD in ('00', '08', '10', '87') "
			+ "and DEBIT_ENC.ENCRYPT_RQST_ACCT_NUM_DE002 = ? "
			+ "and D01.DW_PRCSS_DT BETWEEN ? AND ?";

	private static final String CLEARING_QUERY = "Select Max(C01.TXN_DATE) AS TXN_DATE "
			+ "FROM CLEARD01_DETAIL C01 "
			+ "INNER JOIN CLEARD01_DETAIL_ENC CLEARING_ENC ON "
			+ "( C01.DW_INET_SEQUENCE_NBR = CLEARING_ENC.DW_INET_SEQUENCE_NBR AND C01.DW_INET_PROCESS_DATE = CLEARING_ENC.DW_INET_PROCESS_DATE ) "
			+ "where CLEARING_ENC.DW_ENCRYPT_CARDHOLDER_NUM = ? "
			+ "and C01.DW_INET_PROCESS_DATE BETWEEN ? AND ?";

	private static final String PAN_LENGTH = "PAN_LENGTH";
	private static final String ZERO = "0";
	private static final int PADDING_MAX_LIMIT = 19;


	private Date getQueryStartDate(java.util.Date createDate) {

		Calendar cal = GregorianCalendar.getInstance();
		cal.setTime(createDate);
		cal.add( Calendar.DAY_OF_YEAR, lastActivityDays);
		java.util.Date offset = cal.getTime();

		return new Date(offset.getTime());

	}


	/**
	 * @param pan
	 *            : pan as stored in ProcRecord
	 * @return : Date of Auth transaction.
	 */
	public Date getAuthRecord(String pan, java.util.Date createDate) {
		Date date = getQueryStartDate(createDate);
		Timestamp timestamp = null;
		try {
			logger.info("Auth record startDate = " + date);
			timestamp = jdbcTemplate.queryForObject(AUTH_QUERY,	new Object[] { pan, date, new Date(createDate.getTime()) }, Timestamp.class);
		} catch (DataAccessException e) {
			logger.info("Exception occured while connecting primary DW data Source");
		}
		if (null != timestamp) {
			date = new Date(timestamp.getTime());
		} else {
			date = null;
		}
		return date;
	}

	/**
	 * @param pan
	 *            : pan as stored in ProcRecord
	 * @return : Date of Debit transaction.
	 */
	public Date getDebitRecord(String pan, java.util.Date createDate) {
		Date date = getQueryStartDate(createDate);
		Timestamp timestamp = null;
		pan = StringUtils.rightPad(pan, PADDING_MAX_LIMIT, ZERO);
		try {
			logger.info("Debit record startDate = " + date);
			timestamp = jdbcTemplate.queryForObject(DEBIT_QUERY, new Object[] { pan, date, new Date(createDate.getTime()) }, Timestamp.class);
		} catch (DataAccessException e) {
			logger.info("Exception occured while connecting primary DW data Source");
		}

		if (null != timestamp) {
			date = new Date(timestamp.getTime());
		} else {
			date = null;
		}
		return date;
	}

	/**
	 * @param pan
	 *            : pan as stored in ProcRecord
	 * @return : Date of Clearing transaction.
	 */
	public Date getClearingRecord(String pan, java.util.Date createDate) {
		Date date = getQueryStartDate(createDate);
		Timestamp timestamp = null;
		pan = StringUtils.rightPad(pan, PADDING_MAX_LIMIT, ZERO);
		try {
			logger.info("Clearing record startDate = " + date);
			timestamp = jdbcTemplate.queryForObject(CLEARING_QUERY, new Object[] { pan, date, new Date(createDate.getTime()) }, Timestamp.class);
		} catch (DataAccessException e) {
			logger.error("Connection exception is ",e);
			logger.info("Exception occured while connecting primary DW data Source");
		}
		if (null != timestamp) {
			date = new Date(timestamp.getTime());
		} else {
			date = null;
		}
		return date;
	}


	/*Method will return Auth records for provided cppRuleId*/
	public List<AuthDebitPanDetailRecord> getAuthRecordsByRule(CPPRuleRecord cPPRuleRecord, String runCppRuleForDays) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method getAuthRecordsByRule with cppRuleId ="+cPPRuleRecord.getCppRuleId()+" runCppRuleForDays="+runCppRuleForDays);
		}

		StringBuffer strAuthForByRuleQuery = CPPExecutionQueries.getAuthStrQueryByRule(cPPRuleRecord,runCppRuleForDays,chTranxactionType);

		if (logger.isDebugEnabled()) {
			logger.debug("********AuthQuery For CPPExec Rule ="+strAuthForByRuleQuery+" *************");
		}
		return jdbcTemplate.query(strAuthForByRuleQuery.toString(),new Object[]{CPPExecutionQueries.getAuthDaysOnBasisOfPrcssDate(cPPRuleRecord, runCppRuleForDays)},
				new RowMapper<AuthDebitPanDetailRecord>() {
			@Override
			public AuthDebitPanDetailRecord mapRow(ResultSet rs, int rownumber)
					throws SQLException {
				AuthDebitPanDetailRecord authDebitPanDetailRecord = new AuthDebitPanDetailRecord();
				authDebitPanDetailRecord.setCppRuleId(cPPRuleRecord
						.getCppRuleId());
				authDebitPanDetailRecord.setRawPan(rs.getString(PAN));
				authDebitPanDetailRecord.setdWSource(DW_AUTH);
				return authDebitPanDetailRecord;
			}
		});
	}

	/*Methods will return Debit records after comparing rules*/
	public List<AuthDebitPanDetailRecord> getDebitRecordsByRule(CPPRuleRecord cPPRuleRecord, String runCppRuleForDays) {

		if (logger.isDebugEnabled()) {
			logger.info("Enter in method getDebitRecordsByRule with cppRuleId ="+cPPRuleRecord.getCppRuleId());
		}

		StringBuffer strDebitCPPByRuleQuery = CPPExecutionQueries.getDebitStrQueryByRule(cPPRuleRecord,runCppRuleForDays,chTranxactionType);
		if (logger.isDebugEnabled()) {
			logger.debug("********DebitQuery For CPPExec Rule ="+strDebitCPPByRuleQuery+" *************");
		}

		return jdbcTemplate.query(strDebitCPPByRuleQuery.toString(),new Object[]{CPPExecutionQueries.getDebitDaysOnBasisOfPrcssDate(cPPRuleRecord, runCppRuleForDays)},
				new RowMapper<AuthDebitPanDetailRecord>() {
			@Override
			public AuthDebitPanDetailRecord mapRow(ResultSet rs, int rownumber)
					throws SQLException {
				AuthDebitPanDetailRecord authDebitPanDetailRecord = new AuthDebitPanDetailRecord();
				authDebitPanDetailRecord.setCppRuleId(cPPRuleRecord
						.getCppRuleId());

				if( StringUtils.isNotBlank(rs.getString(PAN_LENGTH)) && ( rs.getString(PAN).length() >= Integer.valueOf(rs.getString(PAN_LENGTH)))) {
					authDebitPanDetailRecord.setRawPan(rs.getString(PAN).substring(0, Integer.valueOf(rs.getString(PAN_LENGTH))));
				} else {
					authDebitPanDetailRecord.setRawPan(rs.getString(PAN));
				}
				authDebitPanDetailRecord.setdWSource(DW_DEBIT);
				return authDebitPanDetailRecord;
			}
		});		
	}



}
