package com.mastercard.ess.eds.batch.writer;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.service.CPPItemWriterService;
import com.mastercard.ess.eds.domain.CPPTxnInfo;

/**
 * this class is writer class for cppAnalysis job
 * it writes CPPTxnInfo to EDS_CPP_TRAN table
 * @author e058825
 *
 */
public class CPPItemWriter  implements ItemWriter<CPPTxnInfo>{
	
	@Autowired
	CPPItemWriterService cppItemWriterService;
	
	private static Logger logger = Logger.getLogger(CPPItemWriter.class);
	
	private String jobInstanceName;
	
//for junit
	public CPPItemWriter(CPPItemWriterService cppItemWriterService) {
		this.cppItemWriterService=cppItemWriterService;
	}

	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;

	}

	@Override
	public void write(List<? extends CPPTxnInfo> items) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : write : CPPItemWriter ");
		}
		cppItemWriterService.setJosetJobInstanceName(jobInstanceName);
		cppItemWriterService.writeCppRecord(items);
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : write : CPPItemWriter ");
		}
	}

}
