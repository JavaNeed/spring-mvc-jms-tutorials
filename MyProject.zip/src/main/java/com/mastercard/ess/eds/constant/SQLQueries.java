package com.mastercard.ess.eds.constant;

public final class SQLQueries {

    public static final String FETCH_EDS_GEN_RPT =
            "select * from EDS_OWNER.EDS_GNRT_RPT where FILE_NAM=? and CRTE_USER_ID= ?";

    public static final String SELECT_CUST_MASTER_QUERY =
            "SELECT EDS_CUST_MSTR_ID, CUST_NAM, ENDPNT_ID FROM EDS_CUST_MSTR WHERE ICA_NUM = ? AND ACTV_SW = ? ";

    public static final String UPDATE_HIST_FLAG = " UPDATE eds_cust_mstr set HIST_SW = ? where ICA_NUM = ? ";

    public static final String GET_EMAIL_AND_ICAS =
            "SELECT LOWER (CUST_MSTR.DEFLT_NOTIF_EMAIL_ADDR) AS email_id, CUST_MSTR.ICA_NUM AS ica_num FROM EDS_CUST_MSTR CUST_MSTR "
                    + "WHERE CUST_MSTR.CRTE_DT < SYSDATE AND CUST_MSTR.CRTE_DT > SYSDATE - 1 AND CUST_MSTR.ACTV_SW ='Y'";

    public static final String GET_SUBSCRIBED_EMAIL_IDS =
            "SELECT DISTINCT LOWER(SUB.EMAIL_ID) AS EMAIL_ID FROM EDS_EVENT_SUBSC sub INNER JOIN EDS_EVENT EVT ON "
                    + "SUB.event_id = EVT.eds_event_id AND EVT.type_txt = ? AND SUB.crte_dt > SYSDATE - ? ";

    public static final String GET_EMAIL_BY_ICA =
            "SELECT EMAIL_ID, ICA_NUM FROM EDS_EVENT_SUBSC WHERE EVENT_ID = ?  AND ICA_NUM IN ? ";

    public static final String FETCH_SIMULATION_DATA =
            "SELECT SIM_DATA.SIM_DATA_ID,SIM_DATA.SIM_SRC_ID,SIM_DATA.CPP_RULE_ID,SIM_DATA.PAN_CNT_NUM,SIM_DATA.CRTE_DT,SIM_DATA.CRTE_USER_ID,SIM_DATA.VAL_1,CPP_RULE.VAL_MERCH_LOC_ID,CPP_RULE.VAL_LOC_TRAN_AMT,"
                    + "CPP_RULE.CLS_MERCH_LOC_ID,CPP_RULE.VAL_ISSR_CNTRY_ID,CPP_RULE.CLS_ISSR_CNTRY_ID,CPP_RULE.UNIT_TM_CNT,CPP_RULE.VAL_TM_CNT , CPP_RULE.CAT_CD FROM EDS_CPP_SIM_DATA SIM_DATA "
                    + "INNER JOIN EDS_CPP_RULE CPP_RULE ON CPP_RULE.EDS_CPP_RULE_ID = SIM_DATA.CPP_RULE_ID AND SIM_DATA.SIM_SRC_ID = ? ";

    public static final String UPDATE_CPP_SRC_STATUS_POST_RULE_EXECUTION =
            "UPDATE EDS_SRC SET STAT_CD = ?, LST_UPDT_DT = ?, LST_UPDT_USER_ID = ? WHERE STAT_CD = ? AND SRC_NAM = ?";
    public static final String UPDATE_SUCCESSFUL_EDS_CPP_RULES_FIRST_RUN_SW =
            "UPDATE EDS_CPP_RULE SET FIRST_RUN_SW = ?,LST_UPDT_DT = ?, LST_UPDT_USER_ID =? WHERE ACTV_SW = 'Y' AND FIRST_RUN_SW = ? AND EDS_CPP_RULE_ID NOT IN(?) ";
    public static final String FETCH_EDS_CPP_RULE = "SELECT CAT_CD FROM EDS_CPP_RULE WHERE EDS_CPP_RULE_ID = ?";
    public static final String FETCH_EDS_CPP_RULE_BY_ID =
            "SELECT * FROM EDS_CPP_RULE WHERE ACTV_SW = ? AND EDS_CPP_RULE_ID = ?";
    public static final String FETCH_EDS_CPP_RULE_ID = "SELECT EDS_CPP_RULE_ID FROM EDS_CPP_RULE where ACTV_SW = ? ";
    public static final String UPDATE_EDS_CPP_RULES_FIRST_RUN_SW =
            "UPDATE EDS_CPP_RULE SET FIRST_RUN_SW = ?,LST_UPDT_DT = ?, LST_UPDT_USER_ID =? WHERE ACTV_SW = 'Y' AND FIRST_RUN_SW = ? ";
    public static final String UPDATE_CPP_SIMULATION_SW =
            "MERGE INTO EDS_CPP_RULE CPP_RULE USING EDS_CPP_SIM_DATA CPP_SIM_DATA ON (CPP_RULE.EDS_CPP_RULE_ID = CPP_SIM_DATA.CPP_RULE_ID) "
                    + "WHEN MATCHED THEN UPDATE SET CPP_RULE.IS_SMLTN_SW = ?, CPP_RULE.LST_UPDT_DT = ?, CPP_RULE.LST_UPDT_USER_ID = ? WHERE CPP_SIM_DATA.SIM_SRC_ID = ? ";
    public static final String UPDATE_CPP_SIM_SRC =
            "UPDATE EDS_CPP_SIM_SRC SET STAT_CD = ?, LST_UPDT_DT = ?, LST_UPDT_USER_ID = ? WHERE STAT_CD = ? AND SRC_NAM = ?";
    public static final String DELETE_CPP_SIM_DATA = "delete from EDS_CPP_SIM_DATA where CRTE_DT < SYSDATE - ?";
    public static final String FETCH_EDS_SIM_SRC_ID = "select SIM_SRC_ID from EDS_CPP_SIM_SRC where SRC_NAM = ? ";
    public static final String FETCH_MERCH_NAME_BY_LOCATIONID =
            "SELECT MERCHANT_DBA_NAME FROM MMH_LOCATION where OLD_LOC_ID=?";

    public static final String ENROLLED_CUSTOMER =
            "SELECT COUNT (distinct e.ICA_NUM) AS ICA_count,t.CODE AS code FROM eds_cust_mstr e INNER JOIN MBR_HIER m ON e.ICA_NUM = m.ICA_CODE "
                    + "INNER JOIN TGPACYD t ON t.ALPHA3_CD = m.COUNTRY_CODE WHERE  e.actv_sw = 'Y' AND e.crte_dt > LAST_DAY (ADD_MONTHS (TRUNC (SYSDATE, 'mm'), -2)) "
                    + "AND e.crte_dt < LAST_DAY (ADD_MONTHS (TRUNC (SYSDATE, 'mm'), -1)) + 1 GROUP BY t.CODE ORDER BY t.CODE";
    public static final String ACTIVE_CUSTOMER =
            "SELECT COUNT (DISTINCT e.ICA_NUM) AS ICA_count, t.CODE AS code FROM eds_cust_mstr e INNER JOIN MBR_HIER m ON e.ICA_NUM = m.ICA_CODE INNER JOIN TGPACYD t ON t.ALPHA3_CD = m.COUNTRY_CODE "
                    + "WHERE e.actv_sw = 'Y' GROUP BY t.CODE ORDER BY t.CODE";
    public static final String UN_ENROLLED_CUSTOMER =
            "SELECT COUNT (DISTINCT ica) as ICA_count, code FROM (SELECT e.ica_num AS ica, g.code AS code FROM eds_cust_mstr e INNER JOIN MBR_HIER f ON e.ICA_NUM = f.ICA_CODE INNER JOIN TGPACYD g ON g.ALPHA3_CD = f.COUNTRY_CODE "
                    + "WHERE e.actv_sw = 'N' AND e.LST_UPDT_DT > LAST_DAY (ADD_MONTHS (TRUNC (SYSDATE, 'mm'), -2)) AND e.LST_UPDT_DT < LAST_DAY (ADD_MONTHS (TRUNC (SYSDATE, 'mm'), -1)) + 1 UNION "
                    + "SELECT k.ica_num AS ica, n.code AS code FROM eds_cust_mstr k INNER JOIN MBR_HIER m ON k.ICA_NUM = m.ICA_CODE INNER JOIN TGPACYD n ON n.ALPHA3_CD = m.COUNTRY_CODE  WHERE  k.actv_sw = 'Y' "
                    + "AND k.rnwl_dt < LAST_DAY (ADD_MONTHS (TRUNC (SYSDATE, 'mm'), -1)) + 1 AND k.rnwl_dt > LAST_DAY (ADD_MONTHS (TRUNC (SYSDATE, 'mm'), -2))) GROUP BY code ORDER BY code";

    public static final String UPDATE_RECORD_STATUS_POST_PROCESSING_QUERY =
            "UPDATE EDS_SRC_DATA SET STAT_CD = ?, LST_UPDT_DT = ?, LST_UPDT_USER_ID = ? , JOB_INSTNCE_ID= ? WHERE EDS_SRC_DATA_ID = ?";
    public static final String UPDATE_FAULTY_INPUT_RECORD_STATUS_QUERY =
            "UPDATE EDS_SRC_DATA SET STAT_CD = ?, LST_UPDT_DT = ?, LST_UPDT_USER_ID = ?, JOB_INSTNCE_ID= ? WHERE EDS_SRC_DATA_ID = ?";
    public static final String ICAS_FOR_FILE_GEN_QUERY =
            "SELECT distinct(ICA_NUM) FROM EDS_CUST_MSTR where ACTV_SW = 'Y'";
    public static final String ICAS_HIST_FLAG_FOR_FILE_GEN_QUERY =
            " SELECT distinct(ICA_NUM) , HIST_SW FROM EDS_CUST_MSTR where ACTV_SW = 'Y' ";
    public static final String EDS_PROCESS_DATA_ID_QUERY = "select EDS_PRCSS_DATA_ID_SEQ.nextval from dual";
    public static final String DUPLICATE_PAN_CHECK =
            "select PRICE_CAT_CD,CNFDNC_SCR_NUM from (select PRICE_CAT_CD,CNFDNC_SCR_NUM from EDS_PRCSS_DATA where PAN_NUM = ? and "
                    + "FRAUD_RPT_SW = 'N' and CNFDNC_SCR_NUM=(select max(CNFDNC_SCR_NUM) from EDS_PRCSS_DATA where PAN_NUM = ? and FRAUD_RPT_SW = 'N') order by PRICE_CAT_CD asc) where  rownum=1";
    public static final String UPDATE_DUPLICATION =
            "UPDATE EDS_PRCSS_DATA set PAN_DUP_SW = ? , LST_UPDT_USER_ID = ?, LST_UPDT_DT = ? where PAN_NUM = ? and (STAT_CD != 7 OR STAT_CD IS NULL)";
    public static final String UPDATE_DUPLICATE_AND_STATUS =
            "UPDATE EDS_PRCSS_DATA set PAN_DUP_SW = ?, STAT_CD = ?, LST_UPDT_USER_ID = ?, LST_UPDT_DT = ? , JOB_INSTNCE_ID= ? where EDS_PRCSS_DATA_ID = ?";
    public static final String FETCH_MAX_MIN_EDS_SRC_DATA_QUERY =
            "select min(eds_src_data_id) as startIndex, max(eds_src_data_id) as endIndex from eds_src_data where stat_cd = ?";
    public static final String PAN_REPORTED_CHECK =
            "select case when exists (select 1 from EDS_PRCSS_DATA where PAN_NUM = ? and RPT_SW = 'Y') then 'Y' else 'N' end from dual";
    public static final String UPDATE_INPUT_RECORD_STATUS_QUERY =
            "UPDATE EDS_SRC_DATA SET STAT_CD = ?, LST_UPDT_USER_ID = ?, JOB_INSTNCE_ID= ?, ERR_DTL_DESC=?, LST_UPDT_DT=? WHERE EDS_SRC_DATA_ID = ?";
    public static final String FETCH_SRC_RULE_DATA =
            "select EDS_SRC_DATA_ID AS srcdataid, EDS_CPP_RULE_ID AS cppruleid, CAT_CD as categoryCode from ( "
                    + "select EDS_SRC_DATA_ID , EDS_CPP_RULE_ID , CAT_CD, row_number() over (partition by EDS_SRC_DATA_ID order by CAT_CD asc) rn "
                    + "FROM EDS_OWNER.EDS_SRC_RULE_DATA ruleData join EDS_OWNER.EDS_CPP_RULE rule using (EDS_CPP_RULE_ID) "
                    + "WHERE ruleData.EDS_SRC_DATA_ID BETWEEN ? AND ?) where rn = 1 order by EDS_SRC_DATA_ID";

    public static final String UPDATE_QUERY =
            "UPDATE EDS_GNRT_RPT SET STAT_CD = ?, LST_UPDT_USER_ID =? , LST_UPDT_DT = ? where FILE_NAM = ?";
    public static final String EDS_GRNT_RPT_ID_SEQ = "select EDS_GRNT_RPT_ID_SEQ.nextval from dual";
    public static final String FETCH_QUEUED_FILES_QUERY =
            "SELECT EDS_SRC_ID, EDS_SRC_TYPE_ID, SRC_NAM, LOC_TXT, ERR_FILE_NAM, ERR_FILE_LOC_TXT, PURGED_SW, LST_UPDT_USER_ID, LST_UPDT_DT FROM EDS_SRC WHERE STAT_CD = ?";
    public static final String UPDATE_FILE_STATUS_PRE_PROCESSING_QUERY =
            "UPDATE EDS_SRC SET STAT_CD = ?, LST_UPDT_DT = ?, LST_UPDT_USER_ID = ? , JOB_INSTNCE_ID = ? WHERE STAT_CD = ? AND SRC_NAM = ?";
    public static final String UPDATE_FILE_STATUS_POST_PROCESSING_QUERY =
            "UPDATE EDS_SRC SET STAT_CD = ?, LST_UPDT_DT = ?, LST_UPDT_USER_ID = ? WHERE STAT_CD = ? AND SRC_NAM = ?";
    public static final String UPDATE_ERROR_DETAILS_QUERY =
            "update EDS_SRC set ERR_FILE_NAM = ? , ERR_FILE_LOC_TXT = ? where SRC_NAM = ?";
    public static final String UPDATE_SOURCE_STATUS_QUERY = "update EDS_SRC set STAT_CD = ?  where SRC_NAM = ?";

    public static final String UPDATE_SOURCE_FOR_KEY_STATUS_QUERY =
            "update EDS_SRC set STAT_CD = ? , ERR_DTL_TXT = ?, LST_UPDT_DT = ?, LST_UPDT_USER_ID = ? where SRC_NAM = ?";
    public static final String FETCH_COUNTRY_EXPONENT_MAP = "select ALPHA_CURR_CD,CURR_EXPNT_NUM from CURR_CD_HIER";
    public static final String FETCH_EDS_SRC_ID = "SELECT EDS_SRC_ID FROM EDS_SRC WHERE SRC_NAM = ?";
}
