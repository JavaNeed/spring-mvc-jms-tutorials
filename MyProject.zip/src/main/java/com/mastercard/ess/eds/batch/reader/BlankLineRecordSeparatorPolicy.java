package com.mastercard.ess.eds.batch.reader;

import org.springframework.batch.item.file.separator.SimpleRecordSeparatorPolicy;

/**
 * this class removes all blank line from input file to avoid parsing exception
 *
 */
public class BlankLineRecordSeparatorPolicy extends SimpleRecordSeparatorPolicy {

	@Override
	public boolean isEndOfRecord(final String line) {
		if (line.trim().length() == 0) {
			return false;
		}
		return super.isEndOfRecord(line);
	}

	@Override
	public String postProcess(final String record) {
		if (record == null || record.trim().length() == 0) {
			return null;
		}
		return super.postProcess(record);
	}

}
