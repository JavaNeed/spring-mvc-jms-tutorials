package com.mastercard.ess.eds.batch.writer;

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.service.EDSRecordWriterService;
import com.mastercard.ess.eds.core.service.EDSSourceService;
import com.mastercard.ess.eds.domain.EDSRecord;

/**
 *  EDS Records as received by chained processors after processing are sent to writer service to be written
 *  in EDS_SOURCE_PROC_DATA table
 * @author e067588
 *
 */
public class EDSRecordDBWriter implements ItemWriter<EDSRecord>, ItemWriteListener<EDSRecord>{

	
	private static Logger logger = Logger.getLogger(EDSRecordDBWriter.class);

	@Autowired
	EDSRecordWriterService edsRecordWriterService;
	
	@Autowired
	EDSSourceService edsSourceService;
	
	private String jobInstanceName;
	
	private BigDecimal jobInstanceId;

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}
	
	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}
	
	// Added for JUnit
	public String getJobInstanceName(){
		return jobInstanceName;
	}
	
	public EDSRecordDBWriter() {
		super();
	}
	public EDSRecordDBWriter(EDSRecordWriterService edsRecordWriterService) {
		super();
		this.edsRecordWriterService = edsRecordWriterService;
	}


	/*
	 * After read step data will be persisted in eds source data table in
	 * this method . Records come in form of List of object and stored in DB
	 */
	@Override
	public void write(List<? extends EDSRecord> edsRecords){
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : write ");
		}
	
		edsRecordWriterService.writeRecord(edsRecords, jobInstanceId);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : write ");
		}
		
	}
	@Override
	public void afterWrite(List<? extends EDSRecord> edsRecords) {
		logger.info("Going to update the status code 4 in EDS_SRC_DATA");
		edsRecordWriterService.updateRecordStatusPostProcessing(edsRecords,jobInstanceName, jobInstanceId);					
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : afterWrite ");
		}
	}
	
	@Override
	public void beforeWrite(List<? extends EDSRecord> paramList) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : beforeWrite ");
		}
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : beforeWrite ");
		}
		
	}
	@Override
	public void onWriteError(Exception paramException, List<? extends EDSRecord> paramList) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : onWriteError ");
		}
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : onWriteError ");
		}
		
	}

}
