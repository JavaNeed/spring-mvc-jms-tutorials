package com.mastercard.ess.eds.batch.validator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.crypto.SecretKey;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;

import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.core.parser.VendorPayloadTokens;
import com.mastercard.ess.eds.core.service.EDSSourceService;
import com.mastercard.ess.eds.core.util.SecurityUtils;
import com.mastercard.ess.eds.notification.util.NotificationEventConstants;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;

public class PreProcessor implements Tasklet{
	
	private static Logger logger = Logger.getLogger(PreProcessor.class);
	
	@Autowired
	EDSSourceService edsSourceService;
	@Autowired
	EventPublisher eventPublisher;
	@Autowired
	NotificationEventVO notificationEventVO;
	
	@Autowired
	SecurityUtils securityUtils;
	
	@Value("${input.directory}")
	private String unzipLocation;
	
	private String sessionKeyFile;
	
	private String dataFileName;
	
	public void setSessionKeyFile(String sessionKeyFile) {
		this.sessionKeyFile = sessionKeyFile;
	}

	public void setDataFileName(String dataFileName) {
		this.dataFileName = dataFileName;
	}

	public void setUnzipLocation(String unzipLocation) {
		this.unzipLocation = unzipLocation;
	}

	/* 
	 * this method unzip the zip input file and extract the wrapped session key 
	 * from key file and store it in executionContext.
	 */
	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext)
			throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : execute ");
		}
		Properties propertyFile = (Properties) chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get("vendorProperties");
		
		setSessionKeyFile(propertyFile.getProperty(VendorPayloadTokens.WRAPPED_KEY_FILENAME.getDesc()));
		setDataFileName(propertyFile.getProperty(VendorPayloadTokens.DATAFILE_NAME.getDesc()));
		
		List<String> filesInsideZip = new ArrayList<String>();
		
		byte[] buffer = new byte[1024];
		String unzipedFileName =""; 
		
		String fullyQualifiedfileName = (String) chunkContext.getStepContext()
				.getJobParameters().get("input.file");

		FileSystemResource fileSystemResource = new FileSystemResource(
				fullyQualifiedfileName);
		String zipFileName = fileSystemResource.getFile().getName();
		
		unzipedFileName = unzipLocation + zipFileName;
		
			
		File tempFolder = new File(unzipedFileName);
		
		if(!tempFolder.exists()){
			tempFolder.mkdir();
    	}

		try (FileInputStream fis = new FileInputStream(fileSystemResource.getFile().getPath().substring(5));
			
			ZipInputStream zis = new ZipInputStream(fis)) {
				
			ZipEntry ze = zis.getNextEntry();
			while (ze != null) {

				String fileName = ze.getName();
				filesInsideZip.add(fileName);
				File newFile = writeInCreatedNewFile(buffer, tempFolder, zis,
						fileName);
				ze = zis.getNextEntry();
				
				addSessionKeyWithContext(chunkContext, fileName, newFile);
				
			}
			
			boolean isSessionKeyPresent = checkKeyFilePresent(filesInsideZip);
			
			Map <String,String> jobParams=new HashMap<String,String>();
			if(!isSessionKeyPresent){
				/*
				 * Key value pair for JsonString is provided
				 * For Invalid File scenarios: Setting params with keys available from NotificationEventConstants File
				 */				
				jobParams.put(NotificationEventConstants.TOKEN_SOURCE_NAME,(String) chunkContext
                        .getStepContext()
                        .getStepExecution()
                        .getJobExecution()
                        .getExecutionContext()
                        .get(NotificationEventConstants.TOKEN_SOURCE_NAME));
				jobParams.put(NotificationEventConstants.TOKEN_ERROR_MESSAGE,NotificationEventConstants.ERROR_MSG_DATA_KEY_MISSING);
				jobParams.put(NotificationEventConstants.TOKEN_FILE_NAME, zipFileName);
				jobParams.put(NotificationEventConstants.TOKEN_FILE_SIZE, (String)chunkContext
                        .getStepContext()
                        .getStepExecution()
                        .getJobExecution()
                        .getExecutionContext()
                        .get(NotificationEventConstants.TOKEN_FILE_SIZE));		
				
				
				
				/*
				 * setting the values for notificationEventVO
				 */
				notificationEventVO.setEventName(NotificationEventConstants.NOTIF_EVT_INVALID_SOURCE_FILE_RECEIVED);
				notificationEventVO.setJobParams(jobParams);
				notificationEventVO.setJobName("importRawRecords");
				notificationEventVO.setJobID((BigDecimal)chunkContext
		                .getStepContext()
		                .getStepExecution()
		                .getJobExecution()
		                .getExecutionContext()
		                .get(NotificationEventConstants.JOB_ID));
				logger.info("inside Preprocessor | Event has been triggered for the event : "+notificationEventVO.getEventName());
				
				eventPublisher.placeEvent(notificationEventVO);
				stepContribution.setExitStatus(new ExitStatus("FAILED"));
				edsSourceService.updateSourceForMissingKey(zipFileName);
				
			}else {
				
				/*
				 * setting the values for event notificationEventVO
				 */
				jobParams.put(NotificationEventConstants.TOKEN_SOURCE_NAME,(String) chunkContext.getStepContext().getJobExecutionContext().get(NotificationEventConstants.TOKEN_SOURCE_NAME));

				notificationEventVO.setEventName(NotificationEventConstants.NOTIF_EVT_VALID_SOURCE_FILE_RECEIVED);
				notificationEventVO.setJobName("importRawRecords");
				notificationEventVO.setJobParams(jobParams);
				
				notificationEventVO.setJobID((BigDecimal)chunkContext
		                .getStepContext()
		                .getStepExecution()
		                .getJobExecution()
		                .getExecutionContext()
		                .get(NotificationEventConstants.JOB_ID));
				logger.info("inside Preprocessor | Event has been triggered for the event : "+notificationEventVO.getEventName());
				
				eventPublisher.placeEvent(notificationEventVO);
			}
			
			zis.closeEntry();
	    	zis.close();
	    	
			
		}catch(IOException ex){
			   stepContribution.setExitStatus(new ExitStatus("FAILED"));
			   logger.error("exception occured in unzipping the file : " + ex);
		}
		
		return RepeatStatus.FINISHED;
	}

	/**
	 * @param chunkContext
	 * @param fileName
	 * @param newFile
	 */
	private void addSessionKeyWithContext(ChunkContext chunkContext,
			String fileName, File newFile) {
		logger.info("sessionKeyFile - " + sessionKeyFile);
		if (fileName.equals(sessionKeyFile)) {
			String wrappedSessionKey = readWrappedSessionKey(newFile);
			SecretKey sessionKey = unwrapSessionKey(wrappedSessionKey);
			chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("session.key", sessionKey);
		}
	}

	/**
	 * @param buffer
	 * @param tempFolder
	 * @param zis
	 * @param fileName
	 * @return
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	private File writeInCreatedNewFile(byte[] buffer, File tempFolder,
			ZipInputStream zis, String fileName) throws IOException,
			FileNotFoundException {
		File newFile = new File(tempFolder.getPath() + File.separator
				+ fileName);
		// create all non exists folders
		// else you will hit FileNotFoundException for compressed folder
		new File(newFile.getParent()).mkdirs();

		try (FileOutputStream fos = new FileOutputStream(newFile)) {

			int len; 
			while ((len = zis.read(buffer)) > 0) {
				fos.write(buffer, 0, len);
			}
		}
		return newFile;
	}


	/**
	 * @param filesInsideZip : all files zipped in side file from vendor
	 * @return : checks a list of required file in side the zip file
	 *           and returns true if all expected files present.
	 */
	public boolean checkKeyFilePresent(List<String> filesInsideZip) {
		
		boolean isValidZip = filesInsideZip.containsAll(Arrays.asList(dataFileName,sessionKeyFile));
		
		if (isValidZip) {
			return true;
		}
		return false;
	}

	/**
	 * @param newFile : reads the key file 
	 * @return : wrappedSessionKey
	 */
	public String readWrappedSessionKey(File newFile) {
		logger.info("PreProcessor | readWrappedSessionKey | Enter method - ");
		String sessionKey = null;
		String sCurrentLine;
		
		try (FileReader fr = new FileReader(newFile);
			BufferedReader br = new BufferedReader(fr)) {

			while (((sCurrentLine = br.readLine()) != null) && (!(sCurrentLine.trim().isEmpty()))) {
				sessionKey = sCurrentLine;
			}

		} catch (IOException e) {
			logger.error("exception occured in reading the file : " + e);
		}

		logger.info("PreProcessor | readWrappedSessionKey | Exit method - ");
		return sessionKey;
	}

	/**
	 * @param wrappedSessionKey : wrappedSessionKey fetched from key file
	 * @return : This method returns SecretKey to decrypt the encrypted data
	 *           in input csv file
	 */
	public SecretKey unwrapSessionKey(String wrappedSessionKey) {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : unwrapSessionKey ");
		}
		
		SecretKey secretKey = securityUtils.getSessionKey(wrappedSessionKey);
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : unwrapSessionKey ");
		}
		
		return secretKey;
		
	}
	
	//For Junit

	public void setSecurityUtils(SecurityUtils securityUtils) {
		this.securityUtils = securityUtils;
	}

	

}
