package com.mastercard.ess.eds.core.dao;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;


@Component
public class CPPDAO {
	
	private Logger logger = Logger.getLogger(CPPDAO.class);
	
	@Value("${cppdata.purge}")
	private String truncateCPPFlag;

	private JdbcTemplate jdbcTemplate;

	public CPPDAO(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * this method truncates EDS_CPP_TRAN and EDS_CPP_TRAN_SUMM
	 * before cppAnalysis job is started
	 */
	public void truncateCPPData() {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : truncateCPPData | CPPDAO ");
		}

		if ("Y".equals(truncateCPPFlag)) {
			logger.info("CPP Data truncated ");
			final String truncateTranSql = "DELETE FROM EDS_CPP_TRAN";
			int rows = jdbcTemplate.update(truncateTranSql);
			logger.info("EDS_CPP_TRAN truncated. Total number of rows deleted -"
					+ rows);

			final String truncateSummarySql = "DELETE FROM EDS_CPP_TRAN_SUMM";
			int rowsSummary = jdbcTemplate.update(truncateSummarySql);

			logger.info("EDS_CPP_TRAN_SUMM truncated. Total number of rows deleted -"
					+ rowsSummary);
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : truncateCPPData | CPPDAO ");
		}

	}

}
