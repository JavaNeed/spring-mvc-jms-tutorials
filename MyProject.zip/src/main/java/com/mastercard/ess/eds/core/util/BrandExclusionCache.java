package com.mastercard.ess.eds.core.util;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.dao.BrandExclusionDAO;

public class BrandExclusionCache {

	private static Logger logger = Logger.getLogger(BrandExclusionCache.class); 

	@Autowired
	private BrandExclusionDAO brandExclusionDAO;

	private List<String> excludedBrands;

	// for JUnit
	public List<String> getExcludedBrands() {
		return excludedBrands;
	}

	// for JUnit
	public void setExcludedBrands(List<String> excludedBrands) {
		this.excludedBrands = excludedBrands;
	}

	public void updateListOfExcludedBrands() {

		if (logger.isDebugEnabled()) {
			logger.debug("BrandExclusionCache | updateListOfExcludedBrands | Enter in method ");
		}

		excludedBrands = brandExclusionDAO.getExcludedBrandList();

		if (logger.isDebugEnabled()) {
			logger.debug("BrandExclusionCache | updateListOfExcludedBrands | Exit from method ");
		}
	}

	public List<String> getListOfExcludedBrands() {

		if (null != excludedBrands) {
			return excludedBrands;
		} else {
			updateListOfExcludedBrands();
		}
		return excludedBrands;
	}

	// for JUnit
	public void setBrandExclusionDAO(BrandExclusionDAO brandExclusionDao2) {
		brandExclusionDAO = brandExclusionDao2;

	}
}
