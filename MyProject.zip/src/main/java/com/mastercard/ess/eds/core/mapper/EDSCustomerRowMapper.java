package com.mastercard.ess.eds.core.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.mastercard.ess.eds.domain.EDSCustomer;

/**
 * Maps columns from EDS_CUST_MSTR table to fields in EDS Customer domain object. Required by reader while
 * parsing data and returning a populated object.
 * 
 *
 */
public class EDSCustomerRowMapper implements RowMapper<EDSCustomer> {
	
	private static Logger logger = Logger.getLogger(EDSCustomerRowMapper.class);

	@Override
	public EDSCustomer mapRow(ResultSet paramResultSet, int paramInt) throws SQLException {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : mapRow ");
		}
		
		EDSCustomer customer = new EDSCustomer();
		customer.setCustomerName(paramResultSet.getString("CUST_NAM"));
		customer.setIca(paramResultSet.getLong("ICA_NUM"));
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : mapRow ");
		}
		
		return customer;
	}

}
