package com.mastercard.ess.eds.core.util;

import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.dao.CidDAO;
import com.mastercard.ess.eds.core.dao.DAAcctRangeDAO;
import com.mastercard.ess.eds.core.dao.PANAccountRangeDAO;
import com.mastercard.ess.eds.domain.PANAccountRange;

/**
 * This cache is maintained locally to reduce any DB calls for validating PAN against range from RDS database.
 * @author e067588
 *
 */
public class PANAccountRangeCache {
	
	private static Logger logger = Logger.getLogger(PANAccountRangeCache.class);
	
	/** Read Write Lock for Cache. */
    private static final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    
	@Autowired
	private PANAccountRangeDAO panAccountRangeDao;

	@Autowired
	private DAAcctRangeDAO daAcctRangeDAO;
	
	@Autowired
	CidDAO cidDAO;
	
	public String getScheduleExpression() {
		return scheduleExpression;
	}

	public void setScheduleExpression(String scheduleExpression) {
		this.scheduleExpression = scheduleExpression;
	}


	private String scheduleExpression;
	
	private Map<PANAccountRange,PANAccountRange> panAccountRangeCache;
	

	
	//for JUnit Test
	public void setPanAccountRangeDao(PANAccountRangeDAO panAccountRangeDao){
		this.panAccountRangeDao = panAccountRangeDao;
	}
	
	public void setDaAcctRangeDAO(DAAcctRangeDAO daAcctRangeDAO) {
		this.daAcctRangeDAO = daAcctRangeDAO;
	}

	public void setCidDAO(CidDAO cidDAO) {
		this.cidDAO = cidDAO;
	}


	/**
	 * This method will first load the Range data and then schedule the update service to run at intervals configured in the scheduler.properties file.
	 * @return true/false based on the successful update of cache
	 */
	public boolean loadPanAccRangeCache(){
		if (logger.isDebugEnabled()) {
			logger.debug("Enter PANAccountRangeCache | getInstance()");
		}
		
		boolean isUpdated = updateCache();
		if(!isUpdated) {
			logger.error("Error while updating pan account range Cache");
		} else {
			ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
			
			scheduler.scheduleWithFixedDelay(new Runnable(){
				@Override
				public void run() {
					boolean isUpdated = updateCache();
					if(!isUpdated) {
						logger.error("Error while updating pan account range Cache");
					}
					logger.info("Exit thread to update Cache");
				}
			}, new Long(scheduleExpression), new Long(scheduleExpression), TimeUnit.MINUTES);
		}
		if (logger.isDebugEnabled()) {
			logger.info("Exit PANAccountRangeCache | getInstance()");
		}
		return isUpdated;
	}
	
	/**
	 * Method to update the panAccRangeCache, rtnCache and CIDCache. Returns true if panAccRangeCache is updated.
	 * @return
	 */
	public boolean updateCache(){
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : updateCache ");
		}
        lock.writeLock().lock();
        boolean isUpdated = true;
		try {
			Map <PANAccountRange, PANAccountRange> updatedARCache = panAccountRangeDao.getPANAccountRangeCache();
			if (null != updatedARCache && !updatedARCache.isEmpty()) {
				panAccountRangeCache = updatedARCache;
			} else {
				isUpdated = false;
			}

		} finally {
			lock.writeLock().unlock();
			if (logger.isDebugEnabled()) {
				logger.debug("Exit from method : updateCache ");
			}
		}
		return isUpdated;
	}

	
	public Map<PANAccountRange,PANAccountRange> getCache(){
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : getCache ");
		}
		if (null != panAccountRangeCache)
		{
			if (logger.isDebugEnabled()) {
				logger.debug("Exit from method : getCache ");
			}
		return panAccountRangeCache;
		}
		else{
			updateCache();
			if (logger.isDebugEnabled()) {
				logger.debug("Exit from method : getCache ");
			}
			return panAccountRangeCache;
		}
	}
}
