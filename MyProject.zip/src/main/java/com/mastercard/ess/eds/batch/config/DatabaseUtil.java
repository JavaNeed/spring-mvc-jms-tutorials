package com.mastercard.ess.eds.batch.config;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.UncategorizedSQLException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class DatabaseUtil {
	
	private   Logger logger = Logger.getLogger(DatabaseUtil.class);
	
	@Autowired 
	@Qualifier("primaryDWDataSource") 
	private DataSource primaryDWDataSource ;
	 
	@Autowired 
	@Qualifier("secondaryDWDataSource") 
	private DataSource secondaryDWDataSource ; 
	
	 public   JdbcTemplate buildDWJdbcTemplate() {
		JdbcTemplate jdbcTemplate = null ;
		try {
			jdbcTemplate = new JdbcTemplate(primaryDWDataSource);
			logger.info("Connected to Primary Data source successfully"); 
		} catch (UncategorizedSQLException e) {
				UncategorizedSQLException ex=(UncategorizedSQLException) e;
				logger.info("SQL Error Obtained" +ex.getSQLException().getErrorCode());
				if(SQLErrorCodes.shouldRetryForSQLErrorCode(ex.getSQLException().getErrorCode())){
					try{
						jdbcTemplate = new JdbcTemplate(secondaryDWDataSource);
					}catch(DataAccessException de){
						logger.error("Exception Occured accessing the secondary DW data source"+de);
					}
				}
			
		}catch (DataAccessException e) {
			logger.error("Exception Occured accessing the secondary DW data source"+e);
		}
		
		return jdbcTemplate;
	} 
	 
}
