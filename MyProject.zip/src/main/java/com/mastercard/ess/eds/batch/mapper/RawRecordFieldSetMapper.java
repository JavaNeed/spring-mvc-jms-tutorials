package com.mastercard.ess.eds.batch.mapper;

import java.util.Date;
import java.util.Properties;

import javax.crypto.SecretKey;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.BindException;

import com.mastercard.ess.eds.core.parser.EDSParser;
import com.mastercard.ess.eds.core.parser.VendorPayloadTokens;
import com.mastercard.ess.eds.core.util.DeDupeLevels;
import com.mastercard.ess.eds.core.util.DeDupePan;
import com.mastercard.ess.eds.core.util.DeDupeTokens;
import com.mastercard.ess.eds.core.util.EDSProcessStatus;
import com.mastercard.ess.eds.domain.PANMetadataRecord;
import com.mastercard.ess.eds.domain.RawRecord;

/**
 * this class maps data obtained from a fieldSet into an object.
 *
 */
public class RawRecordFieldSetMapper implements
FieldSetMapper<RawRecord> {

	private static Logger logger = Logger.getLogger(RawRecordFieldSetMapper.class);

	@Value("${enc.transform}")
	public String transform;

	private String jobInstanceName;

	private ExecutionContext executionContext;
	
	public String getTransform() {
		return transform;
	}

	public void setTransform(String transform) {
		this.transform = transform;
	}

	public String getJobInstanceName() {
		return jobInstanceName;
	}

	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}

	public ExecutionContext getExecutionContext() {
		return executionContext;
	}

	public void setExecutionContext(ExecutionContext executionContext) {
		this.executionContext = executionContext;
	}

	/* 
	 * This method invokes a vendor specific parser to decrypt and map data obtained from a fieldSet into an object.
	 */
	@Override
	public RawRecord mapFieldSet(FieldSet fieldSet) throws BindException {

		logger.info("Enter in RawRecordFieldSetMapper : mapFieldSet() ");

		RawRecord rawRecord = null;

		SecretKey sessionKey = (SecretKey)this.executionContext.get(VendorPayloadTokens.SESSION_KEY.getDesc());

		try {
			Properties vendorProperties = (Properties) this.executionContext.get("vendorProperties");
			String parserClassName = (String) vendorProperties.get(VendorPayloadTokens.PAYLOAD_PARSER.getDesc());
			String encLevel = (String) vendorProperties.get(VendorPayloadTokens.ENC_LEVEL.getDesc());
			Class cls = Class.forName(parserClassName);  
			EDSParser parser = (EDSParser) cls.newInstance();
			logger.info("Parser loaded successfully!");

			if(vendorProperties.get(VendorPayloadTokens.ENC_TRANSFORM.getDesc()) != null){
				setTransform((String) vendorProperties.get(VendorPayloadTokens.ENC_TRANSFORM.getDesc()));
			}
			String encFields = null;
			if(encLevel.equalsIgnoreCase(VendorPayloadTokens.FIELD.getDesc())){
				encFields = (String) vendorProperties.get(VendorPayloadTokens.ENC_FIELDS.getDesc());
			}

			rawRecord = parser.parseAndDecrypt(fieldSet, sessionKey, getTransform(), encFields);

			/*
			 * Check if pan is duplicate and set isDuplicate as Y or N
			 */
			rawRecord = checkDuplicate(rawRecord);

			rawRecord.setCreatedBy(getJobInstanceName());
			rawRecord.setCreateDate(new Date());
			rawRecord.setLastUpdatedBy(getJobInstanceName());
			rawRecord.setLastUpdateDate(new Date());

		} catch (Exception e) {
			logger.error("Exception in RawRecordFieldSetMapper : mapFieldSet() : " + e.getMessage());
			throw new BindException(e, e.getMessage());
		}

		logger.info("Exit from RawRecordFieldSetMapper : mapFieldSet() ");

		return rawRecord;

	}

	public RawRecord checkDuplicate(RawRecord rawRecord){
		DeDupePan deDupePan = (DeDupePan) this.executionContext.get(DeDupeTokens.DE_DUPE_PAN.getDesc());
		PANMetadataRecord panMetadataRecord = new PANMetadataRecord();
		panMetadataRecord.setPan(rawRecord.getRawPan());
		panMetadataRecord.addMetadataEntry(DeDupeTokens.SOURCE.getDesc(), DeDupeTokens.EXTERNAL.getDesc());
		/*Check level1 cache, if pan is duplicate(true) then mark it as duplicate
		 * If pan is not duplicate in level1 then check level2.*/
		if(deDupePan.isDuplicate(panMetadataRecord, DeDupeLevels.LEVEL_LOCAL)){

			rawRecord.setIsDuplicate(DeDupeTokens.DUPLICATE_Y.getDesc());
			rawRecord.setStatus(EDSProcessStatus.ERROR.getStatusCode());
		} else {
			deDupePan.addPan(panMetadataRecord, DeDupeLevels.LEVEL_LOCAL);
			rawRecord.setIsDuplicate(DeDupeTokens.DUPLICATE_N.getDesc());
			rawRecord.setStatus(EDSProcessStatus.UNPROCESSED.getStatusCode());
		}
		return rawRecord;
	}
}
