package com.mastercard.ess.eds.batch.writer;

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.service.RawRecordDBWriterService;
import com.mastercard.ess.eds.domain.RawRecord;

public class RawRecordDBWriter implements ItemWriter<RawRecord> {


	private static Logger logger = Logger.getLogger(RawRecordDBWriter.class);
	
	private String edsSrcId;
	
    public String srcName;
    
    private BigDecimal jobInstanceId;

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}
	
	public void setSrcName(String srcName) {
		this.srcName = srcName;
	}


	@Autowired
	RawRecordDBWriterService rawRecordDBWriterService;
	
	public RawRecordDBWriter() {
		super();
	}
	public RawRecordDBWriter(RawRecordDBWriterService rawRecordDBWriterService) {
		super();
		this.rawRecordDBWriterService = rawRecordDBWriterService;
	}


	/*
	 * After read step data will be persisted in eds source data table in
	 * this method . Records come in form of List of object and stored in DB
	 */
	@Override
	public void write(List<? extends RawRecord> rawRecords) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : write ");
		}
		
		edsSrcId = rawRecordDBWriterService.getEdsSrcId(srcName);
		
		rawRecordDBWriterService.writeRecord(rawRecords,edsSrcId, jobInstanceId);
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : write ");
		}
	}

}
