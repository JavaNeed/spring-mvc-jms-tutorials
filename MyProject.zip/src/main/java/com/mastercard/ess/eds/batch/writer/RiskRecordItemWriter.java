package com.mastercard.ess.eds.batch.writer;

import static com.mastercard.ess.eds.constant.BatchConstants.COMMA_DELIMITER;
import static com.mastercard.ess.eds.constant.BatchConstants.COUNTER_PREFIX;
import static com.mastercard.ess.eds.constant.BatchConstants.CUSTOMER_FILE_HEADER;
import static com.mastercard.ess.eds.constant.BatchConstants.DATE_PREFIX;
import static com.mastercard.ess.eds.constant.BatchConstants.DOT;
import static com.mastercard.ess.eds.constant.BatchConstants.EVENT_ID_AT_PAN_RISK;
import static com.mastercard.ess.eds.constant.BatchConstants.ICA_TO_RANGE_CACHE;
import static com.mastercard.ess.eds.constant.BatchConstants.NEW_LINE_SEPERATOR;
import static com.mastercard.ess.eds.constant.BatchConstants.TIME_PREFIX;
import static com.mastercard.ess.eds.constant.BatchConstants.NO ;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.mastercard.ess.eds.batch.config.FileStatus;
import com.mastercard.ess.eds.batch.exception.EDSCoreException;
import com.mastercard.ess.eds.core.icatopanmapping.ICAAccountRange;
import com.mastercard.ess.eds.core.icatopanmapping.PanVerificationUsingICAToRangeMapping;
import com.mastercard.ess.eds.core.rule.PriceCategoryRule;
import com.mastercard.ess.eds.core.service.CustomerFileReportService;
import com.mastercard.ess.eds.core.service.CustomerMasterService;
import com.mastercard.ess.eds.core.service.EDSRecordWriterService;
import com.mastercard.ess.eds.core.util.EDSProcessStatus;
import com.mastercard.ess.eds.core.util.PriceCategoryRuleCache;
import com.mastercard.ess.eds.core.util.UniqueFileNameFetcherUtils;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.ICAStatus;
import com.mastercard.ess.eds.notification.util.NotificationEventConstants;

public class RiskRecordItemWriter implements ItemWriter<EDSRecord>,
StepExecutionListener {



	private static Logger logger = Logger.getLogger(RiskRecordItemWriter.class);
	
	@Value("${customerfiles.directory}")
	private String location;

	@Value("${customerfiles.prefix}")
	private String filePrefix;

	@Autowired
	private EDSRecordWriterService edsRecordWriterService;


	@Autowired
	private CustomerFileReportService customerFileReportService;

	@Autowired
	private CustomerMasterService customerMasterService;

	@Autowired
	private PriceCategoryRuleCache priceCategoryRuleCache;
	
	@Autowired
	private UniqueFileNameFetcherUtils uniqueFileNameFetcherUtils ;
	
	private String jobInstanceName;
	private BigDecimal jobInstanceId;
	
	private String icaNum;
	private String organizationName;
	private List<ICAStatus> icastatusList = null ;
	private	List<EDSRecord> listOfRecordsToWrite = new CopyOnWriteArrayList<>();
	private List<EDSRecord> listOfDupRecords = new CopyOnWriteArrayList<>();
	private Map <BigDecimal, String> uniquePanMap = new ConcurrentHashMap<>();
	private Map<BigDecimal, String> procRecordToFileMap = new ConcurrentHashMap<>();

	private ExecutionContext executionContext;

	public RiskRecordItemWriter() {
		super();
	}

	public RiskRecordItemWriter(String location, String filePrefix,
			PriceCategoryRuleCache priceCategoryRuleCache, BigDecimal jobInstanceId,
			String jobInstanceName) {
		this.location = location;
		this.filePrefix = filePrefix;
		this.priceCategoryRuleCache = priceCategoryRuleCache;
		this.jobInstanceId = jobInstanceId;
		this.jobInstanceName = jobInstanceName;

	}



	public void setServices(
			CustomerFileReportService customerFileReportService,
			CustomerMasterService customerMasterService,
			EDSRecordWriterService edsRecordWriterService) {
		this.customerFileReportService = customerFileReportService;
		this.customerMasterService = customerMasterService;
		this.edsRecordWriterService = edsRecordWriterService;
	}

	// for Junit
	public void setList(List<EDSRecord> listOfRecordsToWrite,
			Map<BigDecimal, String> procRecordToFileMap) {
		this.listOfRecordsToWrite = listOfRecordsToWrite;
		this.procRecordToFileMap = procRecordToFileMap;
	}

	public void setService(EDSRecordWriterService edsRecordWriterService) {
		this.edsRecordWriterService = edsRecordWriterService;
	}

	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}
	public ExecutionContext getExecutionContext() {
		return executionContext;
	}

	public void setExecutionContext(ExecutionContext executionContext) {
		this.executionContext = executionContext;
	}

	@Override
	public void write(List<? extends EDSRecord> edsRecordList) throws Exception {

		logger.info("Enter into the RiskRecordItemWriter: write Method");
		
		
		if (!edsRecordList.isEmpty()) {
			

		ICAStatus icaStatus = new ICAStatus();
			
		try{
			icastatusList = getICAList();
			String ica = getIcaFromRecord(edsRecordList);
			icaStatus.setIca(ica);
			
			edsRecordList = validatePansToIcas(edsRecordList, ica);
			logger.info("edsRecordList size = "+ edsRecordList.size());
			
			if(edsRecordList.isEmpty()){
				return ;
			}
	
			logger.info("edsRecordList size = "+ edsRecordList.size());
			Set<EDSRecord> edsRecordSet = edsRecordList.stream().collect(Collectors.toSet()); 
			logger.info("edsRecordSet size = "+ edsRecordSet.size());
			if(edsRecordSet.size() < edsRecordList.size()){
				populateSentFlag(edsRecordList);
			}
			
			Map<String, Object> customerInfo = customerMasterService.getCustomerInfo(ica);
			
			
			String filename = getFileNameFromIca(ica, customerInfo);
			icaStatus.setFileName(filename);

			Object custMasterKey = customerInfo.get("EDS_CUST_MSTR_ID");

			Object custName = customerInfo.get("CUST_NAM");
			organizationName = (null != custName) ? "" + custName : "";

			logger.info("Customer Master Key=" + custMasterKey
					+ ", for filename =" + filename);

			BigDecimal masterKey = (null != custMasterKey) ? new BigDecimal(""
					+ custMasterKey) : BigDecimal.ONE;

			Map<Integer, PriceCategoryRule> rulesMap = priceCategoryRuleCache
					.getPriceCategoryMap();
			Instant createTime = Instant.now();	
			try (FileWriter fileWriter = new FileWriter(location
						+ System.getProperty("file.separator") + filename)) {
	
				synchronized (fileWriter) {

					fileWriter.append(CUSTOMER_FILE_HEADER);
					fileWriter.append(NEW_LINE_SEPERATOR);

					for (EDSRecord edsRecord : edsRecordList) {
						prepareEDSRecordList(NEW_LINE_SEPERATOR, COMMA_DELIMITER,
								filename, rulesMap, fileWriter, edsRecord);

					}
					fileWriter.flush();
					logger.debug("file flushed, calling createCustomerReportRecord");

					customerFileReportService.createCustomerPanReportRecord(
							masterKey, ica, filename, location,
							jobInstanceName, jobInstanceId);
					icaStatus.setStatus(FileStatus.GEN_SUCCESS.getStatus());
					
					logger.info("CSV file was created successfully !!!");

					}
				
				} catch (IOException e) {
					icaStatus.setErrorDetails(e.getMessage());
					icaStatus.setStatus(FileStatus.GEN_FAILURE.getStatus());
					icaStatus.setFileName(null);
					logger.error("Exception occured while writing the file exception= "
							+ e.getMessage());
				}
			
			Instant endTime = Instant.now();	
			logger.info("Time to create the file with ICA = " + icaNum + "Period = "+(Duration.between(createTime, endTime)));
			
			}
			catch (Exception e) {
				icaStatus.setErrorDetails(e.getMessage());
				icaStatus.setStatus(FileStatus.GEN_FAILURE.getStatus());
				icaStatus.setFileName(null);
				logger.error("Exception occured while creating a file" + e.getMessage());
			}
		
			icastatusList.add(icaStatus);
			this.executionContext.put("icaStatusList", icastatusList );
		}
	}
	
	/**
	 * This method populates the sent Flag for EDSRecord based on the confidence score and process data id
	 * @param edsRecordList
	 */
	private void populateSentFlag(List<? extends EDSRecord> edsRecordList) {
		Map<String,  List<EDSRecord>> edsRecordMap = new ConcurrentHashMap<String, List<EDSRecord>>();
		for(EDSRecord edsRecord : edsRecordList){
			edsRecord.getProcRecord().setToBeSentFlag("Y");
			List<EDSRecord> edsRecordsForPANList;
			if (edsRecordMap.containsKey(edsRecord.getProcRecord().getPan())) {
				edsRecordsForPANList = edsRecordMap.get(edsRecord.getProcRecord().getPan());
				checkConfScoreAndPrcssId(edsRecordsForPANList,edsRecord);
			} else {
				edsRecordsForPANList = new CopyOnWriteArrayList<>();
			}
			edsRecordsForPANList.add(edsRecord);
			edsRecordMap.put(edsRecord.getProcRecord().getPan().toString(), edsRecordsForPANList);
		}
		
	}

	/**
	 *  This method updates the sent flag based on maximum confidence score and process data id.
	 * @param edsRecordsForPANList
	 * @param newEdsRecord
	 */
	private void checkConfScoreAndPrcssId(List<EDSRecord> edsRecordsForPANList,
			EDSRecord newEdsRecord) {
		for(EDSRecord edsRecord : edsRecordsForPANList ){
			
			if(newEdsRecord.getProcRecord().getConfidenceScore() > edsRecord.getProcRecord().getConfidenceScore() ){
				edsRecord.getProcRecord().setToBeSentFlag(NO);
			}else if ( newEdsRecord.getProcRecord().getConfidenceScore() < edsRecord.getProcRecord().getConfidenceScore()){
			
				newEdsRecord.getProcRecord().setToBeSentFlag(NO);
			}else{
				checkPrcssId(newEdsRecord, edsRecord);
			}
		}
		
	}

	private void checkPrcssId(EDSRecord newEdsRecord, EDSRecord edsRecord) {
		if(newEdsRecord.getProcRecord().getProcRecordKey().compareTo(edsRecord.getProcRecord().getProcRecordKey()) >1){
			edsRecord.getProcRecord().setToBeSentFlag(NO);
		}else{
			newEdsRecord.getProcRecord().setToBeSentFlag(NO);
		}
	}

	@SuppressWarnings("unchecked")
	private synchronized List<ICAStatus> getICAList() {
		icastatusList = (List<ICAStatus>) this.getExecutionContext().get("icaStatusList");
		
		if(icastatusList==null ){
			icastatusList = new CopyOnWriteArrayList<>();
		}
		return icastatusList;
	}

	private String getIcaFromRecord(List<? extends EDSRecord> edsRecordList) throws EDSCoreException {
		String ica = null ;
		if(edsRecordList.get(0).getProcRecord()!=null && StringUtils.isNotBlank(edsRecordList.get(0).getProcRecord().getIca())){
			ica = edsRecordList.get(0).getProcRecord().getIca();
			icaNum = ica;
		}else{
			logger.error("ICA is null");
			throw new EDSCoreException("ICA cannot be Blank or Null");
		}
		
		return ica;

	}

	@SuppressWarnings("unchecked")
	private List<? extends EDSRecord> validatePansToIcas(List<? extends EDSRecord> edsRecordList,
			String ica ) throws EDSCoreException {
		/* We will fetch invalid pans and log correct ICA's for those invalid pans */
		PanVerificationUsingICAToRangeMapping panVerificationUsingICAToRangeMapping = new PanVerificationUsingICAToRangeMapping();
		
		List<BigInteger> panList = getPanList(edsRecordList);
		if (null != panList && !panList.isEmpty()) {
		/* We will fetch IcaToRangeCache from execution context */
			Map<String, Map<ICAAccountRange, ICAAccountRange>> icaToRangeCache = (Map<String, Map<ICAAccountRange, ICAAccountRange>>) this.executionContext.get(ICA_TO_RANGE_CACHE);
			if (null != icaToRangeCache  ) {
			
				List<BigInteger> invalidPanList = panVerificationUsingICAToRangeMapping.validatePansToIcas(icaToRangeCache, panList, ica);
				if (null != invalidPanList && !invalidPanList.isEmpty()) {
				
					logger.warn(" We found below invalid pans : ");
					for (BigInteger invalidPan : invalidPanList) {
						logger.warn(" InvalidPan = " + getMaskedAccountNumber(invalidPan.toString())); // Mask the pans before printing
					}
					getActualICAForPans(invalidPanList, icaToRangeCache);
					
					edsRecordList= getValidPanList(invalidPanList,edsRecordList);
					logger.info("edsRecordList" + edsRecordList.size());
				} else {
					logger.info(" We do not find any invalid Pans");
				}
			}
		}
		return edsRecordList ;
	}
	
	/**
	 * Method will return list of valid pans
	 * @param invalidPanList
	 * @param list
	 * @return
	 */
	private List<? extends EDSRecord> getValidPanList( List<BigInteger> invalidPans, List<? extends EDSRecord> list) {

		logger.info(" Start Method : getValidPanList ");
		List<EDSRecord> validRecordList = new CopyOnWriteArrayList<EDSRecord>();
		List<EDSRecord> invalidPanList = new CopyOnWriteArrayList<EDSRecord>();
		
		for ( EDSRecord edsRecord : list ) {
			if ( ! invalidPans.contains( edsRecord.getProcRecord().getPan().toBigInteger() )) {
				validRecordList.add(edsRecord);
			} else{
				invalidPanList.add(edsRecord);
			}
		}		
		
		if(invalidPanList!=null && !invalidPanList.isEmpty()){
			logger.info("Status update for invalid PAN's =-" + invalidPanList.size() + " for update");
			int status = EDSProcessStatus.INVALID.getStatusCode();
			edsRecordWriterService.updateRecordStatusPostFileGeneration(jobInstanceName, jobInstanceId, invalidPanList,
					null, status);
		}
		logger.info(" End method : getValidPanList ");
		return validRecordList;
	}

	/**
	 * Method will print Actual ICA for pans which we found invalid by comparing start and end range for those PAN's.
	 * @param invalidPanList
	 * @param icaToRangeCache
	 * @param ica
	 */
	private void getActualICAForPans(List<BigInteger> invalidPanList, Map<String, Map<ICAAccountRange, ICAAccountRange>> icaToRangeCache) {
		logger.info("Start Method : getActualICAForPans");
		for (BigInteger pan:invalidPanList) {
			BigInteger paddedPan = new BigInteger(StringUtils.rightPad(pan.toString(), 19, '0'));

			for (Map.Entry<String, Map<ICAAccountRange, ICAAccountRange>> entry : icaToRangeCache.entrySet()) {
				String ica = entry.getKey();  

				Map<ICAAccountRange, ICAAccountRange> ranges = entry.getValue();

				for (Map.Entry<ICAAccountRange, ICAAccountRange> entryRange : ranges.entrySet()) {

					ICAAccountRange iccAcctRange = entryRange.getKey();

					if ((0 <= paddedPan.compareTo(iccAcctRange.getStart()))
							&& ((0 >= paddedPan.compareTo(iccAcctRange.getEnd())))) {

						logger.info(" Found ICA startAR = " + iccAcctRange.getStart() + ", endAR = " + iccAcctRange.getEnd() + ", ica = " + ica);
						break;
					}
				}
			}
		}
		logger.info("End method : getActualICAForPans");
	}

	/**
	 * Method will return list Of pans after iterating over List of EDSRecords
	 * @param list :List of EDSRecod
	 * @return
	 */
	private List<BigInteger> getPanList(List<? extends EDSRecord> list) {
		List<BigInteger> panList = new ArrayList<BigInteger>();

		if (null != list && 0 <list.size()) {
			for ( EDSRecord eDSRecord : list) {
				panList.add(eDSRecord.getProcRecord().getPan().toBigInteger());
			}
		}
		return panList;
	}

	/**
	 * @param NEW_LINE_SEPARATOR
	 * @param COMMA_DELIMITER
	 * @param filename
	 * @param rulesMap
	 * @param fileWriter
	 * @param edsRecord
	 * @throws IOException
	 */
	private void prepareEDSRecordList(final String lineSeperator,
			final String newCommaDelimiter, String filename,
			Map<Integer, PriceCategoryRule> rulesMap, FileWriter fileWriter,
			EDSRecord edsRecord) throws IOException {
		String confidenceText = "";
		String activityText = "";

		/**
		 * Check for Duplicate PANs if any if they are in the list.
		 * Ideally no Dup PANs should exist in the list after the query to 
		 * fetch eligible records from the PRCSS_TABLE using the collumn
		 * isDuplicate
		 */
		if(isPANDuplicateInFinalWriteList( edsRecord.getProcRecord().getPan() , edsRecord.getProcRecord().getToBeSentFlag() )){
			logger.warn("Duplicate PAN was found in final list to be sent : PRCSS SRC ID KEY : " + edsRecord.getProcRecord().getProcRecordKey());
			listOfDupRecords.add(edsRecord);
		} else {
			fileWriter.append(String.valueOf(edsRecord.getProcRecord().getPan()));
			fileWriter.append(newCommaDelimiter);

			PriceCategoryRule category = rulesMap.get(edsRecord.getProcRecord()
					.getPriceCategory());
			if (null != category) {

				confidenceText = category.getConfidenceText();
				activityText = category.getActivityText();
			}

			fileWriter.append(confidenceText);
			fileWriter.append(newCommaDelimiter);
			fileWriter.append(activityText);
			fileWriter.append(lineSeperator);

			uniquePanMap.put(edsRecord.getProcRecord().getPan(),"");
			procRecordToFileMap.put(edsRecord.getProcRecord().getProcRecordKey(),
					filename);
			listOfRecordsToWrite.add(edsRecord);
		}
	}

	public String getFileNameFromIca(String ica,
			Map<String, Object> customerInfo) {
		StringBuilder name = new StringBuilder();
		// Get Endpoint from EDS_CUST_MSTR for this ICA

		Object custEndPoint = customerInfo.get("ENDPNT_ID");
		logger.info("Endpoint =" + custEndPoint + ", for ICA=" + ica);
		String endPoint = (null != custEndPoint) ? "" + custEndPoint
				: "E0000000";

		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyMMdd");
		DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HHmmss");
		LocalDateTime dateTime = LocalDateTime.now();
		String formattedDate = dateTime.format(dateFormatter);
		String formattedTime = dateTime.format(timeFormatter);


		String strRandom = uniqueFileNameFetcherUtils.getRandomFileId();
		logger.info("strRandom in file = " + strRandom);
		
		name.append(filePrefix).append(endPoint).append(DOT)
		.append(DATE_PREFIX).append(formattedDate).append(DOT)
		.append(TIME_PREFIX).append(formattedTime).append(DOT)
		.append(COUNTER_PREFIX).append(strRandom);

		return name.toString();
	}

	@Override
	public ExitStatus afterStep(StepExecution paramStepExecution) {
		if (paramStepExecution.getExitStatus() != ExitStatus.FAILED
				|| paramStepExecution.getExitStatus() != ExitStatus.STOPPED) {

			if (!(listOfRecordsToWrite.isEmpty() && procRecordToFileMap
					.isEmpty())) {
				logger.info("Writer after step executing and sending list of size -"
						+ listOfRecordsToWrite.size() + " for update");
				int status = EDSProcessStatus.SENT.getStatusCode();
				edsRecordWriterService.updateRecordStatusPostFileGeneration(
						jobInstanceName, jobInstanceId,listOfRecordsToWrite,
						procRecordToFileMap, status);

				sendFilesToGFT(procRecordToFileMap);
			}
			if (!(listOfDupRecords.isEmpty())){
				logger.info("Updating Dup_Sw to 'Y' in eds_prcss_data table for duplicate pans, list of size -" + listOfDupRecords.size());
				edsRecordWriterService.updateSwForDupRecords(jobInstanceName, jobInstanceId ,listOfDupRecords);
			}

			listOfRecordsToWrite.clear();
			procRecordToFileMap.clear();
			uniquePanMap.clear();
		}
		return ExitStatus.COMPLETED;
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		logger.debug("RiskRecordItemWriter | beforeStep");
	}

	@SuppressWarnings("unchecked")
	public void sendFilesToGFT(Map<BigDecimal, String> procRecordToFileMap) {

		HashSet<String> uniqueFiles = new HashSet<>(
				procRecordToFileMap.values());
		Iterator<String> fileNames = uniqueFiles.iterator();

		logger.info("fileNames size =" + procRecordToFileMap.values().size());
		Instant createTime = Instant.now();	
		while (fileNames.hasNext()) {
			String fileStatus = FileStatus.GFT_FAILURE.getStatus();
			int exitStatus = 0 ; 
					
			String fileName = fileNames.next();
			logger.info("Calling archxfer script to send file =" + fileName);
			ProcessBuilder procBuilder = new ProcessBuilder("/bin/bash",
					"sendCustomerBatchFiles.sh", fileName);
			try {

				Map<String, String> env = procBuilder.environment();
				env.put("PATH", "/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/usr/seos/bin:"
						+ "/opt/nfast/bin:/sys_apps_01/cdunix/ndm/bin:/apps_01/eds/bin");

				//Fix missing CLI variable 
				env.put("MCSTAR_HOME","/apps_01/mcstar");
				env.put("MCSTARINI","NULL");
				env.put("MCSTARAPP","EDS");		
				env.put("LD_LIBRARY_PATH", "/apps_01/mcstar/lib:/sys_apps_01/dmexpress/lib");
				env.put("NDMDIR","/sys_apps_01/cdunix/ndm");
				env.put("NDMAPICFG", "/sys_apps_01/cdunix/ndm/cfg/cliapi/ndmapi.cfg");
				env.put("SRCNODE","`hostname`");
				env.put("CDRMCFG","$NDMDIR/cfg/$SRCNODE/initparm.cfg");

				Process proc = procBuilder.start();

				BufferedReader br = new BufferedReader(new InputStreamReader(proc.getErrorStream()));
				String line = null;
				logger.info("script output start");
				while ( (line = br.readLine()) != null) {
					logger.info(line);
				}
				logger.info("script output end");

				exitStatus = proc.waitFor();

				logger.info("process exit status =" + exitStatus);
				
				if (0 == exitStatus) {

					// process was successful, update EDS_CUST_PAN_RPT
					int status = EDSProcessStatus.SENT.getStatusCode();
					logger.info("Updating CustomerFileStatus with FileName = "
							+ fileName + " and Status = " + status);
					customerFileReportService.updateCustomerFileStatus(
							fileName, status, jobInstanceName, jobInstanceId,
							location);
				 
					List<String> icaList =   (List<String>) this.executionContext.get("icas");
					Map<String, String> icaNameMap =   (Map<String, String>) this.executionContext.get("icaName");
					if(icaList == null){
						icaList = new ArrayList<>();
					}
					icaList.add(icaNum);

					if(icaNameMap == null){
						icaNameMap = new ConcurrentHashMap<>();
					}
					icaNameMap.put(icaNum, organizationName);
					this.executionContext.put("icas", icaList );
					this.executionContext.put("icaName", icaNameMap);
					this.executionContext.put("eventName", NotificationEventConstants.NOTIF_EVT_COMPROMISED_PANS_AVL);
					this.executionContext.put("eventId", EVENT_ID_AT_PAN_RISK);
					
					fileStatus = FileStatus.GFT_SUCCESS.getStatus();
				} 
				

			} catch (IOException | InterruptedException e) {
				logger.error("An exception occurred while running send file process"
						+ e);
			}
			updateFileStatus(icaNum, fileName , exitStatus, fileStatus);
			Instant endIca = Instant.now();	
			logger.info("Time to send a file using GFT for ICA = "+ icaNum + "Period = "+(Duration.between(createTime, endIca)));
		}
		this.executionContext.put("icaStatusList", icastatusList );
	}

	private void updateFileStatus(String icaToUpdate, String fileName ,int exitCode , String fileStatus) {
		
		if(icastatusList.isEmpty()){
			logger.info("Nothing to update");
			return ;
		}	
		
		for(ICAStatus icaStatus : icastatusList){
			if(StringUtils.isNotBlank(icaStatus.getIca()) && icaStatus.getIca().equalsIgnoreCase(icaToUpdate) &&
			   StringUtils.isNotBlank(icaStatus.getFileName())&& icaStatus.getFileName().equalsIgnoreCase(fileName)){
				icaStatus.setStatus(fileStatus);
				icaStatus.setErrorCode(String.valueOf(exitCode));
				break ;
			}
			 
		 }
		
	}

	/**
	 * This method is  simple method to check if the incoming PAN
	 * exists in the final list of PANS to be delivered to the
	 * customer in the file.
	 * This is only a 2nd level check and ideally will not yield 
	 * any duplicates. 
	 * @return
	 */
	private boolean isPANDuplicateInFinalWriteList( BigDecimal PAN , String toBeSentFlag){
		boolean isDuplicate = true ;
		if(StringUtils.isBlank(toBeSentFlag) || toBeSentFlag.equalsIgnoreCase("Y")){
			isDuplicate = uniquePanMap.containsKey(PAN); ;
		}
		return isDuplicate ;
	}
	
	public static String getMaskedAccountNumber(String accountNumber) {
		String result = null;

		if (accountNumber != null) {
			int accountNumberLength = accountNumber.length();
			if (accountNumberLength > 6) {
				StringBuilder buf = new StringBuilder();
				buf.append(accountNumber.substring(0, 6));

				String last4 = accountNumber.substring(accountNumberLength - 4);
				for (int i = 6; i < accountNumberLength - 4; i++) {
					buf.append("X");
				}
				buf.append(last4);
				result = buf.toString();
			} else {
				result = accountNumber;
			}
		}
		return result;
	}

}