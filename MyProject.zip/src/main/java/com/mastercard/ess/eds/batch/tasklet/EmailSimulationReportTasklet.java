package com.mastercard.ess.eds.batch.tasklet;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;

import com.mastercard.ess.eds.core.dao.EDSSourceTypeDao;
import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;

/**
 * This tasklet used to place the simulation event in the queue so that email
 * will be sent to the subscribed user.
 * 
 * @author e070836
 * @version 1.0
 * @date : Dec 29, 2017
 */
public class EmailSimulationReportTasklet implements Tasklet {

	private static Logger logger = Logger
			.getLogger(EmailSimulationReportTasklet.class);

	@Autowired
	private EventPublisher eventPublisher;

	@Autowired
	private EDSSourceTypeDao edsSourceTypeDao;

	@Value("${simulationReport.path}")
	private String simulationReportPath;

	private static final String DD_MMM_YY = "dd-MMM-yyyy";
	private static final String SUMMARY_FILE = "summaryFile";
	private static final String REPORT_DATE = "reportDate";
	private static final String SIMULATION_REPORT = "Simulation_Report";
	private static final String UNDERSCORE = "_";
	public static final String NOTIF_EVT_CPP_SIMULATION_REPORT = "CPP Simulation Report";
	private static final String JOB_NAME = "jobName" ;

	public EmailSimulationReportTasklet(EDSSourceTypeDao edsSourceTypeDao) {
		this.edsSourceTypeDao = edsSourceTypeDao;
	}

	
	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {

		logger.debug("Enter method : execute : EmailSimulationReportTasklet ");

		NotificationEventVO notificationEventVO = new NotificationEventVO();
		Map<String, String> jobParams = new HashMap<>();

		Calendar currentCal = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat(DD_MMM_YY);
		String currentDate = dateFormat.format(currentCal.getTime());

		String simlulationReportFile = simulationReportPath.trim()
				+ SIMULATION_REPORT + UNDERSCORE + currentDate + ".xlsx";

		jobParams.put(SUMMARY_FILE, simlulationReportFile);
		jobParams.put(REPORT_DATE, currentDate);
		jobParams.put(JOB_NAME, chunkContext.getStepContext().getStepExecution().getJobExecution().getJobInstance().getJobName());

		notificationEventVO.setEventName(NOTIF_EVT_CPP_SIMULATION_REPORT);
		notificationEventVO.setJobParams(jobParams);
		notificationEventVO.setJobName(chunkContext.getStepContext()
				.getStepExecution().getJobExecution().getJobInstance()
				.getJobName());
		notificationEventVO.setJobID(BigDecimal.valueOf(chunkContext
				.getStepContext().getStepExecution().getJobExecution()
				.getJobId()));

		FileSystemResource customerReportFileSystemResource = new FileSystemResource(
				simlulationReportFile);

		if (customerReportFileSystemResource.exists()) {
			logger.info("placing notification event for Simulation Report ");
			eventPublisher.placeEvent(notificationEventVO);
		}
		logger.debug("Exit from method : execute : EmailSimulationReportTasklet ");

		return RepeatStatus.FINISHED ;
	}

	
	public void setCustomerEnrollmentReportPath(
			String customerEnrollmentReportPath) {
		this.simulationReportPath = customerEnrollmentReportPath;
	}

	public void setEventPublisher(EventPublisher eventPublisher) {
		this.eventPublisher = eventPublisher;
	}

	public void setEdsSourceTypeDao(EDSSourceTypeDao edsSourceTypeDao) {
		this.edsSourceTypeDao = edsSourceTypeDao;
	}
}
