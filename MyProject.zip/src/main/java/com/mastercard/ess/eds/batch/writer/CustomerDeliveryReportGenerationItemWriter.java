package com.mastercard.ess.eds.batch.writer;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.util.CustomerDeliveryReportGenerator;
import com.mastercard.ess.eds.domain.CustomerDeliveryReportRecord;

public class CustomerDeliveryReportGenerationItemWriter implements ItemWriter<CustomerDeliveryReportRecord> , StepExecutionListener {

	private static Logger logger = Logger.getLogger(CustomerDeliveryReportGenerationItemWriter.class);

	private static final String MEDIUM = "Medium";

	private static final String GREATER_THAN_90_DAYS = "Greater than 90 days";

	private static final String LESS_THAN_90_DAYS = "Less than  90 days";

	private static final String HIGH = "High";

	private static final String VERY_HIGH = "Very High";
	
	private Map<String, Map<Integer,List<Object>>> continentMap=new LinkedHashMap<String, Map<Integer,List<Object>>>();

	@Autowired
	private CustomerDeliveryReportGenerator customerDeliveryReportGenerator;


	private BigDecimal jobInstanceId;
	private String jobInstanceName;

	public void setGenerator(CustomerDeliveryReportGenerator customerDeliveryReportGenerator) {
		this.customerDeliveryReportGenerator = customerDeliveryReportGenerator;

	}

	public BigDecimal getJobInstanceId() {
		return jobInstanceId;
	}

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}

	public String getJobInstanceName() {
		return jobInstanceName;
	}

	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}


	@Override
	public void write(List<? extends CustomerDeliveryReportRecord> customerDeliveryReportRecordList) throws Exception {

		logger.info("Start write method in CustomerDelivery Report Generator .......");

		if (customerDeliveryReportRecordList!=null && customerDeliveryReportRecordList.size()>0) {
			logger.info( "customerReport list size = " + customerDeliveryReportRecordList.size());
			for (CustomerDeliveryReportRecord customerDeliverySummary : customerDeliveryReportRecordList) {

				if (!continentMap.containsKey(String
						.valueOf(customerDeliverySummary.getCatagoryCode()))) {
					Map<Integer, List<Object>> prizeCodetoPanCountMap = new TreeMap<Integer, List<Object>>();
					List<Object> panCountForMonthList = getPANCountForMonthList(customerDeliverySummary
							.getPriceCatagory());
					panCountForMonthList.add(customerDeliverySummary
							.getPANCount());
					prizeCodetoPanCountMap.put(
							customerDeliverySummary.getPriceCatagory(),
							panCountForMonthList);
					continentMap.put(customerDeliverySummary.getCatagoryCode(),
							prizeCodetoPanCountMap);

				} else {
					if (!continentMap.get(
							String.valueOf(customerDeliverySummary
									.getCatagoryCode())).containsKey(
											customerDeliverySummary.getPriceCatagory())) {
						Map<Integer, List<Object>> prizeCodetoPanCountMap = new TreeMap<Integer, List<Object>>();
						List<Object> panCountForMonthList = getPANCountForMonthList(customerDeliverySummary
								.getPriceCatagory());
						panCountForMonthList.add(customerDeliverySummary
								.getPANCount());
						prizeCodetoPanCountMap.put(
								customerDeliverySummary.getPriceCatagory(),
								panCountForMonthList);

						continentMap.get(
								String.valueOf(customerDeliverySummary
										.getCatagoryCode())).put(
												customerDeliverySummary.getPriceCatagory(),
												panCountForMonthList);
					} else {
						continentMap
						.get(String.valueOf(customerDeliverySummary
								.getCatagoryCode()))
								.get(customerDeliverySummary.getPriceCatagory())
								.add(customerDeliverySummary.getPANCount());
					}
				}

			}
		}


		logger.info("*************END write method in CustomerDelivery Report Generator *********************");

	}

	/*This will return list of pancount for prizeCatagory code provided.*/
	public List<Object> getPANCountForMonthList(int i) {

		List<Object> panCountForMonthList = new LinkedList<Object>();
		switch (i) {

		case 1:
			panCountForMonthList.add("");
			panCountForMonthList.add(VERY_HIGH);
			panCountForMonthList.add("");
			panCountForMonthList.add(LESS_THAN_90_DAYS);
			panCountForMonthList.add("");
			break;
		case 2:
			panCountForMonthList.add("");
			panCountForMonthList.add(VERY_HIGH);
			panCountForMonthList.add("");
			panCountForMonthList.add(GREATER_THAN_90_DAYS);
			panCountForMonthList.add("");
			break;
		case 3:
			panCountForMonthList.add("");
			panCountForMonthList.add(HIGH);
			panCountForMonthList.add("");
			panCountForMonthList.add(LESS_THAN_90_DAYS);
			panCountForMonthList.add("");
			break;
		case 4:
			panCountForMonthList.add("");
			panCountForMonthList.add(HIGH);
			panCountForMonthList.add("");
			panCountForMonthList.add(GREATER_THAN_90_DAYS);
			panCountForMonthList.add("");
			break;
		case 5:
			panCountForMonthList.add("");
			panCountForMonthList.add(MEDIUM);
			panCountForMonthList.add("");
			panCountForMonthList.add(LESS_THAN_90_DAYS);
			panCountForMonthList.add("");
			break;
		case 6:
			panCountForMonthList.add("");
			panCountForMonthList.add(MEDIUM);
			panCountForMonthList.add("");
			panCountForMonthList.add(GREATER_THAN_90_DAYS);
			panCountForMonthList.add("");
			break;
		default:
			break;
		}		
		return panCountForMonthList;
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		logger.info("Before Step");
		
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		if (stepExecution.getExitStatus() != ExitStatus.FAILED
				|| stepExecution.getExitStatus() != ExitStatus.STOPPED) {
			
			if(!continentMap.isEmpty()){
				customerDeliveryReportGenerator.
			              writeToCustomerDeliveryReport(continentMap, jobInstanceId, jobInstanceName);
			}
			
			continentMap.clear();
		}
		
		return ExitStatus.COMPLETED;
	}




}
