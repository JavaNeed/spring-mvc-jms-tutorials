package com.mastercard.ess.eds.core.dao;

import static com.mastercard.ess.eds.constant.SQLQueries.GET_SUBSCRIBED_EMAIL_IDS;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
/**
 * @author e069468
 *
 */
@Component
public class EventSubscriptionDAO {

	private static Logger logger = Logger.getLogger(EventSubscriptionDAO.class);

	private JdbcTemplate jdbcTemplate;

	

	public EventSubscriptionDAO(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * @return - This method returns the list of emailIds of the customer type event who has subscribed for email notification 
	 */
	public List<String> getEmailIdsByEventType(String eventType , int days) {
		Object[] parameters = new Object[] {eventType, days};
		return jdbcTemplate.queryForList(GET_SUBSCRIBED_EMAIL_IDS, parameters ,String.class);
	}

	public List<Map<String, Object>> getEmailIdsUsingICA(String eventId, List<String> icaList) {
		List<Map<String, Object>> resultList =  new ArrayList<Map<String,Object>>();
		
		if(icaList != null && icaList.size()>0){
			int noOfLoops = (icaList.size() / 999) + 1;
			int startIndex=0;
			int endIndex=0;
			logger.info("strICAList ="+icaList.size());
			

			for (int i = 0; i <noOfLoops; i++) {
				List<Map<String, Object>>  subList = new ArrayList<Map<String,Object>>();
				startIndex=endIndex;
				endIndex=((startIndex+999)>icaList.size())?icaList.size():startIndex+999;
				
				StringBuilder buildSql=new StringBuilder("");
				buildSql=buildSql.append("SELECT EMAIL_ID, ICA_NUM FROM EDS_EVENT_SUBSC WHERE EVENT_ID = ?  AND ICA_NUM IN ( ").
						append(String.join(",", icaList.subList(startIndex,endIndex))).append(")") ;
				
				
				Object[] parameters = new Object[] {eventId};
				subList = jdbcTemplate.queryForList(buildSql.toString(), parameters );
				resultList.addAll(subList);
			}
		} 
		return resultList;
	}

}
