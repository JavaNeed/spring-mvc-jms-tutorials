package com.mastercard.ess.eds.batch.listener;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.springframework.batch.core.SkipListener;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.batch.exception.InvalidCPPRecordException;
import com.mastercard.ess.eds.core.service.EDSRecordWriterService;
import com.mastercard.ess.eds.core.util.EDSProcessStatus;
import com.mastercard.ess.eds.domain.RawRecord;

/**
 * This listener class reports all the skipped items which fail validation and are dropped thereby from further processing
 * @author e067588
 *
 */
public class RawRecordSkipListener implements SkipListener<RawRecord, RawRecord> {

	private static Logger logger = Logger.getLogger(RawRecordSkipListener.class);
	
	@Autowired
	EDSRecordWriterService edsRecordWriterService;
	
	private String jobInstanceName;
	
	private BigDecimal jobInstanceId;

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}
	
	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.batch.core.SkipListener#onSkipInProcess(java.lang.Object, java.lang.Throwable)
	 */
	@Override
	public void onSkipInProcess(RawRecord rawRecord, Throwable arg1) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : onSkipInProcess ");
		}

		if(arg1 instanceof InvalidCPPRecordException){
			/*If the pan is derived from CPP and does not have a src-rule mapping, log the src id and skip processing.*/
			logger.error(arg1.getMessage());
			
		} else {
			String error = "";
			int status = EDSProcessStatus.ERROR.getStatusCode();
			logger.info("Skipping rawRecord = " + rawRecord.getSrc_data_ky() + ", message = " + arg1.getMessage());

			if("duplicatePan".equals(arg1.getMessage())) {
				error = "Duplicate Pan";
				status = EDSProcessStatus.PROCESSED.getStatusCode();
			} else if("MOD-10 Check Failed".equalsIgnoreCase(arg1.getMessage())){
				error = "MOD-10 Check Failed";
			}else{
				error = "Invalid Pan";
			}

			edsRecordWriterService.updateRawRecordStatus(rawRecord.getSrc_data_ky(), status, error, jobInstanceName, jobInstanceId);
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : onSkipInProcess ");
		}
	}

	public RawRecordSkipListener(EDSRecordWriterService edsRecordWriterService) {
		super();
		this.edsRecordWriterService = edsRecordWriterService;
	}

	/* (non-Javadoc)
	 * @see org.springframework.batch.core.SkipListener#onSkipInRead(java.lang.Throwable)
	 */
	@Override
	public void onSkipInRead(Throwable arg0) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : onSkipInRead ");
		}
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : onSkipInRead ");
		}
	}

	/* (non-Javadoc)
	 * @see org.springframework.batch.core.SkipListener#onSkipInWrite(java.lang.Object, java.lang.Throwable)
	 */
	@Override
	public void onSkipInWrite(RawRecord rawRecord, Throwable arg1) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : onSkipInWrite ");
		}
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : onSkipInWrite ");
		}
	}

}
