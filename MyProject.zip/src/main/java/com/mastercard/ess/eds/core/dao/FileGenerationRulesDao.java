package com.mastercard.ess.eds.core.dao;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.easyrules.core.BasicRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.rule.FileGenerationCustomRules;
import com.mastercard.ess.eds.core.rule.FileGenerationRules;
import com.mastercard.ess.eds.core.util.BrandExclusionCache;

@Component
public class FileGenerationRulesDao {

	private JdbcTemplate jdbcTemplate;
	@Autowired
	BrandExclusionCache brandExclusionCache;

	public FileGenerationRulesDao(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);

	}
	private static Logger logger = Logger.getLogger(FileGenerationRulesDao.class);

	private static final String FETCH_EDS_CUST_MASTER_RULE = "SELECT * from EDS_CUST_FILE_GNRT_RULE";

	public List<BasicRule> loadAllCategoryRules() {
		List<BasicRule> fileGenerationRuleCache = new ArrayList<BasicRule>();
		int fileGenerationRuleNameIncrementer = 0;
		int fileGenerationCustomRuleNameIncrementer = 0;

		List<Map<String, Object>> fileGenerationRuleData = jdbcTemplate.queryForList(FETCH_EDS_CUST_MASTER_RULE);

		if (null != fileGenerationRuleData) {
			for (Map<String, Object> row : fileGenerationRuleData) {

				if ("DB".equals((String) row.get("RULE_CAT_CD"))) {

					FileGenerationRules fileGenerationRules = new FileGenerationRules(
							"FileGenerationRule_" + fileGenerationRuleNameIncrementer);
					setFileGenerationRulesFlag(row, fileGenerationRules);

					fileGenerationRuleCache.add(fileGenerationRules);
					++fileGenerationRuleNameIncrementer;
				}

				else if ("CUSTOM".equalsIgnoreCase((String) row.get("RULE_CAT_CD"))) {

					fileGenerationCustomRuleNameIncrementer = customFileGenerationHandling(
							fileGenerationRuleCache,
							fileGenerationCustomRuleNameIncrementer, row);
				}
			}

		}
		return fileGenerationRuleCache;
	}

	/**
	 * @param fileGenerationRuleCache
	 * @param fileGenerationCustomRuleNameIncrementer
	 * @param row
	 * @return
	 */
	private int customFileGenerationHandling(
			List<BasicRule> fileGenerationRuleCache,
			int fileGenerationCustomRuleNameIncrementer, Map<String, Object> row) {

		Object customRuleObject = null;

		if (null != (String) row.get("RULE_IMPLEMENTER_CLASS_NAM")) {

			String ruleClass = (String) row.get("RULE_IMPLEMENTER_CLASS_NAM");


			try {

				customRuleObject = customRuleObjectPreparation(
						fileGenerationCustomRuleNameIncrementer,
						ruleClass, customRuleObject);
			} catch (InstantiationException | IllegalAccessException | ClassNotFoundException
					| IllegalArgumentException | InvocationTargetException | SecurityException e) {
				logger.error("Exception : "  + e);

			}
			if (null != customRuleObject && customRuleObject instanceof FileGenerationCustomRules) {
				Map<String, String> icaToSilentSwitchMap = getICAToSilentSwitchMap();

				((FileGenerationCustomRules) customRuleObject).setIcaToIsSilentMap(icaToSilentSwitchMap);
				// ((FileGenerationCustomRules)

				((FileGenerationCustomRules) customRuleObject).setBrandExclusionCache(brandExclusionCache);
				setFileGenerationCustomRulesFlag(row,
						customRuleObject);
				fileGenerationRuleCache.add((FileGenerationCustomRules) customRuleObject);
			}
		}
		++fileGenerationCustomRuleNameIncrementer;
		return fileGenerationCustomRuleNameIncrementer;
	}

	/**
	 * @param fileGenerationCustomRuleNameIncrementer
	 * @param ruleClass
	 * @param customRuleObject
	 * @param customRuleClass
	 * @return
	 * @throws ClassNotFoundException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 */

	private Object customRuleObjectPreparation(

			int fileGenerationCustomRuleNameIncrementer, String ruleClass,
			Object customRuleObject)
					throws ClassNotFoundException, InstantiationException,
					IllegalAccessException, InvocationTargetException {


		if (null != ruleClass){
			Class  customRuleClass = Class.forName(ruleClass);

			if (null != customRuleClass) {
				logger.info("FileGenerationCustomRules class found");
				customRuleObject = customRuleObjectInstantiation(
						fileGenerationCustomRuleNameIncrementer, customRuleObject,
						customRuleClass);
				if (null == customRuleObject ) {		

					customRuleObject = customRuleClass.newInstance();		 

				}

			}
		}
		return customRuleObject;
	}

	/**
	 * @param fileGenerationCustomRuleNameIncrementer
	 * @param customRuleObject
	 * @param customRuleClass
	 * @return
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 */
	private Object customRuleObjectInstantiation(
			int fileGenerationCustomRuleNameIncrementer,
			Object customRuleObject, Class customRuleClass)
					throws InstantiationException, IllegalAccessException,
					InvocationTargetException {
		for (Constructor<?> constructor : customRuleClass.getConstructors()) {
			Class<?>[] arr = constructor.getParameterTypes();
			List<?> list = Arrays.asList(arr);
			if (list.contains(String.class)) {
				customRuleObject = constructor
						.newInstance("BasicRule_" + fileGenerationCustomRuleNameIncrementer);
				break;
			}
		}
		return customRuleObject;
	}

	/**
	 * @param row
	 * @param customRuleObject
	 */
	private void setFileGenerationCustomRulesFlag(Map<String, Object> row,
			Object customRuleObject) {
		if (null != (String) row.get("ACCT_ACTV_SW")) {
			((FileGenerationCustomRules) customRuleObject)
			.setIsAccountActiveFlag((String) row.get("ACCT_ACTV_SW"));
		}

		if (null != (String) row.get("ACCT_VAL_SW")) {
			if ("Y".equals((String) row.get("ACCT_VAL_SW"))) {
				((FileGenerationCustomRules) customRuleObject).setAccountValidFlag(true);
			} else {
				((FileGenerationCustomRules) customRuleObject).setAccountValidFlag(false);
			}

		}

		if (null != (String) row.get("ADC_NOTIF_SW")) {
			((FileGenerationCustomRules) customRuleObject)
			.setIsADCNotifiedFlag((String) row.get("ADC_NOTIF_SW"));
		}

		if (null != (String) row.get("FRAUD_RPT_SW")) {
			((FileGenerationCustomRules) customRuleObject)
			.setIsFraudReportedFlag((String) row.get("FRAUD_RPT_SW"));
		}

		if (null != (String) row.get("RPT_BFRE_SW")) {
			((FileGenerationCustomRules) customRuleObject)
			.setIsAlreadyReportedFlag((String) row.get("RPT_BFRE_SW"));
		}

		if (null != (String) row.get("DUP_SW")) {
			((FileGenerationCustomRules) customRuleObject)
			.setIsDuplicateFlag((String) row.get("DUP_SW"));
		}
	}

	/**
	 * @param row
	 * @param fileGenerationRules
	 */
	private void setFileGenerationRulesFlag(Map<String, Object> row,
			FileGenerationRules fileGenerationRules) {
		if (null != (String) row.get("ACCT_ACTV_SW")) {
			fileGenerationRules.setIsAccountActiveFlag((String) row.get("ACCT_ACTV_SW"));
		}

		if (null != (String) row.get("ACCT_VAL_SW")) {
			if ("Y".equals((String) row.get("ACCT_VAL_SW"))) {
				fileGenerationRules.setAccountValidFlag(true);
			} else {
				fileGenerationRules.setAccountValidFlag(false);
			}

		}

		if (null != (String) row.get("ADC_NOTIF_SW")) {
			fileGenerationRules.setIsADCNotifiedFlag((String) row.get("ADC_NOTIF_SW"));
		}

		if (null != (String) row.get("FRAUD_RPT_SW")) {
			fileGenerationRules.setIsFraudReportedFlag((String) row.get("FRAUD_RPT_SW"));
		}

		if (null != (String) row.get("RPT_BFRE_SW")) {
			fileGenerationRules.setIsAlreadyReportedFlag((String) row.get("RPT_BFRE_SW"));
		}

		if (null != (String) row.get("DUP_SW")) {
			fileGenerationRules.setIsDuplicateFlag((String) row.get("DUP_SW"));
		}
	}

	private Map<String, String> getICAToSilentSwitchMap() {
		List<Map<String, Object>> list = jdbcTemplate.queryForList("Select ICA_NUM, SILENT_SW from EDS_CUST_MSTR");
		Map<String, String> icaToSilentSwitchMap = new HashMap<String, String>();
		if (null != list) {
			for (Map<String, Object> row : list) {
				icaToSilentSwitchMap.put(((BigDecimal) row.get("ICA_NUM")).toString(),
						(String) row.get("SILENT_SW"));
			}
		}
		return icaToSilentSwitchMap;
	}
}
