package com.mastercard.ess.eds.core.dao;

import static com.mastercard.ess.eds.constant.SQLQueries.FETCH_EDS_CPP_RULE;
import static com.mastercard.ess.eds.constant.SQLQueries.FETCH_EDS_CPP_RULE_BY_ID;
import static com.mastercard.ess.eds.constant.SQLQueries.FETCH_EDS_CPP_RULE_ID;
import static com.mastercard.ess.eds.constant.SQLQueries.UPDATE_CPP_SRC_STATUS_POST_RULE_EXECUTION;
import static com.mastercard.ess.eds.constant.SQLQueries.UPDATE_EDS_CPP_RULES_FIRST_RUN_SW;
import static com.mastercard.ess.eds.constant.SQLQueries.UPDATE_SUCCESSFUL_EDS_CPP_RULES_FIRST_RUN_SW;
import static com.mastercard.ess.eds.constant.SQLQueries.UPDATE_CPP_SIMULATION_SW;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.constant.BatchConstants;
import com.mastercard.ess.eds.core.mapper.CPPRuleRowMapper;
import com.mastercard.ess.eds.core.util.EDSProcessStatus;
import com.mastercard.ess.eds.domain.CPPRuleRecord;


@Component
public class EDSCPPRulesDao {
	private static Logger logger = Logger.getLogger(EDSCPPRulesDao.class);
	private static final String N = "N";
	private static final String Y = "Y";
	
	@Autowired 
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private CPPSimulationDataDAO cppSimulationDataDAO ;

	CPPRuleRecord cppRuleRecord=new CPPRuleRecord();
	List<Integer> listOfCPPRuleIds=new LinkedList<Integer>();

	public CPPRuleRecord getCppRuleRecord() {
		return cppRuleRecord;
	}

	public void setCppRuleRecord(CPPRuleRecord cppRuleRecord) {
		this.cppRuleRecord = cppRuleRecord;
	}

	public List<Integer> getListOfCPPRuleIds() {
		return listOfCPPRuleIds;
	}

	public void setListOfCPPRuleIds(List<Integer> listOfCPPRuleIds) {
		this.listOfCPPRuleIds = listOfCPPRuleIds;
	}

	public void updateCPPSrcStatusPostProcessing(String cppSrcName, String jobInstanceName,int status) {

		logger.info("Enter in method : updateCPPSrcStatusPostProcessing for cppSrcName="+cppSrcName+" JobInstance ="+status);

		int processedStatus=0;
		/**According to job status we will update SRC Status to either 2 or 5
		 * For Error-2
		 * For Success-5
		 * */
		if (2==status) {
			processedStatus = EDSProcessStatus.ERROR.getStatusCode();
		}
		else {
			processedStatus = EDSProcessStatus.PROCESSED.getStatusCode();
		}
		int unprocessedStatus = EDSProcessStatus.UNPROCESSED.getStatusCode();
		Timestamp date = new java.sql.Timestamp(System.currentTimeMillis());

		jdbcTemplate.update(UPDATE_CPP_SRC_STATUS_POST_RULE_EXECUTION, processedStatus, date, jobInstanceName, unprocessedStatus,cppSrcName);
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : updateCPPSrcStatusPostProcessing ");
		}
	}

	public void updateFirstRunSW(String jobInstanceName, List<String> cppRuleIdList) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : updateFirstRunSW ");
		}

		Timestamp date = new java.sql.Timestamp(System.currentTimeMillis());

		if (cppRuleIdList!=null && cppRuleIdList.size()>0) {
			logger.info("CPPRules which are NOT executed properly");
			
			if (cppRuleIdList.size()<1000) {
				String strCppRuleIds = String.join(",", cppRuleIdList);
				logger.info("UpdateFirstRunSW Method with strCppRuleIds="+strCppRuleIds);
				jdbcTemplate.update(UPDATE_SUCCESSFUL_EDS_CPP_RULES_FIRST_RUN_SW, N,date,jobInstanceName,Y,strCppRuleIds);
			}
			else {
				int startIndex=0;
				int endIndex=0;
				int noOfLoops = cppRuleIdList.size()/999;
				if (cppRuleIdList.size()%999 !=0) {
					noOfLoops=noOfLoops+1;
				}
				for (int i = 0; i <noOfLoops; i++) {
					startIndex=endIndex;
					endIndex=((startIndex+999)>cppRuleIdList.size())?cppRuleIdList.size():startIndex+999;
					String strCppRuleIds = String.join(",", cppRuleIdList.subList(startIndex,endIndex));
					logger.info("UpdateFirstRunSW Method with strCppRuleIds="+strCppRuleIds);
					jdbcTemplate.update(UPDATE_SUCCESSFUL_EDS_CPP_RULES_FIRST_RUN_SW, N,date,jobInstanceName,Y,strCppRuleIds);
				}
			}
		}else {
			logger.info("All CPPRules are executed properly");
			jdbcTemplate.update(UPDATE_EDS_CPP_RULES_FIRST_RUN_SW, N,date,jobInstanceName,Y);
		}
	}
	
	
	public String getCatogeryType(BigDecimal cppRuleId){
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in getCatogeryType method");
		}
		String catogeryType =null ;
		List<Map<String, Object>> cppRule = jdbcTemplate.queryForList(FETCH_EDS_CPP_RULE, cppRuleId);
		for (Map<String, Object> row : cppRule) {
			catogeryType =  (String) row.get("CAT_CD");
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from getCatogeryType method");
		}
		return catogeryType;
	}

	/*Method will return List of CPPRuleIds having active flag='Y' */
	public List<Integer> getCPPRuleIds(String cppRunMode) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method getCPPRuleIds");
		}
		
		String statusFlag = "Y" ;
		if(cppRunMode.equalsIgnoreCase(BatchConstants.SIMULATION)){
			statusFlag = "P" ;
		}
		listOfCPPRuleIds = jdbcTemplate.queryForList(FETCH_EDS_CPP_RULE_ID, new Object[] { statusFlag },Integer.class);
		if (listOfCPPRuleIds!=null && !listOfCPPRuleIds.isEmpty()) {
			logger.info("Size of List of CPPRuleIds is ="+listOfCPPRuleIds.size());
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Exit in method getCPPRuleIds");
		}
		return listOfCPPRuleIds;
	}

	/*Method will return CPPRuleIds for provided cppRuleId*/
	public CPPRuleRecord getCPPRulesByRuleId(String activeStatus,int cppRuleId) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method getCPPRulesByRuleId");
		}
		cppRuleRecord = jdbcTemplate.queryForObject(FETCH_EDS_CPP_RULE_BY_ID,new Object[] {activeStatus, cppRuleId },new CPPRuleRowMapper());			
		if (logger.isDebugEnabled()) {
			logger.debug("Exit in getCPPRulesByRuleId");
		}
		return cppRuleRecord;

	}

	public void updateSimulationFlag(String jobInstanceName, String simSrcId) {
		
		logger.info("Enter into the method updateSimulationFlag");
		Timestamp date = new java.sql.Timestamp(System.currentTimeMillis());
		
		jdbcTemplate.update(UPDATE_CPP_SIMULATION_SW, Y , date , jobInstanceName , simSrcId);
		
	}
}
