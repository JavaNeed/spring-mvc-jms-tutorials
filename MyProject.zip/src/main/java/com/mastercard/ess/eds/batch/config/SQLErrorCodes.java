package com.mastercard.ess.eds.batch.config;

public enum SQLErrorCodes {
	SWITCHOVER_IN_PROGRESS(16456, "Please alert Support team of database issue!! Encountered Error Code 16456 - Switchover is in progress. Will retry getting connection to DB."), 
	IO_ERROR(17002, "Please alert Support team of database issue!! Encountered Error Code 17002 - IO Error. Will retry getting connection to DB."), 
	CLOSED_CONNECTION(17008, "Please alert Support team of database issue!! Encountered Error Code 17008 - Closed Connection. Will retry getting connection to DB."),
	NO_MORE_DATA_FROM_SOCKET(17410, "Please alert Support team of database issue!! Encountered Error Code 17410 - No More Data From Socket. Will retry getting connection to DB."),
	SERVICE_NAME_NOT_FOUND(12514, "Please alert Support team of database issue!! Encountered Error Code 12514 - TNS:listener does not currently know of service requested in connect descriptor. Will retry getting connection to DB."),
	END_OF_FILE_COMM_CHANNEL(03113, "Please alert Support team of database issue!! Encountered Error Code 03113 - end-of-file on communication channel. Will retry getting connection to DB.");

	private int errorCode;
	private String customErrorMessage;

	private SQLErrorCodes(int errorCode, String customErrorMessage) {
		this.setErrorCode(errorCode);
		this.setErrorMessage(customErrorMessage);
	}

	public static boolean shouldRetryForSQLErrorCode(int errorCode) {
		for (SQLErrorCodes ec : SQLErrorCodes.values()) {
			if (ec.errorCode == errorCode) {
				return true;
			}
		}
		return false;
	}

	public static String getCustomErrorMessage(int errorCode) {
		for (SQLErrorCodes ec : SQLErrorCodes.values()) {
			if (ec.errorCode == errorCode) {
				return ec.customErrorMessage;
			}
		}
		return null;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return customErrorMessage;
	}

	public void setErrorMessage(String customErrorMessage) {
		this.customErrorMessage = customErrorMessage;
	}
}
