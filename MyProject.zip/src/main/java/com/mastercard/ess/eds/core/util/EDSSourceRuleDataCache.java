package com.mastercard.ess.eds.core.util;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class EDSSourceRuleDataCache {

	private Logger logger = Logger.getLogger(EDSSourceRuleDataCache.class);
	Map<Long, RuleCatCdRecord> cache = new ConcurrentHashMap<Long, RuleCatCdRecord>();

	/**
	 * This method is used to load the source_rule_data_cache. The src_data_id is key and value is of type RuleCatCdRecord, which is 
	 * a mapping of cpp_rule_id and category code for that rule.
	 * @param key
	 * @param ruleCatCdRecord
	 * @return
	 */
	public boolean insert(Long key, RuleCatCdRecord ruleCatCdRecord) {
		logger.info("EDSSourceRuleDataCache | insert Enter ");
		if (null != key) {
			if (null == cache.put(key, ruleCatCdRecord)) {
				return true;
			}
		}
		logger.info("EDSSourceRuleDataCache | insert Exit ");
		return false;
	}

	public void bulkInsert(List<CPPRuleIdHolder> srcRuleData) {
		
		if (!srcRuleData.isEmpty()) {
			for (CPPRuleIdHolder row  : srcRuleData) {
					cache.put(row.getSrcDataKey(), new RuleCatCdRecord(row.getCppRuleId(), row.getCategoryCode()));
				}
			}
		}

	/**
	 * This method returns the RuleCatCdRecord object which contains cpp_rule_id and category code for that rule.
	 * @param key
	 * @return
	 */
	public RuleCatCdRecord getResult(Long key) {
		logger.info("EDSSourceRuleDataCache | getResult - key = " + key);
		return cache.get(key);
	}
}
