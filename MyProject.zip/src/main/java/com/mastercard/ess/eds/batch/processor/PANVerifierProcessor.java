package com.mastercard.ess.eds.batch.processor;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TreeMap;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.mastercard.ess.eds.core.util.GlobalConstants;
import com.mastercard.ess.eds.core.util.PANAccountRangeCache;
import com.mastercard.ess.eds.domain.CIDInfo;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.PANAccountRange;
import com.mastercard.ess.eds.domain.ProcessedRecord;
import com.mastercard.ess.eds.domain.RawRecord;

/**
 * This ItemProcessor verifies a given PAN against a range from RDS database
 * @author e067588
 *
 */
public class PANVerifierProcessor implements ItemProcessor<EDSRecord,EDSRecord> {

	@Autowired
	PANAccountRangeCache panAccountRangeCache;

	private static final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
	private String jobInstanceName;

	@Value("#{jobParameters['currentDateTime']}")
	private String timestamp;

	private static Logger logger = Logger.getLogger(PANVerifierProcessor.class);
	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}

	// for JUnit Test
	public String getJobInstanceName(){
		return jobInstanceName;
	}

	// for JUnit Test
	public void setTimestamp(String timestamp){
		this.timestamp = timestamp;
	}



	/* (non-Javadoc)
	 * @see org.springframework.batch.item.ItemProcessor#process(java.lang.Object)
	 */

	/**
	 * this method processes PAN to verify if a PAN lies in an authentic PAN range.
	 * This is done by querying RDS for the same.
	 * @param EDSRecord
	 * @return EDSRecord
	 */
	@Override
	public EDSRecord process(EDSRecord edsRecord){
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : process ");
		}
		boolean isPANNotNull = false;
		RawRecord rawRecord = edsRecord.getRawRecord();
		String pan = "";
		if(null != rawRecord.getRawPan()){
			pan = formatPAN(rawRecord.getRawPan());
			isPANNotNull = true;
		}
		/**
		 * Create a new instance of Processed Record
		 */

		ProcessedRecord processedRecord = new ProcessedRecord();
		processedRecord.setCacheResult(rawRecord.getCacheResult());
		processedRecord.setLastUpdatedUser(jobInstanceName);
		processedRecord.setCreatedBy(jobInstanceName);
		processedRecord.setCreateDate(new java.sql.Timestamp(System.currentTimeMillis()));
		processedRecord.setProcRawRecordKey(rawRecord.getSrc_data_ky());
		processedRecord.setLastUpdatedDate(new java.sql.Timestamp(System.currentTimeMillis()));
		if(isPANNotNull){
			processedRecord.setPan(new BigDecimal(pan));
		}

		/**
		 * Try and get the account range for this PAN
		 */
		PANAccountRange panAccountRange = getAcctRange(pan);

		//edsRecord.setRawRecord(rawRecord); : commented on 9/2/18
		setIsValidAndIsVerfied(panAccountRange, processedRecord); 

		/**
		 * Set the Processed record 
		 */
		edsRecord.setProcRecord(processedRecord);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : process");
		}
		return edsRecord;		
	}

	


	/**
	 * Method will fetch panAccountRangeCache cache.
	 * @param pan
	 * @return
	 */
	private PANAccountRange getAcctRange(String pan) {
		logger.info("Going to relaease the read lock from PanAcctRange Cache");

		lock.readLock().lock();
		PANAccountRange panAccountRange = null;
		try {
			TreeMap<PANAccountRange,PANAccountRange> countryCodeCache = (TreeMap<PANAccountRange, PANAccountRange>) panAccountRangeCache.getCache();

			if (StringUtils.isNotBlank(pan)){
				String rightPaddedPan = StringUtils.rightPad(pan, 19, '0');
				panAccountRange = countryCodeCache.get(new PANAccountRange(rightPaddedPan));	

				logger.info(" for " +  getMaskedAccountNumber(pan));
				if( null != panAccountRange ){
					logger.info("got mbr_id " + panAccountRange.getMbrId() + ", startOfRange = " + getMaskedAccountNumber(panAccountRange.getStart().toString()) + " for " +  getMaskedAccountNumber(pan));
				}
			}

		} finally {
			logger.info("Going to release the read lock from PanAcctRange Cache");

			lock.readLock().unlock();
		}
		return panAccountRange;
	}

	public void setIsValidAndIsVerfied(PANAccountRange panAccountRange,
			ProcessedRecord processedRecord) {
		if (null != panAccountRange) {
			processedRecord.setAccountValid(true);
			if (("A").equals(panAccountRange.getStatus())) {
				processedRecord.setIsAccountActive("Y");
			} else {
				processedRecord.setIsAccountActive("N");
			}
		} else {
			processedRecord.setAccountValid(false);
			processedRecord.setIsAccountActive("N");
		}

		if(panAccountRange != null && processedRecord.isAccountValid() && (processedRecord.getIsAccountActive().equals("Y"))) {
			processedRecord.setIca(panAccountRange.getMbrId());
		}

		if(panAccountRange != null && processedRecord.isAccountValid() && (processedRecord.getIsAccountActive().equals("Y"))) {
			processedRecord.setBrandProductCode(panAccountRange.getBrandProductCode());
		}
	}

	/**
	 * This method is a utility method which formats a PAN string to remove all whitespaces or
	 * unwanted characters to extract numbers from the string
	 * @param rawPan
	 * @return
	 */
	private String formatPAN(String rawPan) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : formatPAN ");
		}

		String formattedPan = rawPan.replaceAll("\\D+","");

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : formatPAN ");
		}
		return formattedPan;
	}

	public static String getMaskedAccountNumber(String accountNumber) {
		String result = null;

		if (accountNumber != null) {
			int accountNumberLength = accountNumber.length();
			if (accountNumberLength > 6) {
				StringBuilder buf = new StringBuilder();
				buf.append(accountNumber.substring(0, 6));

				String last4 = accountNumber.substring(accountNumberLength - 4);
				for (int i = 6; i < accountNumberLength - 4; i++) {
					buf.append("X");
				}
				buf.append(last4);
				result = buf.toString();
			} else {
				result = accountNumber;
			}
		}
		return result;
	}
}
