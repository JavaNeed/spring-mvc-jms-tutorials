package com.mastercard.ess.eds.core.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;
import org.easyrules.core.BasicRule;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.dao.FileGenerationRulesDao;
import com.mastercard.ess.eds.core.rule.FileGenerationCustomRules;
import com.mastercard.ess.eds.core.rule.FileGenerationRules;

public class FileGenerationRulesCache {

	private static Logger logger = Logger.getLogger(FileGenerationRulesCache.class);

	@Autowired
	FileGenerationRulesDao fileGenerationRulesDao;

	private  List<BasicRule> fileGenRulesCache;

	public void updateCache() {
 
		if (logger.isDebugEnabled()) {
			logger.debug("FileGenerationRulesCache | updateCache | Enter in method ");
		}

		fileGenRulesCache = fileGenerationRulesDao.loadAllCategoryRules();

		if (logger.isDebugEnabled()) {
			logger.debug("FileGenerationRulesCache | updateCache | Exit from method ");
		}
	}

	public List<BasicRule> getCache() {

		if (logger.isDebugEnabled()) {
			logger.debug("FileGenerationRulesCache | getCache | Enter in method ");
		}
		List<BasicRule> rulesCache; 
		
		if (null != fileGenRulesCache) {
			if (logger.isDebugEnabled()) {
				logger.debug("FileGenerationRulesCache | Exit from method : getCache ");
			}
			 rulesCache = getNewList(fileGenRulesCache);
			
		} else {
			updateCache();
			if (logger.isDebugEnabled()) {
				logger.debug("FileGenerationRulesCache | Exit from method : getCache ");
			}
			rulesCache= getNewList(fileGenRulesCache);
		}
		return Collections.unmodifiableList(rulesCache);
	}

	// for JUnit
	public void setFileGenerationRulesDAO(FileGenerationRulesDao fileGenerationRulesDao2) {
		fileGenerationRulesDao = fileGenerationRulesDao2;

	}
	
	/*
	 * Deep copy the list objects so each thread gets its own copy
	 */
	public List<BasicRule> getNewList(List<BasicRule> ruleList) {
		if (logger.isDebugEnabled()) {
			logger.debug("FileGenerationRulesCache | getNewList | Enter in method ");
		}

		List<BasicRule> returnList  = new ArrayList<BasicRule>(ruleList.size());
		
		for(BasicRule rule : ruleList) {
			if(rule instanceof FileGenerationRules) {
				FileGenerationRules copiedRule = new FileGenerationRules((FileGenerationRules)rule);
				logger.debug("Adding FileGenerationRules to return list rule name = " + rule.getName()); 
				returnList.add(copiedRule);
			} else if (rule instanceof FileGenerationCustomRules) {
				FileGenerationCustomRules copiedRule = new FileGenerationCustomRules((FileGenerationCustomRules)rule); 
				logger.debug("Adding FileGenerationCustomRules to return list rule name = " + rule.getName());
				returnList.add(copiedRule);
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("FileGenerationRulesCache | Exit from method : getNewList ");
		}

		return returnList;
	}

}
