package com.mastercard.ess.eds.core.util;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.springframework.stereotype.Component;

@Component
public class KnownPanCache {
	
	/** Read Write Lock for Cache. */
    private static final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

	Map<String, String> cache = new ConcurrentHashMap<String, String>();

	public boolean insert(String pan, String result) {
		lock.writeLock().lock();

		try {
			if (null != pan) {
				
				if (null == cache.put(pan, result)) {
					return true;
				}
			}
				return false;
				
		} finally {
			lock.writeLock().unlock();
		}
	}

	public void bulkInsert(List<PanResultHolder> pans) {
		lock.writeLock().lock();
		try {
			if (null != pans && pans.size() != 0) {
	
				for (PanResultHolder row  : pans) {
						cache.put(row.getPan(), (String) row.getResult());
					}
				}
			} finally {
				lock.writeLock().unlock();
			}
		}

	public String getResult(String pan) {
		lock.readLock().lock();
		String result = null;
		try {
			result = cache.get(pan);
			return result;
		} finally {
			lock.readLock().unlock();
		}
		
	}
}
