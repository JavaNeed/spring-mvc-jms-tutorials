package com.mastercard.ess.eds.batch.scheduler;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.mastercard.ess.eds.common.SplunkEvent;
import com.mastercard.ess.eds.common.SplunkEventLogger;
import com.mastercard.ess.eds.core.util.GlobalConstants;

public class CPPAnalysisScheduler {
	
	@Autowired
	ApplicationContext context;
	
	@Autowired
	private JobLauncher jobLauncher;
	
	private Job job;
	
	@SuppressWarnings("unused")
	private JdbcTemplate jdbcTemplate;
	
	private Logger logger = Logger.getLogger(CPPAnalysisScheduler.class);
	
	public void run()  throws JobExecutionAlreadyRunningException{
		JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
		SimpleDateFormat datetimeFormat = new SimpleDateFormat(GlobalConstants.DATE_TIME_FORMAT);
		String timestamp  = datetimeFormat.format(new Date());
		jobParametersBuilder.addString("currentDateTime", timestamp); //Spring Batch API does not support java.time's LocalDate/LocalTime yet.
		JobParameters jobParameters = jobParametersBuilder.toJobParameters();
		job = (Job) context.getBean("cppAnalysis");
		
		try {
			 jobLauncher.run(job, jobParameters);
		} 
		catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException | JobParametersInvalidException  e){
			splunkLogger(e);
			}

	}
	
	public void splunkLogger(JobExecutionException e) {
		Map<String, String> splunkLogError = new HashMap<>();
		splunkLogError.put("exception", e.getMessage());
		splunkLogError.put("job", job.getName());
		SplunkEventLogger.logEvent(SplunkEvent.JOB_LAUNCH_FAILURE, splunkLogError, logger);
		logger.error("cppAnalysis job Failed, exception = "+e);
		
	}

	// for Junit
	public void setContext(ApplicationContext context)
	{
		this.context = context;
	}
	// for Junit
	public void setJoLauncher(JobLauncher jobLauncher) {
		this.jobLauncher =jobLauncher;
	}
	// for Junit
	public void setJob(Job job) {
		this.job=job;		
	}

}
