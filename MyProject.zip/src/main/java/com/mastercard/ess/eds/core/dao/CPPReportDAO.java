package com.mastercard.ess.eds.core.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class CPPReportDAO {

	private static final String FETCH_CNTRY_CODES_QUERY = "SELECT distinct(ISSR_CNTRY_CD) FROM EDS_CPP_TRAN_SUMM";
	private static final String FETCH_MRCHNT_CNTRY_CODES_QUERY = "SELECT distinct(MERCH_CNTRY_CD) FROM EDS_CPP_TRAN_SUMM";
	private JdbcTemplate jdbcTemplate;

	public CPPReportDAO(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);

	}

	public List<String> getListOfCountries() {
		return jdbcTemplate.queryForList(FETCH_CNTRY_CODES_QUERY, String.class);

	}

	public List<String> getListOfMerchantCountries() {
		return jdbcTemplate.queryForList(FETCH_MRCHNT_CNTRY_CODES_QUERY, String.class);

	}

}
