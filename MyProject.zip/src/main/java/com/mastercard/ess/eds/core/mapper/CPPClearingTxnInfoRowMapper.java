package com.mastercard.ess.eds.core.mapper;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.mastercard.ess.eds.domain.CPPTxnInfo;

public class CPPClearingTxnInfoRowMapper implements RowMapper<CPPTxnInfo>{

	private static Logger logger = Logger.getLogger(CPPAuthTxnInfoRowMapper.class);
	
	@Override
	public CPPTxnInfo mapRow(ResultSet paramResultSet, int paramInt) throws SQLException {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : mapRow | CPPClearingTxnInfoRowMapper ");
		}
		CPPTxnInfo cppTxnInfo = new CPPTxnInfo();
		cppTxnInfo.setPan(new BigDecimal(paramResultSet.getString("PAN")));
		cppTxnInfo.setTransactionAmount(Long.toString(paramResultSet.getLong("LOC_TXN_AMT")));
		cppTxnInfo.setLocationId(paramResultSet.getLong("LOC_ID"));
		cppTxnInfo.setSequenceNumber(paramResultSet.getLong("SEQ_NBR"));
		cppTxnInfo.setMerchantCountryCode(paramResultSet.getString("MERCH_NAM"));
		cppTxnInfo.setIssuerCountryCode(paramResultSet.getString("ISSR_CNTRY_CD"));
		cppTxnInfo.setMerchantCountryCode(paramResultSet.getString("MERCH_CNTRY_CD"));
		cppTxnInfo.setTransactionChannel(paramResultSet.getString("TRAN_CHNL"));
		cppTxnInfo.setSource("CLEARING");
		
		return cppTxnInfo;
	}
	
}

