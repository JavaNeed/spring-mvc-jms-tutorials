package com.mastercard.ess.eds.billing.writer;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.util.CustomerEnrollmentReportGenerator;
import com.mastercard.ess.eds.domain.CustomerEnrollmentReport;

public class CustomerEnrollmentReportWriter implements ItemWriter<CustomerEnrollmentReport>, StepExecutionListener{

	private static Logger logger = Logger.getLogger(CustomerEnrollmentReportWriter.class);

	@Autowired
	CustomerEnrollmentReportGenerator customerEnrollmentReportGenerator;


	private BigDecimal jobInstanceId;
	private String jobInstanceName;
	private StepExecution stepExcecution;
	private boolean generated = false;

	@Override
	public void write(List<? extends CustomerEnrollmentReport> customerEnrollmentReportList)
			throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : CustomerEnrollmentReportWriter - write ");
		}
		
		customerEnrollmentReportGenerator.writeToCustomerEnrollmentReport(customerEnrollmentReportList, jobInstanceId, jobInstanceName);
		generated=true;

		if (logger.isDebugEnabled()) {
			logger.debug("Exit in method : CustomerEnrollmentReportWriter - write ");
		}
	}

	public void setCustomerEnrollmentReportGenerator(
			CustomerEnrollmentReportGenerator customerEnrollmentReportGenerator) {
		this.customerEnrollmentReportGenerator = customerEnrollmentReportGenerator;
	}

	@Override
	public ExitStatus afterStep(StepExecution arg0) {		
		if(!generated){			
			customerEnrollmentReportGenerator.writeToCustomerEnrollmentReport(new ArrayList<CustomerEnrollmentReport>(), jobInstanceId, jobInstanceName);
		}
		return null;
	}

	

	@Override
	public void beforeStep(StepExecution arg0) {
		// TODO Auto-generated method stub

	}
	public BigDecimal getJobInstanceId() {
		return jobInstanceId;
	}

	public void setJobInstanceId(BigDecimal jobInstanceId2) {
		this.jobInstanceId = jobInstanceId2;
	}

	public String getJobInstanceName() {
		return jobInstanceName;
	}

	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}

	@BeforeStep
	public void setStepExecution(StepExecution stepExecution) {
		this.stepExcecution = stepExecution;
	}

	public StepExecution getStepExcecution() {
		return stepExcecution;
	}

	public boolean isGenerated() {
		return generated;
	}

	public void setGenerated(boolean generated) {
		this.generated = generated;
	}

}
