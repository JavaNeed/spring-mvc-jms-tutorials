package com.mastercard.ess.eds.renewal.vo;
import java.util.Date;

public class CustMstrVO {
	private long edsCustMstrId;
	private String custTypeId;
	private String custNam;
	private String isActvSw;
	private String isSilentSw;
	private long icaNum;
	private long prntIcaNum;
	private String ServId;
	private String defltNotifEmailAddr;
	private String endpntId;
	private String lstUpdtUserId;
	private String lstUpdtDt;
	private Date lstUpdDt;
	private Date endDt;
	private Date strtDt;
	private Date crteDt;
	public long getEdsCustMstrId() {
		return edsCustMstrId;
	}
	public void setEdsCustMstrId(long edsCustMstrId) {
		this.edsCustMstrId = edsCustMstrId;
	}
	public String getCustTypeId() {
		return custTypeId;
	}
	public void setCustTypeId(String custTypeId) {
		this.custTypeId = custTypeId;
	}
	public String getCustNam() {
		return custNam;
	}
	public void setCustNam(String custNam) {
		this.custNam = custNam;
	}
	public String getIsActvSw() {
		return isActvSw;
	}
	public void setIsActvSw(String isActvSw) {
		this.isActvSw = isActvSw;
	}
	public String getIsSilentSw() {
		return isSilentSw;
	}
	public void setIsSilentSw(String isSilentSw) {
		this.isSilentSw = isSilentSw;
	}
	public long getIcaNum() {
		return icaNum;
	}
	public void setIcaNum(long icaNum) {
		this.icaNum = icaNum;
	}
	public long getPrntIcaNum() {
		return prntIcaNum;
	}
	public void setPrntIcaNum(long prntIcaNum) {
		this.prntIcaNum = prntIcaNum;
	}
	public String getServId() {
		return ServId;
	}
	public void setServId(String servId) {
		ServId = servId;
	}
	public String getDefltNotifEmailAddr() {
		return defltNotifEmailAddr;
	}
	public void setDefltNotifEmailAddr(String defltNotifEmailAddr) {
		this.defltNotifEmailAddr = defltNotifEmailAddr;
	}
	public String getEndpntId() {
		return endpntId;
	}
	public void setEndpntId(String endpntId) {
		this.endpntId = endpntId;
	}
	public String getLstUpdtUserId() {
		return lstUpdtUserId;
	}
	public void setLstUpdtUserId(String lstUpdtUserId) {
		this.lstUpdtUserId = lstUpdtUserId;
	}
	public String getLstUpdtDt() {
		return lstUpdtDt;
	}
	public void setLstUpdtDt(String lstUpdtDt) {
		this.lstUpdtDt = lstUpdtDt;
	}
	public Date getLstUpdDt() {
		return lstUpdDt;
	}
	public void setLstUpdDt(Date lstUpdDt) {
		this.lstUpdDt = lstUpdDt;
	}
	public Date getEndDt() {
		return endDt;
	}
	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}
	public Date getStrtDt() {
		return strtDt;
	}
	public void setStrtDt(Date strtDt) {
		this.strtDt = strtDt;
	}
	public Date getCrteDt() {
		return crteDt;
	}
	public void setCrteDt(Date crteDt) {
		this.crteDt = crteDt;
	}
	
}
