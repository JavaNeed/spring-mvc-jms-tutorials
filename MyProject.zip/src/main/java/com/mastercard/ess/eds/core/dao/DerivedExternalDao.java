package com.mastercard.ess.eds.core.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.domain.ProcessedRecord;

@Component
public class DerivedExternalDao {

	private static Logger logger = Logger.getLogger(DerivedExternalDao.class);
	
	private static final String FETCH_SRC_RULE_DATA = "select DISTINCT(EDS_CPP_RULE_ID) from EDS_SRC_RULE_DATA where EDS_SRC_DATA_ID = ?";

	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private EDSCPPRulesDao eDSCPPRulesDao ;
	
	
	public DerivedExternalDao(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {

		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	
	public void updateExternalDerivedForPricingCategory(BigDecimal srcDataKey, ProcessedRecord processedRecord) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : updateExternalDerivedForPricingCategory ");
		}
		
		List<Map<String, Object>> sourceRuleDataIds = jdbcTemplate.queryForList(FETCH_SRC_RULE_DATA, srcDataKey);
		processedRecord.setIsDerived("N");
		processedRecord.setIsExternal("Y");
		
	if (null != sourceRuleDataIds && !sourceRuleDataIds.isEmpty() ){
		
		for (Map<String, Object> row : sourceRuleDataIds) {
			
			BigDecimal cppRuleId = (BigDecimal) row.get("EDS_CPP_RULE_ID");
			
			String catogeryType = eDSCPPRulesDao.getCatogeryType(cppRuleId);
			
			processedRecord.setIsDerived("Y");
			
			if(StringUtils.isNotBlank(catogeryType) && catogeryType.equalsIgnoreCase("E")){
				break ;
			}
			processedRecord.setIsExternal("N");
				
		}
		
	}
	logger.info("set derived = N and external = Y");
	
	if (logger.isDebugEnabled()) {
		logger.debug("Exiting method : updateExternalDerivedForPricingCategory ");
	}

	}

}
