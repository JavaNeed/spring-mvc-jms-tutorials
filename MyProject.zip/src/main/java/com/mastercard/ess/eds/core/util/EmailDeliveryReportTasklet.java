package com.mastercard.ess.eds.core.util;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;

import com.mastercard.ess.eds.core.dao.EDSSourceTypeDao;
import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.notification.util.NotificationEventConstants;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;

public class EmailDeliveryReportTasklet  implements Tasklet{

	private static final String CUSTOMER_INTERNAL_DELIVERY_REPORT = "Customer_Internal_DeliveryReport";

	private static Logger logger = Logger.getLogger(EmailDeliveryReportTasklet.class);
	
	private static final String JOB_NAME = "jobName" ;

	@Autowired
	EventPublisher eventPublisher;

	@Autowired
	EDSSourceTypeDao edsSourceTypeDao;

	@Value("${customerDeliveryReport.path}")
	private String customerDeliveryReportPath;
	private static final String MMM_YYYY = "MMM-yyyy";
	
	//for junit
	public EmailDeliveryReportTasklet(EDSSourceTypeDao edsSourceTypeDao) {
		this.edsSourceTypeDao = edsSourceTypeDao;
	}
	public EmailDeliveryReportTasklet() {
	}

	public String getCustomerDeliveryReportPath() {
		return customerDeliveryReportPath;
	}

	public void setCustomerDeliveryReportPath(String customerDeliveryReportPath) {
		this.customerDeliveryReportPath = customerDeliveryReportPath;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		logger.debug("Enter method : execute : EmailDeliveryReportTasklet ");
		
		Calendar currentCal = Calendar.getInstance();  
		DateFormat dateFormat = new SimpleDateFormat(MMM_YYYY);
		String currentMonth=dateFormat.format(currentCal.getTime());
		
		String deliverReportPath = customerDeliveryReportPath.trim(); 
		String deliveryReportFile = "Customer_Internal_DeliveryReport"+ "_" + currentMonth + ".xlsx";
		logger.info(" *******deliverReportPath ="+deliverReportPath);
		logger.info("******* deliveryReportFile =" + deliveryReportFile);

		NotificationEventVO notificationEventVO = new NotificationEventVO();
		Map<String, String> jobParams = new HashMap<>();
		jobParams.put("summaryFile", deliverReportPath+deliveryReportFile);
		jobParams.put("month", currentMonth);
		jobParams.put(JOB_NAME, chunkContext.getStepContext().getStepExecution().getJobExecution().getJobInstance().getJobName());
		notificationEventVO.setEventName(NotificationEventConstants.NOTIF_EVT_CUSTOMER_DELIVERY_REPORT_FILE_GENERATED);
		notificationEventVO.setJobParams(jobParams);
		notificationEventVO.setJobName(chunkContext.getStepContext().getStepExecution().getJobExecution().getJobInstance().getJobName());
		notificationEventVO.setJobID(BigDecimal.valueOf(chunkContext.getStepContext().getStepExecution().getJobExecution().getJobId()));
		
		FileSystemResource customerReportFileSystemResource = new FileSystemResource(deliverReportPath+deliveryReportFile);
		logger.info("customerReportFileSystemResource :"+customerReportFileSystemResource);
		
		if (customerReportFileSystemResource.exists()) {
			logger.info("placing notification event for delivery report generation ");
			eventPublisher.placeEvent(notificationEventVO);
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : execute : EmailDeliveryReportTasklet ");
		}
		
		return null;
	}
}
