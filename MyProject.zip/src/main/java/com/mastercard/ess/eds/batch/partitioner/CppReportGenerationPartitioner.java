package com.mastercard.ess.eds.batch.partitioner;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.service.CPPReportService;

public class CppReportGenerationPartitioner implements Partitioner {

	@Autowired
	CPPReportService cppReportService;

	private Logger logger = Logger.getLogger(CppReportGenerationPartitioner.class);

	public CppReportGenerationPartitioner() {
		super();
	}

	@Override
	public Map<String, ExecutionContext> partition(int arg0) {

		int i = 0;
		List<String> countrycodes = cppReportService.getListOfCountries();

		Map<String, ExecutionContext> partitionMap = new HashMap<String, ExecutionContext>();

		for (String issCntryCode : countrycodes) {
			ExecutionContext ctxMap = new ExecutionContext();
			ctxMap.putString("issr_cntry_cd", issCntryCode);
			partitionMap.put("CPPFileGenerationThread -" + i, ctxMap);
			++i;
		}
		return partitionMap;
	}

	public void setCppReportService(CPPReportService cPPReportService2) {
		this.cppReportService = cPPReportService2;
		
	}

}
