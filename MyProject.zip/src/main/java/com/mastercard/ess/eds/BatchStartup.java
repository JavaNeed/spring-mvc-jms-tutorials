package com.mastercard.ess.eds;

import org.springframework.batch.core.JobExecution;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.integration.channel.QueueChannel;
import org.springframework.messaging.Message;

import com.mastercard.ess.eds.batch.config.CommonConfig;

/**
 * Starts the Spring Context and will initialize the Spring Integration routes.
 *
 *
 */
public final class BatchStartup {

	private BatchStartup() {
	}

	/**
	 * Load the Spring Integration Application Context
	 *
	 * @param args 
	 *            - command line arguments
	 * @throws InterruptedException
	 */
	public static void main(final String... args) throws InterruptedException {

		final ConfigurableApplicationContext context = SpringApplication.run(CommonConfig.class); //NOSONAR

		final QueueChannel completeApplicationChannel = context.getBean("completeApplication", QueueChannel.class);

		completeApplicationChannel.receive(1200000);

	}
}
