package com.mastercard.ess.eds.batch.tasklet;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.constant.BatchConstants;
import com.mastercard.ess.eds.core.service.CPPSimulationService;
import com.mastercard.ess.eds.core.service.RawRecordDBWriterService;

public class TruncateCPPSimulationDataTasklet implements Tasklet{

	private static Logger logger = Logger.getLogger(TruncateCPPSimulationDataTasklet.class);
	
	
	@Autowired
	private CPPSimulationService cppSimulationService;

	
	@Autowired
	private RawRecordDBWriterService rawRecordDBWriterService;


	private String cppRunMode;
	

	public String getCppRunMode() {
		return cppRunMode;
	}

	public void setCppRunMode(String cppRunMode) {
		this.cppRunMode = cppRunMode;
	}

	 

	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext)
			throws Exception {
		
		
		logger.info("Enter into the execute method : TruncateCPPSimulationDataTasklet with cppRunMode = " + cppRunMode);

		
		if(BatchConstants.SIMULATION.equalsIgnoreCase(cppRunMode)){
			cppSimulationService.truncateCPPSimulationData();
			chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("cppRunMode", BatchConstants.SIMULATION);
			logger.info("Truncated the CPP simulation Data" );
		} 
		
		logger.info("Exit from the method execute: TruncateCPPSimulationDataTasklet");
		return RepeatStatus.FINISHED;
	}

	//Junit
	public void setCppSimulationService(CPPSimulationService cppSimulationService) {
		this.cppSimulationService = cppSimulationService;
	}

	public void setRawRecordDBWriterService(
			RawRecordDBWriterService rawRecordDBWriterService) {
		this.rawRecordDBWriterService = rawRecordDBWriterService;
	}
 
}
