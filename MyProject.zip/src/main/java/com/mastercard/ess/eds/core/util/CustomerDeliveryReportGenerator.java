package com.mastercard.ess.eds.core.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.service.CustomerFileReportService;

@Component
public class CustomerDeliveryReportGenerator {

	private static final String E = "E";

	private static final String D = "D";

	private static final String C = "C";

	private static final String B = "B";

	private static final String A = "A";

	private static final String MEA = "MEA";

	private static final String APAC = "APAC";

	private static final String LAC = "LAC";

	private static final String EUROPE = "EUROPE";

	private static final String NAM = "NAM";

	private static final String US = "US";

	private static final String FIRST = "1";

	private static final String ACTIVITY = "Activity";

	private static final String TO = " to ";

	private static final String DATE_RANGE = "Date Range";

	private static final String ISSUER_REGION = "Issuer Region";

	private static final String CONFIDENCE_SCORE = "Confidence Score";

	private static final String MMM_YY = "MMM-yy";

	private static final String MMM_YYYY = "MMM-yyyy";

	private static final int EDS_CUSTOMER_DILIVERY_REPORT_TYPE =5;

	@Autowired
	CustomerFileReportService customerFileReportService;

	@Value("${customerDeliveryReport.path}")
	private String customerDeliveryReportPath;

	private static Logger logger = Logger.getLogger(CustomerDeliveryReportGenerator.class);

	public CustomerDeliveryReportGenerator() {
		super();
		logger.info("Default Constructor - CustomerDeliveryReportGenerator");
	}
	public CustomerDeliveryReportGenerator(String customerDeliveryReportPath,
			CustomerFileReportService customerFileReportService) {
		this.customerDeliveryReportPath = customerDeliveryReportPath;
		this.customerFileReportService =customerFileReportService;
	}

	private FileOutputStream getFileoutputStream(String filePath) throws FileNotFoundException {
		return new FileOutputStream(new File(filePath));
	}

	private Workbook getWorkbook()
			throws IOException, InvalidFormatException {
		return new XSSFWorkbook();
	}

	private Row createRow(Sheet spreadsheet, int rowNum) {
		return spreadsheet.createRow(rowNum);
	}

	private Cell createCellWithValue(Row row, int cellNo, Object value, Workbook wb) {

		XSSFCellStyle style = (XSSFCellStyle) wb.createCellStyle();
		Font f = wb.createFont();
		f.setBoldweight(Font.BOLDWEIGHT_NORMAL);
		f.setFontHeightInPoints((short) 10);
		style.setFont(f);
		style.setAlignment(CellStyle.ALIGN_CENTER);

		XSSFCellStyle style1 = (XSSFCellStyle) wb.createCellStyle();
		Font f1 = wb.createFont();
		f1.setBoldweight(Font.BOLDWEIGHT_NORMAL);
		f1.setFontHeightInPoints((short) 10);

		style1.setFont(f1);

		XSSFCellStyle style2 = (XSSFCellStyle) wb.createCellStyle();
		Font f2 = wb.createFont();
		f2.setBoldweight(Font.BOLDWEIGHT_NORMAL);
		f2.setFontHeightInPoints((short) 10);
		style2.setFont(f2);

		Cell c = row.createCell(cellNo);

		setCellWithStyle1(value, style1, c);			


		c.setCellValue(value.toString());
		if(value instanceof Integer || value instanceof Double) {
			c.setCellValue(Double.valueOf(value.toString()));
		} else {
			c.setCellValue(value.toString());
		} 

		return c;
	}
	/**
	 * @param value
	 * @param style1
	 * @param c
	 */
	private void setCellWithStyle1(Object value, XSSFCellStyle style1, Cell c) {
		c.setCellStyle(style1);
	}

	private static void writeToFile(Workbook workbook, FileOutputStream fos) throws IOException {
		workbook.write(fos);

	}

	/**
	 * @param stepExecution
	 * @param summaryList
	 *            : data to be exported to excel file
	 * @param monthlySummary
	 *            : total counts for the month
	 * @param jobInstanceName
	 * @param jobInstanceId
	 *            this method populates the data fetched from EDS_PRCSS_DATA
	 *            based on grouping
	 */
	public synchronized void writeToCustomerDeliveryReport(Map<String, Map<Integer,List<Object>>> contimenMap,
			BigDecimal jobInstanceId, String jobInstanceName) {

		logger.debug("***************Start Method writeToCustomerDeliveryReport*******"); 
		logger.info("Customer Internal Delivery Report Size = "+ contimenMap.size());

		try{

			logger.info("Customer Delivery Path :"+customerDeliveryReportPath+" jobInstanceId :"+jobInstanceId+" jobInstanceName :"+jobInstanceName);
			String filePath=customerDeliveryReportPath;
			String sheetName = "customerDeliveryReport";

			Calendar cal = Calendar.getInstance();  
			cal.add(Calendar.MONTH, -1);  
			DateFormat df = new SimpleDateFormat(MMM_YY);
			String toDate =df.format(cal.getTime());
			cal.add(Calendar.MONTH, -11);  
			String fromDate=df.format(cal.getTime());

			//Getting month-Year mapping for previous Month

			Calendar currentCal = Calendar.getInstance();  

			DateFormat dateFormat = new SimpleDateFormat(MMM_YYYY);
			String currentMonth=dateFormat.format(currentCal.getTime());

			logger.info(" FromDate :"+fromDate+"Calender after 12 months"+" ToDate :"+toDate+" Previous Month :"+currentMonth);

			filePath = filePath + "Customer_Internal_DeliveryReport"+ "_" + currentMonth + ".xlsx";

			logger.info("CustomerDelivery filePath= "+filePath);

			if(contimenMap!=null && contimenMap.size()>0)

			{
				File file = null;
				FileOutputStream fos = null;
				Workbook wb = null;
				Sheet sheet = null;
				Integer keyRow = 0;

				file = new File(filePath);
				boolean fileFlag=file.exists()?true:false;
				logger.info("file already exists exiting .."+fileFlag);

				wb = getWorkbook();
				fos = getFileoutputStream(filePath);


				for (Map.Entry<String, Map<Integer,List<Object>>> entry:contimenMap.entrySet() ) {
					String continentId=entry.getKey();
					sheetName= getSheetNameByContinentId(continentId);
					sheet = wb.createSheet(sheetName);
					logger.info("Sheet Name:"+sheetName);
					int existingRows = sheet.getPhysicalNumberOfRows();
					// Create row object
					// This data needs to be written (Object[])
					Map<Integer, Object[]> rowEntry = new TreeMap<>();

					mapObjectWithContinentToPanCount(contimenMap.get(continentId), fromDate,toDate, sheet, keyRow, rowEntry);

					// Iterate over data and write to sheet
					int rowid = existingRows;
					for (Integer key : rowEntry.keySet()) {
						createCellValue(wb, createRow(sheet, rowid++), rowEntry.get(key), 0);
					}

					for (int i = 0; i < 4; i++) {
						sheet.autoSizeColumn(i);
					}
				}
				writeToFile(wb, fos);
				logger.info("Customer Internal Delivery Report Path is  = " + filePath );

				//This will update the table after report is generated
				customerFileReportService.createGeneratedFileRecord(filePath, jobInstanceId, jobInstanceName, EDS_CUSTOMER_DILIVERY_REPORT_TYPE);
			}
		}catch (Exception e) {
			logger.error("Exception : " + e);
		} 

		logger.debug("End Method writeToCustomerDeliveryReport*******");
	}


	//Going to fetch sheetName based on continentId
	public String getSheetNameByContinentId(String continentId) {

		String sheetName="";
		switch (continentId) {
		case FIRST:
			sheetName=US;
			break;

		case A:
			sheetName=NAM;
			break;
		case B:
			sheetName=EUROPE;
			break;
		case C:
			sheetName=LAC;
			break;
		case D:
			sheetName=APAC;
			break;
		case E:
			sheetName=MEA;
			break;

		default:
			sheetName=US;
			break;
		}		
		return sheetName;
	}
	private void mapObjectWithContinentToPanCount(
			Map<Integer, List<Object>> prizeCodeMap, String fromDate, String toDate,
			Sheet sheet, Integer keyRow, Map<Integer, Object[]> rowEntry) {
		logger.info("***************Start method mapObjectWithContinentToPanCount *****************");
		rowEntry.put((keyRow++), new Object[] { " " });
		rowEntry.put((keyRow++), new Object[] { ISSUER_REGION,sheet.getSheetName() });
		rowEntry.put((keyRow++), new Object[] { DATE_RANGE, fromDate ,TO, toDate });

		rowEntry.put((keyRow++), new Object[] { " "});
		rowEntry.put((keyRow++), new Object[] { " " });
		List<String> prevMonthList=new ArrayList<>();
		prevMonthList.add(" ");	
		prevMonthList.add(CONFIDENCE_SCORE);
		prevMonthList.add(" ");
		prevMonthList.add(ACTIVITY);	
		prevMonthList.add(" ");
		prevMonthList.addAll(getPrevMonthList());
		rowEntry.put((keyRow++), prevMonthList.toArray());
		
		for(Map.Entry<Integer, List<Object>> entryMap: prizeCodeMap.entrySet()){
			rowEntry.put((keyRow++), prizeCodeMap.get(entryMap.getKey()).toArray());
		}
		
		logger.info("***************End method mapObjectWithContinentToPanCount *****************");
	}

	/**
	 * @param wb
	 * @param row
	 * @param objectArr
	 * @param cellid
	 */
	private void createCellValue(Workbook wb, Row row, Object[] objectArr,
			int cell) {
		int cellid = cell;
		for (Object obj : objectArr) {
			if (obj != null) {
				createCellWithValue(row, cellid++, obj, wb);
			} else {
				createCellWithValue(row, cellid++, " ", wb);
			}

		}
	}

	/**Getting list of previous 12 months*/
	public static List<String> getPrevMonthList() {

		Calendar cal = Calendar.getInstance();  
		cal.add(Calendar.MONTH, -1);  
		List<String> prevMonthList=new ArrayList<String>();
		SimpleDateFormat monthDate = new SimpleDateFormat(MMM_YY);
		for (int i = 1; i <= 12; i++) {
			prevMonthList.add(monthDate.format(cal.getTime()));
			cal.add(Calendar.MONTH, -1);
		}
		return prevMonthList;
	}

}
