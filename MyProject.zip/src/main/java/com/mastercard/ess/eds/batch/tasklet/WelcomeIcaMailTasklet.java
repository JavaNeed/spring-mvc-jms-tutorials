package com.mastercard.ess.eds.batch.tasklet;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.core.service.CustomerMasterService;
import com.mastercard.ess.eds.core.service.EventSubscriptionService;
import com.mastercard.ess.eds.notification.util.NotificationEventConstants;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;

public class WelcomeIcaMailTasklet implements Tasklet{

	private static Logger logger = Logger.getLogger(WelcomeIcaMailTasklet.class);
	private static String CUSTOMER_ONBOARD_EMAIL = "customerOnboardEmail";
	private static String CUSTOMER_ONBOARD_ICAS = "customerOnboardIcas";
	
	@Autowired
	private EventPublisher eventPublisher;

	@Autowired
	private CustomerMasterService customerMasterService;

	@Autowired
	private EventSubscriptionService eventSubscriptionService;
	
	//required for writing junit
	public WelcomeIcaMailTasklet() {
		//NOOP
	}
	
	//required for writing junit
	public WelcomeIcaMailTasklet(EventPublisher eventPublisher, CustomerMasterService customerMasterService, EventSubscriptionService eventSubscriptionService) {
		this.eventPublisher = eventPublisher;
		this.customerMasterService = customerMasterService;
		this.eventSubscriptionService = eventSubscriptionService;
	}
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		logger.info("Enter method : execute : WELCOME ICA MAIL ");

		Map<String, List<Integer>> icaemail = customerMasterService.getSubscribtionEmailWithICA();
		if(icaemail.isEmpty()){
			return RepeatStatus.FINISHED ;
		}
		
		for (Map.Entry<String, List<Integer>> entry : icaemail.entrySet())
		{
			NotificationEventVO notificationEventVO = new NotificationEventVO();
			Map<String, String> jobParams = new HashMap<>();
			String customerOnboardedEmail = (String)entry.getKey();
			List<Integer> icas =  icaemail.get(customerOnboardedEmail);

			jobParams.put(CUSTOMER_ONBOARD_EMAIL, customerOnboardedEmail);
			jobParams.put(CUSTOMER_ONBOARD_ICAS, StringUtils.join(icas, ","));

			notificationEventVO.setJobParams(jobParams);
			notificationEventVO.setJobName(chunkContext.getStepContext().getStepExecution().getJobExecution().getJobInstance().getJobName());
			notificationEventVO.setJobID(BigDecimal.valueOf(chunkContext.getStepContext().getStepExecution().getJobExecution().getJobId().longValue()));
			notificationEventVO.setEventName(NotificationEventConstants.WELCOME_EMAIL_ICA);
			this.eventPublisher.placeEvent(notificationEventVO);
		}

		logger.info("Exit from method : execute : WELCOME ICA MAIL ");
		return RepeatStatus.FINISHED;
		
	}
	
}
