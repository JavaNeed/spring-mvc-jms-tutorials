package com.mastercard.ess.eds.core.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.dao.CPPItemWriterDAO;
import com.mastercard.ess.eds.domain.CPPTxnInfo;



@Component
public class CPPItemWriterService {
	
	@Autowired
	CPPItemWriterDAO cppItemWriterDAO;
//for junit
	public CPPItemWriterService(CPPItemWriterDAO cppItemWriterDAO) {
		this.cppItemWriterDAO = cppItemWriterDAO;
	}

	public void writeCppRecord(List<? extends CPPTxnInfo> items) {
		
		cppItemWriterDAO.writeCppRecord(items);
	}

	public void setJosetJobInstanceName(String jobInstanceName) {
		cppItemWriterDAO.setJosetJobInstanceName(jobInstanceName);
	}

}
