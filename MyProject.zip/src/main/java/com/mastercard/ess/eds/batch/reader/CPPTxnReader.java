package com.mastercard.ess.eds.batch.reader;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamReader;

import com.mastercard.ess.eds.domain.CPPTxnInfo;

/**
 * This class is used as composite item reader
 * it delegates to all readers configured in cpp analysis xml file
 * @author e058825
 *
 */
public class CPPTxnReader implements ItemReader<CPPTxnInfo>, ItemStream {
	
	  private ItemStreamReader<CPPTxnInfo>[] delegates;
	  private int delegateIndex;
	  private ItemStreamReader<CPPTxnInfo> currentDelegate;
	  private ExecutionContext stepExecutionContext;
	  private static final String INDEX="index";
	  private static final String IN_OPEN_FOR_INDEX=" in open for index ";
	  private static Logger logger = Logger.getLogger(CPPTxnReader.class);
	  
	public void setDelegates(ItemStreamReader<CPPTxnInfo>[] delegates) {
	    this.delegates = delegates;
	  }
	
	 public void setCurrentDelegate(ItemStreamReader<CPPTxnInfo> currentDelegate) {
			this.currentDelegate = currentDelegate;
		}

	  @BeforeStep
	  private void beforeStep(StepExecution stepExecution) {
	    this.stepExecutionContext = stepExecution.getExecutionContext();
	  }

	  public CPPTxnInfo read() {
		  
	    if (logger.isDebugEnabled()) {
			logger.debug("Enter in method read : CPPTxnReader ");
		}
	    
		CPPTxnInfo item = null;
	    if(null != currentDelegate) {
	      try {
			item = currentDelegate.read();
		} catch (Exception e) {
			logger.error("Exception occurred for currentDelegate=" + currentDelegate + ", message " + e);
		}
	      if(null == item) {
	        this.currentDelegate.close();
	        this.currentDelegate = null;
	      }
	    }
	    // Move to next delegate if previous was exhausted!
	    if(null == item && this.delegateIndex< this.delegates.length) {
	      this.currentDelegate = this.delegates[this.delegateIndex++];

	      this.currentDelegate.open(this.stepExecutionContext);
	      
	      update(this.stepExecutionContext);
	      // Recurse to read() to simulate loop through delegates
	      item = read();
	    }
	    
	    if (logger.isDebugEnabled()) {
			logger.debug("Exit from method read : CPPTxnReader");
		}
	    return item;
	  }

	  public void open(ExecutionContext ctx) {
	    // During open restore last active reader and restore its state
		   
	    if(ctx.containsKey(INDEX)) {
	    	
	      this.delegateIndex = ctx.getInt(INDEX);
	      logger.info(IN_OPEN_FOR_INDEX+"=" + this.delegateIndex);
	      this.currentDelegate = this.delegates[this.delegateIndex];
	      ((ItemStream)this.currentDelegate ).open(ctx);
	      logger.info(IN_OPEN_FOR_INDEX+" =" + this.delegateIndex +", called open");
	    }
	  }

	  public void update(ExecutionContext ctx) {
	    // Update current delegate index and state
	    ctx.putInt(INDEX, this.delegateIndex);
	    if(null != this.currentDelegate) {
	      this.currentDelegate.update(ctx);
	      logger.info(IN_OPEN_FOR_INDEX+"=" + this.delegateIndex +", called update");
	    }
	  }

	@Override
	public void close(){
	    if(null != this.currentDelegate) {
		      this.currentDelegate.close();
		      logger.info(IN_OPEN_FOR_INDEX+"=" + this.delegateIndex +", called close");
		  }
		
	}
}
