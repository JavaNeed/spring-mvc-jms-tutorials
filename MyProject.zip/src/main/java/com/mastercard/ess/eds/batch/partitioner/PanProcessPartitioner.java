package com.mastercard.ess.eds.batch.partitioner;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.batch.config.CommonCacheTokens;
import com.mastercard.ess.eds.core.service.EDSRecordWriterService;
import com.mastercard.ess.eds.core.util.EDSSourceRuleDataCache;

public class PanProcessPartitioner implements Partitioner {

	private static final String END_INDEX = "endIndex";

	private static final String START_INDEX = "startIndex";

	@Autowired
	EDSRecordWriterService edsRecordWriterService;
	
	@Autowired
	EDSSourceRuleDataCache edsSourceRuleDataCache;

	private ExecutionContext executionContext;
	
	private Logger logger = Logger.getLogger(PanProcessPartitioner.class);

	private int numRecords;

	public ExecutionContext getExecutionContext() {
		return executionContext;
	}

	public void setExecutionContext(ExecutionContext executionContext) {
		this.executionContext = executionContext;
	}

	public EDSRecordWriterService getEdsRecordWriterService() {
		return edsRecordWriterService;
	}

	public void setEdsRecordWriterService(
			EDSRecordWriterService edsRecordWriterService) {
		this.edsRecordWriterService = edsRecordWriterService;
	}

	public int getNumRecords() {
		return numRecords;
	}

	public void setNumRecords(int numRecords) {
		this.numRecords = numRecords;
	}

	@Override
	public Map<String, ExecutionContext> partition(int threadCount) {

		logger.info("Start of partition method in PanProcessPartitioner");
		Long startIndex = new Long(0);
		Long endIndex =  new Long(0);
		Long totalCount=new Long(0);
		Long finalEndIndex= new Long(0);
		Long totalRecords= new Long(0);
		Map<String, ExecutionContext> partitionMap = new HashMap<String, ExecutionContext>();

		//Fetching the start index and end index from the executionContext, this was initialized in CommonCacheLoader

		if (executionContext!=null && executionContext.get(CommonCacheTokens.START_INDEX.getDesc())!=null && 
				executionContext.get(CommonCacheTokens.END_INDEX.getDesc())!=null) {
			
			startIndex = new Long(executionContext.get(CommonCacheTokens.START_INDEX.getDesc()).toString());
			endIndex = new Long(executionContext.get(CommonCacheTokens.END_INDEX.getDesc()).toString());
			totalCount=startIndex+numRecords;
			finalEndIndex=endIndex;
			totalRecords=endIndex-startIndex;

			logger.info("Thread Count = "+threadCount+" startIndex = "+startIndex +", endIndex = " + endIndex +", numRecords = " + numRecords +" totalCount = "+totalCount);
			if (startIndex != endIndex) {
				if ((startIndex + numRecords) <= endIndex) {
					logger.info("Diffrence in start index =" + startIndex
							+ " and end Index =" + endIndex
							+ " is greater than =" + numRecords);

					for (int i = 0; i < threadCount; i++) {
						if (i > 0) {
							startIndex = endIndex+1;
						}
						if (i == (threadCount - 1)) {
							if ((startIndex) <= (totalCount)) {
								logger.info("Start index ="+startIndex+" is less than equal ="+totalCount);
								endIndex = totalCount;
							}
							else {
								endIndex = startIndex + (numRecords / threadCount);
							}
						} else {
							endIndex = startIndex + (numRecords / threadCount);

						}
						ExecutionContext ctxMap = new ExecutionContext();
						logger.info("Thread Index= " + i+" startIndex= "+ startIndex + "endIndex ="+ endIndex);
						ctxMap.putLong(START_INDEX, startIndex);
						ctxMap.putLong(END_INDEX, endIndex);
						partitionMap.put("Thread -" + i, ctxMap);

					}
				}//If diffrence between endindex and start index is less than numRecords then we will partitione records on (endIndex-startIndex)
				else {
					logger.info("Diffrence in start index : " + startIndex+ " and end Index :" + endIndex + " is less than "+ numRecords+" totalCount = "+totalCount);
					if ((totalRecords)>(numRecords/threadCount)) {
						for (int i = 0; i < threadCount; i++) {
							if (i > 0) {
								startIndex = endIndex + 1;
							}
							if (i == (threadCount - 1)) {
								if ((startIndex) < (totalCount)) {
									if (totalCount < finalEndIndex) {
										endIndex = totalCount;
									} else {
										endIndex = finalEndIndex;
									}
								}
							} else {
								endIndex = startIndex + ((totalRecords) / threadCount);
							}
							ExecutionContext ctxMap = new ExecutionContext();
							logger.info("Thread Index=" + i + "startIndex= "+ startIndex + "endIndex =" + endIndex);
							ctxMap.putLong(START_INDEX, startIndex);
							ctxMap.putLong(END_INDEX, endIndex);
							partitionMap.put("Thread -" + i, ctxMap);
						}
					}
					else {
						logger.info("Thread Index=" + 1 + "startIndex= "+ startIndex + "endIndex =" + endIndex +" as (totalRecords>numRecords/threadCount)="+totalRecords/threadCount +" NumRecords ="+numRecords );		
						ExecutionContext ctxMap = new ExecutionContext();
						logger.info("Thread Index=" + 1 + "startIndex= "+ startIndex + "endIndex =" + endIndex);
						ctxMap.putLong(START_INDEX, startIndex);
						ctxMap.putLong(END_INDEX, endIndex);
						partitionMap.put("Thread -" + 1, ctxMap);
					}

				}
			}
			else {
				logger.info("startIndex equals to endIndex");

			}
			logger.info("End of partition method in PanProcessPartitioner");

		}

		return partitionMap;
	}
	
	
}
