package com.mastercard.ess.eds.core.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.service.CustomerFileReportService;
import com.mastercard.ess.eds.domain.CPPRuleRecord;

@Component
public class CPPSimulationReportGenerator {

	private static Logger logger = Logger.getLogger(CPPSimulationReportGenerator.class);
	private static final String CPP_SIMULATION_DATE = "Simulation Run Date:";
	private static final String DD_MMM_YYYY = "dd-MMM-yyyy";
	private static final int SIMULATION_REPORT_TYPE = 8;
	private static final String CPP_SIMULATION_REPORT = "SIMULATION_REPORT";
	private static final String ROW_RULE_ID = "Rule ID";
	private static final String ROW_MERCHANT_LOCATION_ID = "Merchant Location ID"; 
	private static final String ROW_MERCHANT_NAME = "Merchant Name"; 
	private static final String ROW_ISSUER_COUNTRY = "Issuer Country"; 
	private static final String ROW_AMOUNT = "Amount"; 
	private static final String ROW_PERIOD = "Period";
	private static final String ROW_PAN_COUNT = "PAN count";
	private static final String ROW_CAT_CD = "Rule type (Internal/External)";
	private static final String NOT_APPLICABLE = "N/A";

	@Autowired
	private CustomerFileReportService customerFileReportService;

	@Value("${simulationReport.path}")
	private String simulationReportPath;


	//for junit
	public CPPSimulationReportGenerator(){
		super();
	}

	// for Junit
	public CPPSimulationReportGenerator(String simulationReportPath,
			CustomerFileReportService customerFileReportService) {
		this.simulationReportPath = simulationReportPath;
		this.customerFileReportService = customerFileReportService;
	}

	private Cell createCellWithValue(Row row, int cellNo, Object value,
			Workbook wb) {



		XSSFCellStyle style1 = (XSSFCellStyle) wb.createCellStyle();
		Font f1 = wb.createFont();
		f1.setBoldweight(Font.BOLDWEIGHT_BOLD);
		f1.setFontHeightInPoints((short) 10);
		f1.setUnderline((byte) 10);

		style1.setFont(f1);

		Cell xssCell = row.createCell(cellNo);

		String[] styleArray =  { ROW_RULE_ID, ROW_MERCHANT_LOCATION_ID, ROW_MERCHANT_NAME , ROW_ISSUER_COUNTRY ,ROW_AMOUNT , ROW_PERIOD , ROW_PAN_COUNT ,ROW_CAT_CD , CPP_SIMULATION_DATE  };
		List<String> styleList = Arrays.asList(styleArray);

		if ( value!=null && styleList.contains(value)) {
			setCellStyle(style1,xssCell);
		}


		if (value instanceof Integer || value instanceof Double) {
			xssCell.setCellValue(Double.valueOf(value.toString()));
		} else {
			xssCell.setCellValue(value.toString());
		}

		return xssCell;

	}


	private void setCellStyle(XSSFCellStyle style1, Cell c) {
		c.setCellStyle(style1);
	}

	public void generateSimulationReport(
			List<CPPRuleRecord> cppSimulationRecord, BigDecimal jobInstanceId,
			String jobInstanceName) {
		logger.info("***************Start Method generateSimulationReport*******"); 

		try{

			logger.info("SImulation Report Path  :"+simulationReportPath+" jobInstanceId :"+jobInstanceId+" jobInstanceName :"+jobInstanceName);
			String filePath=simulationReportPath;

			Calendar currentCal = Calendar.getInstance();  

			DateFormat dateFormat = new SimpleDateFormat(DD_MMM_YYYY);
			String currentMonth=dateFormat.format(currentCal.getTime());

			filePath = filePath + "Simulation_Report"+ "_" + currentMonth + ".xlsx";

			if(CollectionUtils.isNotEmpty(cppSimulationRecord))

			{
				File file = null;
				FileOutputStream fos = null;
				Workbook wb = null;
				Sheet sheet = null;

				file = new File(filePath);
				if (file.exists()) {
					logger.info("file already exists exiting ..");
					return;
				}

				wb = getXSSFWorkBook();
				fos = getFileOutputStream(filePath);

				sheet = wb.createSheet(CPP_SIMULATION_REPORT);
				int existingRows = sheet.getPhysicalNumberOfRows();

				// This data needs to be written (Object[])
				Map<Integer, Object[]> rowEntry = new TreeMap<>();

				mapObjectWithCPPSimulationRecord(cppSimulationRecord, 
						rowEntry);

				// Iterate over data and write to sheet
				writeDataInSheet(wb, sheet, existingRows, rowEntry);

				writeToFile(wb, fos);

				//This will update the table after report is generated
				customerFileReportService.createGeneratedFileRecord(filePath, jobInstanceId, jobInstanceName, SIMULATION_REPORT_TYPE);

			}
		}catch (Exception e) {
			logger.error("Exception : " + e);
		} 

		logger.info("***************End Method generateSimulationReport*******");  

	}

	/**
	 * @param value
	 * @param style1
	 * @param c
	 */
	private static void writeToFile(Workbook workbook, FileOutputStream fos)
			throws IOException {
		workbook.write(fos);

	}


	private void mapObjectWithCPPSimulationRecord(
			List<CPPRuleRecord> cppSimulationRecord,   
			Map<Integer, Object[]> rowEntry )  {
		logger.info("***************Enter method mapObjectWithCPPSimulationRecord *****************");
		Integer keyRow = 0 ;
		DateFormat dateFormat = new SimpleDateFormat(DD_MMM_YYYY);

		rowEntry.put((keyRow++), new Object[] { CPP_SIMULATION_DATE,
				dateFormat.format(new Date()) });
		rowEntry.put((keyRow++), new Object[] { "" });
		rowEntry.put((keyRow++), new Object[] { " "});

		rowEntry.put((keyRow++), new Object[] { ROW_RULE_ID ,ROW_MERCHANT_LOCATION_ID , ROW_MERCHANT_NAME , ROW_ISSUER_COUNTRY , ROW_AMOUNT , ROW_PERIOD , ROW_PAN_COUNT , ROW_CAT_CD });

		getSimulationReportData( cppSimulationRecord ,rowEntry , keyRow);

		logger.info("***************End method mapObjectWithCPPSimulationRecord *****************");

	}

	private void getSimulationReportData(List<CPPRuleRecord> cppSimulationRecords , Map<Integer, Object[]> rowEntry ,Integer keyRow ) {

		String issuerCountry = null ;
		String locationTranAmt = null ;
		String valueAmount = null ;
		Integer ruleId = null ;

		for(CPPRuleRecord cppRuleRecord : cppSimulationRecords) {
			issuerCountry = StringUtils.isNotBlank(cppRuleRecord.getValIssrCntry()) ? 
					cppRuleRecord.getClsIssrCntry() + " " + cppRuleRecord.getValIssrCntry() : NOT_APPLICABLE ;

					locationTranAmt = cppRuleRecord.getValLocTranAmt()!= null ? cppRuleRecord.getClsLocTranAmt() + " " + cppRuleRecord.getValLocTranAmt() : NOT_APPLICABLE ;

					valueAmount = cppRuleRecord.getValTmCount()!= 0 ? cppRuleRecord.getValTmCount() + " " + cppRuleRecord.getUnitTmCount() : NOT_APPLICABLE ;
					ruleId = cppRuleRecord.getCppRuleId().intValue() ;
					
					rowEntry.put((keyRow++), new Object[] { ruleId ,
							cppRuleRecord.getValMerchant()!= 0 ? cppRuleRecord.getValMerchant() : NOT_APPLICABLE  , cppRuleRecord.getMerchantName() , issuerCountry , locationTranAmt,	 valueAmount,
									cppRuleRecord.getPanCount(), cppRuleRecord.getCatCD()
					});
		}
	}



	/**
	 * @param wb
	 * @param row
	 * @param objectArr
	 * @param cellid
	 */
	private void createCellValue(Workbook wb, Row row, Object[] objectArr,
			int cell) {
		int cellid = cell;
		for (Object obj : objectArr) {
			if (obj != null) {
				createCellWithValue(row, cellid++, obj, wb);
			} else {
				createCellWithValue(row, cellid++, "", wb);
			}

		}
	}

	public String getFormattedDate(Date date, String format) {
		String formattedDate = "";
		if (null != date) {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			formattedDate = sdf.format(date);
		}
		return formattedDate;
	}


	private FileOutputStream getFileOutputStream(String filePath) throws FileNotFoundException {
		return new FileOutputStream(new File(filePath));
	}

	private Workbook getXSSFWorkBook() {
		return new XSSFWorkbook();
	}

	private Row createRowInSpreadSheet(Sheet spreadsheet, int rowNum) {
		return spreadsheet.createRow(rowNum);
	}

	private void writeDataInSheet(Workbook wb, Sheet sheet, int existingRows,
			Map<Integer, Object[]> rowEntry) {
		Row row;
		Set<Integer> keyid = rowEntry.keySet();
		int rowid = existingRows;

		for (Integer key : keyid) {
			row = createRowInSpreadSheet(sheet, rowid++);
			Object[] objectArr = rowEntry.get(key);
			int cellid = 0;
			createCellValue(wb, row, objectArr, cellid);
		}

		for (int i = 0; i < 4; i++) {
			sheet.autoSizeColumn(i);
		}
	}


	public void setCustomerFileReportService(
			CustomerFileReportService customerFileReportService) {
		this.customerFileReportService = customerFileReportService;
	}

	public void setSimulationReportPath(String simulationReportPath) {
		this.simulationReportPath = simulationReportPath;
	}



}
