package com.mastercard.ess.eds.core.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.service.CustomerFileReportService;
import com.mastercard.ess.eds.domain.FraudReportRecord;

@Component
public class FraudReportGenerator {

	private static final String SUBSCRIBED_BEFORE_FRAUD = "PANs had Fraud before EDS notified customer";
	private static final String SUBSCRIBED_AFTER_FRAUD = "PANs saw Fraud after EDS notified customer";	
	private static final String UNSUBSCRIBED_BEFORE_FRAUD = "PANs had Fraud before EDS notified customer";
	private static final String UNSUBSCRIBED_AFTER_FRAUD = "PANs saw Fraud after EDS notified customer";
	
	private static final String SUBSCRIBED_CUSTOMER = "Subscribed Customer";
	private static final String NON_SUBSCRIBED_CUSTOMER = "Non Subscribed Customer";
	private static final String EDS_FRAUD_REPORT = "Fraud Report";
	private static final String DATE_RANGE = "Date Range";
	private static final String MMM_YY = "MMM-YY";

	private static final String MMMM_YYYY = "MMMM-yyyy";
	private static final int FRAUD_REPORT_TYPE = 7; 
	private static final String ZERO = "0" ;

	@Autowired
	private CustomerFileReportService customerFileReportService;

	@Value("${frDetailReport.path}")
	private String fraudReportPath;

	private static Logger logger = Logger.getLogger(FraudReportGenerator.class);

	// Added to fix dependency issues
	public FraudReportGenerator() {
		super();
	}

	// for Junit
	public FraudReportGenerator(String fraudReportPath,
			CustomerFileReportService customerFileReportService) {
		this.fraudReportPath = fraudReportPath;
		this.customerFileReportService = customerFileReportService;
	}


	private Cell createCellWithValue(Row row, int cellNo, Object value,
			Workbook wb) {



		XSSFCellStyle style1 = (XSSFCellStyle) wb.createCellStyle();
		Font f1 = wb.createFont();
		f1.setBoldweight(Font.BOLDWEIGHT_BOLD);
		f1.setFontHeightInPoints((short) 10);

		style1.setFont(f1);

		XSSFCellStyle style2 = (XSSFCellStyle) wb.createCellStyle();
		Font f2 = wb.createFont();
		f2.setBoldweight(Font.BOLDWEIGHT_BOLD);
		f2.setFontHeightInPoints((short) 10);
		style2.setFont(f2);

		Cell xssCell = row.createCell(cellNo);

		if (EDS_FRAUD_REPORT.equals(value) || SUBSCRIBED_CUSTOMER.equals(value)
				|| NON_SUBSCRIBED_CUSTOMER.equals(value)) {
			setCellStyle(style1,xssCell);
		}

		if (DATE_RANGE.equals(value)) {
			setCellStyle(style1,xssCell);
		}

		if (value instanceof Integer || value instanceof Double) {
			xssCell.setCellValue(Double.valueOf(value.toString()));
		} else {
			xssCell.setCellValue(value.toString());
		}

		return xssCell;

	}
	

	private void setCellStyle(XSSFCellStyle style1, Cell c) {
		c.setCellStyle(style1);
	}
	/**
	 * @param value
	 * @param style1
	 * @param c
	 */
	private static void writeToFile(Workbook workbook, FileOutputStream fos)
			throws IOException {
		workbook.write(fos);

	}

	/**
	 * @param stepExecution
	 * @param summaryList
	 *            : data to be exported to excel file
	 * @param monthlySummary
	 *            : total counts for the month
	 * @param jobInstanceName
	 * @param jobInstanceId
	 *            this method populates the data fetched from EDS_PRCSS_DATA
	 *            based on grouping
	 */
	public synchronized void writeToFraudReport(List<FraudReportRecord> fraudReportList,
			BigDecimal jobInstanceId, String jobInstanceName) {
	
		logger.info("***************Start Method writeToFraudReport*******"); 

		try{

			logger.info("Fraud Report Path  :"+fraudReportPath+" jobInstanceId :"+jobInstanceId+" jobInstanceName :"+jobInstanceName);
			String filePath=fraudReportPath;

			Calendar cal = Calendar.getInstance();  
			cal.add(Calendar.MONTH, -1);  
			DateFormat df = new SimpleDateFormat(MMM_YY);
			String toDate =df.format(cal.getTime());
			cal.add(Calendar.MONTH, -11);  
			String fromDate=df.format(cal.getTime());

			Calendar currentCal = Calendar.getInstance();  

			DateFormat dateFormat = new SimpleDateFormat(MMMM_YYYY);
			String currentMonth=dateFormat.format(currentCal.getTime());

			filePath = filePath + "Fraud_Report"+ "_" + currentMonth + ".xlsx";

			if(CollectionUtils.isNotEmpty(fraudReportList))

			{
				File file = null;
				FileOutputStream fos = null;
				Workbook wb = null;
				Sheet sheet = null;

				file = new File(filePath);
				if (file.exists()) {
					logger.info("file already exists exiting ..");
					return;
				}

				wb = getXSSFWorkBook();
				fos = getFileOutputStream(filePath);

				sheet = wb.createSheet(EDS_FRAUD_REPORT);
				int existingRows = sheet.getPhysicalNumberOfRows();
				
				// This data needs to be written (Object[])
				Map<Integer, Object[]> rowEntry = new TreeMap<>();
				
				mapObjectWithFraudReportRecord(fraudReportList, fromDate, toDate,
						  rowEntry, wb);
				
				// Iterate over data and write to sheet
				writeDataInSheet(wb, sheet, existingRows, rowEntry);
				
				writeToFile(wb, fos);

				//This will update the table after report is generated
				customerFileReportService.createGeneratedFileRecord(filePath, jobInstanceId, jobInstanceName, FRAUD_REPORT_TYPE);

			}
		}catch (Exception e) {
			logger.error("Exception : " + e);
		} 

		logger.info("***************End Method writeToFraudReport*******");  

	}

	private void mapObjectWithFraudReportRecord(
			List<FraudReportRecord> fraudList, String fromDate,
			String toDate,   
			Map<Integer, Object[]> rowEntry, Workbook wkbook)  {
		logger.info("***************Enter method mapObjectWithFraudReportRecord *****************");
		Integer keyRow = 0 ;
		rowEntry.put((keyRow++), new Object[] { EDS_FRAUD_REPORT });
		rowEntry.put((keyRow++), new Object[] { "" });
		
		rowEntry.put((keyRow++), new Object[] { DATE_RANGE,
				fromDate + " to " + toDate });
		rowEntry.put((keyRow++), new Object[] { "" });
		rowEntry.put((keyRow++), new Object[] { " "});
		
		List<String> prevMonthList=new ArrayList<>();
		List<String> subscribedCustomer=new ArrayList<>();
		List<String> unsubscribedCustomer=new ArrayList<>();
		List<String>  subscribedBeforeList = new ArrayList<>();
		List<String>  subscribedAfterList = new ArrayList<>();
		List<String>  unsubscribedBeforeList = new ArrayList<>();
		List<String>  unsubscribedAfterList = new ArrayList<>();
		
		
		Integer incr = 12;
		prevMonthList.add(" ");
		prevMonthList.add(" ");
		prevMonthList.add(" ");
		prevMonthList.addAll(getPrevMonthList(incr));
		
		subscribedCustomer.add(" ");
		subscribedCustomer.add(" ");
		subscribedCustomer.add(SUBSCRIBED_CUSTOMER);
		
		unsubscribedCustomer.add(" ");
		unsubscribedCustomer.add(" ");
		unsubscribedCustomer.add(NON_SUBSCRIBED_CUSTOMER);
		
		subscribedBeforeList.add(" ");
		subscribedBeforeList.add(" ");
		subscribedBeforeList.add(SUBSCRIBED_BEFORE_FRAUD);
		
		subscribedAfterList.add(" ");
		subscribedAfterList.add(" ");
		subscribedAfterList.add(SUBSCRIBED_AFTER_FRAUD);
		
		
		unsubscribedBeforeList.add(" ");
		unsubscribedBeforeList.add(" ");
		unsubscribedBeforeList.add(UNSUBSCRIBED_BEFORE_FRAUD);
		
		
		unsubscribedAfterList.add(" ");
		unsubscribedAfterList.add(" ");
		unsubscribedAfterList.add(UNSUBSCRIBED_AFTER_FRAUD);
		
		getFraudReportDataList(subscribedBeforeList, subscribedAfterList, unsubscribedBeforeList, unsubscribedAfterList,  fraudList);
		 
		
		rowEntry.put((keyRow++), prevMonthList.toArray());
		rowEntry.put((keyRow++), subscribedCustomer.toArray());
		rowEntry.put((keyRow++), subscribedBeforeList.toArray());
		rowEntry.put((keyRow++), subscribedAfterList.toArray());
		rowEntry.put((keyRow++), unsubscribedCustomer.toArray());
		rowEntry.put((keyRow++), unsubscribedBeforeList.toArray());
		rowEntry.put((keyRow), unsubscribedAfterList.toArray());
		
	 
		logger.info("***************End method mapObjectWithFraudReportRecord *****************");

	}

	private void getFraudReportDataList(List<String> subscribedBeforeList,	List<String> subscribedAfterList,
			List<String> unsubscribedBeforeList, List<String> unsubscribedAfterList,  
			List<FraudReportRecord> fraudList) {
		boolean fraudListFlag = false ;
	 
		SimpleDateFormat monthDate = new SimpleDateFormat("MMM-yy");
        for (int i = 1; i <13; i++) {
        	fraudListFlag = false ;
              Calendar calendar1 = Calendar.getInstance();
              calendar1.add(Calendar.MONTH, -i);
              String monthName = monthDate.format(calendar1.getTime());
              for( FraudReportRecord fraudReportRecord :fraudList){
	              if(fraudReportRecord.getMonth().equalsIgnoreCase(monthName)){
	            	  subscribedBeforeList.add(String.valueOf(fraudReportRecord.getSubscribedBeforeCt()));
	            	  subscribedAfterList.add(String.valueOf(fraudReportRecord.getSubscribedAfterCt()));
	            	  unsubscribedBeforeList.add(String.valueOf(fraudReportRecord.getUnsubscribedBeforeCt()));
	            	  unsubscribedAfterList.add(String.valueOf(fraudReportRecord.getUnsubscribedAfterCt()));
	            	  fraudListFlag = true;
            		  break ;
	              }
              }
              
              if(!fraudListFlag){
	            	subscribedBeforeList.add(ZERO);
	            	  subscribedAfterList.add(ZERO);
	            	  unsubscribedBeforeList.add(ZERO);
	            	  unsubscribedAfterList.add(ZERO);
	           }
         }
               

	}

	/**
	 * @param wb
	 * @param row
	 * @param objectArr
	 * @param cellid
	 */
	private void createCellValue(Workbook wb, Row row, Object[] objectArr,
			int cell) {
		int cellid = cell;
		for (Object obj : objectArr) {
			if (obj != null) {
				createCellWithValue(row, cellid++, obj, wb);
			} else {
				createCellWithValue(row, cellid++, "", wb);
			}

		}
	}

	public String getFormattedDate(Date date, String format) {
		String formattedDate = "";
		if (null != date) {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			formattedDate = sdf.format(date);
		}
		return formattedDate;
	}

	
	private FileOutputStream getFileOutputStream(String filePath) throws FileNotFoundException {
		return new FileOutputStream(new File(filePath));
	}

	private Workbook getXSSFWorkBook() {
		return new XSSFWorkbook();
	}

	private Row createRowInSpreadSheet(Sheet spreadsheet, int rowNum) {
		return spreadsheet.createRow(rowNum);
	}

	private void writeDataInSheet(Workbook wb, Sheet sheet, int existingRows,
			Map<Integer, Object[]> rowEntry) {
		Row row;
		Set<Integer> keyid = rowEntry.keySet();
		int rowid = existingRows;

		for (Integer key : keyid) {
			row = createRowInSpreadSheet(sheet, rowid++);
			Object[] objectArr = rowEntry.get(key);
			int cellid = 0;
			createCellValue(wb, row, objectArr, cellid);
		}

		for (int i = 0; i < 4; i++) {
			sheet.autoSizeColumn(i);
		}
	}
	

	/**Getting list of previous 12 months
	 * @param incr */
	public static List<String> getPrevMonthList(Integer incr) {

		Calendar cal = Calendar.getInstance();  
		cal.add(Calendar.MONTH, -1);  
		List<String> prevMonthList=new ArrayList<>();
		SimpleDateFormat monthDate = new SimpleDateFormat(MMM_YY);
		for (int i = 1; i <= incr; i++) {
			String monthName = monthDate.format(cal.getTime());
			prevMonthList.add(monthName);
			cal.add(Calendar.MONTH, -1);
		}
		return prevMonthList;
	}

	public void setCustomerFileReportService(
			CustomerFileReportService customerFileReportService) {
		this.customerFileReportService = customerFileReportService;
	}

	public void setFraudReportPath(String fraudReportPath) {
		this.fraudReportPath = fraudReportPath;
	}
}
