package com.mastercard.ess.eds.batch.processor;

import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.log4j.Logger;
import org.easyrules.api.RulesEngine;
import org.easyrules.core.BasicRule;
import org.easyrules.core.RulesEngineBuilder;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.rule.FileGenerationCustomRules;
import com.mastercard.ess.eds.core.rule.FileGenerationRules;
import com.mastercard.ess.eds.core.service.EDSRecordWriterService;
import com.mastercard.ess.eds.core.util.EDSProcessStatus;
import com.mastercard.ess.eds.core.util.FileGenerationRulesCache;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.ProcessedRecord;

public class RiskRecordItemProcessor implements ItemProcessor<EDSRecord, EDSRecord>, StepExecutionListener {

	private static Logger logger = Logger.getLogger(RiskRecordItemProcessor.class);
	
	@Autowired
	private FileGenerationRulesCache fileGenerationRulesCache;

	@Autowired
	private EDSRecordWriterService edsRecordWriterService;

	private List<EDSRecord> listOfFilteredRecords = new CopyOnWriteArrayList<EDSRecord>();
	private StepExecution stepExecution;
	private String jobInstanceName;
	private BigDecimal jobInstanceId ; 	
	
// for junit
	public RiskRecordItemProcessor(
			FileGenerationRulesCache fileGenerationRulesCache) {
		this.fileGenerationRulesCache = fileGenerationRulesCache;
	}

	public StepExecution getStepExecution() {
		return stepExecution;
	}

	public void setStepExecution(StepExecution stepExecution) {
		this.stepExecution = stepExecution;
	}

	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}

	@Override
	public EDSRecord process(EDSRecord edsRecord) {

		ProcessedRecord processedRecord = null;

		if (edsRecord != null) {
			logger.debug("EDSRecord received with ICA --" + edsRecord.getProcRecord().getIca() + ",  procRecordKey="
					+ edsRecord.getProcRecord().getProcRecordKey() + " and PAN = " + getMaskedAccountNumber("" +edsRecord.getProcRecord().getPan()));
			processedRecord = edsRecord.getProcRecord();
			
			List<BasicRule> fileGenerationRuleList = fileGenerationRulesCache.getCache();
			RulesEngine rulesEngine = RulesEngineBuilder.aNewRulesEngine().build();
			//logger.info("RulesEngine instance=" + rulesEngine+"@"+rulesEngine.hashCode());
	
			for (BasicRule rule : fileGenerationRuleList) {
	
				if (rule instanceof FileGenerationRules) {
					((FileGenerationRules) rule).setInputToRule(processedRecord);
					logger.debug("1.rule instance=" + rule+"@"+rule.hashCode());	
				}
	
				else if (rule instanceof FileGenerationCustomRules) {
					((FileGenerationCustomRules) rule).setInputToRule(processedRecord);
					logger.debug("2.rule instance=" + rule+"@"+rule.hashCode());
				}
	
				rulesEngine.registerRule(rule);
			}
			logger.debug("firing rules with " + rulesEngine+"@"+rulesEngine.hashCode() 
					+", for edsRecord with procRecordKey="+ processedRecord.getProcRecordKey());
			rulesEngine.fireRules();
	
		}
			
		if(processedRecord != null){
			logger.debug("edsRecord with procRecordKey=" + processedRecord.getProcRecordKey() + " and PAN = "
					+ getMaskedAccountNumber(""+ processedRecord.getPan()) + " has IsFiltered=" + processedRecord.getIsFiltered());
			if (!"Y".equals(processedRecord.getIsFiltered())) {

				logger.info("Forwarding edsRecord to Writer with procRecordKey=" + processedRecord.getProcRecordKey()
						+ " , ICA --" + edsRecord.getProcRecord().getIca() + " and PAN =" + getMaskedAccountNumber(""+ processedRecord.getPan()));
				return edsRecord;
			} else {
				logger.info("Adding edsRecord to filter list with procRecordKey=" + processedRecord.getProcRecordKey()
						+ " , ICA --" + edsRecord.getProcRecord().getIca() + " and PAN =" + getMaskedAccountNumber(""+ processedRecord.getPan()));
				listOfFilteredRecords.add(edsRecord);
				return null;
			}
		} else {
			return null;
		}

	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		if (stepExecution.getExitStatus() != ExitStatus.FAILED || stepExecution.getExitStatus() != ExitStatus.STOPPED) {

			if (!(listOfFilteredRecords.isEmpty())) {
				int status = EDSProcessStatus.INVALID.getStatusCode();
				logger.info("Processor after step executing and sending list of size -" + listOfFilteredRecords.size()
						+ " for update");
				edsRecordWriterService.updateRecordStatusPostFileGeneration(jobInstanceName, jobInstanceId, listOfFilteredRecords,
						null, status);
			}
			listOfFilteredRecords.clear();
		}

		return ExitStatus.COMPLETED;
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		this.setStepExecution(stepExecution);

	}
	
	public  String getMaskedAccountNumber(String accountNumber) {
		String result = null;

		if (accountNumber != null) {
			int accountNumberLength = accountNumber.length();
			if (accountNumberLength > 6) {
				StringBuilder buf = new StringBuilder();
				buf.append(accountNumber.substring(0, 6));

				String last4 = accountNumber.substring(accountNumberLength - 4);
				for (int i = 6; i < accountNumberLength - 4; i++) {
					buf.append("X");
				}
				buf.append(last4);
				result = buf.toString();
			} else {
				result = accountNumber;
			}
		}
		return result;
	}

	public BigDecimal getJobInstanceId() {
		return jobInstanceId;
	}

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}
}
