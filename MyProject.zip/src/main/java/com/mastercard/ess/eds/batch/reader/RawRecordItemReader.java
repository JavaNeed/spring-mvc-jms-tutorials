package com.mastercard.ess.eds.batch.reader;

import java.util.HashMap;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.mastercard.ess.eds.core.mapper.RawRecordRowMapper;
import com.mastercard.ess.eds.domain.RawRecord;

/**
 * Implements ItemReader and creates an instance of JdbcCursorItemReader to stream data from DB.
 * @author e067588
 *
 */
public class RawRecordItemReader implements ItemReader<RawRecord>{

	private static Logger logger = Logger.getLogger(RawRecordItemReader.class);
	
	private JdbcCursorItemReader<RawRecord> rawRecItemReader;
	
	/**
	 * Query to fetch queued files from EDS_SOURCE table
	 */
	private static final String QUERY_FETCH_DETAILS_FROM_EDS_SOURCE_DATA =
            "SELECT " +
                "EDS_SRC_ID, " +
                "EDS_SRC_DATA_ID, " +
                "ARTIFACT_ID, " +
                "URL_ADDR, "+
                "RAW_PAN_NUM, "+
                "RAW_DATA_TXT, "+
                "ERR_DTL_DESC, "+
                "LST_UPDT_DT, "+
                "LST_UPDT_USER_ID, "+
                "LINE_NUM "+
                "FROM EDS_SRC_DATA WHERE STAT_CD = '4'";
	
	public RawRecordItemReader(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
		rawRecItemReader = new JdbcCursorItemReader<RawRecord>();
		rawRecItemReader.setDataSource(dataSource);
		rawRecItemReader.setSql(QUERY_FETCH_DETAILS_FROM_EDS_SOURCE_DATA);
		rawRecItemReader.setRowMapper(new RawRecordRowMapper());
		
		//required to open reader stream		 
		ExecutionContext executionContext = new ExecutionContext();
		
		try{
			rawRecItemReader.open(executionContext);
		}catch(ItemStreamException e){
			logger.error("Could not open RawRecordItemReader --" +e);
		}
	}
	
	

	/* (non-Javadoc)
	 * @see org.springframework.batch.item.ItemReader#read()
	 */
	@Override
	public RawRecord read() {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : read ");
		}
		RawRecord rawRecord = new RawRecord(new HashMap<String,String>());
		
			try {
				rawRecord = rawRecItemReader.read();
			} catch ( Exception e ) {
				logger.error(e);
			}
			if (logger.isDebugEnabled()) {
				logger.debug("Exit from method : read ");
			}
			return rawRecord;		
	}
}
