package com.mastercard.ess.eds.core.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.dao.EDSRecordDao;
import com.mastercard.ess.eds.core.util.CPPRuleIdHolder;
import com.mastercard.ess.eds.domain.EDSCustomer;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.RawRecord;

/**
 * Service class to delegate requests to DAO
 * 
 * @author e067588
 *
 */
@Component
public class EDSRecordWriterService {

	@Autowired
	EDSRecordDao edsRecordDao;

	public EDSRecordWriterService() {
		super();
	}

	public EDSRecordWriterService(EDSRecordDao edsRecordDao) {
		super();
		this.edsRecordDao = edsRecordDao;
	}

	public void writeRecord(List<? extends EDSRecord> edsRecords, BigDecimal jobInstanceId) {
		edsRecordDao.writeRecord(edsRecords, jobInstanceId);
	}

	public void updateStatusOfFaultyInputRecords(RawRecord rawRecord) {
		edsRecordDao.updateStatusOfFaultyInputRecords(rawRecord);

	}
	
	public void updateRawRecordStatus(BigDecimal srcDataKey, int status, String error, String jobInstanceName, BigDecimal jobInstanceId) {
		edsRecordDao.updateRawRecordStatus(srcDataKey, status, error, jobInstanceName, jobInstanceId);
	}

	public void updateRecordStatusPostProcessing(List<? extends EDSRecord> edsRecords, String jobInstanceName, BigDecimal jobInstanceId) {

		edsRecordDao.updateRecordStatusPostProcessing(edsRecords, jobInstanceName, jobInstanceId);
	}

	public void setJobInstanceName(String jobInstanceName) {
		edsRecordDao.setJobInstanceName(jobInstanceName);

	}
	
	public void setJobInstanceId(BigDecimal jobInstanceId) {
		edsRecordDao.setJobInstanceId(jobInstanceId);

	}

	public boolean ifReportableRecordsExist() {

		return edsRecordDao.ifReportableRecordsExist();
	}

	public void updateRecordStatusPostFileGeneration(String jobInstanceName,  BigDecimal jobInstanceId,List<EDSRecord> listOfAllRecordsToUpdate,
			Map<BigDecimal, String> recordToFileMap, int status) {
		edsRecordDao.updateRecordStatusPostFileGeneration(jobInstanceName, jobInstanceId, listOfAllRecordsToUpdate, recordToFileMap,
				status);
	}
	
	/**
	 * This method updates the Dup_Sw for records which are not eleigible to be sent in the customer file.
	 * @param jobInstanceName
	 * @param setOfDupRecords
	 */
	public void updateSwForDupRecords(String jobInstanceName, BigDecimal jobInstanceId, List<EDSRecord> listOfDupRecords) {
		edsRecordDao.updateSwforDupRecords(jobInstanceName,jobInstanceId, listOfDupRecords);
	}

	public Map<String, Object> getIndexesForEDSSrcDataId() {
		return edsRecordDao.getIndexesForEDSSrcDataId();
	}

	public List<CPPRuleIdHolder> getEDSSrcRuleData(Long startIndex,Long endIndex){
		return edsRecordDao.getEDSSrcRuleData(startIndex,endIndex);
	}
	
	public List<EDSCustomer> getICAsWithHistFlagForFileGeneration() {
		return edsRecordDao.getICAsWithHistFlagForFileGeneration();
	}
	
}
