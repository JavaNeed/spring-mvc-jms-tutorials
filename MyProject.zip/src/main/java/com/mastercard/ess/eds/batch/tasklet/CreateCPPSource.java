package com.mastercard.ess.eds.batch.tasklet;

import java.math.BigDecimal;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.mastercard.ess.eds.constant.BatchConstants;
import com.mastercard.ess.eds.core.service.CPPSimulationService;
import com.mastercard.ess.eds.core.service.EDSSourceService;
import com.mastercard.ess.eds.core.service.EDSSourceTypeService;
import com.mastercard.ess.eds.core.service.RawRecordDBWriterService;
import com.mastercard.ess.eds.core.util.DeDupeTokens;
import com.mastercard.ess.eds.core.util.EDSProcessStatus;
import com.mastercard.ess.eds.domain.EDSSourceType;

public class CreateCPPSource implements Tasklet{

	private static Logger logger = Logger.getLogger(CreateCPPSource.class);
	
	@Autowired
	private EDSSourceTypeService edsSourceTypeService;

	@Autowired
	private EDSSourceService edsSourceService;

	@Autowired
	private CPPSimulationService cppSimulationService;

	
	@Autowired
	private RawRecordDBWriterService rawRecordDBWriterService;


	@Value("#{jobParameters['cppSrcName']}")
	public String cppSrcName;

	private String cppRunMode;
	
	private BigDecimal jobInstanceId;
	
	

	public String getCppRunMode() {
		return cppRunMode;
	}

	public void setCppRunMode(String cppRunMode) {
		this.cppRunMode = cppRunMode;
	}

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}

	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext)
			throws Exception {
		
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : CreateCPPSource : execute ");
		}

		String jobName = chunkContext.getStepContext().getJobName();
		int status = EDSProcessStatus.UNPROCESSED.getStatusCode();
		
		logger.info("createSourceRecord started : " + jobInstanceId+ " cppSrcName is = "+cppSrcName + "cppRunMode" + cppRunMode);

		if(BatchConstants.SIMULATION.equalsIgnoreCase(cppRunMode)){
			
			cppSimulationService.createSimulationSource(cppSrcName, jobName, jobInstanceId, status);
			String edsSimSrcId =    cppSimulationService.getSimulationSrcId(cppSrcName);
			chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("edsSimSrcId", edsSimSrcId);
			chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("cppRunMode", BatchConstants.SIMULATION);
			logger.info("Created the simulation Source with"+ "edsSimSrcId = "+ edsSimSrcId);
		} else {
			EDSSourceType edsSourceType = edsSourceTypeService.getEDSSourceTypeFromProvider("CPP");
			if(null==edsSourceType){
				edsSourceType = new EDSSourceType();
				edsSourceType.setProvider("unknown");
			}
			
			
			logger.info("createSourceRecord started : " + jobInstanceId+ " cppSrcName is = "+cppSrcName);

			edsSourceService.createSourceRecord(cppSrcName, jobName, jobInstanceId, status, "" , edsSourceType.getSourceTypeId(), "");

			String edsSrcId = rawRecordDBWriterService.getEdsSrcId(cppSrcName);

			chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("edsSrcId", edsSrcId);
			
			Map<String, Set> panRuleMap = new ConcurrentHashMap<String, Set>();
			chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(DeDupeTokens.PAN_RULE_MAP.getDesc(), panRuleMap);
		}

		
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : CreateCPPSource : execute ");
		}
		return RepeatStatus.FINISHED;
	}

	//for Junit
	public void setServices(EDSSourceTypeService edsSourceTypeService,
			EDSSourceService edsSourceService, RawRecordDBWriterService rawRecordDBWriterService) {
		this.edsSourceTypeService = edsSourceTypeService;
		this.edsSourceService = edsSourceService;
		this.rawRecordDBWriterService = rawRecordDBWriterService ;
	}
}
