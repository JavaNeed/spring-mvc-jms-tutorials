package com.mastercard.ess.eds.core.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.batch.exception.EDSCoreException;
import com.mastercard.ess.eds.core.dao.FraudDao;

/**
 * @author e067588 This is service class to interact with FraudDao to query
 *         Datawarehouse.
 */
@Component
public class FraudDetectionService {

    @Autowired
   private  FraudDao fraudDao;

    @Autowired
    private RetryTemplate retryTemplate;

    // for JUnit test
    public FraudDetectionService(FraudDao fraudDao, RetryTemplate retryTemplate) {
        super();
        this.fraudDao = fraudDao;
        this.retryTemplate = retryTemplate;
    }

    /**
     * Enable retry mechanism in Fraud Query.
     * @param pan
     * @return
     * @throws EDSCoreException
     */
    public boolean isFraudReported(String pan) throws EDSCoreException {
        return retryTemplate.execute(context -> {
            return fraudDao.isFraudReported(pan);
        });
    }

}
