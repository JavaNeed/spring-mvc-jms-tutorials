package com.mastercard.ess.eds.billing.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.mastercard.ess.eds.common.SplunkEvent;
import com.mastercard.ess.eds.common.SplunkEventLogger;
import com.mastercard.ess.eds.core.util.GlobalConstants;

/**
 * @author e069483
 * 
 * This is a scheduler class to launch the billing job
 *
 */
public class BillDataScheduler {
	@Autowired
	ApplicationContext context;
	@Autowired
	private JobLauncher jobLauncher;
	private static Logger logger = Logger.getLogger(BillDataScheduler.class);

	
	
	public void run() throws JobExecutionAlreadyRunningException {
		
		if (logger.isDebugEnabled()) {
			logger.debug("BillDataScheduler  | run() | Enter in method : run ");
		}
		
		
		if (null != context && null != jobLauncher) {
			Job job = (Job) context.getBean("billDataBatchJob");
			logger.info("job"+job);
			try {
				JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
				SimpleDateFormat datetimeFormat = new SimpleDateFormat(
						GlobalConstants.DATE_TIME_FORMAT);
				String timestamp = datetimeFormat.format(new Date());
				jobParametersBuilder.addString("currentDateTime", timestamp, true);
				JobParameters jobParameters = jobParametersBuilder.toJobParameters();
				logger.info("job"+jobParameters.getParameters());
				jobLauncher.run(job, jobParameters);

			} catch (Exception e) {
				e.printStackTrace();
				Map<String, String> splunkLogError = new HashMap<String, String>();
				splunkLogError.put("exception", e.getMessage());
				splunkLogError.put("job", job.getName());
				logger.error("BillDataScheduler  | run() | exception inside | BillDataScheduler : ", e);
				SplunkEventLogger.logEvent(SplunkEvent.JOB_LAUNCH_FAILURE, splunkLogError, logger);
			}
		} else {
			logger.info("BillDataScheduler | run() | context or JobLauncher instance not available");
		}
		if (logger.isDebugEnabled()) {
			logger.debug("BillDataScheduler  | run() | Exit from method : run ");
		}
	}



	public JobLauncher getJoLauncher() {
		return jobLauncher;
	}



	public void setJoLauncher(JobLauncher jobLauncher) {
		this.jobLauncher = jobLauncher;
	}
	
}
