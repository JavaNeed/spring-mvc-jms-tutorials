package com.mastercard.ess.eds.core.dao;

import static com.mastercard.ess.eds.constant.SQLConstants.CAT_CD;
import static com.mastercard.ess.eds.constant.SQLConstants.CLS_ISSR_CNTRY_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.CLS_MERCH_LOC_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.CPP_RULE_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.CRTE_DT;
import static com.mastercard.ess.eds.constant.SQLConstants.CRTE_USER_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.EDS_CPP_SIM_DATA;
import static com.mastercard.ess.eds.constant.SQLConstants.JOB_INSTANCE_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.PAN_CNT_NUM;
import static com.mastercard.ess.eds.constant.SQLConstants.SIM_DATA_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.SIM_SRC_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.UNIT_TM_CNT;
import static com.mastercard.ess.eds.constant.SQLConstants.VAL_ISSR_CNTRY_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.VAL_LOC_TRAN_AMT;
import static com.mastercard.ess.eds.constant.SQLConstants.VAL_MERCH_LOC_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.VAL_TM_CNT;
import static com.mastercard.ess.eds.constant.SQLConstants.VAL_1;


import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.mastercard.ess.eds.constant.SQLQueries;
import com.mastercard.ess.eds.domain.CPPRuleRecord;

/**
 *  This dao class has the CRUD operation for EDS_CPP_SIM_DATA table.
 * @author e070836
 * @version 1.0
 * @date : Dec 29, 2017
 */
@Component
public class CPPSimulationDataDAO {

	private static Logger logger = Logger.getLogger(CPPSimulationDataDAO.class);
	
	@Value("${cppsimulationdata.purge}")
	private String numberOfDays;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	private SimpleJdbcInsert simSourceDataInsert;

	@Autowired 
	private PlatformTransactionManager platformTransactionManager;

	public CPPSimulationDataDAO(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
		simSourceDataInsert = new SimpleJdbcInsert(dataSource).withTableName(
				EDS_CPP_SIM_DATA).usingColumns(SIM_DATA_ID, SIM_SRC_ID, CPP_RULE_ID, PAN_CNT_NUM, CRTE_USER_ID, CRTE_DT,JOB_INSTANCE_ID, VAL_1);
	}

	/**
	 * This method insert the records in EDS_CPP_SIM_DATA table.
	 * @param cppRuleId
	 * @param count
	 * @param jobInstanceName
	 * @param jobInstanceId
	 * @param simSrcId
	 * @return
	 */
	public void saveSimulationData(String merchantName,String cppRuleId, Integer count,
			String jobInstanceName, BigDecimal jobInstanceId, String simSrcId) {
	
		logger.info("Enter in method : saveSimulationData for simSrcId = "+simSrcId+" RuleId = "+cppRuleId+"with count = "+ count + " MerchantName = " +merchantName );

		DefaultTransactionDefinition paramTransactionDefinition = new    DefaultTransactionDefinition();
		TransactionStatus status=platformTransactionManager.getTransaction(paramTransactionDefinition );

		MapSqlParameterSource parameterSource = new MapSqlParameterSource();
		parameterSource.addValue(SIM_DATA_ID,  jdbcTemplate.queryForObject("select EDS_CPP_SIM_DATA_ID_SEQ.nextval from dual" , Integer.class))
		.addValue(SIM_SRC_ID, Integer.valueOf(simSrcId))
		.addValue(CPP_RULE_ID, Integer.valueOf(cppRuleId) )
		.addValue(PAN_CNT_NUM, count)
		.addValue(CRTE_USER_ID, jobInstanceName)
		.addValue(CRTE_DT, new Date())
		.addValue(JOB_INSTANCE_ID, jobInstanceId)
		.addValue(VAL_1, merchantName);

		try{
			simSourceDataInsert.execute(parameterSource);
			platformTransactionManager.commit(status);
		} catch(Exception e){
			logger.error("Exeception occured while inserting data in EDS_CPP_SIM_DATA",e);
			platformTransactionManager.rollback(status);
		}
		

	}
	
	/**
	 *  This method get the simulation record from EDS_CPP_SIM_DATA table.
	 * @param simSrcId 
	 * @return
	 */
	public List<CPPRuleRecord> fetchSimulationReport(String simSrcId){
		return jdbcTemplate.query(SQLQueries.FETCH_SIMULATION_DATA , new Object[]{simSrcId} ,  new RowMapper<CPPRuleRecord>(){

			@Override
			public CPPRuleRecord mapRow(ResultSet paramResultSet, int rownumber)
					throws SQLException {
				CPPRuleRecord cppRuleRecord = new CPPRuleRecord();
				cppRuleRecord.setClsIssrCntry(paramResultSet.getString(CLS_ISSR_CNTRY_ID));
				cppRuleRecord.setClsLocTranAmt(paramResultSet.getString(CLS_MERCH_LOC_ID));
				cppRuleRecord.setCppRuleId(paramResultSet.getBigDecimal(CPP_RULE_ID));
				cppRuleRecord.setUnitTmCount(paramResultSet.getString(UNIT_TM_CNT));
				cppRuleRecord.setValIssrCntry(paramResultSet.getString(VAL_ISSR_CNTRY_ID));
				cppRuleRecord.setValLocTranAmt(paramResultSet.getBigDecimal(VAL_LOC_TRAN_AMT));
				cppRuleRecord.setValMerchant(paramResultSet.getInt(VAL_MERCH_LOC_ID));
				cppRuleRecord.setValTmCount(paramResultSet.getInt(VAL_TM_CNT));
				cppRuleRecord.setCreateDate(paramResultSet.getDate(CRTE_DT));
				cppRuleRecord.setCreatedBy(paramResultSet.getString(CRTE_USER_ID));
				cppRuleRecord.setCatCD(paramResultSet.getString(CAT_CD));
				cppRuleRecord.setPanCount(paramResultSet.getInt(PAN_CNT_NUM));
				cppRuleRecord.setMerchantName(paramResultSet.getString(VAL_1));

				return cppRuleRecord;
			}
			
			
		});
		
	}

	/**
	 *  This method truncates the data from EDS_CP_SIM_DATA table based on the configurable parameter.
	 */
	public void truncateCPPSimulationData() {
		logger.info("Enter in method :truncateCPPSimulationData numberOfDays =  " +numberOfDays  );
		int rows = jdbcTemplate.update(SQLQueries.DELETE_CPP_SIM_DATA , numberOfDays);
		logger.info("Number of rows deleted = " + rows);
		
	}
	

}
