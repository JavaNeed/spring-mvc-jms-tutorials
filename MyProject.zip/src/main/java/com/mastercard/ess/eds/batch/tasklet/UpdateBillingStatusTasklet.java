package com.mastercard.ess.eds.batch.tasklet;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.batch.config.FileStatus;
import com.mastercard.ess.eds.batch.exception.EDSCoreException;
import com.mastercard.ess.eds.constant.BatchConstants;
import com.mastercard.ess.eds.core.service.LastBatchJobRunService;
import com.mastercard.ess.eds.domain.FileDetails;

/**
 *  This class logs the status of all files in the application logs with error details
 * @author e070836
 * @version 1.0
 * @date : Mar 13 2018
 *
 */
public class UpdateBillingStatusTasklet  implements Tasklet{

	private static Logger logger = Logger.getLogger(UpdateFileGenStatusTasklet.class);

	@Autowired
	private LastBatchJobRunService lastBatchJobRunService;
	

	private String jobInstanceName;
	private BigDecimal jobInstanceId;
	
	public String getJobInstanceName() {
		return jobInstanceName;
	}


	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}


	public BigDecimal getJobInstanceId() {
		return jobInstanceId;
	}


	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}

	/**
	 *  This method updates the last batch job date and prints the status of File and error details.
	 *   @param  arg0 , chunkContext
	 *  @return RepeatStatus 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext)
			throws Exception {

		logger.info("Enter into the UpdateFileExecutionStatus");
		boolean billJobSuccess = true ;
		lastBatchJobRunService.updateLastBatchJobRun(jobInstanceName);
		
		List<FileDetails> fileStatusList = (List<FileDetails>) chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get("fileStatusList");
		String billRunMode = (String) chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get("billRunMode");
		
		
		if(fileStatusList!= null && !fileStatusList.isEmpty()){
			logger.info("********************************************************* Billing File Status with date ="+ new Date());
			
			logger.info(String.format("%-60s %-20s %-20s %-10s %-10s "  , "File Name" , "File Generation" , "GFT Delivery" , "Error Code" , "Error Message"));
			
			billJobSuccess = logFileGenerationOutput(fileStatusList , billRunMode);
			
			logger.info("***************************************** Billing File Status Ends *********************************");
			
			if(!billJobSuccess){
				throw new EDSCoreException("Billing file Job Failed");
			}
		}

		logger.info("Exit from UpdateFileExecutionStatus");
		
		return RepeatStatus.FINISHED;
	}

 
	/**
	 *  It logs the file generation and GFT transfer status of the customer generation file in application logs.
	 * @param fileStatusList
	 * @param customerRunMode
	 * @return
	 */
	private boolean logFileGenerationOutput(List<FileDetails> fileStatusList , String billRunMode) {
		String fileGenerated = null ;
		String gft_Deilvery = null ;
		String fileName = null ;
		String errorMessage = null ;
		String errorCode = null ;
		boolean billSuccess = true ;
		
		for(FileDetails fileStatus : fileStatusList){
			
			fileGenerated = getFileGenerated(fileStatus , billRunMode) ;
			
			gft_Deilvery = getGFTDeilvery(fileStatus) ;
			
			fileName =   StringUtils.isNotBlank(fileStatus.getFileName()) ?  fileStatus.getFileName() : BatchConstants.NOT_AVAILABLE ;
			
			errorMessage = StringUtils.isNotBlank(fileStatus.getErrorDetails()) ?  fileStatus.getErrorDetails() : BatchConstants.NOT_APPLICABLE ;
			
			errorCode =  StringUtils.isNotBlank(fileStatus.getErrorCode()) ?  fileStatus.getErrorCode() : BatchConstants.NOT_APPLICABLE ;
			
			if(fileGenerated.equalsIgnoreCase(BatchConstants.FAILED) || gft_Deilvery.equalsIgnoreCase(BatchConstants.FAILED)){
				billSuccess = false ;
			}
			
			logger.info(String.format("%-60s %-20s %-20s %-10s %-10s" , fileName, fileGenerated , gft_Deilvery , errorCode ,errorMessage ));
		}
		
		return billSuccess ;
		
	}

	/**
	 * This method populates the file generation status either SUCCESS or FAILURE or NOT applicable based on run mode and ica file status.
	 * @param fileStatus
	 * @param customerRunMode
	 * @return
	 */
	private String getFileGenerated(FileDetails fileStatus , String billRunMode) {
		
		if(StringUtils.isNotBlank(billRunMode) && billRunMode.equalsIgnoreCase(BatchConstants.MODE_GFT_FAILURE)){
			return BatchConstants.NOT_APPLICABLE ;
		} else{
			return ( fileStatus.getStatus().equalsIgnoreCase(FileStatus.GEN_FAILURE.getStatus())) ? BatchConstants.FAILED :BatchConstants.SUCCESS;
		}
	}

	/**
	 * This method populates the GFT delivery status based on the icaStatus object.
	 * @param fileStatus
	 * @return
	 */
	private String getGFTDeilvery(FileDetails fileStatus) {
		
		String gftDeilvery = BatchConstants.SUCCESS ;
		if(StringUtils.isNotBlank(fileStatus.getStatus())){
			if(fileStatus.getStatus().equalsIgnoreCase(FileStatus.GEN_FAILURE.getStatus())){
				gftDeilvery = BatchConstants.NOT_APPLICABLE ;
			}else if (fileStatus.getStatus().equalsIgnoreCase(FileStatus.GFT_FAILURE.getStatus())){
				gftDeilvery =  BatchConstants.FAILED ;
			}
		}
		
		return gftDeilvery;
		 
	}

	public void setLastBatchJobRunService(LastBatchJobRunService lastBatchJobRunService) {
		this.lastBatchJobRunService = lastBatchJobRunService;
	} 

	 
	
}
