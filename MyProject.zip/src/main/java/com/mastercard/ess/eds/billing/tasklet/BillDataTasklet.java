package com.mastercard.ess.eds.billing.tasklet;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.billing.dao.BillDataDAO;

public class BillDataTasklet implements Tasklet {
    private static Logger logger = Logger.getLogger(BillDataTasklet.class);

    @Autowired
    private BillDataDAO billDataDao;

    // for junit
    public void setBillDataDao(BillDataDAO billDataDao) {
        this.billDataDao = billDataDao;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
        logger.info("Enter method : execute : BillDataTasklet ");

        List<Map<String, Object>> eligibleIcaList = billDataDao.getEligibleICAList();
        if (eligibleIcaList != null) {
            logger.info("Printing eligibleIcaList" + eligibleIcaList.size());
        }
        chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(
                "listOfEligibleIca", eligibleIcaList);

        logger.info("Exit method : execute : BillDataTasklet ");

        return RepeatStatus.FINISHED;
    }

}
