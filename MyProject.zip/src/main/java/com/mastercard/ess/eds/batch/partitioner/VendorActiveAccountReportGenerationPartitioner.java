package com.mastercard.ess.eds.batch.partitioner;

import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.service.EDSSourceTypeService;

public class VendorActiveAccountReportGenerationPartitioner implements Partitioner {

	@Autowired
	EDSSourceTypeService edsSourceTypeService;

	private Logger logger = Logger.getLogger(VendorActiveAccountReportGenerationPartitioner.class);
	
	//for junit
		public void setEdsSourceTypeService(
				EDSSourceTypeService edsSourceTypeService) {
	this.edsSourceTypeService =edsSourceTypeService;
		}

	@Override
	public Map<String, ExecutionContext> partition(int arg0) {

		int i = 0;
		List<String> vendorList = edsSourceTypeService.getVendorList();
		logger.info("Received vendor list size =" + vendorList.size());
		
		YearMonth prevMonth = YearMonth.now().minusMonths(1);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM-yyyy");
		
		Map<String, ExecutionContext> partitionMap = new HashMap<String, ExecutionContext>();
		for (String vendor : vendorList) {
			ExecutionContext ctxMap = new ExecutionContext();
			ctxMap.putString("vendor", vendor);
			ctxMap.putString("month" , prevMonth.format(formatter));
		
			logger.info("parition =" + i + ", vendor=" + vendor +", month = " + prevMonth.format(formatter));
			partitionMap.put("Thread -" + i, ctxMap);
			++i;
		}
		return partitionMap;
	}

}
