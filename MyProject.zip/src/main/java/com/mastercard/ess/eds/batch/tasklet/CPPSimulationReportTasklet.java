package com.mastercard.ess.eds.batch.tasklet;

import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.service.CPPSimulationService;
import com.mastercard.ess.eds.core.util.CPPSimulationReportGenerator;
import com.mastercard.ess.eds.domain.CPPRuleRecord;

/**
 *  This tasklet used to generate the simulation report.
 * @author e070836
 * @version 1.0
 * @date : Dec 29, 2017
 */

public class CPPSimulationReportTasklet implements Tasklet {

	private static Logger logger = Logger.getLogger(CPPSimulationReportTasklet.class);

	 
	@Autowired
	private CPPSimulationService cppSimulationService;
	
	@Autowired
	private CPPSimulationReportGenerator cppSimulationReportGenerator ;

	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext)
			throws Exception {

		logger.info("Enter in CPPSimulationReportTasklet execute method ");

		String jobInstanceName = chunkContext.getStepContext().getStepExecution().getJobExecution().getJobInstance().getJobName();
		BigDecimal jobInstanceId = BigDecimal.valueOf(chunkContext.getStepContext().getStepExecution().getJobExecution().getJobId());
		String simSrcId =  chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get("edsSimSrcId").toString();
		
		if(StringUtils.isNotBlank(simSrcId)){
		
			List<CPPRuleRecord> cppSimulationRecord = cppSimulationService.fetchSimulationResults(simSrcId);
		
			cppSimulationReportGenerator.generateSimulationReport(cppSimulationRecord ,jobInstanceId, jobInstanceName);
		} else{
			logger.error("Simulation Source ID is blank");
		}
		logger.info("Exit in CPPSimulationReportTasklet execute method ");

		return RepeatStatus.FINISHED;
	}

	public void setCppSimulationService(CPPSimulationService cppSimulationService) {
		this.cppSimulationService = cppSimulationService;
	}

	

	public void setCppSimulationReportGenerator(
			CPPSimulationReportGenerator cppSimulationReportGenerator) {
		this.cppSimulationReportGenerator = cppSimulationReportGenerator;
	}

}
