package com.mastercard.ess.eds.core.dao;

import static com.mastercard.ess.eds.constant.SQLConstants.CRTE_DT;
import static com.mastercard.ess.eds.constant.SQLConstants.CRTE_USER_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.EDS_SOURCE_DATA;
import static com.mastercard.ess.eds.constant.SQLConstants.EDS_SRC_DATA_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.EDS_SRC_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.JOB_INSTNCE_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.LST_UPDT_DT;
import static com.mastercard.ess.eds.constant.SQLConstants.LST_UPDT_USER_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.RAW_PAN;
import static com.mastercard.ess.eds.constant.SQLConstants.STAT_CD;

import java.math.BigDecimal;
import java.util.Date;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.mastercard.ess.eds.domain.AuthDebitPanDetailRecord;

@Component
public class EDSSourceDataDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;



	private static final Integer STATUS_CODE = 4;

	private static Logger logger = Logger.getLogger(EDSSourceDataDAO.class);

	private SimpleJdbcInsert sourceDataInsert;

	@Autowired 
	private PlatformTransactionManager platformTransactionManager;

	public EDSSourceDataDAO(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
		sourceDataInsert = new SimpleJdbcInsert(dataSource).withTableName(
				EDS_SOURCE_DATA).usingColumns(EDS_SRC_DATA_ID, EDS_SRC_ID, RAW_PAN, STAT_CD, CRTE_USER_ID, CRTE_DT,LST_UPDT_USER_ID,LST_UPDT_DT,JOB_INSTNCE_ID);
	}

	public Integer saveSourceData(AuthDebitPanDetailRecord authDebitPanDetailRecord, String jobInstanceName, String srcId, BigDecimal jobInstanceId) {


		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : saveSourceData for srcId="+srcId+" RuleId ="+authDebitPanDetailRecord.getCppRuleId()+" From DWSource ="+authDebitPanDetailRecord.getdWSource());
		}

		DefaultTransactionDefinition paramTransactionDefinition = new    DefaultTransactionDefinition();
		TransactionStatus status=platformTransactionManager.getTransaction(paramTransactionDefinition );
		String eds_src_data_id_seq = "select EDS_SRC_DATA_ID_SEQ.nextval from dual";
		int edsSrcDataId = jdbcTemplate.queryForObject(eds_src_data_id_seq, Integer.class);

		MapSqlParameterSource parameterSource = new MapSqlParameterSource();
		parameterSource.addValue(EDS_SRC_DATA_ID, edsSrcDataId)
		.addValue(EDS_SRC_ID, Integer.valueOf(srcId))
		.addValue(RAW_PAN, authDebitPanDetailRecord.getRawPan())
		.addValue(STAT_CD, STATUS_CODE)
		.addValue(CRTE_USER_ID, jobInstanceName)
		.addValue(CRTE_DT, new Date())
		.addValue(JOB_INSTNCE_ID, jobInstanceId);

		try{
			sourceDataInsert.execute(parameterSource);
			platformTransactionManager.commit(status);
		} catch(Exception e){
			platformTransactionManager.rollback(status);
			logger.error(e);
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : saveSourceData ");
		}
		return edsSrcDataId;

	}

}
