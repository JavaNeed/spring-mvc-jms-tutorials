package com.mastercard.ess.eds.core.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.mastercard.ess.eds.domain.CPPRecord;

public class CPPAccountsViewRowMapper implements RowMapper<CPPRecord> {

	private static Logger logger = Logger.getLogger(CPPAccountsViewRowMapper.class);

	@Override
	public CPPRecord mapRow(ResultSet paramResultSet, int paramInt) throws SQLException {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : mapRow | CPPAccountsViewRowMapper ");
		}

		CPPRecord cppRecord = new CPPRecord();
		cppRecord.setPan(paramResultSet.getBigDecimal("PAN_NUM"));
		cppRecord.setCreateDate(paramResultSet.getDate("CRTE_DT"));

		
		return cppRecord;
	}

}
