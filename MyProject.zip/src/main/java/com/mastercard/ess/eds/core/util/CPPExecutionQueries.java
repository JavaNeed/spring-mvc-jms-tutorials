package com.mastercard.ess.eds.core.util;

import org.apache.log4j.Logger;

import com.mastercard.ess.eds.domain.CPPRuleRecord;
/** It will create queries for Auth and Debit related queries .
 * And these queries will be created dynamically accrding to values in EDSCPPRule.
 * */
public class CPPExecutionQueries {

	private static final int FISRSTRUNDAYCNT = 90;
	private static final String ALL = "all";
	private static Logger logger = Logger.getLogger(CPPExecutionQueries.class);
	private static final String NOTEQUALS = "notequals";
	private static final String EQUALS = "equals";
	private static final String OTHER = "other";
	private static final String ONEOF = "oneof";
	private static final String MONTHS = "months";
	private static final String WEEKS = "weeks";
	private static final String DAYS = "days";
	private static final String N = "N";
	private static final String Y = "Y";
	private static final String AUTH_RECORD_BY_CPP_RULE="SELECT DISTINCT CASE WHEN AUTH_ENC.ENCRYPT_VRTL_PAN_DE048S33F02 IS NULL THEN AUTH_ENC.ENCRYPT_PAN_DE002 ELSE AUTH_ENC.ENCRYPT_VRTL_PAN_DE048S33F02 END AS PAN , A01.CRD_ACCPT_NAME_LOC_DE043 as MERCH_NAM FROM AUTHOP01_DETAIL A01 INNER JOIN AUTHOP01_DETAIL_ENC AUTH_ENC ON (A01.DW_AUTHOP_SEQ_NBR = AUTH_ENC.DW_AUTHOP_SEQ_NBR AND A01.DW_PROCESS_DATE = AUTH_ENC.DW_PROCESS_DATE) INNER JOIN CURRENCY_CODE_HIERARCHY CURRENCY_CODE_HIERARCHY ON (A01.TXN_CURR_CODE_DE049 = CURRENCY_CODE_HIERARCHY.CURRENCY_CODE) ";
	private static final String DEBIT_RECORD_BY_CPP_RULE="SELECT DISTINCT CASE WHEN TRIM (DEBIT_ENC.ENCRYPT_PAYPASS_ACCT_NUM) IS NULL THEN DEBIT_ENC.ENCRYPT_RQST_ACCT_NUM_DE002 ELSE DEBIT_ENC.ENCRYPT_PAYPASS_ACCT_NUM END AS PAN , B01.DW_DERIVED_MERCH_ID AS MERCH_NAM, B01.RQST_ACCT_LEN_NUM AS PAN_LENGTH FROM DEBITMDS01_DETAIL B01 INNER JOIN DEBITMDS01_DETAIL_ENC DEBIT_ENC ON (B01.DW_DB_MDS_SEQ_NUM = DEBIT_ENC.DW_DB_MDS_SEQ_NUM AND B01.DW_PRCSS_DT = DEBIT_ENC.DW_PRCSS_DT) INNER JOIN CURRENCY_CODE_HIERARCHY CURRENCY_CODE_HIERARCHY ON (B01.MCS_LOC_CURR_CD = CURRENCY_CODE_HIERARCHY.CURRENCY_CODE)";


	/*Method will create Auth query by rule */
	public static StringBuffer getAuthStrQueryByRule(CPPRuleRecord cPPRuleRecord, String runCppRuleForDays,String chTranxactionType ) {


		StringBuffer strAuthForByRuleQuery = new StringBuffer(AUTH_RECORD_BY_CPP_RULE);

		strAuthForByRuleQuery =strAuthForByRuleQuery.append("AND A01.CH_TXN_TYPE_DE003S01 NOT IN(").append(chTranxactionType).append(" )and A01.LOCATION_ID = "+cPPRuleRecord.getValMerchant());

		buildAuthQueryBasedOnLocatnAndIssrCntryCode(cPPRuleRecord,
				strAuthForByRuleQuery);

		buildAuthQueryBasedOnProcessDate(cPPRuleRecord, runCppRuleForDays,
				strAuthForByRuleQuery);

		if (logger.isDebugEnabled()) {
			logger.debug("CPP_EXEC QUERY = " + strAuthForByRuleQuery);
		}
		return strAuthForByRuleQuery;
	}

	/**
	 * @param cPPRuleRecord :Depending on the cppRuleRecord we will build Auth Query on basis of UnitTmCount and ValTmCount.
	 * @param runCppRuleForDays :Fetching value of runCppRulesForDays value from property file when FirstRunSW switch is "N"
	 * @param strAuthForByRuleQuery:Auth query will be set to strAuthForByRuleQuery.  
	 *  
	 */
	public static String buildAuthQueryBasedOnProcessDate(CPPRuleRecord cPPRuleRecord, String runCppRuleForDays,StringBuffer strAuthForByRuleQuery) {
		return strAuthForByRuleQuery.append(" and A01.DW_PROCESS_DATE > SYSDATE - ?").toString();
	}

	/**
	 * 
	 * @param cPPRuleRecord
	 * @param runCppRuleForDays
	 * @return
	 */
	public static Integer getAuthDaysOnBasisOfPrcssDate(CPPRuleRecord cPPRuleRecord, String runCppRuleForDays) {
		if (N.equalsIgnoreCase(cPPRuleRecord.getFirstRunSW())) {
			return 	Integer.valueOf( runCppRuleForDays);
		} 
		else if (Y.equalsIgnoreCase(cPPRuleRecord.getFirstRunSW())){
			if (DAYS.equalsIgnoreCase(cPPRuleRecord.getUnitTmCount())) {
				return getDaysForAuthFirstRunYDays(cPPRuleRecord,runCppRuleForDays);
			}
			if(WEEKS.equalsIgnoreCase(cPPRuleRecord.getUnitTmCount()))
			{
				return getDaysForAuthFirstRunYWeeks(cPPRuleRecord, runCppRuleForDays);
			}
			if(MONTHS.equalsIgnoreCase(cPPRuleRecord.getUnitTmCount()))
			{
				return getDaysForAuthFirstRunYMonths(cPPRuleRecord, runCppRuleForDays);
			}
		}
		return null;
	}

	/**
	 * 
	 * @param cPPRuleRecord
	 * @param strAuthForByRuleQuery
	 * @return
	 */
	private static Integer getDaysForAuthFirstRunYDays(CPPRuleRecord cPPRuleRecord, String strAuthForByRuleQuery) {
		int days = 0;
		if ((DAYS.equalsIgnoreCase(cPPRuleRecord.getUnitTmCount())) && (cPPRuleRecord.getValTmCount()<=FISRSTRUNDAYCNT)) {
			days= cPPRuleRecord.getValTmCount();
		} else if ((DAYS.equalsIgnoreCase(cPPRuleRecord.getUnitTmCount()))&& (cPPRuleRecord.getValTmCount()>FISRSTRUNDAYCNT)) {
			days= FISRSTRUNDAYCNT;
		}
		return days;
	}

	/**
	 * 
	 * @param cPPRuleRecord
	 * @param strAuthForByRuleQuery
	 * @return
	 */
	private static Integer getDaysForAuthFirstRunYWeeks(CPPRuleRecord cPPRuleRecord, String strAuthForByRuleQuery) {
		if ((WEEKS.equalsIgnoreCase(cPPRuleRecord.getUnitTmCount()))&& ((7*cPPRuleRecord.getValTmCount())<=FISRSTRUNDAYCNT)) {
			return (7 * cPPRuleRecord.getValTmCount());
		} else if ((WEEKS.equalsIgnoreCase(cPPRuleRecord.getUnitTmCount()))&& ((7*cPPRuleRecord.getValTmCount())>FISRSTRUNDAYCNT)) {
			return FISRSTRUNDAYCNT;
		}
		return null;
	}

	/**
	 * 
	 * @param cPPRuleRecord
	 * @param strAuthForByRuleQuery
	 * @return
	 */
	private static Integer getDaysForAuthFirstRunYMonths(CPPRuleRecord cPPRuleRecord, String strAuthForByRuleQuery) {
		if ((MONTHS.equalsIgnoreCase(cPPRuleRecord.getUnitTmCount()))&& ((30*cPPRuleRecord.getValTmCount())<=FISRSTRUNDAYCNT)) {
			return 30 * cPPRuleRecord.getValTmCount();
		} else if ((MONTHS.equalsIgnoreCase(cPPRuleRecord.getUnitTmCount()))&& ((30*cPPRuleRecord.getValTmCount())>FISRSTRUNDAYCNT)) {
			return FISRSTRUNDAYCNT;
		}
		return null;
	}
	/**
	 * @param cPPRuleRecord :Depending on the cppRuleRecord we will build Auth Query on basis of Location IssrCntryCode
	 * @param strAuthForByRuleQuery:Auth query will be set to strAuthForByRuleQuery.  
	 */
	private static void buildAuthQueryBasedOnLocatnAndIssrCntryCode(CPPRuleRecord cPPRuleRecord, StringBuffer strAuthForByRuleQuery) {
		if (EQUALS.equalsIgnoreCase(cPPRuleRecord.getClsLocTranAmt())) {
			strAuthForByRuleQuery.append(" and "+cPPRuleRecord.getValLocTranAmt()+" = CAST (A01.TXN_AMT_DE004 AS NUMERIC (17, 3)) / (SELECT POWER (10, (SELECT COALESCE (CURRENCY_CODE_HIERARCHY.CURRENCY_EXPONENT_NUMBER, 2) FROM DUAL)) FROM DUAL)");

		} else if (NOTEQUALS.equalsIgnoreCase(cPPRuleRecord.getClsLocTranAmt())) {
			strAuthForByRuleQuery.append(" and "+cPPRuleRecord.getValLocTranAmt()+" <> CAST (A01.TXN_AMT_DE004 AS NUMERIC (17, 3)) / (SELECT POWER (10, (SELECT COALESCE (CURRENCY_CODE_HIERARCHY.CURRENCY_EXPONENT_NUMBER, 2) FROM DUAL)) FROM DUAL)");
		}
		buildAuthQueryBasedOnIssrCntryCode(cPPRuleRecord, strAuthForByRuleQuery);
	}

	/**
	 * 
	 * @param cPPRuleRecord
	 * @param strAuthForByRuleQuery
	 */
	private static void buildAuthQueryBasedOnIssrCntryCode(	CPPRuleRecord cPPRuleRecord, StringBuffer strAuthForByRuleQuery) {
		if (EQUALS.equalsIgnoreCase(cPPRuleRecord.getClsIssrCntry())) {
			strAuthForByRuleQuery.append(" and A01.DW_ISS_CNTRY_CODE = '"+cPPRuleRecord.getValIssrCntry()).append("'");
		} else if(NOTEQUALS.equalsIgnoreCase(cPPRuleRecord.getClsIssrCntry())){
			strAuthForByRuleQuery.append(" and A01.DW_ISS_CNTRY_CODE <> '"+cPPRuleRecord.getValIssrCntry()).append("'");

		} else if(OTHER.equalsIgnoreCase(cPPRuleRecord.getClsIssrCntry()) && null!=cPPRuleRecord.getValIssrCntry() && ! ALL.equalsIgnoreCase(cPPRuleRecord.getValIssrCntry())){
			strAuthForByRuleQuery.append(" and A01.DW_ISS_CNTRY_CODE not in('"+cPPRuleRecord.getValIssrCntry()).append("')");

		} else if(ONEOF.equalsIgnoreCase(cPPRuleRecord.getClsIssrCntry()) && null!=cPPRuleRecord.getValIssrCntry() && ! ALL.equalsIgnoreCase(cPPRuleRecord.getValIssrCntry())){
			strAuthForByRuleQuery.append(" and A01.DW_ISS_CNTRY_CODE in ('"+cPPRuleRecord.getValIssrCntry()).append("')");
		}
	}


	/**
	 * Method will create debit query by rule
	 * @param cPPRuleRecord
	 * @param runCppRuleForDays
	 * @param chTranxactionType
	 * @return
	 */
	public static StringBuffer getDebitStrQueryByRule(CPPRuleRecord cPPRuleRecord,String runCppRuleForDays,String chTranxactionType ) {
		if (logger.isDebugEnabled()) {
			logger.debug("Entering method getDebitStrQueryByRule");
		}
		StringBuffer  strDebitCPPByRuleQuery= new StringBuffer(DEBIT_RECORD_BY_CPP_RULE);

		strDebitCPPByRuleQuery = strDebitCPPByRuleQuery.append( " AND B01.CRDHLDR_TRAN_TYPE_DE003S01 not in (").append(chTranxactionType).append(" ) and B01.DW_LOCATION_ID = "+cPPRuleRecord.getValMerchant());

		buildDebitQueryBasedOnLocatnAndIssrCntryCode(cPPRuleRecord,	strDebitCPPByRuleQuery);

		buildDebitQueryBasedOnProcessDate(cPPRuleRecord, runCppRuleForDays,	strDebitCPPByRuleQuery);

		if (logger.isDebugEnabled()) {
			logger.debug("CPP_EXEC QUERY = " + strDebitCPPByRuleQuery);
		}
		return strDebitCPPByRuleQuery;
	}

	/**
	 * @param cPPRuleRecord :Depending on the cppRuleRecord we will build Auth Query on basis of UnitTmCount and ValTmCount.
	 * @param runCppRuleForDays :Fetching value of runCppRulesForDays value from property file when FirstRunSW switch is "N"
	 * @param strDebitCPPByRuleQuery: Debit query will be set to strDebitCPPByRuleQuery.  
	 *  
	 */
	public static void buildDebitQueryBasedOnProcessDate(CPPRuleRecord cPPRuleRecord, String runCppRuleForDays,StringBuffer strDebitCPPByRuleQuery) {

		strDebitCPPByRuleQuery.append(" and B01.DW_PRCSS_DT > SYSDATE - ? ");
	}

	/**
	 * 
	 * @param cPPRuleRecord
	 * @param runCppRuleForDays
	 * @return
	 */
	public static Integer getDebitDaysOnBasisOfPrcssDate(CPPRuleRecord cPPRuleRecord, String runCppRuleForDays) {
		if (N.equalsIgnoreCase(cPPRuleRecord.getFirstRunSW())) {
			return Integer.valueOf( runCppRuleForDays);	
		}   else if (Y.equalsIgnoreCase(cPPRuleRecord.getFirstRunSW())) {
			if (DAYS.equalsIgnoreCase(cPPRuleRecord.getUnitTmCount())) {
				return getDaysForDebitFirstRunYDays(cPPRuleRecord);
			}
			if(WEEKS.equalsIgnoreCase(cPPRuleRecord.getUnitTmCount())){
				return getDaysForDebitFirstRunYWeeks( cPPRuleRecord);
			}
			if(MONTHS.equalsIgnoreCase(cPPRuleRecord.getUnitTmCount())){
				return getDaysForDebitFirstRunYMonths( cPPRuleRecord);
			}
		}
		return null;
	}


	/**
	 * 
	 * @param cPPRuleRecord
	 * @return
	 */
	private static Integer getDaysForDebitFirstRunYDays( CPPRuleRecord cPPRuleRecord ) {
		if ((DAYS.equalsIgnoreCase(cPPRuleRecord.getUnitTmCount())) && (cPPRuleRecord.getValTmCount()<=FISRSTRUNDAYCNT)) {
			return cPPRuleRecord.getValTmCount();
		} else if ((DAYS.equalsIgnoreCase(cPPRuleRecord.getUnitTmCount()))&& (cPPRuleRecord.getValTmCount()>FISRSTRUNDAYCNT)) {
			return FISRSTRUNDAYCNT;
		}
		return null;
	}


	/**
	 * 
	 * @param cPPRuleRecord
	 * @return
	 */
	private static Integer getDaysForDebitFirstRunYWeeks( CPPRuleRecord cPPRuleRecord) {
		if ((WEEKS.equalsIgnoreCase(cPPRuleRecord.getUnitTmCount()))&& ((7*cPPRuleRecord.getValTmCount())<=FISRSTRUNDAYCNT)) {
			return 7 * cPPRuleRecord.getValTmCount();
		} else if ((WEEKS.equalsIgnoreCase(cPPRuleRecord.getUnitTmCount()))&& ((7*cPPRuleRecord.getValTmCount())>FISRSTRUNDAYCNT)) {
			return FISRSTRUNDAYCNT;
		}
		return null;
	}


	/**
	 * 
	 * @param cPPRuleRecord
	 * @return
	 */
	private static Integer getDaysForDebitFirstRunYMonths( CPPRuleRecord cPPRuleRecord) {
		if ((MONTHS.equalsIgnoreCase(cPPRuleRecord.getUnitTmCount()))&& ((30*cPPRuleRecord.getValTmCount())<=FISRSTRUNDAYCNT)) {
			return 30 * cPPRuleRecord.getValTmCount();
		} else if ((MONTHS.equalsIgnoreCase(cPPRuleRecord.getUnitTmCount()))&& ((30*cPPRuleRecord.getValTmCount())>FISRSTRUNDAYCNT)) {
			return FISRSTRUNDAYCNT;
		}
		return null;
	}

	/**
	 * @param cPPRuleRecord :Depending on the cppRuleRecord we will build Debit Query on basis of Location IssrCntryCode
	 * @param strDebitCPPByRuleQuery: Debit query will be set to strDebitCPPByRuleQuery.  
	 */
	private static void buildDebitQueryBasedOnLocatnAndIssrCntryCode(CPPRuleRecord cPPRuleRecord, StringBuffer strDebitCPPByRuleQuery) {
		if (EQUALS.equalsIgnoreCase(cPPRuleRecord.getClsLocTranAmt())) {
			strDebitCPPByRuleQuery.append(" and "+cPPRuleRecord.getValLocTranAmt()+" = CAST (B01.MCS_LOC_RQST_AMT AS NUMERIC (17, 3)) / (SELECT POWER (10, (SELECT COALESCE (CURRENCY_CODE_HIERARCHY.CURRENCY_EXPONENT_NUMBER, 2) FROM DUAL)) FROM DUAL)");
		} else if (NOTEQUALS.equalsIgnoreCase(cPPRuleRecord.getClsLocTranAmt())) {
			strDebitCPPByRuleQuery.append(" and "+cPPRuleRecord.getValLocTranAmt()+" <> CAST (B01.MCS_LOC_RQST_AMT AS NUMERIC (17, 3)) / (SELECT POWER (10, (SELECT COALESCE (CURRENCY_CODE_HIERARCHY.CURRENCY_EXPONENT_NUMBER, 2) FROM DUAL)) FROM DUAL)");
		}
		buildDebitQueryBasedOnIssrCntryCode(cPPRuleRecord,strDebitCPPByRuleQuery);
	}

	private static void buildDebitQueryBasedOnIssrCntryCode(
			CPPRuleRecord cPPRuleRecord, StringBuffer strDebitCPPByRuleQuery) {
		if (EQUALS.equalsIgnoreCase(cPPRuleRecord.getClsIssrCntry())) {
			strDebitCPPByRuleQuery.append(" and B01.DW_ISSR_CNTRY_CD = '"+cPPRuleRecord.getValIssrCntry()).append("'");
		} else if(NOTEQUALS.equalsIgnoreCase(cPPRuleRecord.getClsIssrCntry())){
			strDebitCPPByRuleQuery.append(" and B01.DW_ISSR_CNTRY_CD <> '"+cPPRuleRecord.getValIssrCntry()).append("'");

		} else  if(OTHER.equalsIgnoreCase(cPPRuleRecord.getClsIssrCntry()) && null !=cPPRuleRecord.getValIssrCntry() && ! ALL.equalsIgnoreCase(cPPRuleRecord.getValIssrCntry())){
			strDebitCPPByRuleQuery.append(" and B01.DW_ISSR_CNTRY_CD not in('"+cPPRuleRecord.getValIssrCntry()).append("')");

		} else if(ONEOF.equalsIgnoreCase(cPPRuleRecord.getClsIssrCntry()) && null !=cPPRuleRecord.getValIssrCntry() && ! ALL.equalsIgnoreCase(cPPRuleRecord.getValIssrCntry())){
			strDebitCPPByRuleQuery.append(" and B01.DW_ISSR_CNTRY_CD in('"+cPPRuleRecord.getValIssrCntry()).append("')");
		}
	}

}

