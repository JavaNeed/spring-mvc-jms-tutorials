package com.mastercard.ess.eds.core.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.mastercard.ess.eds.common.SplunkEvent;
import com.mastercard.ess.eds.common.SplunkEventLogger;

/**
 * Scheduler for Pan Unavailability Notification Job
 *  
 * @author e056479
 *
 */

public class PanUnavailabilityNotificationScheduler {

	@Autowired
	ApplicationContext context;

	@Autowired
	private JobLauncher jobLauncher;

	private Job job;
	
	private Logger logger = Logger.getLogger(PanUnavailabilityNotificationScheduler.class);

	public void run() {


		job = (Job) context.getBean("panUnavailableNotificationJob");
		try {
			JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
			SimpleDateFormat datetimeFormat = new SimpleDateFormat(GlobalConstants.DATE_TIME_FORMAT);
			String timestamp = datetimeFormat.format(new Date());
			jobParametersBuilder.addString("currentDateTime", timestamp);
			JobParameters jobParameters = jobParametersBuilder.toJobParameters();
			jobLauncher.run(job, jobParameters);
			logger.info("launching panUnavailableNotificationJob ");
		} catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException
				| JobParametersInvalidException e) {
			splunkLogger(e);
		}


	}
	
	private void splunkLogger(Exception e) {
		Map<String, String> splunkLogError = new HashMap<>();
		splunkLogError.put("exception", e.getMessage());
		splunkLogError.put("job", job.getName());
		SplunkEventLogger.logEvent(SplunkEvent.JOB_LAUNCH_FAILURE, splunkLogError, logger);
		logger.error("Error occurred in launching customerFileGenerationJob " + e);
	}
	public Job getJob() {
		return job;
	}
	public void setJob(Job job) {
		this.job = job;
	}
	public ApplicationContext getContext() {
		return context;
	}
	// For Junit
	public void setContext(ApplicationContext context) {
		this.context = context;		
	}
// For Junit
	public void setJoLauncher(JobLauncher jobLauncher) {
		this.jobLauncher = jobLauncher;		
	}
}
