package com.mastercard.ess.eds.core.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.mastercard.ess.eds.core.parser.VendorPayloadTokens;
import com.mastercard.ess.eds.domain.RawRecord;

/**
 * Maps columns from EDS_SOURCE_DATA table to fields in RawRecord domain object. Required by reader while
 * parsing data and returning a populated object.
 * @author e067588
 *
 */
public class RawRecordRowMapper implements RowMapper<RawRecord> {
	
	private static Logger logger = Logger.getLogger(RawRecordRowMapper.class);

	/* (non-Javadoc)
	 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
	 */
	@Override
	public RawRecord mapRow(ResultSet paramResultSet, int paramInt) throws SQLException {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : mapRow ");
		}
		Map<String, String> payloadData = new HashMap<>();
		payloadData.put(VendorPayloadTokens.CWID.getDesc(), paramResultSet.getString("ARTIFACT_ID"));
		payloadData.put(VendorPayloadTokens.URL.getDesc(), paramResultSet.getString("URL_ADDR"));
		payloadData.put(VendorPayloadTokens.RAW_DATA.getDesc(), paramResultSet.getString("RAW_DATA_TXT"));
		
		RawRecord rawRecord = new RawRecord(payloadData);
		
		rawRecord.setErrorDetails(paramResultSet.getString("ERR_DTL_DESC"));
		rawRecord.setLastUpdateDate(paramResultSet.getDate("LST_UPDT_DT"));
		rawRecord.setLastUpdatedBy(paramResultSet.getString("LST_UPDT_USER_ID"));
		rawRecord.setLineNumber(paramResultSet.getInt("LINE_NUM"));
		rawRecord.setRawPan(paramResultSet.getString("RAW_PAN_NUM"));
		rawRecord.setSrc_ky(paramResultSet.getBigDecimal("EDS_SRC_ID"));
		rawRecord.setSrc_data_ky(paramResultSet.getBigDecimal("EDS_SRC_DATA_ID"));
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : mapRow ");
		}
		
		return rawRecord;
	}

}
