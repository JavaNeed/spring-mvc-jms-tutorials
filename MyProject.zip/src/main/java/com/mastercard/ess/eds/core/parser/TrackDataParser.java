package com.mastercard.ess.eds.core.parser;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.crypto.SecretKey;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.batch.item.file.transform.FieldSet;

import com.mastercard.ess.eds.domain.RawRecord;

/**
 * Class to parse and decrypt track data.
 * @author E075766
 */
public class TrackDataParser implements EDSParser {

	private static final String Y = "Y";
	private static final String TRACK2 = "Track2";
	private static final String TRACK1 = "Track1";
	private static final String EQUAL = "=";
	private static final String CARET = "^";
	private static final String LETTER_D = "D";

	private static Logger logger = Logger.getLogger(TrackDataParser.class);

	/**Method to decrypt the encrypted fieldSet values and bind rawpan and rawData to RawRecord Object.
	 * @param fieldSet        : fieldSet object containing the tokenized values
	 * @param key             : key used to decrypt the encrypted value          
	 * @param transform       : The algorithm for decryption
	 * @param fieldsToDecrypt : string which contains comma separated fields to be decrypted	
	 * @return RawRecord      : It will set rawPan values and payload map to rawrecord and will return that rawRecord object
	 */
	@Override
	public RawRecord parseAndDecrypt(FieldSet fieldSet, SecretKey key, String transform, String fieldsToDecrypt) throws Exception {
		logger.info("Enter TrackDataParser | parseAndDecrypt()");
		RawRecord rawRecord = new RawRecord(new HashMap<String, String>());		
		Map<String,String> decryptedData = ParserUtil.decryptValues(fieldSet, key, transform, fieldsToDecrypt);
		String decryptedText = decryptedData.get(VendorPayloadTokens.VALUE.getDesc());

		if (decryptedText != null && (decryptedText.contains( CARET ) && (!decryptedText.contains( EQUAL ))) && decryptedText.length()<=79) {
			return 	parseTrack1Data(decryptedText, rawRecord);
		} else if(decryptedText != null && ((decryptedText.contains( EQUAL ) || decryptedText.contains("D")))){
			if ((!decryptedText.contains( CARET )) && decryptedText.length()<=40) {
				return parseTrack2Data(decryptedText, rawRecord);
			}
		}
		else {
			logger.info("Invalid Track Data ");
			return null;
		}
		return rawRecord;
	}

	/**
	 * Method to parse Track1 data and bind it to RawRecord
	 * @param decryptedText:Contains decrypted text for track  data which should contain "^" as separator.
	 * @param rawRecord :Rawrecord to which we will set rawPan and PayloadKey fields.
	 * @return RawRecord :It will set rawPan values and payload map to rawrecord and will return that rawRecord object
	 * @throws IOException 
	 */
	public RawRecord parseTrack1Data(String decryptedText, RawRecord rawRecord) throws IOException{
		logger.info("Enter TrackDataParser | parseTrack1Data()");

		String[] data = null ;
		if (null != decryptedText) {
			data = decryptedText.split("\\" + CARET);

			Map<String, String> rawDataTxtMap = new LinkedHashMap<>();

			if (null != data) {
				/* data[0] contains RawPan
				 * If data contains B as first letter we will ignore it else we will store data[0] as rawPan.
				 */
				if ( data.length >= 1 && null != data[0] && !data[0].isEmpty() && data[0].charAt(0) == 'B') {
					rawRecord.setRawPan(data[0].substring(1, data[0].length()));
				} else if (data.length >= 1) {
					rawRecord.setRawPan(data[0]);
				}
				rawRecord.addPayloadEntry(VendorPayloadTokens.CWID.getDesc(),
						TRACK1);
				parseTrack1DataForCardHolderName(data, rawDataTxtMap);
				parseTrack1DataForExpDate(data, rawDataTxtMap);
				parseTrack1DataForServiceCd(data, rawDataTxtMap);
			}

			try {
				rawRecord.addPayloadEntry(VendorPayloadTokens.RAW_DATA.getDesc() , new ObjectMapper().writeValueAsString(rawDataTxtMap));
			} catch (IOException e) {
				logger.error("Exception in TrackDataParser | mapRawData() : ", e);		
				throw new IOException(e.getMessage());
			}
		}
		return rawRecord;
	}

	/*Method to parse track1 data for CardHolder Name*/
	private void parseTrack1DataForCardHolderName(String[] data,
			Map<String, String> rawDataTxtMap) {
		if ( data.length > 1 && null != data[1] && !data[1].isEmpty()) {
			rawDataTxtMap.put(VendorPayloadTokens.NAME.getDesc(), Y);
		}
	}

	/*Method to parse track1 data for expiry date*/
	private void parseTrack1DataForExpDate(String[] data, Map<String, String> rawDataTxtMap) {
		/*data[2] contains ExpirayDate and ExtServiceCode*/
		if ( (3 <= data.length) && (null != data[2]) && (data[2].length() >= 4) && (NumberUtils.isNumber(data[2].substring(0, 4)))) {
			rawDataTxtMap.put(VendorPayloadTokens.EXP_DT.getDesc(),	Y);					
		}
	}

	/*Method to parse track1 data for external service code*/
	private void parseTrack1DataForServiceCd(String[] data, Map<String, String> rawDataTxtMap) {
		/*data[2] contains ExpirayDate and ExtServiceCode*/
		if ( (3 <= data.length) && (null != data[2]) && (data[2].length() >= 7) && (NumberUtils.isNumber(data[2].substring(4, 7)))) {
			rawDataTxtMap.put( VendorPayloadTokens.EXT_SERVICE_CODE.getDesc(),Y);
		} else if ( (data.length >= 7) && ( data[2].isEmpty()) &&  (!data[6].isEmpty()) && (NumberUtils.isNumber(data[6]))) {
			rawDataTxtMap.put(VendorPayloadTokens.EXT_SERVICE_CODE.getDesc(),Y);
		}
	}

	/**
	 * Method to parse Track2 data and bind it to RawRecord
	 * @param decryptedText:Contains decrypted text for track  data which should contain "=" or "D" as separator.
	 * @param rawRecord :Rawrecord to which we will set rawPan and PayloadKey fields.
	 * @return RawRecord :It will set rawPan values and payload map to rawRecord and will return that rawRecord object
	 * @throws IOException 
	 */
	public RawRecord parseTrack2Data(String decryptedText,RawRecord rawRecord) throws IOException {
		logger.info("Enter TrackDataParser | parseTrack2Data()");
		String[] data = null;
		Map<String, String> rawDataTxtMap = new LinkedHashMap<>();
		if (!decryptedText.isEmpty() && decryptedText.contains( EQUAL )) {
			data = decryptedText.split(EQUAL);
		} else {
			data = decryptedText.split( LETTER_D );
		}

		if (null != data) {
			/*data[0] contains RawPan*/
			if (ArrayUtils.isNotEmpty(data) && data.length > 0) {
				rawRecord.setRawPan(data[0]);
			}
			rawRecord.addPayloadEntry(VendorPayloadTokens.CWID.getDesc(),
					TRACK2);
			/*data[1] contains ExpirayDate and ExtServiceCode*/
			if ( (1 <= data.length) && (null != data[1]) && (data[1].length() >= 4) && (NumberUtils.isNumber(data[1].substring(0, 4)))) {
				rawDataTxtMap.put(VendorPayloadTokens.EXP_DT.getDesc(), Y);
			}
			parseTrack2DataForRawData(data, rawDataTxtMap);
		}
		try {
			rawRecord.addPayloadEntry(VendorPayloadTokens.RAW_DATA.getDesc() , new ObjectMapper().writeValueAsString(rawDataTxtMap));
		} catch (IOException e) {
			logger.error("Exception in TrackDataParser | mapRawData() : ", e);		
			throw new IOException(e.getMessage());
		}
		return rawRecord;
	}

	/*Method to parse external service code for track2 data*/
	private void parseTrack2DataForRawData(String[] data,
			Map<String, String> rawDataTxtMap) {
		if ( 2 <= data.length && null != data[1] && data[1].length() >= 7 && NumberUtils.isNumber(data[1].substring(4, 7))) {
			rawDataTxtMap.put(VendorPayloadTokens.EXT_SERVICE_CODE.getDesc(), Y);
			//If data length is greater than 6 and data[5] is empty
		} else if ( data.length >= 6 && (data[1].isEmpty()) && (!data[5].isEmpty()) && (NumberUtils.isNumber(data[5]))) {
			rawDataTxtMap.put(VendorPayloadTokens.EXT_SERVICE_CODE.getDesc(), Y);
		}
	}

}
