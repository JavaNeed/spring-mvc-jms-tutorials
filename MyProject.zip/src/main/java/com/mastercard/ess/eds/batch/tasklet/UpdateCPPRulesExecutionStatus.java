package com.mastercard.ess.eds.batch.tasklet;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.mastercard.ess.eds.constant.BatchConstants;
import com.mastercard.ess.eds.core.service.CPPSimulationService;
import com.mastercard.ess.eds.core.service.EDSCPPRulesService;
import com.mastercard.ess.eds.core.util.EDSProcessStatus;

public class UpdateCPPRulesExecutionStatus implements Tasklet{
	private static Logger logger = Logger.getLogger(UpdateCPPRulesExecutionStatus.class);

	@Value("#{jobParameters['cppSrcName']}")
	public String cppSrcName;
	
	
	private int status;
	private String jobInstanceName;
	private static final String FAILED_CPP_RULE_IDS = "failedCPPRuleIds";

	@Value("#{jobParameters['edsSrcId']}")
	private String edsSrcId;

	private ExecutionContext executionContext;
	private BigDecimal jobInstanceId;
	
	@Autowired
	private EDSCPPRulesService edsCPPRulesService;

	@Autowired
	private CPPSimulationService cppSimulationService;
	

	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}

	public String getCppSrcName() {
		return cppSrcName;
	}

	public void setCppSrcName(String cppSrcName) {
		this.cppSrcName = cppSrcName;
	}

	public String getJobInstanceName() {
		return jobInstanceName;
	}

	public ExecutionContext getExecutionContext() {
		return executionContext;
	}

	public void setExecutionContext(ExecutionContext executionContext) {
		this.executionContext = executionContext;
	}

	public BigDecimal getJobInstanceId() {
		return jobInstanceId;
	}

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	
	// for Junit
	public void testService(EDSCPPRulesService edsCPPRulesService) {
		this.edsCPPRulesService = edsCPPRulesService;	
	}

	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext)
			throws Exception {
			logger.info("Start UpdateCPPRulesExecutionStatus class for Method : execute :  jobInstanceId="+jobInstanceId+" Job status is :"+status);
		
			String cppRunMode = (String) chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get("cppRunMode");
		logger.info("cppRunMode = " + cppRunMode);
		if(BatchConstants.SIMULATION.equalsIgnoreCase(cppRunMode)){
			String simSrcId =  chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get("edsSimSrcId").toString();
			if( status!= EDSProcessStatus.ERROR.getStatusCode()){
				edsCPPRulesService.updateSimulationFlag(jobInstanceName , simSrcId);
			}
			cppSimulationService.updateSimulationSourcePostProcessing(cppSrcName ,jobInstanceName, status);
		}else{
			List<String> cppRuleIdList=new ArrayList<String>();
			if ( this.executionContext!=null && this.executionContext.get(FAILED_CPP_RULE_IDS) !=null) {
				cppRuleIdList = (List<String>) this.executionContext.get(FAILED_CPP_RULE_IDS);
				logger.info("Size of the cppRuleIdList is ="+cppRuleIdList.size());
			}
			else {
				logger.info("this.executionContext.get(FAILED_CPP_RULE_IDS) = IS NULL");
			}
			edsCPPRulesService.updateFirstRunSW(jobInstanceName,cppRuleIdList);
			edsCPPRulesService.updateCPPSrcStatusPostProcessing(cppSrcName, jobInstanceName,status);
		}
		
		logger.info("End UpdateCPPRulesExecutionStatus class for Method : execute  ");
		return RepeatStatus.FINISHED;
	}

}
