package com.mastercard.ess.eds.batch.tasklet;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.service.FraudReportService;
import com.mastercard.ess.eds.core.util.FraudReportGenerator;
import com.mastercard.ess.eds.domain.FraudReportRecord;

public class FraudReportGeneratorTasklet implements Tasklet  {

	private static Logger logger = Logger.getLogger(FraudReportGeneratorTasklet.class);
	
	private static String SUBSCRIBED_BEFORE_COUNT = "SUBSCRIBED_BEFORE_COUNT" ;
	private static String UNSUBSCRIBED_BEFORE_COUNT = "UNSUBSCRIBED_BEFORE_COUNT" ;
	private static String SUBSCRIBED_AFTER_COUNT = "SUBSCRIBED_AFTER_COUNT" ;
	private static String UNSUBSCRIBED_AFTER_COUNT = "UNSUBSCRIBED_AFTER_COUNT" ;
	
	@Autowired
	private FraudReportService fraudReportService;
	
	@Autowired
	private FraudReportGenerator fraudReportGenerator ;
	
	@SuppressWarnings("unchecked")
	@Override
	public RepeatStatus execute(StepContribution arg0, ChunkContext chunkContext)
			throws Exception {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : FraudReportGeneratorTasklet - execute ");
		}
		
		String jobInstanceName = chunkContext.getStepContext().getStepExecution().getJobExecution().getJobInstance().getJobName();
		BigDecimal jobInstanceId = BigDecimal.valueOf(chunkContext.getStepContext().getStepExecution().getJobExecution().getJobId());
				
		Map<String, String>  beforeSubsFraudCt = (Map<String, String>) chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get(SUBSCRIBED_BEFORE_COUNT);
		Map<String, String>  beforeUnSubsFraudCt = (Map<String, String>) chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get(UNSUBSCRIBED_BEFORE_COUNT);
		Map<String, Integer>  afterSubsFraudCt = (Map<String, Integer>) chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get(SUBSCRIBED_AFTER_COUNT);
		Map<String, Integer>  afterUnSubsFraudCt =(Map<String, Integer>) chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get(UNSUBSCRIBED_AFTER_COUNT);
		
		List<FraudReportRecord> fraudReports = fraudReportService.wrapFraudReport(beforeSubsFraudCt, beforeUnSubsFraudCt , afterSubsFraudCt ,afterUnSubsFraudCt);
		
		fraudReportGenerator.writeToFraudReport( fraudReports, jobInstanceId, jobInstanceName);
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit in method : FraudReportGeneratorTasklet - execute ");
		}
		return RepeatStatus.FINISHED;
	}
	
	//for junit
	public void setFraudReportService(FraudReportService fraudReportService) {
		this.fraudReportService = fraudReportService;
	}

	
	public void setFraudReportGenerator(FraudReportGenerator fraudReportGenerator) {
		this.fraudReportGenerator = fraudReportGenerator;
	}

}
