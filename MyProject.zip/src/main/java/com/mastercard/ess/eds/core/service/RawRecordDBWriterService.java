package com.mastercard.ess.eds.core.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.dao.RawRecordDBWriterDao;
import com.mastercard.ess.eds.domain.RawRecord;


@Component
public class RawRecordDBWriterService {
	
	public RawRecordDBWriterService() {
		super();
	}

	public RawRecordDBWriterService(RawRecordDBWriterDao rawRecordDBWriterDao) {
		super();
		this.rawRecordDBWriterDao = rawRecordDBWriterDao;
	}

	@Autowired
	RawRecordDBWriterDao rawRecordDBWriterDao;
	
	public void writeRecord(List<? extends RawRecord> rawRecords,String edsSrcId, BigDecimal jobInstanceId) {
		rawRecordDBWriterDao.writeRecord(rawRecords,edsSrcId ,jobInstanceId);
	}

	public String getEdsSrcId(String srcName) {
		return rawRecordDBWriterDao.getEdsSrcId(srcName);
	}

}
