package com.mastercard.ess.eds.batch.decider;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;

import com.mastercard.ess.eds.constant.BatchConstants;

/**
 *  This decider class return flow execution status based on the run mode from the context
 * @author e070836
 * @version 1.0
 * @date : Dec 29, 2017
 *
 */
public class CPPDecider implements JobExecutionDecider {

	/**
	 *  This override method set the flow execution status based context.
	 *  @param  jobExecution , stepExecutionStatus
	 *  @return FlowExecutionStatus
	 */
	@Override
	public FlowExecutionStatus decide(JobExecution jobExecution, StepExecution stepExecutionStatus) {
		
		String cppRunMode = (String) jobExecution.getExecutionContext().get("cppRunMode");
		
		if(null != cppRunMode && cppRunMode.equalsIgnoreCase(BatchConstants.SIMULATION)){
			return new FlowExecutionStatus(BatchConstants.SIMULATION) ;
		}
		
		return new FlowExecutionStatus(BatchConstants.EXECUTION) ;
	}

}
