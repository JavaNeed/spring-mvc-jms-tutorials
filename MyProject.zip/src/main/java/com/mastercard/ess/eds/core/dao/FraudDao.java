package com.mastercard.ess.eds.core.dao;

import java.sql.Date;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.batch.config.DatabaseUtil;
import com.mastercard.ess.eds.batch.exception.EDSCoreException;

@Component
public class FraudDao {

	private static final String FRAUD_QUERY = "SELECT CASE WHEN EXISTS ( (SELECT 1 FROM AUTHOP01_DETAIL_ENC AUTH_ENC WHERE  AUTH_ENC.ENCRYPT_VRTL_PAN_DE048S33F02 = ? "+
            "OR ( AUTH_ENC.ENCRYPT_PAN_DE002 = ? AND AUTH_ENC.ENCRYPT_VRTL_PAN_DE048S33F02 IS NULL) AND EXISTS "+
            "(SELECT /*+ index (F01, FRAUD_LABEL_NDX1) */ NULL FROM FRAUD_LABEL F01 WHERE F01.DW_AUTHOP_SEQ_NUM = AUTH_ENC.DW_AUTHOP_SEQ_NBR "+
            " AND F01.DW_AUTHOP_PRCSS_DT = AUTH_ENC.DW_PROCESS_DATE)) UNION (SELECT 1 FROM DEBITMDS01_DETAIL_ENC DEBIT_ENC WHERE "+
            " DEBIT_ENC.ENCRYPT_PAYPASS_ACCT_NUM = ? OR ( DEBIT_ENC.ENCRYPT_RQST_ACCT_NUM_DE002 = ? AND DEBIT_ENC.ENCRYPT_PAYPASS_ACCT_NUM IS NULL) "+
            " AND EXISTS (SELECT /*+ index (F01, FRAUD_LABEL_NDX2) */ NULL FROM FRAUD_LABEL F01 WHERE F01.DW_DB_SEQ_NUM = DEBIT_ENC.DW_DB_MDS_SEQ_NUM "+
            " AND F01.DW_DB_PRCSS_DT = DEBIT_ENC.DW_PRCSS_DT))) THEN 'Y' ELSE 'N' END FROM DUAL";
	
	private static final String FRAUD_MIN_DATE_QUERY = "SELECT TO_CHAR (MIN (fraud_date), 'MON-YY') AS FRAUD_DT FROM ( (SELECT /*+ index (F01, FRAUD_LABEL_NDX1) */ "+
               "F01.TRAN_DT AS fraud_date FROM FRAUD_LABEL F01 INNER JOIN AUTHOP01_DETAIL_ENC AUTH_ENC ON ( F01.DW_AUTHOP_SEQ_NUM = AUTH_ENC.DW_AUTHOP_SEQ_NBR "+
               "AND F01.DW_AUTHOP_PRCSS_DT = AUTH_ENC.DW_PROCESS_DATE) WHERE AUTH_ENC.ENCRYPT_VRTL_PAN_DE048S33F02 = ? OR ( AUTH_ENC.ENCRYPT_PAN_DE002 = ? "+
               "AND AUTH_ENC.ENCRYPT_VRTL_PAN_DE048S33F02 IS NULL) AND AUTH_ENC.DW_PROCESS_DATE > ? ) UNION (SELECT /*+ index (F01, FRAUD_LABEL_NDX1) */ "+
               "F01.TRAN_DT AS fraud_date FROM FRAUD_LABEL F01 INNER JOIN DEBITMDS01_DETAIL_ENC DEBIT_ENC ON ( F01.DW_DB_SEQ_NUM = DEBIT_ENC.DW_DB_MDS_SEQ_NUM "+
               "AND F01.DW_DB_PRCSS_DT = DEBIT_ENC.DW_PRCSS_DT) WHERE DEBIT_ENC.ENCRYPT_PAYPASS_ACCT_NUM = ? OR ( DEBIT_ENC.ENCRYPT_RQST_ACCT_NUM_DE002 = ? "+
               "AND DEBIT_ENC.ENCRYPT_PAYPASS_ACCT_NUM IS NULL) AND DEBIT_ENC.DW_PRCSS_DT > ?)) WHERE fraud_date > LAST_DAY (ADD_MONTHS (TRUNC (SYSDATE, 'mm'), -13)) "+
               "AND fraud_date < LAST_DAY (ADD_MONTHS (TRUNC (SYSDATE, 'mm'), -1)) + 1";
	
	private static Logger logger = Logger.getLogger(FraudDao.class);
	
	@Value("${fraudGenerateDays}")
	private int fraudGenerateDays;
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private DatabaseUtil databaseUtil;

	private static final String ZERO = "0";
	private static final int PADDING_MAX_LIMIT = 19;
	
	public FraudDao(DatabaseUtil databaseUtil) {
		jdbcTemplate = databaseUtil.buildDWJdbcTemplate();
	}

	/**
	 * check if a PAN account exists in concerned relations in datawarehouse
	 * 
	 * @param pan
	 * @return boolean
	 */
	public boolean isFraudReported(String pan) throws EDSCoreException {
		String ifexists = null ;
		String paddedPan =   StringUtils.rightPad(pan, PADDING_MAX_LIMIT, ZERO);
		try {
			ifexists = jdbcTemplate.queryForObject(FRAUD_QUERY, new Object[] { pan , pan , paddedPan ,paddedPan }, String.class);
		}catch (Exception e) {
			logger.error("Exception occured in fraud query from DW "+ e);
			throw new EDSCoreException("Exception occured in fraud query from DW. "+ e.getMessage());
		}

		if (("Y").equals(ifexists)) {

			return true;
		}

		return false;

	}
	
	private Date getQueryStartDate() {

		Calendar cal = GregorianCalendar.getInstance();
		cal.add( Calendar.DAY_OF_YEAR, fraudGenerateDays);
		java.util.Date offset = cal.getTime();
		
		return new Date(offset.getTime());
		
	}
	
	
	/**
	 * It get minimum date of fraud.
	 * 
	 * @param pan
	 * @return boolean
	 */
	public String getMinimumFraudDate(String pan) throws EDSCoreException {
		String minFraudDate = null ;
		try {
			Date queryStartDate= getQueryStartDate() ;
			String paddedPan =   StringUtils.rightPad(pan, PADDING_MAX_LIMIT, ZERO);
			minFraudDate = jdbcTemplate.queryForObject(FRAUD_MIN_DATE_QUERY, new Object[] { pan ,pan ,queryStartDate ,paddedPan, paddedPan , queryStartDate }, String.class);
		} catch (Exception e) {
			logger.error("Exception occured in fraud query from DW "+ e);
			throw new EDSCoreException("Exception occured in fraud query from DW. "+ e.getMessage());
		}

		return minFraudDate ;

	}

}
