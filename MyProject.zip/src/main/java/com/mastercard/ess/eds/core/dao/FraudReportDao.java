package com.mastercard.ess.eds.core.dao;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.batch.exception.EDSCoreException;

@Component
public class FraudReportDao {

    private static Logger logger = Logger.getLogger(FraudReportDao.class);

    private static final String SUBSCRIBED_FRAUD_BEFORE_COUNT =
            "SELECT TO_CHAR (prcss_data.CRTE_DT, 'MON-YY') AS create_date, COUNT (DISTINCT prcss_data.pan_num) AS subscribed_count "
                    + "FROM eds_prcss_data prcss_data INNER JOIN eds_cust_mstr mstr ON prcss_data.ica_num = mstr.ica_num where prcss_data.FRAUD_RPT_SW = 'Y' AND mstr.actv_sw ='Y' "
                    + "AND prcss_data.ACCT_ACTV_SW = 'Y' AND prcss_data.ACCT_VALID_SW = 'Y' AND prcss_data.PAN_DUP_SW = 'N' AND prcss_data.BRND_PRDCT_CD NOT IN "
                    + "(SELECT BRND_PRDCT_CD FROM EDS_EXCLD_BRND_PRCT)  AND prcss_data.crte_dt > LAST_DAY (ADD_MONTHS (TRUNC (SYSDATE, 'mm'), -13)) "
                    + "AND prcss_data.crte_dt < LAST_DAY (ADD_MONTHS (TRUNC (SYSDATE, 'mm'), -1)) + 1 GROUP BY TO_CHAR (prcss_data.CRTE_DT, 'MON-YY')";

    private static final String UNSUBSCRIBED_FRAUD_BEFORE_COUNT =
            "SELECT TO_CHAR (prcss_data.CRTE_DT, 'MON-YY') AS create_date ,COUNT (DISTINCT prcss_data.pan_num) AS unsubscribed_count "
                    + "FROM eds_prcss_data prcss_data LEFT JOIN eds_cust_mstr mstr ON prcss_data.ica_num = mstr.ica_num "
                    + "WHERE mstr.ica_num IS NULL AND prcss_data.ica_num IS NOT NULL AND prcss_data.FRAUD_RPT_SW = 'Y' AND "
                    + "ACCT_ACTV_SW = 'Y'AND ACCT_VALID_SW = 'Y' AND PAN_DUP_SW = 'N' AND BRND_PRDCT_CD NOT IN (SELECT BRND_PRDCT_CD FROM EDS_EXCLD_BRND_PRCT) AND "
                    + "prcss_data.crte_dt > LAST_DAY (ADD_MONTHS (TRUNC (SYSDATE, 'mm'), -13)) AND prcss_data.crte_dt < LAST_DAY (ADD_MONTHS (TRUNC (SYSDATE, 'mm'), -1)) + 1 "
                    + "GROUP BY TO_CHAR (prcss_data.CRTE_DT, 'MON-YY')";

    private static final String PAN_NO_FRAUD_SUBSCRIBED =
            "SELECT DISTINCT (prcss_data.PAN_NUM) FROM eds_prcss_data prcss_data INNER JOIN eds_cust_mstr mstr "
                    + "ON prcss_data.ica_num = mstr.ica_num WHERE  prcss_data.FRAUD_RPT_SW = 'N' AND mstr.actv_sw ='Y'  AND "
                    + "prcss_data.ACCT_ACTV_SW = 'Y' AND prcss_data.ACCT_VALID_SW = 'Y' AND PAN_DUP_SW = 'N' AND BRND_PRDCT_CD NOT IN (SELECT BRND_PRDCT_CD FROM EDS_EXCLD_BRND_PRCT) AND "
                    + "prcss_data.crte_dt > LAST_DAY (ADD_MONTHS (TRUNC (SYSDATE, 'mm'), -13)) AND prcss_data.crte_dt < LAST_DAY (ADD_MONTHS (TRUNC (SYSDATE, 'mm'), -1)) + 1";

    private static final String PAN_NO_FRAUD_UNSUBSCRIBED =
            "SELECT DISTINCT (prcss_data.PAN_NUM) FROM eds_prcss_data prcss_data left JOIN eds_cust_mstr mstr ON prcss_data.ica_num = mstr.ica_num "
                    + "WHERE mstr.ica_num IS NULL AND prcss_data.ica_num IS NOT NULL AND prcss_data.FRAUD_RPT_SW = 'N' "
                    + "AND ACCT_ACTV_SW = 'Y'AND ACCT_VALID_SW = 'Y' AND PAN_DUP_SW = 'N' AND BRND_PRDCT_CD NOT IN (SELECT BRND_PRDCT_CD FROM EDS_EXCLD_BRND_PRCT) "
                    + "AND prcss_data.crte_dt > LAST_DAY (ADD_MONTHS (TRUNC (SYSDATE, 'mm'), -13)) "
                    + "AND prcss_data.crte_dt < LAST_DAY (ADD_MONTHS (TRUNC (SYSDATE, 'mm'), -1)) + 1";

    private JdbcTemplate jdbcTemplate;

    @Autowired
    private FraudDao fraudDao;

    public FraudReportDao(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public List<Map<String, Object>> getBeforeCountSubscribedICA() {
        logger.info("Enter into the method getBeforeCountSubscribedICA");
        return jdbcTemplate.queryForList(SUBSCRIBED_FRAUD_BEFORE_COUNT);
    }

    public List<Map<String, Object>> getBeforeCountUnSubscribedICA() {
        logger.info("Enter into the method getBeforeCountUnSubscribedICA");
        return jdbcTemplate.queryForList(UNSUBSCRIBED_FRAUD_BEFORE_COUNT);
    }

    public Map<String, Integer> getAfterCountSubscribedICA() throws EDSCoreException {
        logger.info("Enter into the method getAfterCountSubscribedICA");
        Map<String, Integer> afterCountMap = new HashMap<>();

        List<BigDecimal> panList = jdbcTemplate.queryForList(PAN_NO_FRAUD_SUBSCRIBED, BigDecimal.class);
        if (panList != null && !panList.isEmpty()) {
            for (BigDecimal pan : panList) {
                updateAfterCount(afterCountMap, pan);
            }
        } else {
            logger.info("No PAN's available for Subscribed ICA");
        }
        logger.info("afterCountMap" + afterCountMap);
        return afterCountMap;
    }

    private void updateAfterCount(Map<String, Integer> afterCountMap, BigDecimal pan) throws EDSCoreException {
        Integer count = 1;
        String monDate = fraudDao.getMinimumFraudDate(pan.toString());
        if (monDate != null) {
            if (afterCountMap.get(monDate) != null) {
                count = afterCountMap.get(monDate);
                count++;
            }

            afterCountMap.put(monDate, count);
        }
    }

    public Map<String, Integer> getAfterCountUnSubscribedICA() throws EDSCoreException {
        logger.info("Enter into the method getAfterCountSubscribedICA");
        Map<String, Integer> afterCountMap = new HashMap<>();

        List<BigDecimal> panList = jdbcTemplate.queryForList(PAN_NO_FRAUD_UNSUBSCRIBED, BigDecimal.class);
        if (panList != null && !panList.isEmpty()) {
            for (BigDecimal pan : panList) {
                updateAfterCount(afterCountMap, pan);
            }
        } else {
            logger.info("No PAN's available for Subscribed ICA");
        }

        return afterCountMap;
    }

}
