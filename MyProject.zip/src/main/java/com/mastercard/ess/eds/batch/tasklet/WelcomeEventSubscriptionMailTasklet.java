package com.mastercard.ess.eds.batch.tasklet;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.core.service.CustomerMasterService;
import com.mastercard.ess.eds.core.service.EventSubscriptionService;
import com.mastercard.ess.eds.notification.util.NotificationEventConstants;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;

import static com.mastercard.ess.eds.constant.SQLConstants.*;
import static com.mastercard.ess.eds.constant.BatchConstants.*;

public class WelcomeEventSubscriptionMailTasklet implements Tasklet{

	private static Logger logger = Logger.getLogger(WelcomeEventSubscriptionMailTasklet.class);

	@Value("${welcomeemail.day}")
	private int numberOfDays;

	@Autowired
	private EventPublisher eventPublisher;
	
	@Autowired
	private CustomerMasterService customerMasterService;

	@Autowired
	private EventSubscriptionService eventSubscriptionService;

	//required for writing junit
	public WelcomeEventSubscriptionMailTasklet() {
		//NOOP
	}

	//required for writing junit
	public WelcomeEventSubscriptionMailTasklet(EventPublisher eventPublisher, CustomerMasterService customerMasterService, EventSubscriptionService eventSubscriptionService) {
		this.eventPublisher = eventPublisher;
		this.customerMasterService = customerMasterService;
		this.eventSubscriptionService = eventSubscriptionService;
	}
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		logger.info("Enter method : execute : WELCOME EVENT SUBSCRIPTION EMAIL ");

		List<String> emailIds = eventSubscriptionService.getEmailIdsByEventType( EVENT_TYPE_EXTERNAL , numberOfDays);
		
		if(emailIds.isEmpty()){
			return RepeatStatus.FINISHED ;
		}
		
		for(String emailId : emailIds){
			Map<String, String> jobParams = new HashMap<>();
			NotificationEventVO notificationEventVO = new NotificationEventVO();
			jobParams.put(CUSTOMER_WELCOME_EMAIL, emailId);
			notificationEventVO.setJobParams(jobParams);
			notificationEventVO.setEventName(NotificationEventConstants.WELCOME_EMAIL_NOTIFICATION_SUBSCRIPTION);
			notificationEventVO.setJobName(chunkContext.getStepContext().getStepExecution().getJobExecution().getJobInstance().getJobName());
			notificationEventVO.setJobID(BigDecimal.valueOf(chunkContext.getStepContext().getStepExecution().getJobExecution().getJobId().longValue()));
			
			logger.info("Placing the event");
			this.eventPublisher.placeEvent(notificationEventVO);
		}
		
		logger.info("Exit from method : execute : WELCOME EVENT SUBSCRIPTION EMAIL ");
		return RepeatStatus.FINISHED;
	}

	public int getNumberOfDays() {
		return numberOfDays;
	}

	public void setNumberOfDays(int numberOfDays) {
		this.numberOfDays = numberOfDays;
	}

}
