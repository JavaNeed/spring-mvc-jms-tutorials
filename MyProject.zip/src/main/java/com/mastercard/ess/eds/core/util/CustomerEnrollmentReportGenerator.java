package com.mastercard.ess.eds.core.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.service.CustomerFileReportService;
import com.mastercard.ess.eds.domain.CustomerEnrollmentReport;

@Component
public class CustomerEnrollmentReportGenerator {

	private static Logger logger = Logger.getLogger(CustomerEnrollmentReportGenerator.class);

	private static final String REGION_E = "E";

	private static final String REGION_D = "D";

	private static final String REGION_C = "C";

	private static final String REGION_B = "B";

	private static final String REGION_A = "A";

	private static final String CONTINENT_MEA = "MEA";

	private static final String CONTINENT_APAC = "APAC";

	private static final String CONTINENT_LAC = "LAC";

	private static final String CONTINENT_EUROPE = "EUROPE";

	private static final String CONTINENT_NAM = "NAM";

	private static final String CONTINENT_US = "US";

	private static final String ICAS_TYPE = "ICAs type";

	private static final String ACTIVE_ICAS = "Total Enrolled ICAs";

	private static final String ENROLLED_ICAS = "Newly Enrolled ICAs";

	private static final String UN_ENROLLED_ICAS = "Cancelled ICAs";

	private static final String ONE = "1";

	private static final String TO = " to ";

	private static final String DATE_RANGE = "Date Range";

	private static final String ISSUER_REGION = "Issuer Region";

	private static final String MM = "MM";

	private static final String MMM_YY = "MMM-yy";

	private static final String MMMM_YYYY = "MMMM-yyyy";
	
	private static final int TWELVE = 12;

	private static final int CUSTOMER_ENROLLMENT_REPORT = 6;

	private static final String ZERO = "0";

	@Value("${customerEnrollmentReport.path}")
	private String customerEnrollmentReportPath;

	@Autowired
	private CustomerFileReportService customerFileReportService;

	public CustomerEnrollmentReportGenerator() {
		super();
	}
	public CustomerEnrollmentReportGenerator(String customerEnrollmentReportPath,
			CustomerFileReportService customerFileReportService) {
		this.customerEnrollmentReportPath = customerEnrollmentReportPath;
		this.customerFileReportService =customerFileReportService;
	}

	public String getCustomerEnrollmentReportPath() {
		return customerEnrollmentReportPath;
	}
	public void setCustomerEnrollmentReportPath(String customerEnrollmentReportPath) {
		this.customerEnrollmentReportPath = customerEnrollmentReportPath;
	}
	public void writeToCustomerEnrollmentReport(List<? extends CustomerEnrollmentReport> customerEnrollmentReportList,
			BigDecimal jobInstanceId, String jobInstanceName) {

		logger.info("***************Start Method writeToCustomerEnrollmentReport*******"); 

		try{

			logger.info("Customer Enrollment Path :"+customerEnrollmentReportPath+" jobInstanceId :"+jobInstanceId+" jobInstanceName :"+jobInstanceName);
			String filePath=customerEnrollmentReportPath;

			Calendar cal = Calendar.getInstance();  
			cal.add(Calendar.MONTH, -1);  
			DateFormat df = new SimpleDateFormat(MMM_YY);
			String toDate =df.format(cal.getTime());
			cal.add(Calendar.MONTH, -11);  
			String fromDate=df.format(cal.getTime());

			Calendar currentCal = Calendar.getInstance();  

			DateFormat dateFormat = new SimpleDateFormat(MMMM_YYYY);
			String currentMonth=dateFormat.format(currentCal.getTime());

			filePath = filePath + "Customer_Enrollment_Report"+ "_" + currentMonth + ".xlsx";

			File file = null;
			FileOutputStream fos = null;
			Workbook wb = null;
			Sheet sheet = null;

			file = new File(filePath);
			if (file.exists()) {
				logger.info("file already exists exiting ..");
				return;
			}

			wb = getXSSFWorkBook();
			fos = getFileOutputStream(filePath);

			String[] codeList = {ONE, REGION_A, REGION_B, REGION_C, REGION_D, REGION_E};

			for ( String continentId : codeList) {

				String sheetName= getSheetNameByContinentId(continentId);
				sheet = wb.createSheet(sheetName);
				int existingRows = sheet.getPhysicalNumberOfRows();
				// This data needs to be written (Object[])
				Map<Integer, Object[]> rowEntry = new TreeMap<>();

				mapObjectWithContinentToCustCount(customerEnrollmentReportList, fromDate,
						toDate, sheet, rowEntry, continentId);

				// Iterate over data and write to sheet
				writeDataInSheet(wb, sheet, existingRows, rowEntry);
			}
			writeToFile(wb, fos);

			//This will update the table after report is generated
			customerFileReportService.createGeneratedFileRecord(filePath, jobInstanceId, jobInstanceName, CUSTOMER_ENROLLMENT_REPORT);
		}catch (Exception e) {
			logger.error("Exception : " + e);
		} 

		logger.info("End Method writeToCustomerEnrollmentReport*******");
	}

	private void writeDataInSheet(Workbook wb, Sheet sheet, int existingRows,
			Map<Integer, Object[]> rowEntry) {
		Row row;
		Set<Integer> keyid = rowEntry.keySet();
		int rowid = existingRows;

		for (Integer key : keyid) {
			row = createRowInSpreadSheet(sheet, rowid++);
			Object[] objectArr = rowEntry.get(key);
			int cellid = 0;
			createCellValue(wb, row, objectArr, cellid);
		}

		for (int i = 0; i < 4; i++) {
			sheet.autoSizeColumn(i);
		}
	}

	private FileOutputStream getFileOutputStream(String filePath) throws FileNotFoundException {
		return new FileOutputStream(new File(filePath));
	}

	private Workbook getXSSFWorkBook() {
		return new XSSFWorkbook();
	}

	private Row createRowInSpreadSheet(Sheet spreadsheet, int rowNum) {
		return spreadsheet.createRow(rowNum);
	}

	private Cell createCellWithValue(Row row, int cellNo, Object value, Workbook wb) {

		XSSFCellStyle style = (XSSFCellStyle) wb.createCellStyle();
		Font fontStyle = wb.createFont();
		fontStyle.setBoldweight(Font.BOLDWEIGHT_NORMAL);
		fontStyle.setFontHeightInPoints((short) 10);
		style.setFont(fontStyle);
		style.setAlignment(CellStyle.ALIGN_CENTER);

		XSSFCellStyle cellStyle = (XSSFCellStyle) wb.createCellStyle();
		Font font1 = wb.createFont();
		font1.setBoldweight(Font.BOLDWEIGHT_NORMAL);
		font1.setFontHeightInPoints((short) 10);

		cellStyle.setFont(font1);

		XSSFCellStyle style2 = (XSSFCellStyle) wb.createCellStyle();
		Font font2 = wb.createFont();
		font2.setBoldweight(Font.BOLDWEIGHT_NORMAL);
		font2.setFontHeightInPoints((short) 10);
		style2.setFont(font2);

		Cell cell = row.createCell(cellNo);

		setCellWithStyle1(cellStyle, cell);			


		cell.setCellValue(value.toString());
		if(value instanceof Integer || value instanceof Double) {
			cell.setCellValue(Double.valueOf(value.toString()));
		} else {
			cell.setCellValue(value.toString());
		} 

		return cell;
	}
	/**
	 * @param value
	 * @param style1
	 * @param c
	 */
	private void setCellWithStyle1(XSSFCellStyle style1, Cell c) {
		c.setCellStyle(style1);
	}

	private static void writeToFile(Workbook workbook, FileOutputStream fos) throws IOException {
		workbook.write(fos);

	}

	//GOing to fetch sheetName based on continentId
	public String getSheetNameByContinentId(String continentId) {

		String sheetName="";
		switch (continentId) {
		case ONE:
			sheetName=CONTINENT_US;
			break;

		case REGION_A:
			sheetName=CONTINENT_NAM;
			break;
		case REGION_B:
			sheetName=CONTINENT_EUROPE;
			break;
		case REGION_C:
			sheetName=CONTINENT_LAC;
			break;
		case REGION_D:
			sheetName=CONTINENT_APAC;
			break;
		case REGION_E:
			sheetName=CONTINENT_MEA;
			break;

		default:
			sheetName=CONTINENT_US;
			break;
		}		
		return sheetName;
	}
	private void mapObjectWithContinentToCustCount(
			List<? extends CustomerEnrollmentReport> customerEnrollmentReportList, String fromDate, String toDate,
			Sheet sheet, Map<Integer, Object[]> rowEntry, String continentId) {
		logger.info("***************Start method mapObjectWithContinentToCustCount *****************");
		Integer mapRow = 0;
		rowEntry.put((mapRow++), new Object[] { "Customer Enrollment Report" });
		rowEntry.put((mapRow++), new Object[] { ISSUER_REGION,sheet.getSheetName() });
		rowEntry.put((mapRow++), new Object[] { DATE_RANGE, fromDate ,TO, toDate });

		rowEntry.put((mapRow++), new Object[] { " "});
		rowEntry.put((mapRow++), new Object[] { " " });

		List<String> prevMonthList=new ArrayList<>();
		List<String>  activeList = new ArrayList<>();
		List<String>  enrollList = new ArrayList<>();
		List<String>  unenrollList = new ArrayList<>();
		Integer incr = 0;
		activeList.add(" ");
		activeList.add(" ");
		activeList.add(" ");
		activeList.add(ACTIVE_ICAS);
		enrollList.add(" ");
		enrollList.add(" ");
		enrollList.add(" ");
		enrollList.add(ENROLLED_ICAS);
		unenrollList.add(" ");
		unenrollList.add(" ");
		unenrollList.add(" ");
		unenrollList.add(UN_ENROLLED_ICAS);
		for(CustomerEnrollmentReport cerl : customerEnrollmentReportList){
			incr = getCustomerEnrollmentDatalist(continentId, activeList,
					enrollList, unenrollList, incr, cerl);
		}
		if(incr<TWELVE){
			int bal = TWELVE - incr;
			for(int i=0;i<bal;i++){
				setCustEnrollDetail(activeList, enrollList, unenrollList, ZERO, ZERO, ZERO);
			}
		}
		prevMonthList.add(" ");	
		prevMonthList.add(" ");
		prevMonthList.add(" ");
		prevMonthList.add(ICAS_TYPE);
		prevMonthList.addAll(getPrevMonthList(TWELVE));

		rowEntry.put((mapRow++), prevMonthList.toArray());
		rowEntry.put((mapRow++), activeList.toArray());
		rowEntry.put((mapRow++), enrollList.toArray());
		rowEntry.put((mapRow), unenrollList.toArray());

		logger.info("***************End method mapObjectWithContinentToCustCount *****************");
	}

	private Integer getCustomerEnrollmentDatalist(String continentId,
			List<String> activeList, List<String> enrollList,
			List<String> unenrollList, Integer incr,
			CustomerEnrollmentReport cerl) {
		if(continentId.equals(cerl.getCode())){
			Calendar cal = Calendar.getInstance();  
			cal.add(Calendar.MONTH, -incr);  
			DateFormat df = new SimpleDateFormat(MM);
			int calTime = Integer.parseInt(df.format(cal.getTime()));
			int datTime = Integer.parseInt(df.format(cerl.getDateCreated()));
			int result = calTime - datTime;
			if(result == 0){
				setCustEnrollDetail(activeList, enrollList, unenrollList, String.valueOf(cerl.getActiveCust()), String.valueOf(cerl.getEnrolledCust()), String.valueOf(cerl.getUnEnrolledCust()));
				incr++;
			}else{
				if(result < 0){
					result = (TWELVE - datTime) + calTime;
				}
				for(int i=0; i<result; i++){
					setCustEnrollDetail(activeList, enrollList, unenrollList, ZERO, ZERO, ZERO);
					incr++;
				}
				setCustEnrollDetail(activeList, enrollList, unenrollList, String.valueOf(cerl.getActiveCust()), String.valueOf(cerl.getEnrolledCust()), String.valueOf(cerl.getUnEnrolledCust()));
				incr++;
			}
		}
		return incr;
	}
	private void setCustEnrollDetail(List<String> activeList,
			List<String> enrollList, List<String> unenrollList, String active, String enroll, String unEnroll) {
		activeList.add(active);
		enrollList.add(enroll);
		unenrollList.add(unEnroll);
	}

	/**
	 * @param wb
	 * @param row
	 * @param objectArr
	 * @param cellid
	 */
	private void createCellValue(Workbook wb, Row row, Object[] objectArr,
			int cell) {
		int cellid = cell;
		for (Object obj : objectArr) {
			if (obj != null) {
				createCellWithValue(row, cellid++, obj, wb);
			} else {
				createCellWithValue(row, cellid++, " ", wb);
			}

		}
	}

	/**Getting list of previous 12 months
	 * @param incr */
	public static List<String> getPrevMonthList(Integer incr) {

		Calendar cal = Calendar.getInstance();  
		cal.add(Calendar.MONTH, -1);  
		List<String> prevMonthList=new ArrayList<>();
		SimpleDateFormat monthDate = new SimpleDateFormat(MMM_YY);
		for (int i = 1; i <= incr; i++) {
			String monthName = monthDate.format(cal.getTime());
			prevMonthList.add(monthName);
			cal.add(Calendar.MONTH, -1);
		}
		return prevMonthList;
	}



}
