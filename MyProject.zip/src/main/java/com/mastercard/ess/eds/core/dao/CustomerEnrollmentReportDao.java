package com.mastercard.ess.eds.core.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Component;

/**
 * This DAO class inserts data into EDS_SOURCE_PROC_DATA table after processing.
 * 
 * @author e067588
 *
 */
@Component
public class CustomerEnrollmentReportDao {

    private static final String EDS_CUST_ENRL_RPT_ID = "EDS_CUST_ENRL_RPT_ID";
    private static final String ISSR_REGN_CD = "ISSR_REGN_CD";
    private static final String ACTV_CUST_CNT = "ACTV_CUST_CNT";
    private static final String ENRL_CUST_CNT = "ENRL_CUST_CNT";
    private static final String UN_ENRL_CUST_CNT = "UN_ENRL_CUST_CNT";
    private static final String CRTE_DT = "CRTE_DT";
    private static final String EDS_CUST_ENRL_RPT = "EDS_CUST_ENRL_RPT";
    private static final String ISSUER_REGION = "CODE";
    private static final String ENROLL = "enrolled";
    private static final String UN_ENROLL = "unenrolled";
    private static final String ACTIVE = "active";
    private static final String ZER0 = "0";
    private static final String ICA_COUNT = "ICA_COUNT";

    private static final String RECORD_EXISTS =
            "select crte_dt from eds_cust_enrl_rpt where crte_dt > last_day(add_months(trunc(sysdate,'mm'),-1))";

    private static Logger logger = Logger.getLogger(CustomerEnrollmentReportDao.class);

    private String jobInstanceName;

    public void setJobInstanceName(String jobInstanceName) {
        this.jobInstanceName = jobInstanceName;

    }

    private SimpleJdbcInsert edsRecordsInsert;

    private JdbcTemplate jdbcTemplate;

    DataSource dataSource;

    public CustomerEnrollmentReportDao(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
        this.dataSource = dataSource;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    /**
     * @param procRecord
     */
    public void saveRecord(List<Map<String, Object>> enrolledCustomerDetail,
            List<Map<String, Object>> unEnrolledCustomerDetail, List<Map<String, Object>> activeCustomerDetail) {
        List<String> exists = jdbcTemplate.queryForList(RECORD_EXISTS, String.class);
        if (exists.isEmpty()) {
            jdbcTemplate = new JdbcTemplate(dataSource);
            Set<String> codeSet = new HashSet<String>();
            getRegionCode(enrolledCustomerDetail, unEnrolledCustomerDetail, activeCustomerDetail, codeSet);

            for (String code : codeSet) {
                logger.info("code" + code);
                Map<String, Integer> finalValue =
                        finalWrap(enrolledCustomerDetail, unEnrolledCustomerDetail, activeCustomerDetail, code);
                edsRecordsInsert =
                        new SimpleJdbcInsert(dataSource).withTableName(EDS_CUST_ENRL_RPT).usingColumns(
                                EDS_CUST_ENRL_RPT_ID, ISSR_REGN_CD, ACTV_CUST_CNT, ENRL_CUST_CNT, UN_ENRL_CUST_CNT,
                                CRTE_DT);
                String eds_gen_rpt_id_seq = "select EDS_CUST_ENRL_RPT_ID_SEQ.nextval from dual";
                int uniquefileId = jdbcTemplate.queryForObject(eds_gen_rpt_id_seq, Integer.class);

                MapSqlParameterSource parameterSource = new MapSqlParameterSource();
                parameterSource.addValue(EDS_CUST_ENRL_RPT_ID, uniquefileId).addValue(ISSR_REGN_CD, code).addValue(
                        ACTV_CUST_CNT, finalValue.get("active")).addValue(ENRL_CUST_CNT, finalValue.get("enrolled"))
                        .addValue(UN_ENRL_CUST_CNT, finalValue.get("unenrolled")).addValue(CRTE_DT, new Date());

                edsRecordsInsert.execute(parameterSource);
            }
        } else {
            logger.info("Already record found for the last month");
        }
    }

    private Map<String, Integer> finalWrap(List<Map<String, Object>> enrolledCustomerDetail,
            List<Map<String, Object>> unEnrolledCustomerDetail, List<Map<String, Object>> activeCustomerDetail,
            String code) {
        Map<String, Integer> map = new HashMap<String, Integer>();
        for (Map<String, Object> a : enrolledCustomerDetail) {
            if (a.get(ISSUER_REGION).equals(code)) {
                map.put(ENROLL, ((BigDecimal) a.get(ICA_COUNT)).intValueExact());
                logger.info("(BigDecimal) a.get(ICA_COUNT)).intValueExact() " + a.get(ICA_COUNT));
            }
        }
        for (Map<String, Object> a : activeCustomerDetail) {
            if (a.get(ISSUER_REGION).equals(code)) {
                map.put(ACTIVE, ((BigDecimal) a.get(ICA_COUNT)).intValueExact());
                logger.info("(BigDecimal) a.get(ICA_COUNT)).intValueExact() " + a.get(ICA_COUNT));
            }
        }

        for (Map<String, Object> a : unEnrolledCustomerDetail) {
            if (a.get(ISSUER_REGION).equals(code)) {
                map.put(UN_ENROLL, ((BigDecimal) a.get(ICA_COUNT)).intValueExact());
                logger.info("(BigDecimal) a.get(ICA_COUNT)).intValueExact() " + a.get(ICA_COUNT));
            }
        }

        if (map.get(ENROLL) == null) {
            map.put(ENROLL, Integer.valueOf(ZER0));
        }
        if (map.get(ACTIVE) == null) {
            map.put(ACTIVE, Integer.valueOf(ZER0));
        }
        if (map.get(UN_ENROLL) == null) {
            map.put(UN_ENROLL, Integer.valueOf(ZER0));
        }
        return map;
    }

    private void getRegionCode(List<Map<String, Object>> enrolledCustomerDetail,
            List<Map<String, Object>> unEnrolledCustomerDetail, List<Map<String, Object>> activeCustomerDetail,
            Set<String> codeSet) {
        for (Map<String, Object> createMap : enrolledCustomerDetail) {
            codeSet.add((String) createMap.get(ISSUER_REGION));
        }
        for (Map<String, Object> createMap : activeCustomerDetail) {
            codeSet.add((String) createMap.get(ISSUER_REGION));
        }

        for (Map<String, Object> createMap : unEnrolledCustomerDetail) {
            codeSet.add((String) createMap.get(ISSUER_REGION));
        }
    }

}
