package com.mastercard.ess.eds.batch.tasklet;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.dao.CustomerEnrollmentReportDao;
import com.mastercard.ess.eds.core.service.CustomerMasterService;

public class CustomerEnrollmentReportTasklet implements Tasklet {

    private static Logger logger = Logger.getLogger(CustomerEnrollmentReportTasklet.class);

    @Autowired
    private CustomerMasterService customerMasterService;

    @Autowired
    private CustomerEnrollmentReportDao customerEnrollmentReportDao;

    @Override
    public RepeatStatus execute(StepContribution arg0, ChunkContext arg1) throws Exception {

        if (logger.isDebugEnabled()) {
            logger.debug("Enter in method : CustomerEnrollmentReportTasklet - execute ");
        }

        List<Map<String, Object>> enrolledCustomerDetail = customerMasterService.getEnrolledCustomerDetail();
        List<Map<String, Object>> UnEnrolledCustomerDetail = customerMasterService.getUnEnrolledCustomerDetail();
        List<Map<String, Object>> ActiveCustomerDetail = customerMasterService.getActiveCustomerDetail();
        customerEnrollmentReportDao.saveRecord(enrolledCustomerDetail, UnEnrolledCustomerDetail, ActiveCustomerDetail);

        if (logger.isDebugEnabled()) {
            logger.debug("Exit in method : CustomerEnrollmentReportTasklet - execute ");
        }

        return RepeatStatus.FINISHED;
    }

    public void setCustomerMasterService(CustomerMasterService customerMasterService) {
        this.customerMasterService = customerMasterService;
    }

    public void setCustomerEnrollmentReportDao(CustomerEnrollmentReportDao customerEnrollmentReportDao) {
        this.customerEnrollmentReportDao = customerEnrollmentReportDao;
    }

}
