package com.mastercard.ess.eds.batch.scheduler;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;

public class CPPRulesExecutionJobScheduler {

	private String cppSrcName;
	private Logger logger = Logger.getLogger(CPPRulesExecutionJobScheduler.class);
	
	public CPPRulesExecutionJobScheduler() {
		Properties prop = new Properties();
		
		try(InputStream inputStream = getClass().getResourceAsStream("/config.properties")) {
			if (inputStream != null) {
                prop.load(inputStream);
                cppSrcName = prop.getProperty("cpprulesrc.name");
            } else {
                throw new FileNotFoundException("File not found in the classpath");
            }
		} catch (IOException e) {
			logger.error("property file '" + "config.properties" + "' not found in the classpath" + e);
		}
	}
	
	public static void main(String[] args) {
		CPPRulesExecutionJobScheduler cppRulesExecutionJobScheduler = new CPPRulesExecutionJobScheduler();
		System.out.println(cppRulesExecutionJobScheduler.execute()); //NOSONAR
		
	}
	
	private String execute() {
		Date date = new Date();  
	    SimpleDateFormat formatter = new SimpleDateFormat("dd_MMM_yyyy_hh_mm_ss");
		return cppSrcName + formatter.format(date);
	}
}
