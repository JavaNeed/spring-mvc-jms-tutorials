package com.mastercard.ess.eds.core.util;

import org.springframework.stereotype.Component;


@Component
public class ProdUtil implements EnvironmentUtil{

	@Override
	public String getKeyStorePath() {
		return null;
	}

	@Override
	public String getEnv() {
		return "prod";
	}

}
