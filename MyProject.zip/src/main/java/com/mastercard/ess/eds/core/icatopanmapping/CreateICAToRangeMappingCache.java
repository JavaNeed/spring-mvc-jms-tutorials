package com.mastercard.ess.eds.core.icatopanmapping;

import java.util.Map;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.dao.PANAccountRangeDAO;

public class CreateICAToRangeMappingCache implements Tasklet{
	private static final Logger logger = Logger.getLogger(CreateICAToRangeMappingCache.class);

	private static final String ICA_TO_RANGE_CACHE = "IcaToRangeCache";
	private static final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

	@Autowired
	PANAccountRangeDAO panAccountRangeDao;
	private ExecutionContext executionContext;

	public ExecutionContext getExecutionContext() {
		return executionContext;
	}

	public void setExecutionContext(ExecutionContext executionContext) {
		this.executionContext = executionContext;
	}

	/**
	 * Method will load the ICAToRange cache .
	 */
	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in Class : CreateICAToRangeMappingCache: Method : execute");
		}
		lock.writeLock().lock();

		try {
			Map<String, Map<ICAAccountRange, ICAAccountRange>> mapOfIcaToRangeMapping = panAccountRangeDao.getICAToRangeMapping();
			chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(ICA_TO_RANGE_CACHE, mapOfIcaToRangeMapping);
		}
		finally {
			if (logger.isDebugEnabled()) {
				logger.debug("Exit from Class : CreateICAToRangeMappingCache: Method : execute");
			}
			lock.writeLock().unlock();
		}
		return RepeatStatus.FINISHED;
	}
}
