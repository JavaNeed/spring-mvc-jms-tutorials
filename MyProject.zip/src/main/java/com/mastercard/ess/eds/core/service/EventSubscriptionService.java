package com.mastercard.ess.eds.core.service;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.dao.EventSubscriptionDAO;

/**
 * @author e069468
 *
 */
@Component
public class EventSubscriptionService {
	
	private static Logger logger = Logger.getLogger(EventSubscriptionService.class);
	
	@Autowired
	public EventSubscriptionDAO eventSubscriptionDAO;
	
	
	/**
	 * @return - This method returns the list of emailIds of the customer type event who has subscribed for email notification 
	 */
	public List<String> getEmailIdsByEventType( String eventType , int days){
		return eventSubscriptionDAO.getEmailIdsByEventType(eventType , days);
	}
	
	public List<Map<String, Object>> getEmailIdsUsingICA(String eventId, List<String> icas){
		logger.info("Enter method : EventSubscriptionService : getEmailIdsUsingICA");
		return eventSubscriptionDAO.getEmailIdsUsingICA(eventId, icas);
	}

	//Junit
	public void setEventSubscriptionDAO(EventSubscriptionDAO eventSubscriptionDAO) {
		this.eventSubscriptionDAO = eventSubscriptionDAO;
	}

}
