package com.mastercard.ess.eds.core.util;

/**
 * This class is used to map rule id to category code.
 * @author E076119
 *
 */
public class RuleCatCdRecord {
	
	Long cppRuleId;
	
	String categoryCode;
	
	public Long getCppRuleId() {
		return cppRuleId;
	}
	public void setCppRuleId(Long cppRuleId) {
		this.cppRuleId = cppRuleId;
	}
	public String getCategoryCode() {
		return categoryCode;
	}
	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}
	
	public RuleCatCdRecord(Long cppRuleId, String categoryCode){
		this.cppRuleId = cppRuleId;
		this.categoryCode = categoryCode;
	}
}
