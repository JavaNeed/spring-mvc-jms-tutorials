package com.mastercard.ess.eds.batch.config;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.mastercard.ess.eds.core.util.DevUtil;
import com.mastercard.ess.eds.core.util.EnvironmentUtil;
import com.mastercard.ess.eds.core.util.ProdUtil;


@Configuration
public class EnvironmentConfig {
	
	private static Logger logger = Logger.getLogger(EnvironmentConfig.class);
	
	@Bean(name = "envUtil")
	@Profile("dev")
	EnvironmentUtil getDevConfig(){
		if (logger.isDebugEnabled()) {
			logger.debug("******dev Profile Loaded******");
		}
		return new DevUtil();
	}
	
	
	@Bean(name = "envUtil")
	@Profile("prod")
	EnvironmentUtil getProdConfig(){
		if (logger.isDebugEnabled()) {
			logger.debug("******prod Profile Loaded******");
		}
		return new ProdUtil();
	}

}
