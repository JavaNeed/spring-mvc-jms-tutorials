package com.mastercard.ess.eds.core.util;

/**
 * This ENUM contains the report types.
 *
 */
public enum ReportTypeTokens {
	
	BILLING_REPORT(1, "Billing"),
	CUST_PAN_REPORT(2, "Customer PAN Report"),
	CPP_REPORT(3, "CPP Report"),
	VENDOR_REPORT(4, "Vendor Report");

	private int typecode;
	private String reportType;

	private ReportTypeTokens(int typecode, String reportType) {
		this.typecode = typecode;
		this.reportType = reportType;
	}

	public int getTypecode() {
		return typecode;
	}

	public String getReportType() {
		return reportType;
	}

}
