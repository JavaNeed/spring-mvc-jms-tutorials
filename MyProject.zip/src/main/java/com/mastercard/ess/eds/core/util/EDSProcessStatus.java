package com.mastercard.ess.eds.core.util;

/**
 * This ENUM contains all status of input file
 *
 */
public enum EDSProcessStatus {

	QUEUED(1, "Queued"), ERROR(2, "Error"), WIP(3, "Wip"), UNPROCESSED(4, "Unprocessed"), PROCESSED(5,
			"processed"), PURGED(6, "Purged"), SENT(7, "Sent"), INVALID(8, "Invalid"), FAILED(9, "Failed"), GENERATED(10, "Generated");

	private int statusCode;
	private String statusDesc;

	private EDSProcessStatus(int statusCode, String statusDesc) {
		this.statusCode = statusCode;
		this.statusDesc = statusDesc;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

}
