package com.mastercard.ess.eds.core.icatopanmapping;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * Model will bind startRange,EndRange and MbrId details ,which will be used to validate ICA's set to PAN.
 * @author e075766
 *
 */
public class ICAAccountRange{

	private BigInteger startOfRange;
	private BigInteger endOfRange;
	private String mbrId;

	public ICAAccountRange(BigDecimal startOfRange, BigDecimal endOfRange) {
		this.startOfRange = startOfRange.toBigInteger();
		this.endOfRange = endOfRange.toBigInteger();
	}

	/**
	 * Constructor for single-value range is used for matching a single value to a range.
	 * Useful to find the desired range value in a sorted list or map
	 * @param value
	 */
	public ICAAccountRange(String value) {
		this.startOfRange = new BigInteger(value);
		this.endOfRange = this.startOfRange;
	}


	public ICAAccountRange() {
	}

	public BigInteger getStart() {
		return startOfRange;
	}

	public BigInteger getEnd() {
		return endOfRange;
	}

	public void setStart(BigInteger startOfRange) {
		this.startOfRange = startOfRange;
	}

	public void setEnd(BigInteger endOfRange) {
		this.endOfRange = endOfRange;
	}

	public Long getBin(int length) {
		Long result = null;
		String start = startOfRange.toString();
		if (length > 0 && length < start.length()){
			result =Long.valueOf(start.substring(0,length)); 
		}
		return result;
	}

	public String getMbrId() {
		return mbrId;
	}

	public void setMbrId(String mbrId) {
		this.mbrId = mbrId;
	}

}
