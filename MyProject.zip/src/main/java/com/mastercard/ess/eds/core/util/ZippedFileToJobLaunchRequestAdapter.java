package com.mastercard.ess.eds.core.util;

import java.io.File;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.integration.launch.JobLaunchRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.util.Assert;

public class ZippedFileToJobLaunchRequestAdapter {

	private Job job;
	
	@Value("${input.directory}")
	private String inputDirectory;
	
	@Value("${datafile.name}")
	private String dataFileName;

	public void setJob(Job job) {
		this.job = job;
	}

	public String getInputDirectory() {
		return inputDirectory;
	}

	public void setInputDirectory(String inputDirectory) {
		this.inputDirectory = inputDirectory;
	}

	public String getDataFileName() {
		return dataFileName;
	}

	public void setDataFileName(String dataFileName) {
		this.dataFileName = dataFileName;
	}

	@ServiceActivator
	public JobLaunchRequest adapt(File file) throws NoSuchJobException {
		String fileName = file.getAbsolutePath();
		
		String name = file.getName(); // get just the file name without path 

		if (!(fileName.startsWith("/"))) {
			fileName = "/" + fileName;
		}

		fileName = "file://" + fileName;

		JobParameters jobParameters = new JobParametersBuilder()
				.addString("input.file", fileName)
				.addString("input.unzipped.file", "file://" + inputDirectory + name + File.separator + dataFileName)
				.toJobParameters();
		

		if (this.job.getJobParametersIncrementer() != null) {
			jobParameters = this.job.getJobParametersIncrementer().getNext(
					jobParameters);
		}

		return new JobLaunchRequest(this.job, jobParameters);
	}
}
