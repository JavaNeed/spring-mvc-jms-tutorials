package com.mastercard.ess.eds.billing.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.mastercard.ess.eds.billing.vo.BillDataVO;

/**
 * Map columns from EDS_PRCSS_DATA table to fields in BillDataVO domain object.
 * Required by reader while parsing data and returning a populated object.
 * 
 * @author e068303
 *
 */

public class BillDataVOMapper implements RowMapper<BillDataVO> {

	private static Logger logger = Logger.getLogger(BillDataVOMapper.class);

	public BillDataVO mapRow(ResultSet rs, int rowNum) throws SQLException {

		if (logger.isDebugEnabled()) {
			logger.debug("BillDataVOMapper | BillDataVO mapRow(ResultSet rs, int rowNum) | Enter in method : mapRow ");
		}

		BillDataVO billDataVO = new BillDataVO();

		billDataVO.setPanNum(rs.getLong("PAN_NUM"));
		billDataVO.setPriceCatid(rs.getLong("PRICE_CAT_CD"));

		if (logger.isDebugEnabled()) {
			logger.debug("BillDataVOMapper | BillDataVO mapRow(ResultSet rs, int rowNum) | Exit from method : mapRow ");
		}

		return billDataVO;
	}

}
