package com.mastercard.ess.eds.batch.tasklet;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.service.FraudReportService;

public class FraudSubscribedAfterCountTasklet implements Tasklet  {

	private static Logger logger = Logger.getLogger(FraudSubscribedAfterCountTasklet.class);
	private static String SUBSCRIBED_AFTER_COUNT = "SUBSCRIBED_AFTER_COUNT" ;
	
	@Autowired
	private FraudReportService fraudReportService;
	
	//required for writing junit
	public FraudSubscribedAfterCountTasklet() {
		//NOOP
	}

	//required for writing junit
	public FraudSubscribedAfterCountTasklet(  FraudReportService fraudReportService) {
		this.fraudReportService = fraudReportService;
	}
	
	@Override
	public RepeatStatus execute(StepContribution arg0, ChunkContext chunkContext)
			throws Exception {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : FraudSubscribedAfterCountTasklet - execute ");
		}
		
		Map<String, Integer>  afterSubsFraudCt = fraudReportService.getAfterCountSubscribedICA();
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(SUBSCRIBED_AFTER_COUNT, afterSubsFraudCt);		
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit in method : FraudSubscribedAfterCountTasklet - execute ");
		}
		return RepeatStatus.FINISHED;
	}

}
