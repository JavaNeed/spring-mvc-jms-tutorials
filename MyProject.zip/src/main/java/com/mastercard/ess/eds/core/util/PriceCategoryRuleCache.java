package com.mastercard.ess.eds.core.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.dao.PriceCategoryDAO;
import com.mastercard.ess.eds.core.rule.PriceCategoryRule;

/**
 * To update the rules using PriceCategoryDAO with the help of Spring scheduler
 * 
 * @author E068303
 */

public class PriceCategoryRuleCache {

	private static Logger logger = Logger
			.getLogger(PriceCategoryRuleCache.class);

	@Autowired
	PriceCategoryDAO priceCategoryDao;
	
	private List<PriceCategoryRule> priceCatRuleCache;
	
	//for JUnit Test
		public void setPriceCategoryDAO(PriceCategoryDAO priceCategoryDao){
			this.priceCategoryDao = priceCategoryDao;
		}

	

	/**
	 * This method is scheduled to be run by spring scheduler for time interval
	 * as configured in scheduler.properties file
	 */
	public void updateCache() {

		if (logger.isDebugEnabled()) {
			logger.debug("PriceCategoryRuleCache | updateCache | Enter in method ");
		}

		priceCatRuleCache = priceCategoryDao.loadAllCategoryRules();

		if (logger.isDebugEnabled()) {
			logger.debug("PriceCategoryRuleCache | updateCache | Exit from method ");
		}
	}

	public List<PriceCategoryRule> getCache() {

		if (logger.isDebugEnabled()) {
			logger.debug("PriceCategoryRuleCache | getCache | Enter in method ");
		}
		List<PriceCategoryRule> rulesCache;
		if (null != priceCatRuleCache)
			{if (logger.isDebugEnabled()) {
				logger.debug("PriceCategoryRuleCache | Exit from method : getCache ");
			}
			rulesCache = getNewList(priceCatRuleCache);
		}
		else {
			updateCache();
			if (logger.isDebugEnabled()) {
				logger.debug("PriceCategoryRuleCache | Exit from method : getCache ");
			}
			rulesCache = getNewList(priceCatRuleCache);
		}
		return rulesCache;	
	}

	public Map<Integer, PriceCategoryRule> getPriceCategoryMap() {
		if (logger.isDebugEnabled()) {
			logger.debug("PriceCategoryRuleCache | getPriceCategoryMap | Enter in method ");
		}

		Map<Integer, PriceCategoryRule> rulesMap = new HashMap<Integer, PriceCategoryRule>();
		List<PriceCategoryRule> rules = getCache();
		
		for(PriceCategoryRule rule : rules) {
			rulesMap.put(rule.getPriceCategory(), rule);
		}
		
		if (logger.isDebugEnabled()) {
			logger.debug("PriceCategoryRuleCache | Exit from method : getPriceCategoryMap ");
		}

		return rulesMap;
	}
	
	/*
	 * Deep copy the list objects so each thread gets its own copy
	 */
	public List<PriceCategoryRule> getNewList(List<PriceCategoryRule> ruleList) {
		if (logger.isDebugEnabled()) {
			logger.debug("PriceCategoryRuleCache | getNewList | Enter in method ");
		}

		List<PriceCategoryRule> returnList  = new ArrayList<PriceCategoryRule>(ruleList.size());
		
		for(PriceCategoryRule rule : ruleList) {

			PriceCategoryRule copiedRule = new PriceCategoryRule(rule);
			if (logger.isDebugEnabled()) {
				logger.debug("Adding to return list rule name = " + rule.getName());
			}
			returnList.add(copiedRule);

		}
		if (logger.isDebugEnabled()) {
			logger.debug("PriceCategoryRuleCache | Exit from method : getNewList ");
		}
		
		logger.info("returning from getNewList");
		return returnList;
	}
}
