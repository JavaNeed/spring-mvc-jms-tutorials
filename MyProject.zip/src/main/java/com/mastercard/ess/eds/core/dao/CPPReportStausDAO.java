package com.mastercard.ess.eds.core.dao;

import java.math.BigDecimal;
import java.util.Date;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.util.EDSProcessStatus;
import static com.mastercard.ess.eds.constant.SQLConstants.*;

@Component
public class CPPReportStausDAO {

	@Value("${cppFile.loc}")
	private String fileLocation;

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private static final Logger logger = Logger.getLogger(CPPReportStausDAO.class);
	private SimpleJdbcInsert insertCPPReportDetails;
	


	public CPPReportStausDAO(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
		insertCPPReportDetails = new SimpleJdbcInsert(dataSource)
				.withTableName(EDS_GEN_RPT).usingColumns(EDS_GEN_RPT_SEQ,EDS_RPT_TYPE_ID,
						FILE_NAM, FILE_LOC_TXT, STAT_CD, CRTE_USER_ID, CRTE_DT
						, JOB_INSTNCE_ID);
	}

	public void writeCPPReportDetails(String filePath, BigDecimal jobInstanceId, String jobInstanceName) {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : writeCPPReportDetails : CPPReportStausDAO ");
		}
		
		String eds_grnt_rpt_id_seq = "select EDS_GRNT_RPT_ID_SEQ.nextval from dual";
		int fileId = jdbcTemplate.queryForObject(eds_grnt_rpt_id_seq, Integer.class);
		
		MapSqlParameterSource parameterSource = new MapSqlParameterSource();

		parameterSource.addValue(EDS_GEN_RPT_SEQ, fileId)
		        .addValue(EDS_RPT_TYPE_ID, Long.valueOf(3))
				.addValue(FILE_NAM, filePath.replace(fileLocation, ""))
				.addValue(FILE_LOC_TXT, fileLocation)
				.addValue(STAT_CD, EDSProcessStatus.GENERATED.getStatusCode())
				.addValue(CRTE_USER_ID, jobInstanceName)
				.addValue(CRTE_DT, new Date())
				.addValue(JOB_INSTNCE_ID, jobInstanceId);

		insertCPPReportDetails.execute(parameterSource);
		
		logger.info("Inserted CPP Details in EDS_GNRT_RPT_ID");

	}

}
