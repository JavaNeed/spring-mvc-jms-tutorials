package com.mastercard.ess.eds.core.service;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.dao.DWDao;

@Component
public class PANLastActivityService {

	// for JUnit test
	public PANLastActivityService(DWDao dwDao) {
		super();
		this.dwDao = dwDao;
	}

	@Autowired
	private DWDao dwDao;

	public Date getAuthRecord(String pan, java.util.Date createDate) {

		return dwDao.getAuthRecord(pan, createDate);
	}

	public Date getDebitRecord(String pan, java.util.Date createDate) {

		return dwDao.getDebitRecord(pan, createDate);
	}

	public Date getClearingRecord(String pan, java.util.Date createDate) {

		return dwDao.getClearingRecord(pan, createDate);
	}
}
