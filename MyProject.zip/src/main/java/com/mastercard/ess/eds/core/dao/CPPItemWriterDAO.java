package com.mastercard.ess.eds.core.dao;

import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.domain.CPPTxnInfo;


@Component
public class CPPItemWriterDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static Logger logger = Logger.getLogger(CPPItemWriterDAO.class);

	private static final String CPP_TRAN_INSERT = "INSERT INTO EDS_CPP_TRAN (EDS_CPP_TRAN_ID, PAN_NUM, LOC_TRAN_AMT,MERCH_LOC_ID, SEQ_NUM, MERCH_NAM,"
			+ " ISSR_CNTRY_CD, MERCH_CNTRY_CD, TRAN_CHNL_CD,TRAN_SRC_NAM, CRTE_USER_ID, CRTE_DT)values(EDS_CPP_TRAN_ID_SEQ.nextval,?,?,?,?,?,?,?,?,?,?,?)";

	private String jobInstanceName;

	public CPPItemWriterDAO(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
	}

	/**
	 * this method writes  merchant and other information
	 *  from the identified PAN to EDS_CPP_TRAN
	 */
	public void writeCppRecord(List<? extends CPPTxnInfo> cppTxnInfoRecords) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : writeCppRecord :CPPItemWriterDAO ");
		}
		
		logger.info("cppTxnInfoRecords size =" + cppTxnInfoRecords.size());
		
		for(CPPTxnInfo cppTxnInfo : cppTxnInfoRecords){
			if(cppTxnInfo != null){
				
				int rowsInserted= jdbcTemplate.update(CPP_TRAN_INSERT,
						new Object[] {cppTxnInfo.getPan(),cppTxnInfo.getTransactionAmount(),cppTxnInfo.getLocationId(),cppTxnInfo.getSequenceNumber(), 
						((StringUtils.isBlank(cppTxnInfo.getMerchantName())) ? "" : StringUtils.substring(cppTxnInfo.getMerchantName() , 0, 22)),cppTxnInfo.getIssuerCountryCode(),cppTxnInfo.getMerchantCountryCode(),cppTxnInfo.getTransactionChannel(),
								cppTxnInfo.getSource(),jobInstanceName,new Date()});

				if (logger.isDebugEnabled()) {
					logger.debug("Rows Inserted are =" + rowsInserted);
				}

			}

		}
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : writeCppRecord :CPPItemWriterDAO ");
		}
	}

	public void setJosetJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}

}
