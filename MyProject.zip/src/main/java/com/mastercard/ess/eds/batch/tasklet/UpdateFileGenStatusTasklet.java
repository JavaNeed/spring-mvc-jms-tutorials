package com.mastercard.ess.eds.batch.tasklet;

import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.batch.config.FileStatus;
import com.mastercard.ess.eds.batch.exception.EDSCoreException;
import com.mastercard.ess.eds.constant.BatchConstants;
import com.mastercard.ess.eds.core.service.CustomerMasterService;
import com.mastercard.ess.eds.core.service.LastBatchJobRunService;
import com.mastercard.ess.eds.domain.ICAStatus;

/**
 *  This class logs the status of all files in the application logs with error details
 * @author e070836
 * @version 1.0
 * @date : Mar 13 2018
 *
 */
public class UpdateFileGenStatusTasklet  implements Tasklet{

	private static Logger logger = Logger.getLogger(UpdateFileGenStatusTasklet.class);

	@Autowired
	private LastBatchJobRunService lastBatchJobRunService;
	
	@Autowired
	private CustomerMasterService customerMasterService ;
	
	private String jobInstanceName;
	private BigDecimal jobInstanceId;
	
	public String getJobInstanceName() {
		return jobInstanceName;
	}


	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}


	public BigDecimal getJobInstanceId() {
		return jobInstanceId;
	}


	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}

	/**
	 *  This method updates the last batch job date and prints the status of File , ICA and error details.
	 *   @param  arg0 , chunkContext
	 *  @return RepeatStatus 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext)
			throws Exception {

		logger.info("Enter into the UpdateFileExecutionStatus");
		boolean customerJobSuccess = true ;
		lastBatchJobRunService.updateLastBatchJobRun(jobInstanceName);
		
		List<ICAStatus> icaStatusList = (List<ICAStatus>) chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get("icaStatusList");
		String customerRunMode = (String) chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get("customerRunMode");
		
		List<String> updateHistIcas = (List<String>) chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get("updateHistIcas");
		
		if(icaStatusList!= null && !icaStatusList.isEmpty()){
	
			logger.info("********************************************************* Customer File Generation Status with date = Tue Mar 13 07:19:27 CDT 2018 *************************************");
			
			logger.info(String.format("%-10s %-50s %-20s %-20s %-10s %-80s"  , " ICA" , "File Name" , "File Generation" , "GFT Delivery" , "Error Code" , "Error Message"));
			
			customerJobSuccess = logFileGenerationOutput(icaStatusList , customerRunMode);
			
			logger.info("*************************************************************** Customer File Generation Status Ends *******************************************************************");
			
			if(!customerJobSuccess){
				throw new EDSCoreException("Customer file generation Job Failed");
			}
		}
		if(customerJobSuccess){
			customerMasterService.updateHistoryFlagForIcas(updateHistIcas, "N", jobInstanceName );
		}
		logger.info("Exit from UpdateFileExecutionStatus");
		
		return RepeatStatus.FINISHED;
	}

 
	/**
	 *  It logs the file generation and GFT transfer status of the customer generation file in application logs.
	 * @param icaStatusList
	 * @param customerRunMode
	 * @return
	 */
	private boolean logFileGenerationOutput(List<ICAStatus> icaStatusList , String customerRunMode) {
		String fileGenerated = null ;
		String gft_Deilvery = null ;
		String fileName = null ;
		String errorMessage = null ;
		String errorCode = null ;
		boolean customerSuccess = true ;
		
		for(ICAStatus icaStatus : icaStatusList){
			
			fileGenerated = getFileGenerated(icaStatus , customerRunMode) ;
			
			gft_Deilvery = getGFTDeilvery(icaStatus) ;
			
			fileName =   StringUtils.isNotBlank(icaStatus.getFileName()) ?  icaStatus.getFileName() : BatchConstants.NOT_AVAILABLE ;
			
			errorMessage = StringUtils.isNotBlank(icaStatus.getErrorDetails()) ?  icaStatus.getErrorDetails() : BatchConstants.NOT_APPLICABLE ;
			
			errorCode =  StringUtils.isNotBlank(icaStatus.getErrorCode()) ?  icaStatus.getErrorCode() : BatchConstants.NOT_APPLICABLE ;
			
			if(fileGenerated.equalsIgnoreCase(BatchConstants.FAILED) || gft_Deilvery.equalsIgnoreCase(BatchConstants.FAILED)){
				customerSuccess = false ;
			}
			
			logger.info(String.format("%-10s %-50s %-20s %-20s %-10s %-80s" , icaStatus.getIca() , fileName, fileGenerated , gft_Deilvery , errorCode ,errorMessage ));
		}
		
		return customerSuccess ;
		
	}

	/**
	 * This method populates the file generation status either SUCCESS or FAILURE or NOT applicable based on run mode and ica file status.
	 * @param icaStatus
	 * @param customerRunMode
	 * @return
	 */
	private String getFileGenerated(ICAStatus icaStatus , String customerRunMode) {
		
		if(StringUtils.isNotBlank(customerRunMode) && customerRunMode.equalsIgnoreCase(BatchConstants.MODE_GFT_FAILURE)){
			return BatchConstants.NOT_APPLICABLE ;
		} else{
			return ( icaStatus.getStatus().equalsIgnoreCase(FileStatus.GEN_FAILURE.getStatus())) ? BatchConstants.FAILED :BatchConstants.SUCCESS;
		}
	}

	/**
	 * This method populates the GFT delivery status based on the icaStatus object.
	 * @param icaStatus
	 * @return
	 */
	private String getGFTDeilvery(ICAStatus icaStatus) {
		String gftDeilvery = BatchConstants.SUCCESS ;
		if(StringUtils.isNotBlank(icaStatus.getStatus())){
			if(icaStatus.getStatus().equalsIgnoreCase(FileStatus.GEN_FAILURE.getStatus())){
				gftDeilvery = BatchConstants.NOT_APPLICABLE ;
			}else if (icaStatus.getStatus().equalsIgnoreCase(FileStatus.GFT_FAILURE.getStatus())){
				gftDeilvery =  BatchConstants.FAILED ;
			}
		}
		
		return gftDeilvery;
		 
	}

	public void setLastBatchJobRunService(LastBatchJobRunService lastBatchJobRunService) {
		this.lastBatchJobRunService = lastBatchJobRunService;
	} 

	 
	
}
