package com.mastercard.ess.eds.core.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.mastercard.ess.eds.domain.CustomerEnrollmentReport;

public class CustomerEnrollmentReportRowMapper implements RowMapper<CustomerEnrollmentReport> {
	
	private static Logger logger = Logger.getLogger(CustomerEnrollmentReportRowMapper.class);
	
	private static final String EDS_CUST_ENRL_RPT_ID = "EDS_CUST_ENRL_RPT_ID";
	private static final String ISSR_REGN_CD = "ISSR_REGN_CD";
	private static final String ACTV_CUST_CNT = "ACTV_CUST_CNT";
	private static final String ENRL_CUST_CNT = "ENRL_CUST_CNT";
	private static final String UN_ENRL_CUST_CNT = "UN_ENRL_CUST_CNT";
	private static final String CRTE_DT = "CRTE_DT";

	@Override
	public CustomerEnrollmentReport mapRow(ResultSet paramResultSet, int paramInt) throws SQLException {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : mapRow ");
		}
		
		CustomerEnrollmentReport customerEnrollmentReport = new CustomerEnrollmentReport();
		customerEnrollmentReport.setCustomerEnrollmentReportId(paramResultSet.getBigDecimal(EDS_CUST_ENRL_RPT_ID).intValueExact());
		customerEnrollmentReport.setActiveCust(paramResultSet.getBigDecimal(ACTV_CUST_CNT).intValueExact());
		customerEnrollmentReport.setEnrolledCust(paramResultSet.getBigDecimal(ENRL_CUST_CNT).intValueExact());
		customerEnrollmentReport.setUnEnrolledCust(paramResultSet.getBigDecimal(UN_ENRL_CUST_CNT).intValueExact());
		customerEnrollmentReport.setCode(paramResultSet.getString(ISSR_REGN_CD));
		customerEnrollmentReport.setDateCreated(paramResultSet.getDate(CRTE_DT));
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : mapRow ");
		}
		
		return customerEnrollmentReport;
	}

}
