package com.mastercard.ess.eds.core.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.dao.DWDao;
import com.mastercard.ess.eds.core.dao.EDSCPPRulesDao;
import com.mastercard.ess.eds.domain.AuthDebitPanDetailRecord;
import com.mastercard.ess.eds.domain.CPPRuleRecord;

@Component
public class EDSCPPRulesService {

	public static final String Y ="Y";
	
	@Autowired
	EDSCPPRulesDao edsCPPRulesDao;

	@Autowired
	private DWDao dwDao;

	// for JUnit test
	public EDSCPPRulesService(DWDao dwDao) {
		super();
		this.dwDao = dwDao;
	}

	public EDSCPPRulesService() {
		super();
	}

	public DWDao getDwDao() {
		return dwDao;
	}

	public void setDwDao(DWDao dwDao) {
		this.dwDao = dwDao;
	}


	// for Junit
	public void setDao(EDSCPPRulesDao edsCPPRulesDao) {
		this.edsCPPRulesDao = edsCPPRulesDao;
	}

	public void updateCPPSrcStatusPostProcessing(String cppSrcName,
			String jobInstanceName, int status) {
		edsCPPRulesDao.updateCPPSrcStatusPostProcessing(cppSrcName,
				jobInstanceName,status);
	}

	public void updateFirstRunSW(String jobInstanceName, List<String> cppRuleIdList) {
		edsCPPRulesDao.updateFirstRunSW(jobInstanceName,cppRuleIdList);
	}

	public CPPRuleRecord getCPPRulesByRuleId(int cppRuleId) {
		return edsCPPRulesDao.getCPPRulesByRuleId(Y,cppRuleId);

	}

	public  List<Integer> getCPPRuleIds(String cppRunMode) {
		return edsCPPRulesDao.getCPPRuleIds(cppRunMode);
	}

	/*It will take CPPRuleRecord as input and returns Auth reocrds from DW database*/
	public List<AuthDebitPanDetailRecord> getAuthRecordsByRule(CPPRuleRecord cPPRuleRecord, String runCppRuleForDays) {
		return dwDao.getAuthRecordsByRule(cPPRuleRecord,runCppRuleForDays);
	}

	/*It will take CPPRuleRecord as input and returns Debit reocrds from DW database*/
	public List<AuthDebitPanDetailRecord> getDebitRecordsByRule(CPPRuleRecord cPPRuleRecord,String runCppRuleForDays) {
		return dwDao.getDebitRecordsByRule(cPPRuleRecord,runCppRuleForDays);
	}
	
	public void updateSimulationFlag(String jobInstanceName, String simSrcId) {
		edsCPPRulesDao.updateSimulationFlag(jobInstanceName  , simSrcId);
	}
}
