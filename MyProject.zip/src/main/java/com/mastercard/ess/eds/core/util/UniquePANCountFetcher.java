package com.mastercard.ess.eds.core.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.mastercard.ess.eds.batch.scheduler.CPPReportGenerationScheduler;
import com.mastercard.ess.eds.core.dao.UniquePANFetchDAO;

public class UniquePANCountFetcher implements Tasklet, StepExecutionListener {

	private Logger logger = Logger.getLogger(UniquePANCountFetcher.class);

	@Autowired
	UniquePANFetchDAO uniquePANFetchDAO;
	
	@Autowired
	CPPReportGenerationScheduler cppReportGenerationScheduler;
	
	@Value("${cpp.taskdir}")
	private String jobDIR;
 

	// for Junit
	public UniquePANCountFetcher(UniquePANFetchDAO uniquePANFetchDAO) {
		this.uniquePANFetchDAO = uniquePANFetchDAO;
	}
	public void setJobDIR(String jobDIR) {
		this.jobDIR = jobDIR;
	}

	public UniquePANCountFetcher(UniquePANFetchDAO uniquePANFetchDAO,
			CPPReportGenerationScheduler cppReportGenerationScheduler) {
		this.cppReportGenerationScheduler = cppReportGenerationScheduler;
		this.uniquePANFetchDAO = uniquePANFetchDAO;
	}

	public UniquePANCountFetcher() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public RepeatStatus execute(StepContribution arg0, ChunkContext arg1) {

		logger.info("UniquePANCountFetcher launched");
		final String zeroGroupJob = "getUniquePanCountWithTxnAmt.dxj";
		final String firstGroupJob = "getUniquePanCountWithoutTxnAmt.dxj";
		final String secondGroupJob = "getDistinctPansCount.dxj";

		List<String> jobList = new ArrayList<String>();
		jobList.add(zeroGroupJob);
		jobList.add(firstGroupJob);
		jobList.add(secondGroupJob);

		executeDMXJob(jobList, jobDIR);

		// executeDMXJob(firstGroupJob, jobDIR);

		// executeDMXJob(secondGroupJob, jobDIR);

		return RepeatStatus.FINISHED;
	}

	// ensure Exec_DMXJob.sh is in PATH variable
	private void executeDMXJob(List<String> jobList, String jobDIR) {

		for (String job : jobList) {
			ProcessBuilder procBuilder = new ProcessBuilder("Exec_DMXJob.sh", "-a", jobDIR, "-j", job);
			try {
				Process proc = procBuilder.start();
				int exitStatus = proc.waitFor();

				logger.info("Process Builder completed with exit status --" + exitStatus);
				if (0 == exitStatus) {
					logger.info("Exec_DMXJob.sh successfully executed for job - " + job);
					truncateTempTable();
					logger.info("EDS_CPP_TRAN_TEMP truncated succesfully");
				}

				else {

					logger.info("Exec_DMXJob.sh could not be successfuly executed for job - " + job
							+ ". EDS_CPP_TRAN_TEMP not truncated.");

				}

			} catch (InterruptedException | IOException ie) {
				logger.error("Process executing Exec_DMXJob.sh interrupted/IOException occured " + ie);
			}
		}

	}

	private void truncateTempTable() {
		uniquePANFetchDAO.truncate();

	}

	@Override
	public ExitStatus afterStep(StepExecution arg0) {
		logger.info("Truncating EDS_CPP_TRAN_TEMP after step");
		uniquePANFetchDAO.truncate();
		cppReportGenerationScheduler.run();
		return ExitStatus.COMPLETED;
	}

	@Override
	public void beforeStep(StepExecution arg0) {
		logger.info("Truncating EDS_CPP_TRAN_TEMP before step");
		uniquePANFetchDAO.truncate();

	}

}
