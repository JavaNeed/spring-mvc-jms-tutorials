package com.mastercard.ess.eds.batch.processor;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.service.DerivedExternalService;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.ProcessedRecord;
import com.mastercard.ess.eds.domain.RawRecord;


public class DerivedExternalProcessor implements
		ItemProcessor<EDSRecord, EDSRecord> {

	private static Logger logger = Logger.getLogger(DerivedExternalProcessor.class);
	
	@Autowired
    private  DerivedExternalService derivedExternalService;

	public DerivedExternalProcessor(DerivedExternalService derivedExternalService) {
		super();
		this.derivedExternalService = derivedExternalService;
	}

	@Override
	public EDSRecord process(EDSRecord edsRecord) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("enter in method : process ");
		}
		long startTime = System.currentTimeMillis();
		ProcessedRecord processedRecord = edsRecord.getProcRecord();
		RawRecord rawRecord = edsRecord.getRawRecord();
		logger.info("source data key = " +rawRecord.getSrc_data_ky() + ", rawRecord.getDerivedSw =  " + rawRecord.getDerivedSw());
		if(rawRecord.getDerivedSw().equalsIgnoreCase("Y")){
			derivedExternalService.updateExternalDerivedForPricingCategory(rawRecord.getSrc_data_ky(), processedRecord);
		} else {
			processedRecord.setIsDerived("N");
			processedRecord.setIsExternal("Y");
		}
		edsRecord.setProcRecord(processedRecord);
		
		logger.info("DerivedExternalProcessor total exec time = " + ((System.currentTimeMillis() - startTime)));
		if (logger.isDebugEnabled()) {
			logger.debug("exiting method : process ");
		}
		return edsRecord;
	}

}
