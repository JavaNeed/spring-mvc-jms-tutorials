package com.mastercard.ess.eds.core.dao;

import static com.mastercard.ess.eds.constant.SQLConstants.CRTE_DT;
import static com.mastercard.ess.eds.constant.SQLConstants.CRTE_USER_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.EDS_CPP_SIM_SRC;
import static com.mastercard.ess.eds.constant.SQLConstants.JOB_INSTANCE_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.SIM_SRC_ID;
import static com.mastercard.ess.eds.constant.SQLConstants.SRC_NAM;
import static com.mastercard.ess.eds.constant.SQLConstants.STAT_CD;
import static com.mastercard.ess.eds.constant.SQLQueries.FETCH_EDS_SIM_SRC_ID;
import static com.mastercard.ess.eds.constant.SQLQueries.UPDATE_CPP_SIM_SRC;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.util.EDSProcessStatus;

/**
 *  This dao class has the CRUD operation for EDS_CPP_SIM_SRC table.
 * @author e070836
 * @version 1.0
 * @date : Dec 29, 2017
 */

@Component
public class CPPSimulationSourceDAO {


	private static Logger logger = Logger.getLogger(CPPSimulationSourceDAO.class);
	
	private SimpleJdbcInsert edsSimulationInsert;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public CPPSimulationSourceDAO(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
		
		edsSimulationInsert = new SimpleJdbcInsert(dataSource).withTableName(EDS_CPP_SIM_SRC).usingColumns(SIM_SRC_ID,
				SRC_NAM, STAT_CD, CRTE_USER_ID, CRTE_DT, JOB_INSTANCE_ID);
	}

	/**
	 *  This method inserts a record in EDS_CPP_SIM_SRC table.
	 * @param fileName
	 * @param jobName
	 * @param jobInstanceID
	 * @param status
	 * @return
	 */
	public String createSimulationSource(String fileName, String jobName,
			BigDecimal jobInstanceID, int status) {

		logger.info("Enter into the method createSimulationSource");
		int uniqueId = 0 ; 
		MapSqlParameterSource parameterSource = new MapSqlParameterSource();
		parameterSource.addValue(SIM_SRC_ID, jdbcTemplate.queryForObject("select EDS_CPP_SIM_SRC_ID_SEQ.nextval from dual" , Integer.class)).addValue(SRC_NAM, fileName).addValue(STAT_CD, status)
		.addValue(CRTE_USER_ID, jobName).addValue(CRTE_DT, new Date()).addValue(JOB_INSTANCE_ID, jobInstanceID);
		
		edsSimulationInsert.execute(parameterSource);

		logger.info("Exit from the method createSimulationSource");

		return  Integer.toString(uniqueId);
	}

	/**
	 *  This method update the status of source record either 2 or 5 in EDS_CPP_SIM_SRC table.
	 *  2 - Error
	 *  5 - Sucess
	 * @param cppSrcName
	 * @param jobInstanceName
	 * @param status
	 */
	public void updateSimulationSourcePostProcessing(String cppSrcName , String jobInstanceName,
			int status) {
		logger.info("Enter into the method updateSimulationSourcePostProcessing");
		
		int processedStatus=0;
		 
		if (2==status) {
			processedStatus = EDSProcessStatus.ERROR.getStatusCode();
		}
		else {
			processedStatus = EDSProcessStatus.PROCESSED.getStatusCode();
		}
		int unprocessedStatus = EDSProcessStatus.UNPROCESSED.getStatusCode();
		Timestamp date = new java.sql.Timestamp(System.currentTimeMillis());

		jdbcTemplate.update(UPDATE_CPP_SIM_SRC, processedStatus, date, jobInstanceName, unprocessedStatus,cppSrcName);
		
		logger.info("exit from the method updateSimulationSourcePostProcessing");
	}

	public String getSimulationSrcId(String srcName) {

		String edsSimulationSrcId = jdbcTemplate.queryForObject(FETCH_EDS_SIM_SRC_ID,String.class,srcName);		
		
		return edsSimulationSrcId;
	}

	 

}
