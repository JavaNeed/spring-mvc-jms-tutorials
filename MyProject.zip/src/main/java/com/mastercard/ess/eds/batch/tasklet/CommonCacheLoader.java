package com.mastercard.ess.eds.batch.tasklet;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.batch.config.CommonCacheTokens;
import com.mastercard.ess.eds.core.service.EDSRecordWriterService;
import com.mastercard.ess.eds.core.util.EDSSourceRuleDataCache;
import com.mastercard.ess.eds.core.util.PANAccountRangeCache;

/**
 * This class loads data in edsSourceRuleDataCache and panAccountRangeCache. 
 * edsSourceRuleDataCache is populated from eds_src_rule_data table, the category code is fetched from eds_cpp_rule table for respective rules.
 * panAccountRangeCache is populated from MPS_AUTH_ACCT_RNG table, contains the account ranges for ICAs.
 * @author E076119
 *
 */
public class CommonCacheLoader implements Tasklet{

	@Autowired
	EDSRecordWriterService edsRecordWriterService;
	
	@Autowired
	EDSSourceRuleDataCache edsSourceRuleDataCache;
	
	@Autowired
	PANAccountRangeCache panAccountRangeCache;
	
	private Logger logger = Logger.getLogger(CommonCacheLoader.class);
			
	public EDSRecordWriterService getEdsRecordWriterService() {
		return edsRecordWriterService;
	}

	public void setEdsRecordWriterService(
			EDSRecordWriterService edsRecordWriterService) {
		this.edsRecordWriterService = edsRecordWriterService;
	}
	
	/**
	 * Method to load data in edsSourceRuleDataCache and panAccountRangeCache. 
	 * The start and end index for records to be processed are put in the execution context to be picked up by the pan process partitioner.
	 */
	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext)
			throws Exception {

		//Fetching min and max value of EDSSrcDataId for setting start index and end index. startIndex endIndex
		Map<String, Object> map = edsRecordWriterService.getIndexesForEDSSrcDataId();
		Long startIndex = 0l;
		Long endIndex =  0l;
		boolean isCacheUpdated = false;
		if (map!=null && map.size()>0 && map.get(CommonCacheTokens.START_INDEX.getDesc())!=null && map.get(CommonCacheTokens.END_INDEX.getDesc())!=null) {
			
			startIndex = new Long(map.get(CommonCacheTokens.START_INDEX.getDesc()).toString());
			endIndex = new Long(map.get(CommonCacheTokens.END_INDEX.getDesc()).toString());
			logger.info("Map size is = "+map.size() + ", Start index = " + startIndex + ", End index = " + endIndex);
			/**
			 * edsSourceRuleDataCache is populated from eds_src_rule_data table, the category code is fetched from eds_cpp_rule table for respective rules.
			 * The key is src_data_id and the value will be an object containing the rule id and category code.
			 * This cache will be queried to check if the pan was fetched by cpp execution or received from vendor.
			 */
			edsSourceRuleDataCache.bulkInsert(edsRecordWriterService.getEDSSrcRuleData(startIndex, endIndex));
			
			/**
			 * panAccountRangeCache is populated from MPS_AUTH_ACCT_RNG table, contains the account ranges for ICAs.
			 * The batch fails if the cache is not loaded.
			 */
			isCacheUpdated = panAccountRangeCache.loadPanAccRangeCache();
			
						
		} else {
			isCacheUpdated = true;
			logger.info("Nothing to process.");
		}
		/**
		 * If cache is not updated, set step and job exit status as FAILED
		 */
		if(!isCacheUpdated){
			stepContribution.setExitStatus(new ExitStatus("FAILED"));
			chunkContext.getStepContext().getStepExecution().getJobExecution().setStatus(BatchStatus.FAILED);
		} else {
			chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(CommonCacheTokens.START_INDEX.getDesc(), startIndex);
			chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(CommonCacheTokens.END_INDEX.getDesc(), endIndex);
		}
		return RepeatStatus.FINISHED;
	}

}
