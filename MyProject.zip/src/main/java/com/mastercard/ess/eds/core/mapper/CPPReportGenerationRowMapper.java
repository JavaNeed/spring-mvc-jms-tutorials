package com.mastercard.ess.eds.core.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.mastercard.ess.eds.domain.CPPReportInfo;

public class CPPReportGenerationRowMapper implements RowMapper<CPPReportInfo> {

	private static Logger logger = Logger.getLogger(CPPAuthTxnInfoRowMapper.class);

	@Override
	public CPPReportInfo mapRow(ResultSet paramResultSet, int paramInt) throws SQLException {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : mapRow | CPPAuthTxnInfoRowMapper ");
		}
		CPPReportInfo cppReportInfo = new CPPReportInfo();
		if (null != paramResultSet) {
			setTransactionAndLocation(paramResultSet, cppReportInfo);
			setMerchantPanCountryInfo(paramResultSet, cppReportInfo);

		}
		return cppReportInfo;
	}

	/**
	 * @param paramResultSet
	 * @param cppReportInfo
	 * @throws SQLException
	 */
	private void setMerchantPanCountryInfo(ResultSet paramResultSet,
			CPPReportInfo cppReportInfo) throws SQLException {
		if (null != paramResultSet.getString("MERCH_NAM"))
			cppReportInfo.setMerchantName(paramResultSet.getString("MERCH_NAM"));
		if (null != paramResultSet.getString("ISSR_CNTRY_CD"))
			cppReportInfo.setIssuerCountryCode(paramResultSet.getString("ISSR_CNTRY_CD"));
		if (null != paramResultSet.getString("MERCH_CNTRY_CD"))
			cppReportInfo.setMerchantCountryCode(paramResultSet.getString("MERCH_CNTRY_CD"));
		if (null != paramResultSet.getString("GRP_ID"))
			cppReportInfo.setGroupId(paramResultSet.getInt("GRP_ID"));
		if (null != paramResultSet.getString("UNQ_PAN_CNT"))
			cppReportInfo.setCardsUsedCount(paramResultSet.getLong("UNQ_PAN_CNT"));
	}

	/**
	 * @param paramResultSet
	 * @param cppReportInfo
	 * @throws SQLException
	 */
	private void setTransactionAndLocation(ResultSet paramResultSet,
			CPPReportInfo cppReportInfo) throws SQLException {
		if (null != paramResultSet.getString("TRAN_CHNL_CD"))
			cppReportInfo.setTransactionChannel(paramResultSet.getString("TRAN_CHNL_CD"));
		if (null != paramResultSet.getString("LOC_TRAN_AMT"))
			cppReportInfo.setLocalTransactionAmount(new Float(paramResultSet.getString("LOC_TRAN_AMT")));
		if (null != paramResultSet.getString("MERCH_LOC_ID"))
			cppReportInfo.setLocationId(Long.toString(paramResultSet.getLong("MERCH_LOC_ID")));
	}
}
