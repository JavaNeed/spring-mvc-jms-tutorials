package com.mastercard.ess.eds.core.events;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.notification.events.Receiver;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;
/**
 * To send the event for which mail needs to be sent 
 * 
 * @author E068303
 */
@Component
public class EventPublisher {
	private static Logger logger = Logger.getLogger(EventPublisher.class);
	/**
	 * This is name of the Channel specified in the email-integration-context.xml
	 */
	@Autowired
	MessageChannel eventReceiverInputQueue;
	@Autowired
	Receiver receiver;
	
	
	/**
	 * This is for JUnit Purpose
	 * @param input
	 * @param receiver
	 */
	public EventPublisher(MessageChannel input, Receiver receiver) {
		this.eventReceiverInputQueue = input;
		this.receiver = receiver;
	}
	public EventPublisher() {
	super();
	}
	/**
	 * this method is called when ever an event has happened
	 * @param notificationEventVO
	 */
	
	public void placeEvent(NotificationEventVO notificationEventVO) {
		
		if (logger.isDebugEnabled()) {
			logger.debug("EventPublisher | placeEvent | Enter in method");
		}
		logger.info("EventPublisher | placeEvent | Enter in method");
		try {
			
			 Message<?> message = new GenericMessage<NotificationEventVO>(notificationEventVO);
			 /**
			  * Send the Event Message to the EventInputQueue
			  */
			 if(eventReceiverInputQueue.send(message)) {
				 logger.info("Message was sent to the eventReceiverInputQueue Sucessfully" + notificationEventVO.getEventName());
			 } else {
				 logger.error("Message was NOT sent to the eventReceiverInputQueue");
			 }
			 //TBD : commented to test
			//receiver.receiveEvent();
			
		} catch (Exception e) {
			logger.error("Exception in  EventPublisher | placeEvent :",e);
		}
		
		logger.info("EventPublisher | placeEvent | Exit from method ");
	}

}
