package com.mastercard.ess.eds.batch.validator;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.ValidatorFactory;

import org.apache.log4j.Logger;
import org.springframework.batch.item.validator.ValidationException;
import org.springframework.batch.item.validator.Validator;
import org.springframework.beans.factory.InitializingBean;

import com.mastercard.ess.eds.domain.RawRecord;

public class RawRecordValidator implements Validator<RawRecord>, InitializingBean {

    private static Logger logger = Logger.getLogger(RawRecordValidator.class);

    private javax.validation.Validator validator;

    @Override
    public void afterPropertiesSet() {
        logger.info("RawRecordValidator : afterPropertiesSet");
        ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
        validator = validatorFactory.usingContext().getValidator();
        logger.info("javax.validation.Validator : " + validator);
    }

    @Override
    public void validate(RawRecord value) {

        logger.info("RawRecordValidator : VALIDATE");
        Set<ConstraintViolation<RawRecord>> constraintViolations = validator.validate(value);

        if (!constraintViolations.isEmpty()) {
            buildValidationException(constraintViolations);
        }
        String rawPan = value.getRawPan();

        validateMod10Algorithm(rawPan);
    }

    private void buildValidationException(Set<ConstraintViolation<RawRecord>> constraintViolations) {
        StringBuilder message = new StringBuilder();

        for (ConstraintViolation<RawRecord> constraintViolation : constraintViolations) {
            message.append(constraintViolation.getMessage());
            message.append("\n");
        }

        throw new ValidationException(message.toString());
    }

    private void validateMod10Algorithm(String pan) throws ValidationException {
        logger.debug("Enter into the method validateMod10Algorithm");
        int sum = 0;
        pan = pan.replace(" ", "");
        boolean flag = false;
        for (int i = pan.length() - 1; i >= 0; i--) {
            try {
                int digit = Integer.parseInt(pan.substring(i, i + 1));
                digit = (flag) ? digit * 2 : digit;
                digit = (digit > 9) ? (digit % 10) + 1 : digit;
                sum += digit;
                flag = !flag;
            } catch (NumberFormatException e) {
                throw new ValidationException("MOD-10 Check Failed");
            }
        }
        if (sum % 10 != 0) {
            throw new ValidationException("MOD-10 Check Failed");
        }
        logger.debug("Exit from the method validateMod10Algorithm");
    }
}
