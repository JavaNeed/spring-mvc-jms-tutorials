package com.mastercard.ess.eds.core.util;

public enum DeDupeTokens {

	DE_DUPE_PAN ("DeDupePan"),
	PAN_RULE_MAP ("panRuleMap"),
	LEVEL_1 ("1"),
	LEVEL_2 ("2"),
	LEVEL_2_SRC ("src"),
	LEVEL_2_PRCSS ("prcss"),
	LEVEL_ALL ("ALL"),
	TYPE("type"),
	LOAD ("load"),
	PROCESS ("process"),
	SOURCE ("source"),
	INTERNAL ("I"),
	EXTERNAL("E"),
	DUPLICATE_Y ("Y"),
	DUPLICATE_N ("N"),
	PRCSS_REGION ("PANDataFromPROCESSData"),
	SRC_REGION ("PANDataFromSRCData"),
	RESULT ("result"),
	EDS_SRC_DATA_ID ("EDS_SRC_DATA_ID"),
	SENT ("SENT"),
	NOTSENTVENDOR ("NOTSENTVENDOR"),
	NOTSENTCPP ("NOTSENTCPP")
	;
	
	
	private String desc;

	public String getDesc() {
		return desc;
	}

	private DeDupeTokens(String desc){
		this.desc = desc;
	}
}
