package com.mastercard.ess.eds.core.rule;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import org.apache.log4j.Logger;
import org.easyrules.core.BasicRule;

import com.mastercard.ess.eds.domain.EDSSourceType;
import com.mastercard.ess.eds.domain.ProcessedRecord;

/**
 * This rule class works on easy rules annotations. It checks for a condition
 * and only if that is true, will trigger an action
 * 
 * @author E068303
 */

public class PriceCategoryRule extends BasicRule {

	private static Logger logger = Logger.getLogger(PriceCategoryRule.class);
	private EDSSourceType recordSourceType;
	private String external;
	private String derived;

	private String adcNotified;
	private LocalDate startDate;
	private LocalDate endDate;
	private int confidenceScore;
	private int pricingCategory;
	private BigDecimal operandOne;
	private BigDecimal operandTwo;

	private String operatorOne;
	private String operatorTwo;
	private ProcessedRecord processedRecord;
	private boolean conditionOne = false;
	private boolean conditionTwo = false;
	private boolean conditionThree = false;
	private boolean conditionFour = false;
	private boolean checkDateValue = false;
	private boolean isEmptyCondition = false;
	private int lastActivity;
	private int procRecordConfidenceScore;
	private String adcNotifiedStatus;
	private String externalStatus;
	private String derivedStatus;

	private LocalDate currentDate;
	private ZoneId defaultZoneId = ZoneId.systemDefault();

	private String confidenceText;
	private String activityText;

	private static final String LESSERTHAN = "<";
	private static final String GREATERTHAN = ">";
	private static final String EQUALSTO = "=";
	private static final String FLAGYES = "Y";
	private static final String FLAGNO = "N";

	private static final String FOR_PAN="for_pan=";

	public PriceCategoryRule() {
		super();
	}

	public PriceCategoryRule(String name) {
		super(name);
	}

	public PriceCategoryRule(PriceCategoryRule rule) {
		super(rule.getName(), rule.getDescription(), rule.getPriority());
		this.adcNotified = rule.adcNotified;
		this.startDate = rule.startDate;
		this.endDate = rule.endDate;
		this.confidenceScore = rule.confidenceScore;
		this.pricingCategory = rule.pricingCategory;
		this.operandOne = rule.operandOne;
		this.operandTwo = rule.operandTwo;
		this.operatorOne = rule.operatorOne;
		this.operatorTwo = rule.operatorTwo;
		this.conditionOne = rule.conditionOne;
		this.conditionTwo = rule.conditionTwo;
		this.conditionThree = rule.conditionThree;
		this.conditionFour = rule.conditionFour;
		this.checkDateValue = rule.checkDateValue;
		this.isEmptyCondition = rule.isEmptyCondition;
		this.lastActivity = rule.lastActivity;
		this.procRecordConfidenceScore = rule.procRecordConfidenceScore;
		this.adcNotifiedStatus = rule.adcNotifiedStatus;
		this.currentDate = rule.currentDate;
		this.defaultZoneId = rule.defaultZoneId;
		this.confidenceText = rule.confidenceText;
		this.activityText = rule.activityText;
		this.external = rule.external;
		this.derived = rule.derived;
		this.recordSourceType = rule.recordSourceType;
		this.externalStatus = rule.externalStatus;
		this.derivedStatus = rule.derivedStatus;
	}

	public String getConfidenceText() {
		return confidenceText;
	}

	public void setConfidenceText(String confidenceText) {
		this.confidenceText = confidenceText;
	}

	public String getActivityText() {
		return activityText;
	}

	public void setActivityText(String activityText) {
		this.activityText = activityText;
	}

	public int getPriceCategory() {

		return this.pricingCategory;
	}

	/**
	 * This function is to identify the operand and operator from the DB and
	 * accordingly helps in finding the rule to be applied for the PAN records
	 * 
	 * @param operator
	 * @param operand
	 * @param procValue
	 * @return boolean
	 */
	public boolean checkOperator(String operator, int operand, int procValue) {

		if (lesserThanOperatorCheck(operator, operand, procValue)
				|| greaterThanOperatorCheck(operator, operand, procValue)) {
			return true;
		} else if (lesserThanOperatorCheck(operator, operand, procValue)
				|| greaterThanOperatorCheck(operator, operand, procValue)
				|| equalsThanOperatorCheck(operator, operand, procValue)) {
			return true;
		} else
			return false;
	}

	boolean lesserThanOperatorCheck(String operator, int operand, int procValue) {

		return LESSERTHAN.equals(operator) && procValue < operand;
	}

	boolean greaterThanOperatorCheck(String operator, int operand, int procValue) {

		return GREATERTHAN.equals(operator) && procValue > operand;
	}

	boolean equalsThanOperatorCheck(String operator, int operand, int procValue) {

		return EQUALSTO.equals(operator) && procValue == operand;
	}

	/**
	 * This function checks if the rule's external field and the pan source
	 * type's external field are the same or not
	 * 
	 * @param external
	 * @param isexternal
	 * @return
	 */
	private boolean checkIsExternal(String external, String isexternal) {
		logger.info("checkIsExternal evaluating rule ="+ this.name+ FOR_PAN+ getMaskedAccountNumber((null == this.processedRecord) ? ""
				: "" + this.processedRecord.getPan()) + ", external ="+ external + ", isexternal=" + isexternal);
		return external.equalsIgnoreCase(isexternal);

	}

	/**
	 * 
	 * This function checks if the rule's derived field and the pan source
	 * type's derived field are the same or not
	 * 
	 * @param derived
	 * @param isderived
	 * @return
	 */
	private boolean checkIsDerived(String derived, String isderived) {
		logger.info("checkIsExternal evaluating rule ="+ this.name+ FOR_PAN+ getMaskedAccountNumber((null == this.processedRecord) ? ""
				: "" + this.processedRecord.getPan()) + ", derived ="+ derived + ", isderived=" + isderived);
		return derived.equalsIgnoreCase(isderived);
	}

	/**
	 * This function is for getting the EDSSourceType object and setting it
	 * locally
	 * 
	 * @param recordSourceType
	 */
	public void setRecordSourceType(EDSSourceType recordSourceType) {
		this.recordSourceType = recordSourceType;

	}

	/**
	 * This function is where the condition is tested as part of easy rules
	 * framework
	 * 
	 * @return boolean : explain what the return does...
	 */
	@Override
	public boolean evaluate() {
		logger.info("evaluating rule =" + this.name+ ", received isExternal = " + this.externalStatus+ ", isDerived=" + this.derivedStatus);
		/*
		 * to check which criteria does last active date of the PAN comes into
		 */
		lastActivity();
		conditionThree = checkIsExternal(external, this.externalStatus);
		conditionFour = checkIsDerived(derived, this.derivedStatus);
		if (conditionOne && conditionTwo && conditionThree) {
			/*
			 * To check the ADC notification status
			 */
			if (conditionFour && adcNotified.equals(adcNotifiedStatus)) {
				logger.info("rule result=true for rule " + " conditionThree = "
						+ conditionThree + ", conditionFour=" + conditionFour
						+ " conditionOne" + conditionOne + "conditionTwo"
						+ conditionTwo);
				return true;
			}


		}

		logger.info("rule result=false for rule"+ " conditionThree = "	+ conditionThree + ", conditionFour=" + conditionFour + 
				" conditionOne" + conditionOne + "conditionTwo"+ conditionTwo);
		return false;
	}

	/**
	 * 
	 */
	private void lastActivity() {
		if (isEmptyCondition) {
			logger.info("setting last activity - both conditions to true");
			conditionOne = true;
			conditionTwo = true;
		} else if (conditionOne && conditionTwo) {
			conditionOne = checkOperator(operatorOne, operandOne.intValue(),lastActivity);
			conditionTwo = checkOperator(operatorTwo, operandTwo.intValue(),lastActivity);
			logger.info("lastActivity=" + lastActivity +", operatorOne =" + operatorOne + ", operandOne=" + operandOne.intValue()
					+ ", operatorTwo="+ operatorTwo + ", operandTwo=" + operandTwo.intValue());
		}
		else if (conditionOne) {
			conditionOne = checkOperator(operatorOne, operandOne.intValue(),lastActivity);
			conditionTwo = true;
			logger.info("lastActivity=" + lastActivity +", operatorOne =" + operatorOne + ", operandOne=" + operandOne.intValue());
		} else if (conditionTwo) {
			conditionTwo = checkOperator(operatorTwo, operandTwo.intValue(),lastActivity);
			conditionOne = true;
			logger.info("lastActivity=" + lastActivity +", operatorTwo="+ operatorTwo + ", operandTwo=" + operandTwo.intValue());
		}
	}

	/*
	 * This function will be executed if the @condition is satisfied (returns
	 * true)
	 */

	@Override
	public void execute() {
		logger.info("set Confidence Score=" + confidenceScore + ", confidence text=" + getConfidenceText() + ", activity text=" + getActivityText());
		processedRecord.setConfidenceScore(confidenceScore);
		processedRecord.setConfidenceText(getConfidenceText());
		processedRecord.setActivityText(getActivityText());

		/*
		 * To ensure that the confidence score is set only if it is not
		 * adcNotified and confidence score is not set already
		 */

		if (FLAGNO.equalsIgnoreCase(adcNotifiedStatus)) {
			confidenceScore();
		} else if (FLAGYES.equalsIgnoreCase(adcNotifiedStatus)) {
			processedRecord.setPriceCategory(pricingCategory);
			logger.info("2. for rule ="+ this.name+ FOR_PAN+ getMaskedAccountNumber((null == this.processedRecord
					.getPan()) ? "" : ""+ this.processedRecord.getPan())+ ", set priceCategory= " + pricingCategory);
		}
	}

	/**
	 * 
	 */
	private void confidenceScore() {
		if (procRecordConfidenceScore == -1) {
			if (logger.isDebugEnabled()) {
				logger.debug("PriceCategoryRule | updateProcRecord | Confidence score is not already set, so setting the values");
			}
			processedRecord.setPriceCategory(pricingCategory);
			processedRecord.setConfidenceScore(confidenceScore);
			logger.info("1. for rule ="+ this.name+ FOR_PAN+ getMaskedAccountNumber((null == this.processedRecord.getPan()) ? "" : 
				""+ this.processedRecord.getPan())+ ", set priceCategory= " + pricingCategory+ ", confidenceScore" + confidenceScore);
		} else {
			if (logger.isDebugEnabled()) {
				logger.debug("PriceCategoryRule | updateProcRecord | Confidence score already set , so not setting the values");
			}

		}
	}

	/**
	 * This function is used to set the DB values to local instances
	 * 
	 * @param priceCategoryRule
	 * @param processedRecord
	 */
	public void setInputToRule(ProcessedRecord processedRecord) {
		this.processedRecord = processedRecord;
		this.lastActivity = processedRecord.getDaysSinceLastActivity();
		this.adcNotifiedStatus = (processedRecord.getIsAccountADCNotified());
		this.procRecordConfidenceScore = (processedRecord.getConfidenceScore());
		this.externalStatus = processedRecord.getIsExternal();
		this.derivedStatus = processedRecord.getIsDerived();
	}

	public void setExternal(String external) {
		this.external = external;
	}

	public void setDerived(String derived) {
		this.derived = derived;
	}

	public String getExternalStatus() {
		return externalStatus;
	}

	public void setExternalStatus(String externalStatus) {
		this.externalStatus = externalStatus;
	}

	public String getDerivedStatus() {
		return derivedStatus;
	}

	public void setDerivedStatus(String derivedStatus) {
		this.derivedStatus = derivedStatus;
	}

	public void setAdcNotified(String adcNotified) {
		this.adcNotified = adcNotified;
	}

	public void setStartDate(Date startDate) {
		Instant instant = startDate.toInstant();
		LocalDate localDate = instant.atZone(defaultZoneId).toLocalDate();
		this.startDate = localDate;
	}

	public void setEndDate(Date endDate) {
		Instant instant = endDate.toInstant();
		LocalDate localDate = instant.atZone(defaultZoneId).toLocalDate();
		this.endDate = localDate;
	}

	public void setOperator1(String operatorOne) {
		this.operatorOne = operatorOne;
	}

	public void setOperator2(String operatorTwo) {
		this.operatorTwo = operatorTwo;
	}

	public void setOperand1(BigDecimal operandOne) {
		this.operandOne = operandOne;
	}

	public void setOperand2(BigDecimal operand2) {
		this.operandTwo = operand2;
	}

	public void setPriceCategory(int pricingCategory) {
		this.pricingCategory = pricingCategory;
	}

	public void setConfidenceScore(int confidenceScore) {
		this.confidenceScore = confidenceScore;
	}

	/**
	 * this function is to first check if the rule is valid, and then only makes
	 * it eligible for getting registered
	 * 
	 * @param rule
	 * @return
	 */
	public boolean validateRule(PriceCategoryRule priceCategoryRule) {

		/*
		 * To check if start date if set in the rule, is in the past
		 */
		conditionOne = false;
		conditionTwo = false;
		checkDateValue = false;
		currentDate = LocalDate.now();
		int operatorChecker = 0;

		if(FLAGYES.equalsIgnoreCase(validateStartDate()))
		{
			return false;
		}
		/* 
		 * To check if operators of a rule are not the same
		 */
		if (null != operatorOne && null != operatorTwo) {
			return compareOperator1AndOperator2();
		}
		/* 
		 * To check if either of the operators for the rule are set
		 */
		else if (null == operatorOne && null != operatorTwo) {
			operatorChecker = varifyingOperandTwoSetForRule(operatorChecker);
		}

		else if (null == operatorTwo && null != operatorOne) {
			operatorChecker = varifyingOperandOneSetForRule(operatorChecker);
		}
		/*
		 * To check if the operators and operands are not set for the rule
		 */
		return verifyingOperaorsetForRule(conditionOne,conditionTwo,operandOne,operandTwo,checkDateValue,operatorChecker);
	}

	private String validateStartDate() {
		// When return flag is set to 'y' ,we will return false in method which has called this method.
		String returnFlag="n";
		if (null == endDate) {
			//Going to validate currentDate should be before startDate
			returnFlag = validateCurrentDate(returnFlag);
		}
		/*
		 * To check if the rule has expired by checking the end date, if they
		 * are set for the rule
		 */
		else if (null != endDate && endDate.isBefore(currentDate)) {
			returnFlag=FLAGYES;
		}
		/*
		 * To check if start date is before end date if they are set for the
		 * rule
		 */
		else if (null != endDate && null != startDate) {
			if (endDate.isBefore(startDate) || currentDate.isBefore(startDate)) {
				returnFlag=FLAGYES;
			} else {
				checkDateValue = true;
			}
		}
		return returnFlag;
	}

	private String validateCurrentDate(String returnFlag) {
		if (null != startDate) {
			if (currentDate.isBefore(startDate)) {
				returnFlag=FLAGYES;
			} else {
				checkDateValue = true;
			}
		} else {
			checkDateValue = true;
		}
		return returnFlag;
	}

	private boolean verifyingOperaorsetForRule(boolean conditionOne2,
			boolean conditionTwo2, BigDecimal operandOne2,
			BigDecimal operandTwo2, boolean checkDateValue2, int operatorChecker) {

		if (conditionOne) {
			if (checkDateValue) {
				return true;
			}
		} else if (conditionTwo) {
			if (checkDateValue) {
				return true;
			}
		}
		/*
		 * To check if the operators and operands are not set for the rule
		 */
		else if (operandOne == null && operandTwo == null) {

			isEmptyCondition = true;
			if (checkDateValue && operatorChecker == 0) {
				return true;
			}
		}
		return false;
	}

	private int varifyingOperandOneSetForRule(int operatorChecker) {
		if (operandOne != null) {
			conditionOne = true;
		} else {
			operatorChecker++;
		}
		return operatorChecker;
	}

	private int varifyingOperandTwoSetForRule(int operatorChecker) {
		if (operandTwo != null) {
			conditionTwo = true;
		} else {
			operatorChecker++;
		}
		return operatorChecker;
	}

	private boolean compareOperator1AndOperator2() {
		if (operatorOne.equals(operatorTwo)) {
			return false;
		} else if (operandOne != null && operandTwo != null && checkDateValue) {
			conditionOne = true;
			conditionTwo = true;
			return true;
		} else {
			return false;
		}
	}

	public static String getMaskedAccountNumber(String accountNumber) {
		String result = null;
		if (accountNumber != null) {
			int accountNumberLength = accountNumber.length();
			if (accountNumberLength > 6) {
				StringBuilder builder = new StringBuilder();
				builder.append(accountNumber.substring(0, 6));
				String last4 = accountNumber.substring(accountNumberLength - 4);
				for (int i = 6; i < accountNumberLength - 4; i++) {
					builder.append("X");
				}
				builder.append(last4);
				result = builder.toString();
			} else {
				result = accountNumber;
			}
		}
		return result;
	}


}
