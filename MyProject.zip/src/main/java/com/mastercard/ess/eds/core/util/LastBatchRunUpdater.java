package com.mastercard.ess.eds.core.util;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.service.LastBatchJobRunService;

/**
 * Utility to update last run batch of the job
 * 
 * @author e056479
 *
 */

public class LastBatchRunUpdater implements Tasklet {

	@Autowired
	LastBatchJobRunService lastBatchJobRunService;
	
	private String jobInstanceName;

	public LastBatchRunUpdater(LastBatchJobRunService lastBatchJobRunService) {
	this.lastBatchJobRunService=lastBatchJobRunService;
		}


	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}
	
	
	@Override
	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
			
		lastBatchJobRunService.updateLastBatchJobRun(jobInstanceName);
		return RepeatStatus.FINISHED;
	}

	
}
