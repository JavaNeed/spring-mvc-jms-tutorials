package com.mastercard.ess.eds.batch.tasklet;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.service.FraudReportService;

public class FraudUnsubscribedBeforeCountTasklet implements Tasklet  {

	private static Logger logger = Logger.getLogger(FraudUnsubscribedBeforeCountTasklet.class);
	
	private static String UNSUBSCRIBED_BEFORE_COUNT = "UNSUBSCRIBED_BEFORE_COUNT" ;
	
	@Autowired
	private FraudReportService fraudReportService;
	
	//required for writing junit
	public FraudUnsubscribedBeforeCountTasklet() {
		//NOOP
	}

	//required for writing junit
	public FraudUnsubscribedBeforeCountTasklet(  FraudReportService fraudReportService) {
		this.fraudReportService = fraudReportService;
	}
	
	@Override
	public RepeatStatus execute(StepContribution arg0, ChunkContext chunkContext)
			throws Exception {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : FraudUnsubscribedBeforeCountTasklet - execute ");
		}
		
				
		Map<String, String>  beforeUnSubsFraudCt = fraudReportService.getBeforeCountunSubscribedICA();
		
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(UNSUBSCRIBED_BEFORE_COUNT, beforeUnSubsFraudCt);
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit in method : FraudUnsubscribedBeforeCountTasklet - execute ");
		}
		return RepeatStatus.FINISHED;
	}

}
