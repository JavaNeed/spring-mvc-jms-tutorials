package com.mastercard.ess.eds.batch.tasklet;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.dao.UniquePANFetchDAO;

public class UpdateDistinctPANCountTasklet
  implements Tasklet
{
  private static Logger logger = Logger.getLogger(UpdateDistinctPANCountTasklet.class);
  private static String GROUP_2 = "2";
  
  @Autowired
  private UniquePANFetchDAO uniquePANFetchDAO;
  
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
    throws Exception
  {
    logger.info("Enter from method : execute : UpdateDistinctPANCountTasklet ");
    
    Map<String, String> uniquePanCounts = new HashMap<>();
    uniquePanCounts = this.uniquePANFetchDAO.fetchPANCountByCountryAndChannel(new BigDecimal(GROUP_2));
    chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("distinctPanCountMap", uniquePanCounts);
    
    logger.info("Exit from method : execute : UpdateDistinctPANCountTasklet ");
    return RepeatStatus.FINISHED;
  }

//for junit

	public void setUniquePANFetchDAO(UniquePANFetchDAO uniquePANFetchDAO) {
		this.uniquePANFetchDAO = uniquePANFetchDAO;
	}
}