package com.mastercard.ess.eds.core.util;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.mastercard.ess.eds.common.SplunkEvent;
import com.mastercard.ess.eds.common.SplunkEventLogger;
import com.mastercard.ess.eds.core.service.EDSSourceService;
import com.mastercard.ess.eds.domain.EDSSource;

public class PANProcessScheduler {

	/**
	 * to launch job
	 */
	@Autowired
	private JobLauncher joLauncher;

	@SuppressWarnings("unused")
	private JdbcTemplate jdbcTemplate;

	@Autowired
	ApplicationContext context;

	@Autowired
	EDSSourceService edsSourceService;

	private Logger logger = Logger.getLogger(PANProcessScheduler.class);

	// Added For JUNIT
				public PANProcessScheduler() {
					super();
				}
				
				public PANProcessScheduler(JdbcTemplate jdbcTemplate) {
					super();
					this.jdbcTemplate = jdbcTemplate;
				}
				
	public PANProcessScheduler(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {

		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	// for Junit
	public void setPanService(EDSSourceService edsSourceService, ApplicationContext context, JobLauncher joLauncher) {
		this.edsSourceService = edsSourceService;
		this.context = context;
		this.joLauncher = joLauncher;
	}

	/**
	 * This method is scheduled to run at an interval or time as configured in
	 * scheduler.properties file.
	 */
	public void run() {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : run ");
		}

		List<Map<String, Object>> edsSourceList = null;

		try {
			edsSourceList = edsSourceService.getQueuedFiles();
		} catch (DataAccessException e) {
			splunkLogger(e);
		}

		if (null != edsSourceList && !edsSourceList.isEmpty()) {
			launchPanProcessJobs(edsSourceList);
		} else {
			if (logger.isDebugEnabled()) {
				logger.debug("No Queued files found OR Error occurred while fetching");
			}
		}
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : run ");
		}
	}

	/**
	 * this method launches the pan process from EDS Source
	 * @param edsSourceList
	 */
	private void launchPanProcessJobs(List<Map<String, Object>> edsSourceList) {
		List<EDSSource> edsSourceInstanceList = new ArrayList<>();
		for (Map<String, Object> row : edsSourceList) {

			edsSourceInstanceList = populateEDSSourceInstanceList(row);
		}

		for (EDSSource edsSourceInstance : edsSourceInstanceList) {
			if (edsSourceInstance.getName() != null) {
				try {
					launchPanProcessJob(edsSourceInstance);
				} catch (JobExecutionAlreadyRunningException e) {
					splunkLogger(e);
				}
			}
		}
	}

	/**
	 * This method launches the job with appropriate parameters.
	 */
					
	public void launchPanProcessJob(EDSSource edsSourceInstance) throws JobExecutionAlreadyRunningException {
		JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
		SimpleDateFormat datetimeFormat = new SimpleDateFormat(GlobalConstants.DATE_TIME_FORMAT);
		String timestamp = datetimeFormat.format(new Date());
		jobParametersBuilder.addString("queuedFileName", edsSourceInstance.getName());
		jobParametersBuilder.addString("currentDateTime", timestamp); // Spring
																		// Batch
																		// API
																		// does
																		// not
																		// support
																		// java.time's
																		// LocalDate/LocalTime
																		// yet.
		JobParameters jobParameters = jobParametersBuilder.toJobParameters();
		Job job = (Job) context.getBean("panProcessJob");
		try {			 
		joLauncher.run(job, jobParameters);
		} catch (JobRestartException | JobInstanceAlreadyCompleteException | JobParametersInvalidException e) {
			splunkLogger(e);
		} 
	}

	/**
	 * This method populates an instance of EDSSource in the list from EDSSource
	 * DAO.
	 */
	

	public List<EDSSource> populateEDSSourceInstanceList(Map<String, Object> row) {
		List<EDSSource> edsSourceInstanceList = new ArrayList<>();
		EDSSource edsSourceInstance = new EDSSource();

		try {
			edsSourceInstance.setSrc_ky((BigDecimal) row.get("EDS_SRC_ID"));
			edsSourceInstance.setErrorFile((String) row.get("ERR_FILE_NAM"));
			edsSourceInstance.setErrorFileLocation((String) row.get("ERR_FILE_LOC_TXT"));
			String isPurged = (String) row.get("IS_PURGED_SW");
			if (("N").equalsIgnoreCase(isPurged)) {
				edsSourceInstance.setIsPurged(false);
			} else {
				edsSourceInstance.setIsPurged(true);
			}
			edsSourceInstance.setLastUpdateTimeStamp((Timestamp) row.get("LST_UPDT_DT"));
			edsSourceInstance.setLastUpdatedBy((String) row.get("LST_UPDT_USER_ID"));
			edsSourceInstance.setSrc_type_ky((BigDecimal) row.get("EDS_SRC_TYPE_ID"));
			edsSourceInstance.setName((String) row.get("SRC_NAM"));
		} catch (ClassCastException e) {
			splunkLogger(e);
		}

		edsSourceInstanceList.add(edsSourceInstance);
		return edsSourceInstanceList;
	}

	private void splunkLogger(Exception e) {
		Map<String, String> splunkLogError = new HashMap<String, String>();
		splunkLogError.put("exception", e.getMessage());
		logger.error("Error occurred in launching pan process job " + e);
		SplunkEventLogger.logEvent(SplunkEvent.JOB_LAUNCH_FAILURE, splunkLogError, logger);
	}
	
}
