package com.mastercard.ess.eds.constant;

public final class BatchConstants {
	
	public final static String SIMULATION = "SIMULATION";
	public final static String EXECUTION = "EXECUTION";
	public final static String DW_AUTH = "DW_AUTH";
	public final static String DW_DEBIT = "DW_DEBIT";
	public final static String MODE_GFT_FAILURE = "GFT_FAILURE";
	public final static String MODE_FILE_GENERATION = "FILE_GENERATION";
	public final static String DOT = ".";
	public final static String DATE_PREFIX = "D";
	public final static String TIME_PREFIX = "T";
	public final static String COUNTER_PREFIX = "C";
	public final static String ICA_TO_RANGE_CACHE = "IcaToRangeCache";
	public final static String CUSTOMER_FILE_HEADER = "PAN,Confidence Score,Activity";
	public final static String NEW_LINE_SEPERATOR = System.getProperty("line.separator");
	public final static String COMMA_DELIMITER = ",";
	public final static String SUCCESS = "SUCCESS";
	public final static String FAILED = "FAILED" ;
	public final static String NOT_AVAILABLE = "Not Available";
	public final static String NOT_APPLICABLE = "N/A";
	public final static  String YES = "Y";
	public final static String NO = "N" ;
	public final static String CUSTOMER_WELCOME_EMAIL = "customerWelcomeEmail";
	public final static String EVENT_ID_NO_PAN_AT_RISK = "3";
	public static final String EVENT_ID_AT_PAN_RISK = "4";
	public static final String HIST_DAYS = "histDays";
	public static final String ICA = "ica";
	
	private BatchConstants() {
	}
	
	
}