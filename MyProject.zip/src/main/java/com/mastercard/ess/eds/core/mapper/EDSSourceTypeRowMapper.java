package com.mastercard.ess.eds.core.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mastercard.ess.eds.domain.EDSSourceType;

/**
 * Mapper class for mapping data fetched from EDS_SOURCE_TYPE table to Object
 *
 */
public class EDSSourceTypeRowMapper implements RowMapper<EDSSourceType> {

	@Override
	public EDSSourceType mapRow(ResultSet rs, int arg1) throws SQLException {

		EDSSourceType edsSourceType = new EDSSourceType();
		edsSourceType.setSourceTypeId(rs.getInt("EDS_SRC_TYPE_ID"));
		edsSourceType.setDescr(rs.getString("SRC_TYPE_DESC"));
		edsSourceType.setLocation(rs.getString("LOC_INFO_TXT"));
		edsSourceType.setProvider(rs.getString("PRVDR_NAM"));
		edsSourceType.setType(rs.getString("SRC_TYPE_CD"));
		edsSourceType.setDefaultNotificationEmailAddress(rs.getString("DEFLT_NOTIF_EMAIL_ADDR"));

		boolean isDerived = false;
		if (rs.getString("DERIV_SW").equals("Y")) {

			isDerived = true;
		}
		edsSourceType.setDerived(isDerived);
		boolean isExternal = false;
		if (rs.getString("EXTRL_SW").equals("Y")) {

			isExternal = true;
		}
		edsSourceType.setExternal(isExternal);

		return edsSourceType;
	}

}
