package com.mastercard.ess.eds.core.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.mastercard.ess.eds.domain.VendorActiveAccountRecord;

public class VendorReportRowMapper implements RowMapper<VendorActiveAccountRecord> {

	private final static String DATE_FORMAT = "MM/dd/yyyy";
	
	private Logger logger = Logger.getLogger(VendorReportRowMapper.class);
	@Override
	public VendorActiveAccountRecord mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		logger.info("Mapping rows for vendor report"+ rowNum);
		
		VendorActiveAccountRecord summaryRecord = new VendorActiveAccountRecord();
		
		Date summaryDate = getSummaryDate(rs.getString("SUMMARYDATE"));
		summaryRecord.setSummaryDate(summaryDate);
		summaryRecord.setActivePANCount(rs.getInt("ACTIVECOUNT"));
		summaryRecord.setInactivePANCount(rs.getInt("INACTIVECOUNT"));
		summaryRecord.setReceivedPANCount(rs.getInt("RECEIVEDCOUNT"));
		summaryRecord.setUniquePANCount(rs.getInt("UNIQUECOUNT"));
		return summaryRecord;
	}
	
	private Date getSummaryDate(String dateString) {
		Date returnDate = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT);
		
		try {
			returnDate = formatter.parse(dateString);
		} catch (ParseException e) {
			logger.error("Parse Exception while getting vendor summary Date");
		}
		return returnDate;
	}

}