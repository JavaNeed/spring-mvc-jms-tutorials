package com.mastercard.ess.eds.billing.dao;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.billing.service.BillingService;
import com.mastercard.ess.eds.billing.tasklet.BillDataTasklet;
import com.mastercard.ess.eds.billing.vo.BatchJobRunVO;
import com.mastercard.ess.eds.billing.vo.FileItemVO;
import com.mastercard.ess.eds.core.util.ReportTypeTokens;

@Component
public class BillDataDAO {

    @Autowired
    FileItemVO fileItemVO;

    @Autowired
    BatchJobRunVO batchJobRunVO;

    @Autowired
    BillDataTasklet billDataTasklet;

    @Autowired
    private BillingService billingService;

    // Getting eligible ICAs
    private static final String GET_ELIGIBLE_ICAS_FOR_YR =
            "select mstr.ica_num, hier.parent_ica_id, mstr.crte_dt,mstr.rnwl_dt ,mstr.crte_user_id from eds_cust_mstr mstr, eds_mbr_hier hier "
                    + "where  ( mstr.rnwl_dt is null and mstr.CRTE_DT < sysdate ) "
                    + "and mstr.ica_num = hier.ica_code and actv_sw = ? " + "union "
                    + "select mstr.ica_num, hier.parent_ica_id, mstr.crte_dt,mstr.rnwl_dt, mstr.crte_user_id from eds_cust_mstr mstr, eds_mbr_hier hier "
                    + "where  ( mstr.rnwl_dt is not null and mstr.rnwl_dt < sysdate ) "
                    + "and mstr.ica_num = hier.ica_code and actv_sw = ?  ";

    // Get Parent ICAs with count from limit table
    private static final String GET_PARENT_ICA_COUNTS =
            "select count(prnt_ica_num) count from eds_bill_ica_limit where BILL_YR = TO_CHAR(sysdate,'yyyy') group by prnt_ica_num "
                    + "having  prnt_ica_num = ?";

    private static final String ADD_BILL_LIMIT_RECORD =
            "insert into eds_bill_ica_limit (EDS_BILL_ICA_LIMIT_ID, PRNT_ICA_NUM, ICA_NUM, BILL_YR, CRTE_USER_ID, CRTE_DT) "
                    + "select EDS_SRC_ID_SEQ.nextval, ?, ?, ?, ?, sysdate from dual "
                    + " where not exists(select * from eds_bill_ica_limit where (PRNT_ICA_NUM = ? and ica_num = ? and BILL_YR = ?))";

    private static final String LST_RUN_BAT_JOB_NAM = "billDataBatchJob";

    private String UPDATE_QUERY =
            "UPDATE EDS_GNRT_RPT SET STAT_CD = ?,  FILE_LOC_TXT = ?, CRTE_USER_ID = ?, LST_UPDT_USER_ID = ?, JOB_INSTNCE_ID = ?,"
                    + " LST_UPDT_DT = ? where FILE_NAM = ?";

    private static final String UPDATE_RENEWAL_DATE =
            "update eds_cust_mstr set rnwl_dt = ? , LST_UPDT_USER_ID = ?, LST_UPDT_DT = ? where ica_num= ? and actv_sw = ?";

    private static final String UPDATE_STATUS =
            "UPDATE EDS_GNRT_RPT SET STAT_CD = ?, LST_UPDT_USER_ID = ?, LST_UPDT_DT = ? WHERE FILE_NAM = ?";

    private static final String GET_CRTE_DT_FOR_ICA =
            "select mstr.crte_dt, mstr.crte_user_id from eds_cust_mstr mstr where ica_num = ? and actv_sw = ?";

    private static int STATUS_CODE = 7;
    private static final int MAX_BILLABLE_CHILD_ICAS = 5;
    private static final String YES = "Y";

    private static Logger logger = Logger.getLogger(BillDataDAO.class);
    private SimpleJdbcInsert fileReportInsert;

    DataSource dataSource;
    private JdbcTemplate jdbcTemplate;

    public BillDataDAO(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {

        this.dataSource = dataSource;
        this.jdbcTemplate = new JdbcTemplate(dataSource);

    }

    public void updateEvents(FileItemVO fileItemVO) {

        int status = 0;
        if (logger.isDebugEnabled()) {
            logger.debug("BillDataDAO | updateEvents | Enter in method : updateEvents");
        }
        java.sql.Timestamp lastUpdatedDate = new java.sql.Timestamp(System.currentTimeMillis());
        if (null != fileItemVO) {

            if (null != jdbcTemplate) {
                status = jdbcTemplate.update(UPDATE_QUERY, fileItemVO.getStat_cd(), fileItemVO.getFile_loc_txt(),
                        fileItemVO.getCrte_user_id(), fileItemVO.getLst_updt_user_id(), fileItemVO.getJob_instnce_id(),
                        lastUpdatedDate, fileItemVO.getFile_nam());
            } else {
                logger.info("BillDataDAO | updateEvents |update query execution - Jdbctemplate unavailable");
            }

        }
        if (status == 1) {
            logger.info("BillDataDAO | updateEvents | Update successful");
        } else {
            logger.info("BillDataDAO | updateEvents | Update failed");
        }

        if (logger.isDebugEnabled()) {
            logger.debug("BillDataDAO | updateEvents | Exit from method : updateEvents");
        }
    }

    public void insertFileDetails(FileItemVO file) {
        if (logger.isDebugEnabled()) {
            logger.debug("BillDataDAO | insertFileDetails(FileItemVO file) | Enter in method : insertFileDetails ");
        }

        fileReportInsert = new SimpleJdbcInsert(dataSource).withTableName("EDS_GNRT_RPT").usingColumns(
                "EDS_GNRT_RPT_ID", "EDS_RPT_TYPE_ID", "STAT_CD", "JOB_INSTNCE_ID", "CRTE_USER_ID", "CRTE_DT",
                "FILE_LOC_TXT", "FILE_NAM", "CUST_MSTR_ID", "ICA_NUM");
        String eds_gen_rpt_id_seq = "select EDS_GRNT_RPT_ID_SEQ.nextval from dual";
        int uniquefileId = jdbcTemplate.queryForObject(eds_gen_rpt_id_seq, Integer.class);
        if (null != fileItemVO) {
            fileItemVO.setEds_gen_rpt_id(uniquefileId);

        } else {
            logger.error("inside BillDataDAO | fileItemVO is null!!!, will cause primary key violation");
        }
        if (null != file) {
            file.setLst_updt_dt(new java.sql.Timestamp(System.currentTimeMillis()));
            MapSqlParameterSource parameterSource = new MapSqlParameterSource();
            /* If isCustAtRiskRpt is set to true, the report is of type 'customer pan report' else it is 'billing' */
            int rptTypeId = ReportTypeTokens.BILLING_REPORT.getTypecode();
            if (file.isCustAtRiskRpt()) {
                rptTypeId = ReportTypeTokens.CUST_PAN_REPORT.getTypecode();
            }
            parameterSource.addValue("EDS_GNRT_RPT_ID", uniquefileId).addValue("EDS_RPT_TYPE_ID", rptTypeId).addValue(
                    "STAT_CD", file.getStat_cd()).addValue("JOB_INSTNCE_ID", file.getJob_instnce_id()).addValue(
                            "CRTE_USER_ID", file.getCrte_user_id()).addValue("CRTE_DT", new Date()).addValue(
                                    "FILE_LOC_TXT", file.getFile_loc_txt()).addValue("FILE_NAM", file.getFile_nam())
                    .addValue("CUST_MSTR_ID", file.getCust_mstr_id() == 0 ? null : file.getCust_mstr_id()).addValue(
                            "ICA_NUM", file.getIca_num());

            fileReportInsert.execute(parameterSource);

        } else {
            logger.info("inside BillDataDAO | file object is null!!!");
        }
        if (logger.isDebugEnabled()) {
            logger.debug("BillDataDAO | insertFileDetails(FileItemVO file) | Exit from method : insertFileDetails ");
        }
    }

    public void updateFileStatus(String edsPrcssDataIds) throws SQLException {
        if (logger.isDebugEnabled()) {
            logger.debug(
                    "BillDataDAO | updateFileStatus(String edsPrcssDataIds ) | Enter in method : updateFileStatus ");
        }

        StringBuilder buildSql = new StringBuilder("");
        buildSql = buildSql.append(
                "update EDS_PRCSS_DATA set EDS_BILL_RPT_ID=? , LST_UPDT_USER_ID=? , LST_UPDT_DT =?, JOB_INSTNCE_ID =?  where PAN_NUM in ")
                .append(edsPrcssDataIds).append(" and STAT_CD = ?");

        try {
            jdbcTemplate.update(buildSql.toString(), fileItemVO.getEds_gen_rpt_id(), fileItemVO.getLst_updt_user_id(),
                    new Date(), fileItemVO.getJob_instnce_id(), STATUS_CODE);
        } catch (DataAccessException e) {
            logger.error("BillDataDAO | updateFileStatus(String edsPrcssDataIds ) | DataAccessException catch" + e);

        }

        if (logger.isDebugEnabled()) {
            logger.debug(
                    "BillDataDAO | updateFileStatus(String edsPrcssDataIds ) | Exit from method : updateFileStatus ");
        }
    }

    public List<String> getBillableICAList(List<Map<String, Object>> childParentMapList) {
        List<String> billableChildICAList = new ArrayList<>();

        /*
         * get list of parent & child ICAs List<Map<String, Object>> childParentMapList =
         * jdbcTemplate.queryForList(GET_BILLABLE_ICAS_FOR_YR);//get it from context
         */

        for (Map<String, Object> m : childParentMapList) {
            BigDecimal childIca = (BigDecimal) m.get("ICA_NUM");
            BigDecimal parentIca = (BigDecimal) m.get("PARENT_ICA_ID");// process

            // check if parent ica already has 5 child icas billed for this year
            Long icaCount = 0L;

            try {
                List<Map<String, Object>> parentIcaListCount = jdbcTemplate.queryForList(GET_PARENT_ICA_COUNTS,
                        parentIca);
                icaCount = getIcaCount(parentIcaListCount);
            } catch (DataAccessException dae) {
                logger.error(dae);
            }

            // else insert row for this combo and add child icas to billable ica list
            if (icaCount < MAX_BILLABLE_CHILD_ICAS && !(billingService.icaIsInTrailPeriod(childIca.longValue()))) {

                Object[] args = new Object[] { parentIca, childIca, LocalDate.now().getYear(), LST_RUN_BAT_JOB_NAM,
                        parentIca, childIca, LocalDate.now().getYear() };
                int[] argTypes = new int[] { Types.NUMERIC, Types.NUMERIC, Types.VARCHAR, Types.VARCHAR, Types.NUMERIC,
                        Types.NUMERIC, Types.VARCHAR };

                int rowsUpdated = jdbcTemplate.update(ADD_BILL_LIMIT_RECORD, args, argTypes);

                if (rowsUpdated == 1) {

                    billableChildICAList.add(childIca.toString());
                }

            }
        }

        return billableChildICAList;
    }

    private Long getIcaCount(List<Map<String, Object>> parentIcaListCount) {
        Long icaCount = 0L;
        if (parentIcaListCount != null && !parentIcaListCount.isEmpty()) {
            Map<String, Object> count = parentIcaListCount.get(0);
            BigDecimal tempCount = (BigDecimal) count.get("count");
            icaCount = tempCount.longValue();
        }
        return icaCount;
    }

    public List<Map<String, Object>> getEligibleICAList() {
        logger.info("Enter method : execute : getEligibleICAList ");
        logger.info("inside dao of eligible icas");
        List<Map<String, Object>> childParentMapList = jdbcTemplate.queryForList(GET_ELIGIBLE_ICAS_FOR_YR, YES, YES);
        return childParentMapList;
    }

    // updating renewal Date from writerutils
    public int updateRenewalDate(Calendar updatedRenewalDate, BigDecimal ica, String jobName) {

        java.sql.Timestamp lastUpdatedDate = new java.sql.Timestamp(System.currentTimeMillis());

        return jdbcTemplate.update(UPDATE_RENEWAL_DATE, updatedRenewalDate, jobName, lastUpdatedDate, ica, YES);
    }

    public void updateStatus(int statusCode, String fileName, String jobName) {

        int status = 0;

        if (logger.isDebugEnabled()) {
            logger.debug("BillDataDAO | updateStatus | Enter in method : updateStatus");
        }

        java.sql.Timestamp lastUpdatedDate = new java.sql.Timestamp(System.currentTimeMillis());

        status = jdbcTemplate.update(UPDATE_STATUS, statusCode, jobName, lastUpdatedDate, fileName);

        if (status == 0) {
            logger.info("status not updated for : " + fileName);
        }

        if (logger.isDebugEnabled()) {
            logger.debug("BillDataDAO | updateStatus | Exit from method : updateStatus");
        }
    }

    public List<Map<String, Object>> getICADetailsFromIcaNum(long icaNum) {
        logger.info("Inside BillingDAO: getCreateDateForICA");
        List<Map<String, Object>> icaList = jdbcTemplate.queryForList(GET_CRTE_DT_FOR_ICA, icaNum, YES);
        return icaList;
    }

}
