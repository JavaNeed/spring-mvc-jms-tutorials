package com.mastercard.ess.eds.core.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.dao.CPPAccountDAO;
import com.mastercard.ess.eds.domain.CPPRecord;



@Component
public class CPPAccountService {
	
	
	@Autowired
	CPPAccountDAO cppAccountDAO;
	
	public List<CPPRecord> fetchVendorProvidedAccounts() {
		
		return cppAccountDAO.fetchVendorProvidedAccounts();

	}

	public void setCppAccountDAO(CPPAccountDAO cppAccountDAO) {
		this.cppAccountDAO = cppAccountDAO;
	}

}
