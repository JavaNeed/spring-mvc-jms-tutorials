package com.mastercard.ess.eds.batch.tasklet;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;

public class UpdateBillingContextTasklet implements Tasklet{

	private static Logger logger = Logger
			.getLogger(UpdateCustomerContextTasklet.class);

	private String billRunMode ;

	private ExecutionContext executionContext;

	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext){
		
		logger.info("Billing Job is executing with runMode = " + billRunMode);
		
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("billRunMode", billRunMode);
		
		return RepeatStatus.FINISHED;
	}
	
	
	public String getBillRunMode() {
		return billRunMode;
	}


	public void setBillRunMode(String billRunMode) {
		this.billRunMode = billRunMode;
	}


	public ExecutionContext getExecutionContext() {
		return executionContext;
	}

	public void setExecutionContext(ExecutionContext executionContext) {
		this.executionContext = executionContext;
	}
}