package com.mastercard.ess.eds.batch.partitioner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.mastercard.ess.eds.core.service.EDSRecordWriterService;
import com.mastercard.ess.eds.domain.EDSCustomer;
import static com.mastercard.ess.eds.constant.BatchConstants.*;

public class CustomerFileGenerationPartitioner implements Partitioner {

	private Logger logger = Logger.getLogger(CustomerFileGenerationPartitioner.class);

	@Autowired
	private EDSRecordWriterService edsRecordWriterService;

	@Value("${custFileGen.subsequentRun}")
	private int subsequentRunLimit;

	@Value("${custFileGen.firstRun}")
	private int firstTimeRunLimit;

	private ExecutionContext executionContext;
	
	public CustomerFileGenerationPartitioner() {
		super();
	}
	//for Junit
	public CustomerFileGenerationPartitioner(
			EDSRecordWriterService edsRecordWriterService) {
		this.edsRecordWriterService = edsRecordWriterService;
	}


	public int getSubsequentRunLimit() {
		return subsequentRunLimit;
	}
	public void setSubsequentRunLimit(int subsequentRunLimit) {
		this.subsequentRunLimit = subsequentRunLimit;
	}
	public int getFirstTimeRunLimit() {
		return firstTimeRunLimit;
	}
	public void setFirstTimeRunLimit(int firstTimeRunLimit) {
		this.firstTimeRunLimit = firstTimeRunLimit;
	}
	@Override
	public Map<String, ExecutionContext> partition(int arg0) {

		int i = 0;
		Map<String, ExecutionContext> partitionMap = new HashMap<String, ExecutionContext>();

		List<EDSCustomer> icaList = edsRecordWriterService.getICAsWithHistFlagForFileGeneration();
		List<String> icas = new ArrayList<>();
		
		if ( CollectionUtils.isNotEmpty(icaList) ) {

			logger.info("Partitioner ICA list size = " + icaList.size());

			for (EDSCustomer ica : icaList) {

				int days = getHistDays(ica.getHistFlag());
				
				if(StringUtils.isNotBlank(ica.getHistFlag()) && ica.getHistFlag().equalsIgnoreCase(YES)){
					icas.add(String.valueOf(ica.getIca()));
				
				}
				ExecutionContext ctxMap = new ExecutionContext();
				ctxMap.putLong(ICA, ica.getIca());
				ctxMap.putLong(HIST_DAYS, days);

				partitionMap.put("Thread -" + i, ctxMap);
				++i;
			}
			
			this.executionContext.put("updateHistIcas", icas );

			logger.info("Partitioner ICA MAP size = " + partitionMap.size()	+ " PartitionMap is = " + partitionMap);
		}
		return partitionMap;
	}

	/** For first run it will return 90 days 
	 * 
	 * @param histFlag
	 * @return
	 */
	private int getHistDays(String histFlag) {

		if ( histFlag.equalsIgnoreCase(YES) ) {
			return firstTimeRunLimit;

		} else {
			return subsequentRunLimit;

		}
	}
	public ExecutionContext getExecutionContext() {
		return executionContext;
	}
	public void setExecutionContext(ExecutionContext executionContext) {
		this.executionContext = executionContext;
	}
}