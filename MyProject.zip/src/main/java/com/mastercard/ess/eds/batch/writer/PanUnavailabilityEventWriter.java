package com.mastercard.ess.eds.batch.writer;

import static com.mastercard.ess.eds.constant.BatchConstants.EVENT_ID_NO_PAN_AT_RISK;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemWriter;

import com.mastercard.ess.eds.domain.EDSCustomer;
import com.mastercard.ess.eds.notification.util.NotificationEventConstants;
/**
 * This writer will write Pan unavailable events for customers 
 * 
 * @author e056479
 *
 */
public class PanUnavailabilityEventWriter implements ItemWriter<EDSCustomer> {


	private static Logger logger = Logger.getLogger(PanUnavailabilityEventWriter.class);
	
	private ExecutionContext executionContext;

	public PanUnavailabilityEventWriter() {
		super();
	}


	public ExecutionContext getExecutionContext() {
		return executionContext;
	}



	public void setExecutionContext(ExecutionContext executionContext) {
		this.executionContext = executionContext;
	}



	/*
	 * After read step data will be persisted in eds source data table in
	 * this method . Records come in form of List of object and stored in DB
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void write(List<? extends EDSCustomer> customers) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : write ");
		}
		List<String> icaList =   (List<String>) this.executionContext.get("icas");
		Map<String, String> icaNameMap =   (Map<String, String>) this.executionContext.get("icaName");
		if(icaList == null){
			icaList = new ArrayList<>();
		}
		if(icaNameMap == null){
			icaNameMap = new HashMap<>();
		}
		
		for(EDSCustomer customer: customers) {
			icaList.add(String.valueOf(customer.getIca()));
			icaNameMap.put(String.valueOf(customer.getIca()), customer.getCustomerName());
		}
		
		this.executionContext.put("icas", icaList );
		this.executionContext.put("icaName", icaNameMap);
		this.executionContext.put("eventName", NotificationEventConstants.NOTIF_EVT_NO_COMPROMISED_PANS_AVL);
		this.executionContext.put("eventId", EVENT_ID_NO_PAN_AT_RISK);


		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : write ");
		}
	}

}
