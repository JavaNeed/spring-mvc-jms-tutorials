package com.mastercard.ess.eds.batch.writer;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.Comparator.PercentageComparator;
import com.mastercard.ess.eds.core.util.CPPReportGenerator;
import com.mastercard.ess.eds.domain.CPPReportInfo;

public class CPPDetailReportGenerationItemWriter implements ItemWriter<CPPReportInfo> {

	private static Logger logger = Logger.getLogger(CPPDetailReportGenerationItemWriter.class);
	
	@Autowired
	private CPPReportGenerator cppReportGenerator;
	
	private BigDecimal jobInstanceId;
	private String jobInstanceName;
	private String countryCode;
	private static final String UNDERSCORE = "_";
	private static final String CP = "CP";
	private static final String CNP = "CNP";
	private ExecutionContext executionContext;
		
	//for Junit
	
	public void setCppReportGenerator(CPPReportGenerator cppReportGenerator) {
		this.cppReportGenerator = cppReportGenerator;
	}
	
	public ExecutionContext getExecutionContext()
	  {
	    return this.executionContext;
	  }
	  
	  public void setExecutionContext(ExecutionContext executionContext)
	  {
	    this.executionContext = executionContext;
	  }
	  
	  public String getCountryCode()
	  {
	    return this.countryCode;
	  }
	  
	  public void setCountryCode(String countryCode)
	  {
	    this.countryCode = countryCode;
	  }
	  
	  public void setObject(CPPReportGenerator cppReportGenerator)
	  {
	    this.cppReportGenerator = cppReportGenerator;
	  }
	  
	  public void setJobInstanceId(BigDecimal jobInstanceId)
	  {
	    this.jobInstanceId = jobInstanceId;
	  }
	  
	  public void setJobInstanceName(String jobInstanceName)
	  {
	    this.jobInstanceName = jobInstanceName;
	  }


	@Override
	public void write(List<? extends CPPReportInfo> reportInfos) throws Exception {
		logger.info("Enter in the write method of CPPDetailReportGenerationItemWriter ");
	    if ((reportInfos == null) || (reportInfos.isEmpty()))
	    {
	      logger.info("No records for writing in Details Records");
	      return;
	    }
	    long totalUniquePANCountCP = 0L;
	    long totalUniquePANCountCNP = 0L;
	    
	    List<CPPReportInfo> group0List = new CopyOnWriteArrayList();
	    List<CPPReportInfo> tempPercentageList = new CopyOnWriteArrayList();
	    
	    ListIterator iterator = reportInfos.listIterator();
	    while (iterator.hasNext())
	    {
	      CPPReportInfo cppReportInfo = (CPPReportInfo)iterator.next();
	      if (0 == cppReportInfo.getGroupId()) {
	        group0List.add(cppReportInfo);
	      }
	    }
	    ListIterator<CPPReportInfo> group0ListIterator = group0List.listIterator();
	    
	    Map<String, String> distinctPanCountMap = (Map<String, String>) this.executionContext.get("distinctPanCountMap");
	    if (distinctPanCountMap != null)
	    {
	      totalUniquePANCountCP = Long.valueOf(StringUtils.isBlank((String)distinctPanCountMap.get(this.countryCode + UNDERSCORE + CP)) ? "0" : (String)distinctPanCountMap.get(this.countryCode + UNDERSCORE + CP)).longValue();
	      totalUniquePANCountCNP = Long.valueOf(StringUtils.isBlank((String)distinctPanCountMap.get(this.countryCode + UNDERSCORE + CNP)) ? "0" : (String)distinctPanCountMap.get(this.countryCode + UNDERSCORE + CNP)).longValue();
	    }
	    logger.info("totalUniquePANCountCP = " + totalUniquePANCountCP);
	    logger.info("totalUniquePANCountCNP = " + totalUniquePANCountCNP);
	    logger.info("group1ListIterator" + group0ListIterator);
	    
	    
	    group0ListIteratorDetails(totalUniquePANCountCP, totalUniquePANCountCNP, group0ListIterator);
	    for (CPPReportInfo cppReportInfo : group0List) {
	      addCppReportInfo(tempPercentageList, cppReportInfo);
	    }
	    logger.info("tempPercentageList" + tempPercentageList);
	    group0List.removeAll(tempPercentageList);
	    
	    group0ListIsEmpty(group0List ,this.countryCode);
	    
	    logger.info("Exit from the write method of CPPDetailReportGenerationItemWriter ");
	}

	/**
	 * @param group0List
	 */
	private void group0ListIsEmpty(List<CPPReportInfo> group0List , String countyCode) {
		if (!group0List.isEmpty()) {
			Collections.sort(group0List,new PercentageComparator());
			logger.info("Writing into Details Report");
			cppReportGenerator.writeToCPPReport(group0List, "details", jobInstanceId, jobInstanceName , countyCode);
		}
	}

	/**
	 * @param tempPercentageList
	 * @param cppReportInfo
	 */
	private void addCppReportInfo(List<CPPReportInfo> tempPercentageList,
			CPPReportInfo cppReportInfo) {
		logger.info("cppReportInfo.getCardsCountryPercentage()" + cppReportInfo.getCardsCountryPercentage());
		logger.info("cppReportInfo.getCardsUsedCount()" + cppReportInfo.getCardsUsedCount());
		if(cppReportInfo.getCardsCountryPercentage() < 2 || cppReportInfo.getCardsUsedCount() < 10){
		   tempPercentageList.add(cppReportInfo); 
		}
	}

	/**
	 * @param totalUniquePANCountCP
	 * @param totalUniquePANCountCNP
	 * @param tempList
	 * @param group0ListIterator
	 */
	private void group0ListIteratorDetails(long totalUniquePANCountCP,
			long totalUniquePANCountCNP,
			ListIterator<CPPReportInfo> group0ListIterator) {
		while (group0ListIterator.hasNext()) {
			CPPReportInfo cppReportInfo =  group0ListIterator.next();
			if ("CP".equals(cppReportInfo.getTransactionChannel())) {
				if (totalUniquePANCountCP == 0) {
					cppReportInfo.setCardsCountryPercentage(0); // For SONAR
				
				}else {
					cppReportInfo.setCardsCountryPercentage(
							(cppReportInfo.getCardsUsedCount() * 100) / totalUniquePANCountCP);
				}
			} else if ("CNP".equals(cppReportInfo.getTransactionChannel())) {
				if (totalUniquePANCountCNP == 0) {
					cppReportInfo.setCardsCountryPercentage(0); // For SONAR
					
				} else {
					cppReportInfo.setCardsCountryPercentage(
							(cppReportInfo.getCardsUsedCount() * 100) / totalUniquePANCountCNP);
				}
			} 
		}
	}

	

}
