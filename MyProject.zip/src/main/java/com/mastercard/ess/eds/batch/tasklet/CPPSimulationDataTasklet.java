package com.mastercard.ess.eds.batch.tasklet;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.service.CPPSimulationService;
import com.mastercard.ess.eds.domain.AuthDebitPanDetailRecord;

/**
 *  This tasklet used to save the simulation results in EDS_CPP_SIM_DATA table.
 * @author e070836
 * @version 1.0
 * @date : Dec 29, 2017
 */

public class CPPSimulationDataTasklet implements Tasklet {

	private static Logger logger = Logger.getLogger(CPPSimulationDataTasklet.class);

	 
	@Autowired
	private CPPSimulationService cppSimulationService;
	
	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext)
			throws Exception {

		logger.info("Enter in CPPSimulationDataTasklet execute method ");

		String jobInstanceName = chunkContext.getStepContext().getStepExecution().getJobExecution().getJobInstance().getJobName();
		BigDecimal jobInstanceId = BigDecimal.valueOf(chunkContext.getStepContext().getStepExecution().getJobExecution().getJobId());
		String simSrcId =  chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get("edsSimSrcId").toString();
		

		Set<AuthDebitPanDetailRecord> simulationSet =   (Set<AuthDebitPanDetailRecord>) chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().get("cppSimulationSet");
		
		//Check simulationSet is null or empty and returns FINISHED if true
		if(simulationSet == null || simulationSet.isEmpty()){
			logger.info("No CPP Pending Rules found");
			return RepeatStatus.FINISHED;
		}
		
		Map<String, Integer> simulationMapCount = new HashMap<>();
		for( AuthDebitPanDetailRecord authDebitRecord: simulationSet){
			createSimulationCount(authDebitRecord, simulationMapCount ) ;
		}
		
		if(simulationMapCount !=null){
			logger.info("simulationMapCount" + simulationMapCount);
			cppSimulationService.saveSimulationResults(simulationMapCount, jobInstanceId, jobInstanceName, simSrcId);
		}
		 
		logger.info("Exit in CPPSimulationDataTasklet execute method ");
		
		return RepeatStatus.FINISHED;
	}

	private void createSimulationCount(
			AuthDebitPanDetailRecord authDebitRecord,
			Map<String, Integer> simulationMapCount) {
		 int count = 0 ;
		
		 if(StringUtils.isNotBlank(authDebitRecord.getRawPan())){
			if(simulationMapCount.get(authDebitRecord.getCppRuleId().toString())!=null){
				count = simulationMapCount.get(authDebitRecord.getCppRuleId().toString()) ;
				count ++ ;
			} else{
				count = 1 ;
			}
		 }

		simulationMapCount.put(authDebitRecord.getCppRuleId().toString(), count);
	}

	public void setCppSimulationService(CPPSimulationService cppSimulationService) {
		this.cppSimulationService = cppSimulationService;
	}

}
