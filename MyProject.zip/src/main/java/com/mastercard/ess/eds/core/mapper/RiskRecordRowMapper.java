package com.mastercard.ess.eds.core.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.ProcessedRecord;

public class RiskRecordRowMapper implements RowMapper<EDSRecord> {

	private static Logger logger = Logger.getLogger(RiskRecordRowMapper.class);

	@Override
	public EDSRecord mapRow(ResultSet paramResultSet, int paramInt) throws SQLException {

		if (logger.isInfoEnabled()) {
			logger.info("Enter in method : mapRow | RiskRecordRowMapper ");
		}

		EDSRecord edsRecord = new EDSRecord();
		ProcessedRecord processedRecord = new ProcessedRecord();

		String isAccountValid = paramResultSet.getString("ACCT_VALID_SW");
		if ("Y".equals(isAccountValid)) {

			processedRecord.setAccountValid(true);
		} else {

			processedRecord.setAccountValid(false);
		}

		processedRecord.setBin(paramResultSet.getString("CARD_BIN_NUM"));
		processedRecord.setBrandProductCode(paramResultSet.getString("BRND_PRDCT_CD"));
		processedRecord.setCid(paramResultSet.getBigDecimal("CID_NUM"));
		processedRecord.setConfidenceScore(paramResultSet.getInt("CNFDNC_SCR_NUM"));
		processedRecord.setCreateDate(paramResultSet.getTimestamp("CRTE_DT"));
		processedRecord.setCreatedBy(paramResultSet.getString("CRTE_USER_ID"));
		processedRecord.setDateOfLastActivity(paramResultSet.getDate("LST_ACTVY_DT"));
		processedRecord.setDaysSinceLastActivity(paramResultSet.getInt("DAYS_SINCE_LST_ACTVY_CNT"));
		processedRecord.setIca(paramResultSet.getString("ICA_NUM"));
		processedRecord.setIsAccountActive(paramResultSet.getString("ACCT_ACTV_SW"));
		processedRecord.setIsAccountADCNotified(paramResultSet.getString("ADC_NOTIF_SW"));
		processedRecord.setIsFraudReported(paramResultSet.getString("FRAUD_RPT_SW"));
		processedRecord.setLastUpdatedDate(paramResultSet.getTimestamp("LST_UPDT_DT"));
		processedRecord.setLastUpdatedUser(paramResultSet.getString("LST_UPDT_USER_ID"));
		processedRecord.setPan(paramResultSet.getBigDecimal("PAN_NUM"));
		processedRecord.setPriceCategory(paramResultSet.getInt("PRICE_CAT_CD"));
		processedRecord.setProcRawRecordKey(paramResultSet.getBigDecimal("EDS_SRC_DATA_ID"));
		processedRecord.setProcRecordKey(paramResultSet.getBigDecimal("EDS_PRCSS_DATA_ID"));
		processedRecord.setRtnId(paramResultSet.getString("RTN_CD"));
		processedRecord.setIsDuplicate(paramResultSet.getString("PAN_DUP_SW"));
		processedRecord.setIsReported(paramResultSet.getString("RPT_SW"));

		edsRecord.setProcRecord(processedRecord);

		if (logger.isInfoEnabled()) {
			logger.info("Exit from method : mapRow | RiskRecordRowMapper ");
		}
		return edsRecord;
	}

}
