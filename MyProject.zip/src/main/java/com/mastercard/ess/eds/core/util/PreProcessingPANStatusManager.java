package com.mastercard.ess.eds.core.util;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.mastercard.ess.eds.core.service.EDSSourceService;

/**
 * This Tasklet just delegates the request to update status of file/records
 * before processing to concerned service.
 * 
 * @author e067588
 *
 */
public class PreProcessingPANStatusManager implements Tasklet {

	private Logger logger = Logger.getLogger(PreProcessingPANStatusManager.class);

	@Value("#{jobParameters['queuedFileName']}")
	public String fileName;

	@Autowired
	EDSSourceService edsSourceService;

	private String jobInstanceName;

	private BigDecimal jobInstanceId;

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}

	public void setJobInstanceName(String jobInstanceName) {
		this.jobInstanceName = jobInstanceName;
	}

	public PreProcessingPANStatusManager() {
	super();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.batch.core.step.tasklet.Tasklet#execute(org.
	 * springframework.batch.core.StepContribution,
	 * org.springframework.batch.core.scope.context.ChunkContext)
	 */
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : execute ");
		}
		edsSourceService.setFileName(fileName);
		edsSourceService.setJobInstanceName(jobInstanceName);
		edsSourceService.updateFileStatusPreProcessing(jobInstanceId);
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : execute ");
		}
		return RepeatStatus.FINISHED;
	}

	// for JUnit test
	public void setEDSSourceService(EDSSourceService edsSourceService) {
		this.edsSourceService = edsSourceService;

	}
}
