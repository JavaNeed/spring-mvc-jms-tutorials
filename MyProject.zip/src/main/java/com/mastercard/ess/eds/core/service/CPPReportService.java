package com.mastercard.ess.eds.core.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.core.dao.CPPReportDAO;
import com.mastercard.ess.eds.core.dao.CPPReportStausDAO;

@Component
public class CPPReportService {

	@Autowired
	CPPReportDAO cppReportDAO;
	
	@Autowired
	CPPReportStausDAO cppReportStausDAO;
// for Junit
	public CPPReportService(CPPReportStausDAO cppReportStausDAO) {
	this.cppReportStausDAO= cppReportStausDAO;
	}

	public CPPReportService() {
		super();
	}

	public List<String> getListOfCountries() {
		return cppReportDAO.getListOfCountries();
	}

	public List<String> getListOfMerchantCountries() {
		return cppReportDAO.getListOfMerchantCountries();
	}

	public void writeCPPReportDetails(String filePath, BigDecimal jobInstanceId, String jobInstanceName) {
		
		cppReportStausDAO.writeCPPReportDetails(filePath, jobInstanceId, jobInstanceName);
	}

	public void setCPPReportDAO(CPPReportDAO cppReportDAO2) {
		this.cppReportDAO = cppReportDAO2;
		
	}



}
