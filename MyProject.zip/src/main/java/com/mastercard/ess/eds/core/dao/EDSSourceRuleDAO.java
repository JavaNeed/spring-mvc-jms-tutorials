package com.mastercard.ess.eds.core.dao;

import java.math.BigDecimal;
import java.util.Date;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Component;
import static com.mastercard.ess.eds.constant.SQLConstants.*;

@Component
public class EDSSourceRuleDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;



	private static Logger logger = Logger.getLogger(EDSSourceRuleDAO.class);

	private SimpleJdbcInsert sourceRuleDataInsert;

	public EDSSourceRuleDAO(@Autowired @Qualifier("edsDataSource") DataSource dataSource) {
		sourceRuleDataInsert = new SimpleJdbcInsert(dataSource).withTableName(
				EDS_SRC_RULE_DATA).usingColumns(EDS_SRC_RULE_DATA_ID, EDS_SRC_DATA_ID, EDS_SRC_ID, EDS_CPP_RULE_ID, CRTE_USER_ID, CRTE_DT);
	}

	public void saveSourceRuleData(BigDecimal ruleId, Integer edsSrcDataId, String srcId, String jobInstanceName) {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : saveSourceRuleData for ruleId = "+ruleId+" edsSrcDataId ="+edsSrcDataId+" srcId="+srcId);
		}

		MapSqlParameterSource parameterSource = new MapSqlParameterSource();
		parameterSource.addValue(EDS_SRC_RULE_DATA_ID, jdbcTemplate.queryForObject("select EDS_SRC_RULE_DATA_ID_SEQ.nextval from dual", Integer.class))
		.addValue(EDS_SRC_DATA_ID, edsSrcDataId)
		.addValue(EDS_SRC_ID, Integer.valueOf(srcId))
		.addValue(EDS_CPP_RULE_ID, ruleId)
		.addValue(CRTE_USER_ID, jobInstanceName)
		.addValue(CRTE_DT, new Date());
		sourceRuleDataInsert.execute(parameterSource);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : saveSourceRuleData for ruleId = "+ruleId);
		}
	}
}

