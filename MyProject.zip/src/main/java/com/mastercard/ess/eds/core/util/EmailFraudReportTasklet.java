package com.mastercard.ess.eds.core.util;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;

import com.mastercard.ess.eds.core.dao.EDSSourceTypeDao;
import com.mastercard.ess.eds.core.events.EventPublisher;
import com.mastercard.ess.eds.notification.util.NotificationEventConstants;
import com.mastercard.ess.eds.notification.vo.NotificationEventVO;

public class EmailFraudReportTasklet  implements Tasklet{

	private static final String MMMM_YYYY = "MMMM-YYYY";

	private static final String MONTH = "month";

	private static final String SUMMARY_FILE = "summaryFile";
	
	private static final String JOB_NAME = "jobName" ;

	private static Logger logger = Logger.getLogger(EmailFraudReportTasklet.class);

	@Autowired
	EventPublisher eventPublisher;

	@Autowired
	EDSSourceTypeDao edsSourceTypeDao;

	@Value("${frDetailReport.path}")
	private String fraudReportPath;

	//for junit
	public EmailFraudReportTasklet(EDSSourceTypeDao edsSourceTypeDao) {
		this.edsSourceTypeDao = edsSourceTypeDao;
	}
	public String getFraudReportPath() {
		return fraudReportPath;
	}

	public void setFraudReportPath(String fraudReportPath) {
		this.fraudReportPath = fraudReportPath;
	}

	       /**
		   * This is the main method which makes use of addNum method.
		   * @param StepContribution contribution
		   * @param ChunkContext chunkContext : Will be used to fetch jobId and JobName
		   * @return RepeatStatus.FINISHED .
		   * @exception IOException On input error.
		   * @see IOException
		   */
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter method : execute : FraudReportTasklet ");
		}

		Calendar currentCal = Calendar.getInstance();  
		DateFormat dateFormat = new SimpleDateFormat(MMMM_YYYY);
		String currentMonth=dateFormat.format(currentCal.getTime());

		fraudReportPath = fraudReportPath.trim(); 
		String fraudReportFile = "Fraud_Report"+ "_" + currentMonth + ".xlsx";
		if (logger.isDebugEnabled()) {
			logger.debug(" fraudReportPath ="+fraudReportPath+" fraudReportFile = "+fraudReportFile);
		}

		NotificationEventVO notificationEventVO = new NotificationEventVO();
		Map<String, String> jobParams = new HashMap<>();
		jobParams.put(SUMMARY_FILE, fraudReportPath+fraudReportFile);
		jobParams.put(MONTH, currentMonth);
		jobParams.put(JOB_NAME, chunkContext.getStepContext().getStepExecution().getJobExecution().getJobInstance().getJobName());
		notificationEventVO.setEventName(NotificationEventConstants.NOTIF_EVT_FRAUD_REPORT_FILE_GENERATED);
		notificationEventVO.setJobParams(jobParams);
		notificationEventVO.setJobName(chunkContext.getStepContext().getStepExecution().getJobExecution().getJobInstance().getJobName());
		notificationEventVO.setJobID(BigDecimal.valueOf(chunkContext.getStepContext().getStepExecution().getJobExecution().getJobId()));

		FileSystemResource fraudReportFileSystemResource = new FileSystemResource(fraudReportPath+fraudReportFile);
		logger.info("fraudReportFileSystemResource :"+fraudReportFileSystemResource);

		if (fraudReportFileSystemResource.exists()) {
			logger.info(" Event Placed for fraud report generation ");
			eventPublisher.placeEvent(notificationEventVO);
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : execute : EmailFraudReportTasklet ");
		}

		return RepeatStatus.FINISHED;
	}
}
