package com.mastercard.ess.eds.batch.processor;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.core.service.ADCNotificationService;
import com.mastercard.ess.eds.domain.EDSRecord;
import com.mastercard.ess.eds.domain.ProcessedRecord;

public class ADCNotificationProcessor implements
		ItemProcessor<EDSRecord, EDSRecord> {
	
	private static Logger logger = Logger.getLogger(ADCNotificationProcessor.class);

	@Autowired
	ADCNotificationService adcNotificationService;

	/*
	 * Checks if specific pan is notified by in ADC or not if a pan is already
	 * notified to ADC then IS_ADC_NOTIFIED will be set to true in
	 * EDS_SOURCE_PROC_DATA table
	 */
	@Override
	public EDSRecord process(EDSRecord edsRecord) throws Exception {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter in method : process ");
		}
		
		String isAccountADCNotified;
		ProcessedRecord procRecord = edsRecord.getProcRecord();

		isAccountADCNotified = adcNotificationService
				.isAccountADCNotified(procRecord.getPan());

		procRecord.setIsAccountADCNotified(isAccountADCNotified);
		edsRecord.setProcRecord(procRecord);
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit from method : process ");
		}
		return edsRecord;
	}

	public ADCNotificationProcessor(
			ADCNotificationService adcNotificationService) {
		super();
		this.adcNotificationService = adcNotificationService;
	}

}
