package com.mastercard.ess.eds.billing.tasklet;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.batch.config.FileStatus;
import com.mastercard.ess.eds.billing.dao.BillDataDAO;
import com.mastercard.ess.eds.core.util.EDSProcessStatus;
import com.mastercard.ess.eds.domain.FileDetails;

public class SendBillingBatchFilesTasklet implements Tasklet {

    private static final String JOB_NAME = "billDataBatchJob";

    @Autowired
    private BillDataDAO billDataDAO;

    private ExecutionContext executionContext;

    private static Logger logger = Logger.getLogger(SendBillingBatchFilesTasklet.class);

    public ExecutionContext getExecutionContext() {
        return executionContext;
    }

    public void setExecutionContext(ExecutionContext executionContext) {
        this.executionContext = executionContext;
    }

    @Override
    public RepeatStatus execute(StepContribution paramStepContribution, ChunkContext chunkContext) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("Enter method : execute : sendBillingBatchFilesTasklet ");
        }

        Set<String> billingFileNames = new HashSet<>();

        List<FileDetails> fileStatusList =
                (List<FileDetails>) chunkContext.getStepContext().getStepExecution().getJobExecution()
                        .getExecutionContext().get("fileStatusList");

        logger.info("fileStatusList" + fileStatusList);

        if (null != executionContext && null != executionContext.get("billingFileNames")) {
            billingFileNames = (Set<String>) executionContext.get("billingFileNames");
        }

        for (String billingFileName : billingFileNames) {
            logger.info("billingFileName ****** : " + billingFileName);
            String fileStatus = FileStatus.GFT_FAILURE.getStatus();
            int exitStatus = 1;
            try {
                if (billingFileName != null) {
                    ProcessBuilder procBuilder =
                            new ProcessBuilder("/bin/bash", "sendBillingBatchFiles.sh", billingFileName);

                    Map<String, String> env = procBuilder.environment();
                    env.put("PATH", "/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/usr/seos/bin:"
                            + "/opt/nfast/bin:/sys_apps_01/cdunix/ndm/bin:/apps_01/eds/bin");

                    // Fix missing CLI variable
                    env.put("MCSTAR_HOME", "/apps_01/mcstar");
                    env.put("MCSTARINI", "NULL");
                    env.put("MCSTARAPP", "EDS");
                    env.put("LD_LIBRARY_PATH", "/apps_01/mcstar/lib:/sys_apps_01/dmexpress/lib");
                    env.put("NDMDIR", "/sys_apps_01/cdunix/ndm");
                    env.put("NDMAPICFG", "/sys_apps_01/cdunix/ndm/cfg/cliapi/ndmapi.cfg");
                    env.put("SRCNODE", "`hostname`");
                    env.put("CDRMCFG", "$NDMDIR/cfg/$SRCNODE/initparm.cfg");

                    Process proc = procBuilder.start();
                    BufferedReader br = new BufferedReader(new InputStreamReader(proc.getErrorStream()));

                    String line = null;
                    logger.info("script output start");
                    while ((line = br.readLine()) != null) {
                        logger.info(line);
                    }
                    logger.info("script output end");

                    exitStatus = proc.waitFor();
                }

                if (0 == exitStatus) {
                    logger.info("sendBillingBatchFiles.sh executed succesfully - " + billingFileName);
                    fileStatus = FileStatus.GFT_SUCCESS.getStatus();
                    billDataDAO.updateStatus(EDSProcessStatus.SENT.getStatusCode(), billingFileName, JOB_NAME);
                } else {
                    logger.info("sendBillingBatchFiles.sh could not be successfuly executed for job - "
                            + billingFileName);
                }

            } catch (Exception ie) {
                logger.error("Process executing sendBillingBatchFiles.sh interrupted/IOException occured " + ie);
            }

            updateFileStatus(fileStatusList, billingFileName, exitStatus, fileStatus);
        }
        return RepeatStatus.FINISHED;
    }

    private void updateFileStatus(List<FileDetails> fileStatusList, String fileName, int exitCode, String fileStatus) {
        logger.info(" fileName" + fileName);
        logger.info(" exitCode" + exitCode);
        logger.info(" fileStatus" + fileStatus);

        if (fileStatusList.isEmpty()) {
            logger.info("Nothing to update");
            return;
        }

        for (FileDetails fileDetails : fileStatusList) {
            if (StringUtils.isNotBlank(fileDetails.getFileName())
                    && fileDetails.getFileName().equalsIgnoreCase(fileName)) {
                logger.info("Inside the fileStatus");
                fileDetails.setStatus(fileStatus);
                fileDetails.setErrorCode(String.valueOf(exitCode));
                break;
            }

        }

    }

}
