package com.mastercard.ess.eds.billing.util;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.mastercard.ess.eds.billing.dao.BillDataDAO;
import com.mastercard.ess.eds.billing.service.BillingService;
import com.mastercard.ess.eds.billing.vo.BillDataVO;
import com.mastercard.ess.eds.billing.vo.FileItemVO;
import com.mastercard.ess.eds.core.util.EDSProcessStatus;
import com.mastercard.ess.eds.renewal.vo.BillIcaLimitVO;

public class CSVWriterUtils {

    private static Logger logger = Logger.getLogger(CSVWriterUtils.class);
    private static final String DOT = ".";
    private static final String DATE_PREFIX = "D";
    private static final int HEADER_RECORD_COUNT = 1;
    private static final String COMMA = ",";
    private static final String NEW_LINE = "\n";

    private static final String CRTE_USER_ID = "CRTE_USER_ID";
    private static final String CRTE_DT = "CRTE_DT";
    private static final String CUST_MASS_ONBOARDING = "custMassOnboarding";

    DataSource dataSource;

    @Autowired
    FileItemVO fileItemVO;

    @Autowired
    BillDataDAO billDataDao;

    @Autowired
    private BillingService billingService;

    @Autowired
    private RenewalDateUtil renewalDateUtil;

    @Value("${billingfiles.directory}")
    private String location;

    @Value("${billingfiles.prefix}")
    private String filePrefix;

    private String billingFileName;

    @Value("${billingfiles.endpoint}")
    String billingFileEndPoint;

    @Value("${billing.trialPeriodInMonths}")
    private int trialPeriod;

    @Autowired
    private CSVWriterUtils csvWriterUtils;

    public CSVWriterUtils() {
        super();
    }

    // For Junit
    public CSVWriterUtils(String location, String filePrefix, BillDataDAO billDataDao, FileItemVO fileItemVO,
            RenewalDateUtil renewalDateUtil, BillingService billingService) {
        this.location = location;
        this.filePrefix = filePrefix;
        this.billDataDao = billDataDao;
        this.fileItemVO = fileItemVO;
        this.renewalDateUtil = renewalDateUtil;
        this.billingService = billingService;
    }

    public FileItemVO createBillDataCSVFile(List<? extends BillDataVO> billDataVOList,
            List<Map<String, Object>> childParentMapList, String jobInstanceName) throws IOException {

        logger.debug("CSVWriterUtils | Enter in method : createBillDataCSVFile ");

        String uniqueID = getFileName();
        Path file = null;

        logger.debug("System.getProperty: " + System.getProperty("file.separator"));

        file = Files.createFile(Paths.get(location + System.getProperty("file.separator") + uniqueID));

        Charset charset = Charset.forName("UTF-8");

        try (BufferedWriter bufferedWriter = Files.newBufferedWriter(file, charset)) {
            this.billingFileName = uniqueID;
            List<String> billableICAs = billDataDao.getBillableICAList(childParentMapList);
            int sizeInHeader = billDataVOList.size() + billableICAs.size() + HEADER_RECORD_COUNT;
            String heading = "H,EDS," + dateFormat() + "," + timeFormat() + "," + nameOfFile() + ",EDS" + uniqueID
                    .substring(38, 43) + "," + sizeInHeader + ",";
            bufferedWriter.write(heading);
            bufferedWriter.newLine();
            for (BillDataVO billDataVO : billDataVOList) {
                Long ica_num = billDataVO.getIcaNum();
                // Added below check to remove ICAs which are on trial period. (We are not writing PANs for those ICAs)
                if (ica_num != null) {
                    boolean trial_period = billingService.icaIsInTrailPeriod(ica_num);

                    if (!trial_period) {
                        bufferedWriter.write(writePANDetails(billDataVO));
                        bufferedWriter.newLine();
                    }
                }
            }

            for (String childICA : billableICAs) {
                String record = createICABillingRecord(childICA);

                bufferedWriter.write(record);
                bufferedWriter.newLine();
            }
            logger.info(
                    "CSVWriterUtils | createBillDataCSVFile(List<? extends BillDataVO> billDataVOList) | FILE_PROCESS: "
                            + EDSProcessStatus.GENERATED.getStatusCode());

            fileItemVO = createFileItemVO(uniqueID, EDSProcessStatus.GENERATED.getStatusCode());

            updateRenewalDate(childParentMapList, jobInstanceName);

        } catch (UnsupportedEncodingException e) {
            logger.error(
                    "CSVWriterUtils | createBillDataCSVFile(List<? extends BillDataVO> billDataVOList) | UnsupportedEncodingException in obtaining session ley "
                            + e);
            fileItemVO = createFileItemVO(uniqueID, EDSProcessStatus.FAILED.getStatusCode());
        } catch (FileNotFoundException e) {
            logger.error(
                    "CSVWriterUtils | createBillDataCSVFile(List<? extends BillDataVO> billDataVOList) | FileNotFoundException in obtaining session ley ",
                    e);
            fileItemVO = createFileItemVO(uniqueID, EDSProcessStatus.FAILED.getStatusCode());
        } catch (IOException e) {
            logger.error(
                    "CSVWriterUtils | createBillDataCSVFile(List<? extends BillDataVO> billDataVOList) | IOException in obtaining session ley "
                            + e);
            fileItemVO = createFileItemVO(uniqueID, EDSProcessStatus.FAILED.getStatusCode());
        }

        if (logger.isDebugEnabled()) {
            logger.debug(
                    "CSVWriterUtils | createBillDataCSVFile(List<? extends BillDataVO> billDataVOList) | Exit from method : createBillDataCSVFile ");
        }
        return fileItemVO;

    }

    /**
     * In updateRenewalDate we will update renewable date as below:
     * A)If createUsetId is 'custMassOnboarding' 
     * 1)If renewalDate is null     : Then renewabledate will be ( createDate + trial period (2 months) ) 
     * 2)If renewalDate is not null : Then renewabledate will be ( renewabledate + 365 ) 
     * 
     * B)If createUsetId  is not 'custMassOnboarding'
     * 1)If renewalDate is null     : Then renewabledate will be ( createDate + 365 )   
     * 2)If renewalDate is not null : Then renewabledate will be ( renewabledate + 365 )   
     * 
     * @param childParentMapList
     */
    private void updateRenewalDate(List<Map<String, Object>> childParentMapList, String jobInstanceName) {

        if (null != childParentMapList) {

            logger.info("CSVWriterUtil | updateRenewalDate | updateRenewalDate starts");

            renewalDateUtil.updateRenewalDate(childParentMapList, jobInstanceName);

            logger.info("CSVWriterUtil | updateRenewalDate | updateRenewalDate Ends");

        }
    }

    public String getFileName() {
        StringBuilder name = new StringBuilder();
        // Get End point from EDS_CUST_MSTR for this ICA

        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyMMdd");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HHmmss");
        LocalDateTime dateTime = LocalDateTime.now();
        String formattedDate = dateTime.format(dateFormatter);
        String formattedTime = dateTime.format(timeFormatter);

        // Generate a 3 digit random ID
        Random random = new Random();
        int randomID = random.nextInt(900) + 100;
        // Convert to string for concatenation later
        String strRandom = String.valueOf(randomID);
        name.append(filePrefix).append(billingFileEndPoint).append(DOT).append(DATE_PREFIX).append(formattedDate)
                .append(DOT).append("T").append(formattedTime).append(DOT).append("C").append(strRandom);
        return name.toString();
    }

    private FileItemVO createFileItemVO(String fileName, int statusCode) {
        if (logger.isDebugEnabled()) {
            logger.debug(
                    "CSVWriterUtils | createFileItemVO(String fileName,String statusCode ) | Enter in method : createFileItemVO ");
        }
        logger.info("CSVWriterUtils | createFileItemVO(String fileName,String statusCode ) | Filename: " + fileName
                + " status " + statusCode);
        if (null != fileItemVO) {
            fileItemVO.setFile_nam(fileName);
            fileItemVO.setLst_updt_dt(new Date());
            fileItemVO.setStat_cd(statusCode);
            fileItemVO.setFile_loc_txt(location);
        }

        if (logger.isDebugEnabled()) {
            logger.debug(
                    "CSVWriterUtils | createBillDataCSVFile(List<? extends BillDataVO> billDataVOList) | Exit from method : createBillDataCSVFile ");
        }
        return fileItemVO;

    }

    public String dateFormat() {
        String dateFormat;
        Date headerDate = new Date();
        SimpleDateFormat sdf2 = new SimpleDateFormat("yy");
        String s3 = sdf2.format(headerDate);
        Calendar cal = new GregorianCalendar();
        cal.setTime(headerDate);
        if (cal.get(Calendar.DAY_OF_YEAR) < 100) {
            if (cal.get(Calendar.DAY_OF_YEAR) < 10) {
                dateFormat = s3 + "00" + cal.get(Calendar.DAY_OF_YEAR);
            } else {
                dateFormat = s3 + "0" + cal.get(Calendar.DAY_OF_YEAR);
            }
        } else {
            dateFormat = s3 + cal.get(Calendar.DAY_OF_YEAR);

        }
        return dateFormat;
    }

    public String timeFormat() {
        Date headertime = new Date();
        SimpleDateFormat sdf1 = new SimpleDateFormat("HH");
        SimpleDateFormat sdf = new SimpleDateFormat("mm");
        String s2 = sdf1.format(headertime);
        String s = sdf.format(headertime);
        return s2.concat(s);
    }

    public String nameOfFile() {
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("dd");
        SimpleDateFormat sdf1 = new SimpleDateFormat("MM");
        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy");
        String s1 = sdf.format(date);
        String s2 = sdf1.format(date);
        String s = sdf2.format(date);
        String systemId = "EDS";
        return systemId.concat(s1).concat(s2).concat(s);
    }

    public String typeUpdate() {
        String typeUpdate = "A";
        BillIcaLimitVO billIcaLimitVO = new BillIcaLimitVO();
        if (billIcaLimitVO.getIcaLimit() < 5) {
            return typeUpdate;
        } else
            return "";
    }

    public String createICABillingFile(List<String> billableICAList) {

        logger.info("In createICABillingFile");

        String uniqueID = getFileName();
        try (FileWriter fileWriter = new FileWriter(location + System.getProperty("file.separator") + uniqueID)) {

            int sizeInHeader = billableICAList.size() + HEADER_RECORD_COUNT;
            String heading = "H,EDS," + dateFormat() + "," + timeFormat() + "," + nameOfFile() + ",EDS" + uniqueID
                    .substring(38, 43) + "," + sizeInHeader + ",";
            fileWriter.write(heading);
            fileWriter.write(NEW_LINE);

            for (String childICA : billableICAList) {

                String record = createICABillingRecord(childICA);
                logger.info("writing ICA CSV Data:");
                fileWriter.write(record);
                fileWriter.write(NEW_LINE);
            }
        } catch (IOException e) {
            logger.error("Error occurred while writing ICA only billing file :" + e);
            return null;
        }
        return uniqueID;

    }

    private String writePANDetails(BillDataVO billDataVO) {
        StringBuilder oneLine = new StringBuilder();
        oneLine.append("D"); // 1
        oneLine.append(COMMA);
        oneLine.append("EDS"); // 2
        oneLine.append(COMMA);
        oneLine.append("B"); // 3
        oneLine.append(COMMA);
        oneLine.append(COMMA); // 4
        oneLine.append(billDataVO.getPanNum()); // 5
        oneLine.append(COMMA);
        oneLine.append(billDataVO.getPriceCatid()); // 6
        oneLine.append(COMMA);
        oneLine.append("+1"); // 7
        oneLine.append(COMMA);
        oneLine.append(COMMA); // 8
        oneLine.append(COMMA); // 9
        oneLine.append(COMMA); // 10
        oneLine.append(COMMA); // 11
        oneLine.append(COMMA); // 12
        oneLine.append(COMMA); // 13

        return oneLine.toString();
    }

    private String createICABillingRecord(String childICA) {
        StringBuilder oneLine = new StringBuilder();
        oneLine.append("D");
        oneLine.append(COMMA);
        oneLine.append("EDS");
        oneLine.append(COMMA);
        oneLine.append("I");
        oneLine.append(COMMA);
        oneLine.append(childICA);
        oneLine.append(COMMA);
        oneLine.append(COMMA);
        oneLine.append(COMMA);
        oneLine.append("+1");
        oneLine.append(COMMA);
        oneLine.append(COMMA);
        oneLine.append(COMMA);
        oneLine.append(COMMA);
        oneLine.append(COMMA);
        oneLine.append(COMMA);
        oneLine.append(COMMA);
        oneLine.append(typeUpdate());

        return oneLine.toString();

    }

    public String getBillingFileName() {
        return billingFileName;
    }

}
