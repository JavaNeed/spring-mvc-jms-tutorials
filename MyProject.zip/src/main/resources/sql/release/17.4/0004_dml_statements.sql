Insert into EDS_OWNER.EDS_RPT_TYPE
   (EDS_RPT_TYPE_ID, TYPE_NAM, RPT_DESC, CRTE_DT)
 Values
   (6, 'Customer Enrollment Report', 'Customer Enrollment Report', TO_DATE('02/12/2018 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into EDS_OWNER.EDS_RPT_TYPE
   (EDS_RPT_TYPE_ID, TYPE_NAM, RPT_DESC, CRTE_DT)
 Values
   (7, 'Fraud Report', 'Fraud Report', TO_DATE('02/12/2018 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
Insert into EDS_OWNER.EDS_RPT_TYPE
   (EDS_RPT_TYPE_ID, TYPE_NAM, RPT_DESC, CRTE_DT)
 Values
   (5, 'Customer Delivery Report', 'Customer Pan Delivery stats', TO_DATE('02/12/2018 05:30:52', 'MM/DD/YYYY HH24:MI:SS'));
   
   Insert into EDS_OWNER.EDS_EMAIL_TMPLT
   (EDS_EMAIL_TMPLT_ID, TMPLT_MSG_BODY_TXT, TMPLT_SUBJ_TXT, TMPLT_SGNTR_TXT, LST_UPDT_DT, 
    LST_UPDT_USER_ID)
 Values
   (7, 'Hi,<br><br>
Please find attached the EDS Delivery Report for the Month of $month for all the regions.<br>', 'EDS Delivery Report for $month', '<tr>
<td><br>
Thank You', TO_DATE('02/12/2018 05:32:08', 'MM/DD/YYYY HH24:MI:SS'), 
    'EDS_USER');
Insert into EDS_OWNER.EDS_EMAIL_TMPLT
   (EDS_EMAIL_TMPLT_ID, TMPLT_MSG_BODY_TXT, TMPLT_SUBJ_TXT, TMPLT_SGNTR_TXT, LST_UPDT_DT, 
    LST_UPDT_USER_ID)
 Values
   (9, 'Hi,<br><br>
Please find attached the Fraud report for the Month of $month for all regions.<br>
', 'Fraud report for $month', '<tr>
<td><br>
Thank You', TO_DATE('02/12/2018 00:18:16', 'MM/DD/YYYY HH24:MI:SS'), 
    'EDS_USER');
Insert into EDS_OWNER.EDS_EMAIL_TMPLT
   (EDS_EMAIL_TMPLT_ID, TMPLT_MSG_BODY_TXT, TMPLT_SUBJ_TXT, TMPLT_SGNTR_TXT, LST_UPDT_DT, 
    LST_UPDT_USER_ID)
 Values
   (8, 'Hi, 
<br><br>
Please find attached the EDS Customer Enrollment Report for the Month of $month for all the regions.
<br>', 'EDS Customer Enrollment Report for $month', '<tr>
<td><br><br><br>
Thank you', TO_DATE('02/12/2018 00:18:16', 'MM/DD/YYYY HH24:MI:SS'), 
    'EDS_USER');
	
   Insert into EDS_OWNER.EDS_EVENT
   (EDS_EVENT_ID, TYPE_TXT, EVENT_NAM, EVENT_DESC, ENBL_SW, 
    EDS_MSG_FROM_ADDR, LST_UPDT_DT, LST_UPDT_USER_ID, EDS_TMPLT_ID, DISP_SW)
 Values
   (7, 'I', 'Customer Delivery Report Generated', 'This event is raised to send the customer delivery report to subscribed users', 'Y', 
    'eds_stage@mastercard.com', TO_DATE('02/12/2018 05:33:22', 'MM/DD/YYYY HH24:MI:SS'), 'EDS_USER', 7, 'Y');
Insert into EDS_OWNER.EDS_EVENT
   (EDS_EVENT_ID, TYPE_TXT, EVENT_NAM, EVENT_DESC, ENBL_SW, 
    EDS_MSG_FROM_ADDR, LST_UPDT_DT, LST_UPDT_USER_ID, EDS_TMPLT_ID, DISP_SW)
 Values
   (8, 'I', 'Customer Enrollment Report', 'This event is raised to send the customer enrollment report to subscribed users', 'Y', 
    'eds_stage@mastercard.com', TO_DATE('02/12/2018 00:18:58', 'MM/DD/YYYY HH24:MI:SS'), 'EDS_USER', 8, 'Y');
Insert into EDS_OWNER.EDS_EVENT
   (EDS_EVENT_ID, TYPE_TXT, EVENT_NAM, EVENT_DESC, ENBL_SW, 
    EDS_MSG_FROM_ADDR, LST_UPDT_DT, LST_UPDT_USER_ID, EDS_TMPLT_ID, DISP_SW)
 Values
   (9, 'I', 'Fraud Report Generated', 'This event is raised to send the fraud report to subscribed users', 'Y', 
    'eds_stage@mastercard.com', TO_DATE('02/12/2018 00:18:58', 'MM/DD/YYYY HH24:MI:SS'), 'EDS_USER', 9, 'Y');

	COMMIT ;