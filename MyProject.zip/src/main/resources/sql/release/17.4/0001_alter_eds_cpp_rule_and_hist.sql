-- These columns are altered to accommodate all country ids as part of defect - DE67381.

ALTER TABLE EDS_OWNER.EDS_CPP_RULE_HIST MODIFY (VAL_ISSR_CNTRY_ID varchar2(2000));

ALTER TABLE EDS_OWNER.EDS_CPP_RULE MODIFY (VAL_ISSR_CNTRY_ID varchar2(2000));

commit;