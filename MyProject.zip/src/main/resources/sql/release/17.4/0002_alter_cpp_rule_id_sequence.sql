-- This is done as some of the rules were added out of sequence as part of defect - DE68342.

ALTER SEQUENCE EDS_OWNER.EDS_CPP_RULE_ID_SEQ INCREMENT BY 237;  -- Value1 - Current value of sequence.

SELECT EDS_OWNER.EDS_CPP_RULE_ID_SEQ.NEXTVAL FROM DUAL; -- Value2 - max rule id

ALTER SEQUENCE EDS_OWNER.EDS_CPP_RULE_ID_SEQ INCREMENT BY 1; -- Value2 - Value1

commit;