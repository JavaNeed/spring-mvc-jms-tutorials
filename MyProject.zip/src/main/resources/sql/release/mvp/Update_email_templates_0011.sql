SET DEFINE OFF;

update EDS_OWNER.EDS_EMAIL_TMPLT set TMPLT_SGNTR_TXT='<tr>
<td><br><br><br>
<b>Mastercard Early Detection System</b>' where EDS_EMAIL_TMPLT_ID='1';

update EDS_OWNER.EDS_EMAIL_TMPLT set TMPLT_SGNTR_TXT='<tr>
<td><br><br><br>
<b>Mastercard Early Detection System</b>' where EDS_EMAIL_TMPLT_ID='2';

update EDS_OWNER.EDS_EMAIL_TMPLT set TMPLT_SUBJ_TXT='Mastercard Early Detection System: No at risk PANs found',TMPLT_SGNTR_TXT='<tr>
<td><br><br><br>
<b>Mastercard Early Detection System</b>' where EDS_EMAIL_TMPLT_ID='3';

update EDS_OWNER.EDS_EMAIL_TMPLT set TMPLT_MSG_BODY_TXT='$customerName,<br><br>

We have found new accounts belonging to your ICA which may be at risk.<br>

Please log in to Mastercard Connect and navigate to Mastercard Data Exchange (MDE) to view and download these accounts.',TMPLT_SUBJ_TXT='Mastercard Early Detection System: New Accounts Available' ,TMPLT_SGNTR_TXT='<tr>
<td><br><br><br>
<b>Mastercard Early Detection System</b>' where EDS_EMAIL_TMPLT_ID='4';

update EDS_OWNER.EDS_EMAIL_TMPLT set TMPLT_SUBJ_TXT='Mastercard Early Detection System: Active Accounts Report' where EDS_EMAIL_TMPLT_ID='5';

update EDS_OWNER.EDS_EMAIL_TMPLT set TMPLT_MSG_BODY_TXT='Fraud Insights Team,<br><br>
The CPP Analysis Report for the week has been generated.
Please download and view the CPP Detail Report and CPP Summary Report from the attachment.<br>' where EDS_EMAIL_TMPLT_ID='6';

COMMIT;
