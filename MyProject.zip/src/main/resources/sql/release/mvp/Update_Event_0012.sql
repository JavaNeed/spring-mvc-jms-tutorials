SET DEFINE OFF;

update EDS_OWNER.EDS_EVENT set EVENT_NAM='At-risk PANs available for download' where EDS_EVENT_ID=4;

update EDS_OWNER.EDS_EVENT set EVENT_NAM='At-risk PANs not found' where EDS_EVENT_ID=3  ;

commit ;