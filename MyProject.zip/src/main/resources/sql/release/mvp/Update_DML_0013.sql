SET DEFINE OFF;

update EDS_OWNER.EDS_EVENT set EVENT_NAM='At-risk PANs available for download' where EDS_EVENT_ID=4;
update EDS_OWNER.EDS_EVENT set EVENT_NAM='At-risk PANs not found' where EDS_EVENT_ID=3  ;

UPDATE EDS_OWNER.EDS_PRICE_CAT_RULE SET OPER_2_TXT='>', VAL_2_NUM = 0 WHERE EDS_PRICE_CAT_RULE_ID = 1 ;
UPDATE EDS_OWNER.EDS_PRICE_CAT_RULE SET OPER_2_TXT='>' , VAL_2_NUM = 0 WHERE EDS_PRICE_CAT_RULE_ID = 3;
UPDATE EDS_OWNER.EDS_PRICE_CAT_RULE SET OPER_2_TXT='>' , VAL_2_NUM = 0 WHERE EDS_PRICE_CAT_RULE_ID = 5;

Delete from EDS_OWNER.EDS_SRC_TYPE where PRVDR_NAM = 'CPPInternal';
Update EDS_OWNER.EDS_SRC_TYPE set PRVDR_NAM = 'CPP', SRC_TYPE_DESC ='Records from CPP config'  where PRVDR_NAM = 'CPPExternal';

update EDS_OWNER.EDS_EMAIL_TMPLT set TMPLT_SGNTR_TXT='<tr>
<td><br><br><br>
<b>Mastercard Early Detection System</b>' where EDS_EMAIL_TMPLT_ID='1';

update EDS_OWNER.EDS_EMAIL_TMPLT set TMPLT_SGNTR_TXT='<tr>
<td><br><br><br>
<b>Mastercard Early Detection System</b>' where EDS_EMAIL_TMPLT_ID='2';

update EDS_OWNER.EDS_EMAIL_TMPLT set TMPLT_MSG_BODY_TXT='Dear $customerName, <br>
<p>
We want to inform you that there are new at-risk PANs from the Mastercard Early Detection System available to download through Mastercard Data Exchange which can be accessed from Mastercard Connect (https://www.mastercardconnect.com).
</p>
<p>
If you experience any issues or have questions, please contact the Mastercard Global Customer Service (GCS) team at 1- 800-999-0363 or <a href="mailto:ess_cos_support_team@mastercard.com">ess_cos_support_team@mastercard.com</a> for support. 
</p>', TMPLT_SUBJ_TXT='Mastercard Early Detection System Data Delivery', TMPLT_SGNTR_TXT='Kind regards,<br><br>
The Mastercard Early Detection System Team' where EDS_EMAIL_TMPLT_ID=4;

update EDS_OWNER.EDS_EMAIL_TMPLT set TMPLT_MSG_BODY_TXT='Dear $customerName, <br>
<p>
We want to inform you that there were no new at-risk PANs from the Mastercard Early Detection System this week.</p>
<p>
If you experience any issues or have questions, please contact the Mastercard Global Customer Service (GCS) team at 1- 800-999-0363 or <a href="mailto:ess_cos_support_team@mastercard.com">ess_cos_support_team@mastercard.com</a> for support. 
</p>', TMPLT_SUBJ_TXT='Mastercard Early Detection System Notification', TMPLT_SGNTR_TXT='Kind regards,<br><br>
The Mastercard Early Detection System Team' where EDS_EMAIL_TMPLT_ID=3;


update EDS_OWNER.EDS_EMAIL_TMPLT set TMPLT_SUBJ_TXT='Mastercard Early Detection System: Active Accounts Report' where EDS_EMAIL_TMPLT_ID='5';

update EDS_OWNER.EDS_EMAIL_TMPLT set TMPLT_MSG_BODY_TXT='Fraud Insights Team,<br><br>
The CPP Analysis Report for the week has been generated.
Please download and view the CPP Detail Report and CPP Summary Report from the attachment.<br>' where EDS_EMAIL_TMPLT_ID='6';

COMMIT; 