SET DEFINE OFF;

alter session set current_schema = EDS_OWNER;

Insert into EDS_USER.EDS_LST_BAT_JOB_RUN
   (EDS_LST_BAT_JOB_RUN_ID, JOB_NAM, LST_RUN_DT)
 Values
   (1, 'customerFileGenerationJob', SYSDATE);
Insert into EDS_USER.EDS_LST_BAT_JOB_RUN
   (EDS_LST_BAT_JOB_RUN_ID, JOB_NAM, LST_RUN_DT)
 Values
   (2, 'panUnavailableNotificationJob', SYSDATE);
Insert into EDS_USER.EDS_LST_BAT_JOB_RUN
   (EDS_LST_BAT_JOB_RUN_ID, JOB_NAM, LST_RUN_DT)
 Values
   (3, 'billDataBatchJob', SYSDATE);
COMMIT;
