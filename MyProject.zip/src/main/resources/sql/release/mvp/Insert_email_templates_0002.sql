SET DEFINE OFF;
alter session set current_schema = EDS_OWNER;

Insert into EDS_EMAIL_TMPLT
   (EDS_EMAIL_TMPLT_ID, TMPLT_MSG_BODY_TXT, TMPLT_SUBJ_TXT, TMPLT_SGNTR_TXT, LST_UPDT_DT, 
    LST_UPDT_USER_ID)
 Values
   (1, 'Fraud Insights Team,<br><br>
New file received from $SOURCENAME and was found to be invalid with the error $ERRORMESSAGE
<br> File Details <br>
File Name:  $FILENAME <BR>
File Size: :  $FILESIZE<br><br>

', 'Invalid file received from $SOURCENAME', '<tr>
<td><br>
Early Detection Service System ', SYSDATE, 
    'EDS_USER');
    
    
Insert into EDS_EMAIL_TMPLT
   (EDS_EMAIL_TMPLT_ID, TMPLT_MSG_BODY_TXT, TMPLT_SUBJ_TXT, TMPLT_SGNTR_TXT, LST_UPDT_DT, 
    LST_UPDT_USER_ID)
 Values
   (2, 'Fraud Insights Team,<br><br>

New file received from $SOURCENAME and is being processed. 
<br>
<br>


', 'New file received from  $SOURCENAME', '<tr>
<td><br>
Early Detection Service System ', SYSDATE, 
    'EDS_USER');
    
Insert into EDS_EMAIL_TMPLT
   (EDS_EMAIL_TMPLT_ID, TMPLT_MSG_BODY_TXT, TMPLT_SUBJ_TXT, TMPLT_SGNTR_TXT, LST_UPDT_DT, 
    LST_UPDT_USER_ID)
 Values
   (3, '$customerName,<br><br>
We did not find any accounts belonging to your ICA which may be at risk this week.




', 'Mastercard Early Detection Service: No at risk PANs found', '
<tr>
<td><br><br><br>
<b>Mastercard Early Detection Service System</b>', SYSDATE, 
    'EDS_USER');
    
Insert into EDS_EMAIL_TMPLT
   (EDS_EMAIL_TMPLT_ID, TMPLT_MSG_BODY_TXT, TMPLT_SUBJ_TXT, TMPLT_SGNTR_TXT, LST_UPDT_DT, 
    LST_UPDT_USER_ID)
 Values
   (4, '$customerName,<br><br>

We have found new accounts belonging to your ICA which may be at risk.<br>

Please log in to Mastercard connect and navigate to Mastercard Data Exchange (MDE) to view and download these accounts.', 'Mastercard Early Detection Service: New Accounts Available', '<tr>
<td><br><br><br>
<b>Mastercard Early Detection Service System</b>', SYSDATE, 
    'EDS_USER');
    
Insert into EDS_EMAIL_TMPLT
   (EDS_EMAIL_TMPLT_ID, TMPLT_MSG_BODY_TXT, TMPLT_SUBJ_TXT, TMPLT_SGNTR_TXT, LST_UPDT_DT, 
    LST_UPDT_USER_ID)
 Values
   (5, '$vendor,<br><br>
Please find attached active accounts report for the month of $month', 'Mastercard Early Detection Service: Active Accounts Report', '<tr>
<td><br>
Thank You', SYSDATE, 'EDS_USER');
    
Insert into EDS_EMAIL_TMPLT
   (EDS_EMAIL_TMPLT_ID, TMPLT_MSG_BODY_TXT, TMPLT_SUBJ_TXT, TMPLT_SGNTR_TXT, LST_UPDT_DT, 
    LST_UPDT_USER_ID)
 Values
   (6, 'Fraud Insight Team,<br><br>
The CPP Analysis Report for the week has been generated.
Please download and view the CPPDetail Report and CPP Summary Report from the attachment.<br> 
', 'Weekly CPP Report Generated', '<tr>
<td><br>
Thank You', SYSDATE, 'EDS_USER');
    
    COMMIT;