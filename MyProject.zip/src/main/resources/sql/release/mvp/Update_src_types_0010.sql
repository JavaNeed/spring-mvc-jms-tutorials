SET DEFINE OFF;

alter session set current_schema = EDS_OWNER;

Delete from EDS_SRC_TYPE where PRVDR_NAM = 'CPPInternal';

Update EDS_SRC_TYPE set PRVDR_NAM = 'CPP', SRC_TYPE_DESC ='Records from CPP config'  where PRVDR_NAM = 'CPPExternal';

COMMIT;