SET DEFINE OFF;

alter session set current_schema = EDS_OWNER;

Insert into EDS_PRCSS_STAT
   (EDS_PRCSS_STAT_CD, STAT_DESC, CRTE_DT)
 Values (1, 'Queued', SYSDATE);

Insert into EDS_PRCSS_STAT
   (EDS_PRCSS_STAT_CD, STAT_DESC, CRTE_DT)
 Values (2, 'Error', SYSDATE);

Insert into EDS_PRCSS_STAT
   (EDS_PRCSS_STAT_CD, STAT_DESC, CRTE_DT)
 Values (3, 'Work In Progress', SYSDATE);

Insert into EDS_PRCSS_STAT
   (EDS_PRCSS_STAT_CD, STAT_DESC, CRTE_DT)
 Values (4, 'Unprocessed', SYSDATE);

Insert into EDS_PRCSS_STAT
   (EDS_PRCSS_STAT_CD, STAT_DESC, CRTE_DT)
 Values (5, 'Processed', SYSDATE);

Insert into EDS_PRCSS_STAT
   (EDS_PRCSS_STAT_CD, STAT_DESC, CRTE_DT)
 Values (6, 'Purged', SYSDATE);

Insert into EDS_PRCSS_STAT
   (EDS_PRCSS_STAT_CD, STAT_DESC, CRTE_DT)
 Values (7, 'Sent', SYSDATE);

Insert into EDS_PRCSS_STAT
   (EDS_PRCSS_STAT_CD, STAT_DESC, CRTE_DT)
 Values (8, 'Invalid for further processing', SYSDATE);

Insert into EDS_PRCSS_STAT
   (EDS_PRCSS_STAT_CD, STAT_DESC, CRTE_DT)
 Values (9, 'Delivery Failed', SYSDATE);

Insert into EDS_PRCSS_STAT
   (EDS_PRCSS_STAT_CD, STAT_DESC, CRTE_DT)
 Values (10, 'Generated', SYSDATE);

COMMIT;
