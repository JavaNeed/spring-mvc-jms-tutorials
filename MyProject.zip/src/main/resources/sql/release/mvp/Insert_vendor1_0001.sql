SET DEFINE OFF;

alter session set current_schema = EDS_OWNER;

Insert into EDS_SRC_TYPE
   (EDS_SRC_TYPE_ID, SRC_TYPE_DESC, SRC_TYPE_CD, PRVDR_NAM, EXTRL_SW, 
    DERIV_SW, LOC_INFO_TXT, PREF_SW, VNDR_SW, DEFLT_NOTIF_EMAIL_ADDR)
 Values
   (1, 'File From GFT Endpoint', 'File', 'Terbium', 'Y', 
    'N', 'E0087406', 'Y','Y', 'eds@mastercard.com' );
    
Insert into EDS_SRC_TYPE
   (EDS_SRC_TYPE_ID, SRC_TYPE_DESC, SRC_TYPE_CD, PRVDR_NAM, EXTRL_SW, 
    DERIV_SW, LOC_INFO_TXT, PREF_SW, VNDR_SW, DEFLT_NOTIF_EMAIL_ADDR)
 Values
   (2, 'Invalid Endpoint', 'File', 'unknown', 'N', 
    'N', NULL, 'N', 'N', 'eds@mastercard.com');

Insert into EDS_SRC_TYPE
   (EDS_SRC_TYPE_ID, SRC_TYPE_DESC, SRC_TYPE_CD, PRVDR_NAM, EXTRL_SW, 
    DERIV_SW, LOC_INFO_TXT, PREF_SW, VNDR_SW, DEFLT_NOTIF_EMAIL_ADDR)
 Values
   (3, 'Records from CPP External config', 'Process', 'CPPExternal', 'Y', 
    'Y', NULL, 'N', 'N', 'eds@mastercard.com');

Insert into EDS_SRC_TYPE
   (EDS_SRC_TYPE_ID, SRC_TYPE_DESC, SRC_TYPE_CD, PRVDR_NAM, EXTRL_SW, 
    DERIV_SW, LOC_INFO_TXT, PREF_SW, VNDR_SW, DEFLT_NOTIF_EMAIL_ADDR)
 Values
   (4, 'Records from CPP Internal config', 'Process', 'CPPInternal', 'N', 
    'Y', NULL, 'N', 'N', 'eds@mastercard.com');    
    
COMMIT;
