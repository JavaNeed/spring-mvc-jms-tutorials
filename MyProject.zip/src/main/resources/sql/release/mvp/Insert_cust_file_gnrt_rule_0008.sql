SET DEFINE OFF;
alter session set current_schema = EDS_OWNER;

Insert into EDS_CUST_FILE_GNRT_RULE
   (EDS_CUST_FILE_GNRT_RULE_ID, RULE_CAT_CD, ADC_NOTIF_SW, ACCT_ACTV_SW, ACCT_VAL_SW, 
    FRAUD_RPT_SW, RPT_BFRE_SW, DUP_SW,  LST_UPDT_DT, LST_UPDT_USER_ID)
 Values
   (1, 'DB', 'N', 'Y', 'Y', 'N', 'N', 'N', SYSDATE, 'EDS_USER');
   
Insert into EDS_CUST_FILE_GNRT_RULE
   (EDS_CUST_FILE_GNRT_RULE_ID, RULE_CAT_CD, RULE_IMPLEMENTER_CLASS_NAM, ADC_NOTIF_SW, ACCT_ACTV_SW, 
    ACCT_VAL_SW, FRAUD_RPT_SW, RPT_BFRE_SW, DUP_SW, LST_UPDT_DT, LST_UPDT_USER_ID)
 Values
   (2, 'Custom', 'com.mastercard.ess.eds.core.rule.FileGenerationCustomRules', 'N', 'Y', 
    'Y', 'N', 'N', 'N', SYSDATE, 'EDS_USER');
    
COMMIT;
