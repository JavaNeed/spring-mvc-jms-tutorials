SET DEFINE OFF;

alter session set current_schema = EDS_OWNER;

Insert into EDS_EVENT
   (EDS_EVENT_ID, TYPE_TXT, EVENT_NAM, EVENT_DESC, EDS_MSG_FROM_ADDR, 
    LST_UPDT_DT, LST_UPDT_USER_ID, EDS_TMPLT_ID, ENBL_SW)
 Values
   (1, 'I', 'Invalid Source data file received', 'This event is raised when an invalid source file is received from a provider in the EDS system', 'eds@mastercard.com', 
    SYSDATE, 'EDS_USER', 1, 'Y');

Insert into EDS_EVENT
   (EDS_EVENT_ID, TYPE_TXT, EVENT_NAM, EVENT_DESC, EDS_MSG_FROM_ADDR, 
    LST_UPDT_DT, LST_UPDT_USER_ID, EDS_TMPLT_ID, ENBL_SW)
 Values
   (2, 'I', 'Source data File received', 'This event is raised when a valid source file is received for processing by the EDS system', 'eds@mastercard.com', 
    SYSDATE, 'EDS_USER', 2, 'Y');

Insert into EDS_EVENT
   (EDS_EVENT_ID, TYPE_TXT, EVENT_NAM, EVENT_DESC, EDS_MSG_FROM_ADDR, 
    LST_UPDT_DT, LST_UPDT_USER_ID, EDS_TMPLT_ID, ENBL_SW)
 Values
   (3, 'E', 'At-risk PANs not found ', 'This event is raised when no compromised PANs are available for a given active customer subscribed to EDS', 'eds@mastercard.com', 
    SYSDATE, 'EDS_USER', 3, 'Y');
    
Insert into EDS_EVENT
   (EDS_EVENT_ID, TYPE_TXT, EVENT_NAM, EVENT_DESC, EDS_MSG_FROM_ADDR, 
    LST_UPDT_DT, LST_UPDT_USER_ID, EDS_TMPLT_ID, ENBL_SW)
 Values
   (4, 'E', 'At-risk PANs available for download ', 'This event is raised when compromised PANs are available for a given active customer subscribed to EDS', 'eds@mastercard.com', 
    SYSDATE, 'EDS_USER', 4, 'Y');
    
Insert into EDS_EVENT
   (EDS_EVENT_ID, TYPE_TXT, EVENT_NAM, EVENT_DESC, ENBL_SW, 
    EDS_MSG_FROM_ADDR, LST_UPDT_DT, LST_UPDT_USER_ID, EDS_TMPLT_ID)
 Values
   (5, 'V', 'Monthly Active Account Report for Vendors', 'Monthly Active Account Report for Vendors', 'Y', 
    'eds@mastercard.com', SYSDATE, 'EDS_USER', 5);

Insert into EDS_EVENT
   (EDS_EVENT_ID, TYPE_TXT, EVENT_NAM, EVENT_DESC, ENBL_SW, 
    EDS_MSG_FROM_ADDR, LST_UPDT_DT, LST_UPDT_USER_ID, EDS_TMPLT_ID)
 Values
   (6, 'I', 'CPP REPORT FILE GENERATED', 'CPP Report generated', 'Y', 
    'eds@mastercard.com', SYSDATE, 'EDS_USER', 6);


COMMIT;
