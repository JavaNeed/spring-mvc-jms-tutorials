SET DEFINE OFF;
Insert into EDS_OWNER.EDS_RPT_TYPE
   (EDS_RPT_TYPE_ID, TYPE_NAM, RPT_DESC, CRTE_DT)
 Values
   (8, 'CPP Simulation Report', 'CPP Simulation Report', TO_DATE('02/12/2018 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));
   
   
   Insert into EDS_OWNER.EDS_EMAIL_TMPLT
   (EDS_EMAIL_TMPLT_ID, TMPLT_MSG_BODY_TXT, TMPLT_SUBJ_TXT, TMPLT_SGNTR_TXT, LST_UPDT_DT, 
    LST_UPDT_USER_ID)
 Values
   (10, 'You have been successfully subscribed to receive the Mastercard Early Detection System email notifications. Email alerts are sent every day when there is at-Risk PAN data available to download. The data remains available to download for 30 days. In the event that no data is available for download, no email is sent for that specific day. However, if there is no data in the prior 7 days an email will be sent to confirm no data was available.
<br><br>
 Users who have been setup to download the EDS at-Risk PAN files should: 
<br>
<UL>
    <LI>Access Mastercard Connect using a browser to go to <a href="https://www.mastercardconnect.com"> https://www.mastercardconnect.com</a>.</LI>
    <LI>Sign in to Mastercard Connect using their User ID and Password. </LI>
    <LI>After successful sign in, click on the ''My Apps'' menu. </LI>
    <LI>From the list of available applications click ''MasterCard Data Exchange'' to launch the application. </LI>
    <LI>MDE launches in a new browser window or tab, from the main landing page select the specific end point that has been setup for EDS files in the left side menu. </LI>
    <LI>Once the endpoint has been selected click on the "Download Files" option in the left side menu to see a list of available files. </LI>
    <LI>Select the file from the list to download - EDS files are bulk file type TZV0. </LI>
    <LI>Files that have been downloaded previously will be saved as Archives and available under the "View Archives" option in the left side menu.</LI>
 
</UL>
<br> 
If you need any assistance please contact your regional Enterprise Security Solutions (ESS) representative or regional Global Customer Service team.
<br>', 'Early Detection System - Your Subscription is Now Active', 'Kind regards,<br><br>
The Mastercard Early Detection System Team', TO_DATE('02/12/2018 00:18:16', 'MM/DD/YYYY HH24:MI:SS'), 
    'EDS_USER');
Insert into EDS_OWNER.EDS_EMAIL_TMPLT
   (EDS_EMAIL_TMPLT_ID, TMPLT_MSG_BODY_TXT, TMPLT_SUBJ_TXT, TMPLT_SGNTR_TXT, LST_UPDT_DT, 
    LST_UPDT_USER_ID)
 Values
   (11, 'Thank you for subscribing to Early Detection System (EDS). We are pleased to confirm that we have completed setup of the following ICAs that were requested:<br>$customerOnboardIcas<br>      
      Your subscription to Early Detection System is now live and the delivery of at-Risk Primary Account Number (PAN) data will begin. Email notifications about the information on availability of at-Risk PANs will be sent to this email address and any additional people/email addresses requested to receive notifications within your organization. Email alerts are sent every day when there is at-Risk PAN data available to download.
      <br><br>Users who have been setup to download the EDS at-Risk PAN files should: 
<br>
<UL>
    <LI>Access Mastercard Connect using a browser to go to <a href="https://www.mastercardconnect.com"> https://www.mastercardconnect.com</a>.</LI>
    <LI>Sign in to Mastercard Connect using their User ID and Password. </LI>
    <LI>After successful sign in, click on the ''My Apps'' menu. </LI>
    <LI>From the list of available applications click ''MasterCard Data Exchange'' to launch the application. </LI>
    <LI>MDE launches in a new browser window or tab, from the main landing page select the specific end point that has been setup for EDS files in the left side menu. </LI>
    <LI>Once the endpoint has been selected click on the "Download Files" option in the left side menu to see a list of available files. </LI>
    <LI>Select the file from the list to download - EDS files are bulk file type TZV0. </LI>
    <LI>Files that have been downloaded previously will be saved as Archives and available under the "View Archives" option in the left side menu.</LI>
 
</UL>
<br> 
If you need any assistance please contact your regional Enterprise Security Solutions (ESS) representative or regional Global Customer Service team.
<br>', 'Early Detection System - Setup Complete', 'Kind regards,<br><br>
The Mastercard Early Detection System Team', TO_DATE('02/12/2018 00:03:00', 'MM/DD/YYYY HH24:MI:SS'), 
    'EDS_USER');
	
	Insert into EDS_OWNER.EDS_EMAIL_TMPLT
   (EDS_EMAIL_TMPLT_ID, TMPLT_MSG_BODY_TXT, TMPLT_SUBJ_TXT, TMPLT_SGNTR_TXT, LST_UPDT_DT, 
    LST_UPDT_USER_ID)
 Values
   (12, 'Hi,
<br><br>
Please find attached EDS Simulation result report for $reportDate.
<br>', 'EDS simulation report for $reportDate', 'Thank You<br><br>
Early Detection System
', TO_DATE('02/12/2018 05:00:00', 'MM/DD/YYYY HH24:MI:SS'), 
    'EDS_USER');
	
	update EDS_OWNER.EDS_EMAIL_TMPLT set TMPLT_MSG_BODY_TXT = 'Dear $customerName, <br>
<p>
We want to inform you that there were no new at-risk PANs for the following ICA(s) from the Mastercard Early Detection System this week:</p>
$ica
<p>
If you experience any issues or have questions, please contact the Mastercard Global Customer Service (GCS) team at 1- 800-999-0363 or <a href="mailto:ess_cos_support_team@mastercard.com">ess_cos_support_team@mastercard.com</a> for support. 
</p>', TMPLT_SUBJ_TXT =  'Mastercard Early Detection System Notification' ,TMPLT_SGNTR_TXT = 'Kind regards,<br><br>
The Mastercard Early Detection System Team' , LST_UPDT_DT = TO_DATE('02/12/2018 01:31:53', 'MM/DD/YYYY HH24:MI:SS') where EDS_EMAIL_TMPLT_ID = 3;

update EDS_OWNER.EDS_EMAIL_TMPLT set TMPLT_MSG_BODY_TXT = 'Dear $customerName, <br>
<p>
We want to inform you that there are new at-risk PANs for the following ICA(s) from the Mastercard Early Detection System:
</p>
$ica
<p>
At risk PANs are available to download through Mastercard Data Exchange which can be accessed from Mastercard Connect (https://www.mastercardconnect.com).
</p>
<p>
If you experience any issues or have questions, please contact the Mastercard Global Customer Service (GCS) team at 1- 800-999-0363 or <a href="mailto:ess_cos_support_team@mastercard.com">ess_cos_support_team@mastercard.com</a> for support. 
</p>', TMPLT_SUBJ_TXT =  'Mastercard Early Detection System Data Delivery' ,TMPLT_SGNTR_TXT = 'Kind regards,<br><br>
The Mastercard Early Detection System Team' , LST_UPDT_DT = TO_DATE('02/12/2018 01:31:53', 'MM/DD/YYYY HH24:MI:SS') where EDS_EMAIL_TMPLT_ID = 4;

Insert into EDS_OWNER.EDS_EVENT
   (EDS_EVENT_ID, TYPE_TXT, EVENT_NAM, EVENT_DESC, ENBL_SW, 
    EDS_MSG_FROM_ADDR, LST_UPDT_DT, LST_UPDT_USER_ID, EDS_TMPLT_ID, DISP_SW)
 Values
   (10, 'E', 'Welcome Email for Notification Subscription', 'This event is raised to send welcome email for newly subscribed user for external events.', 'Y', 
    'eds_stage@mastercard.com', TO_DATE('02/12/2018 04:27:21', 'MM/DD/YYYY HH24:MI:SS'), 'EDS_USER', 10, 'N');
	
	Insert into EDS_OWNER.EDS_EVENT
   (EDS_EVENT_ID, TYPE_TXT, EVENT_NAM, EVENT_DESC, ENBL_SW, 
    EDS_MSG_FROM_ADDR, LST_UPDT_DT, LST_UPDT_USER_ID, EDS_TMPLT_ID, DISP_SW)
 Values
   (11, 'E', 'Welcome Email for ICA', 'This event is raised to send welcome email to new onboarded customers.', 'Y', 
    'eds_stage@mastercard.com', TO_DATE('02/12/2018 04:27:21', 'MM/DD/YYYY HH24:MI:SS'), 'EDS_USER', 11, 'N');
Insert into EDS_OWNER.EDS_EVENT
   (EDS_EVENT_ID, TYPE_TXT, EVENT_NAM, EVENT_DESC, ENBL_SW, 
    EDS_MSG_FROM_ADDR, LST_UPDT_DT, LST_UPDT_USER_ID, EDS_TMPLT_ID, DISP_SW)
 Values
   (12, 'I', 'CPP Simulation Report', 'This event is raised to send the simulation report to subscribed users.', 'Y', 
    'eds_stage@mastercard.com', TO_DATE('02/12/2018 08:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'EDS_USER', 12, 'Y');

COMMIT ;