BEGIN
DBMS_REFRESH.DESTROY (
   name  => 'EDS_OWNER.EMS_MV_REFRESH_GROUP');
END;
/

BEGIN
   DBMS_REFRESH.MAKE (
      name => 'EDS_OWNER.EMS_MV_REFRESH_GROUP',
      list => '', 
      next_date => SYSDATE, 
      interval => 'trunc(sysdate) + 18/24 + round((sysdate - trunc(sysdate)) + 1)/4',
      implicit_destroy => FALSE, 
      rollback_seg => '',
      push_deferred_rpc => TRUE, 
      refresh_after_errors => FALSE);
END;
/


BEGIN
   DBMS_REFRESH.ADD (
      name => 'EDS_OWNER.EMS_MV_REFRESH_GROUP',
      list => 'EDS_OWNER.MPS_AUTH_ACCT_RNG,EDS_OWNER.MPS_MBR,EDS_OWNER.DA_MBR_HIER,EDS_OWNER.TGPACYD,EDS_OWNER.LCN_CUST,EDS_OWNER.MBR_HIER,EDS_OWNER.EDS_MBR_HIER',
      lax => TRUE);
END;
/
