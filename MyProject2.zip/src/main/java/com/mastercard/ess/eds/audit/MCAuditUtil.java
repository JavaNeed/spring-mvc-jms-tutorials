package com.mastercard.ess.eds.audit;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.MDC;

public final class MCAuditUtil {
	
	private static final SimpleDateFormat dtFrmter = new SimpleDateFormat(
			"MMM dd, yyyy HH:mm:ss z");
	
	public static Object getField(PopulatableField field) {
		return MCAuditUtil.getField(field.valueOf());
	}

	public static void setField(PopulatableField field, String value) {
		MCAuditUtil.setField(field.valueOf(), value);
	}

	public static void setField(PopulatableField field, Date value) {
		MCAuditUtil.setField(field.valueOf(), dtFrmter.format(value));
	}

	public static void removeField(PopulatableField field) {
		MCAuditUtil.removeField(field.valueOf());
	}

	public static void removeAll() {
		MCAuditUtil.removeDestMachine();
		MCAuditUtil.removeSourceMachine();
		MCAuditUtil.removeUserName();
		MCAuditUtil.removeOriginSystem();
	}

	public static void setUserName(String userName) {
		MCAuditUtil.setField(PopulatableField.USER_NAME.valueOf(),
				(String) userName);
	}

	public static String getUserName() {
		return (String) MCAuditUtil.getField(PopulatableField.USER_NAME
				.valueOf());
	}

	public static void removeUserName() {
		MCAuditUtil.removeField(PopulatableField.USER_NAME.valueOf());
	}
	
	public static void removeOriginSystem() {
		MCAuditUtil.removeField(PopulatableField.ORIGN_SYSTEM.valueOf());
	}

	public static void setSourceMachine(String sourceIp, String sourcePort) {
		MCAuditUtil.setField(PopulatableField.SOURCE_IP, sourceIp);
		MCAuditUtil.setField(PopulatableField.SOURCE_PORT, sourcePort);
	}

	public static void removeSourceMachine() {
		MCAuditUtil.removeField(PopulatableField.SOURCE_IP);
		MCAuditUtil.removeField(PopulatableField.SOURCE_PORT);
	}

	public static void setDestMachine(String destIp, String destPort) {
		MCAuditUtil.setField(PopulatableField.DEST_IP, destIp);
		MCAuditUtil.setField(PopulatableField.DEST_PORT, destPort);
	}

	public static void removeDestMachine() {
		MCAuditUtil.removeField(PopulatableField.DEST_IP);
		MCAuditUtil.removeField(PopulatableField.DEST_PORT);
	}

	public static void setDateField(PopulatableField field, Date date) {
		MCAuditUtil.setField(field, date);
	}

	public static Date getDateField(PopulatableField field) {
		return (Date) MCAuditUtil.getField(field);
	}

	private static Object getField(String name) {
		return MDC.get((String) name);
	}

	private static void setField(String name, String value) {
		MDC.put((String) name, (String) value);
	}

	private static void removeField(String name) {
		MDC.remove((String) name);
	}
}
