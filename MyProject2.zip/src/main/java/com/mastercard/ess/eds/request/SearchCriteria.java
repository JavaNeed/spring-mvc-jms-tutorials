package com.mastercard.ess.eds.request;

public class SearchCriteria {
	private Integer ica;
	private String orgName;
	private String endPoint;
	private String emailId;
	private String bulkid;
	
	public Integer getIca() {
		return ica;
	}
	public void setIca(Integer ica) {
		this.ica = ica;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getEndPoint() {
		return endPoint;
	}
	public void setEndPoint(String endPoint) {
		this.endPoint = endPoint;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getBulkid() {
		return bulkid;
	}
	public void setBulkid(String bulkid) {
		this.bulkid = bulkid;
	}

}
