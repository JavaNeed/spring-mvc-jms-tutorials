package com.mastercard.ess.eds.response;

import java.util.Map;

/**
 * @author e069468
 *
 */
public class ReferenceResponse {

	private String referenceType;
	private Map<String, String> references ;
	
	public String getReferenceType() {
		return referenceType;
	}
	public void setReferenceType(String referenceType) {
		this.referenceType = referenceType;
	}
	public Map<String, String> getReferences() {
		return references;
	}
	public void setReferences(Map<String, String> references) {
		this.references = references;
	}
	
	
}
