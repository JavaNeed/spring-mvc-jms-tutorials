package com.mastercard.ess.eds.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.audit.AuditLogger;
import com.mastercard.ess.eds.exceptions.EDSException;
import com.mastercard.ess.eds.model.UserDTO;
import com.mastercard.ess.eds.util.UserIdentityUtil;

@Component
public class EDSAuthenticationFilter extends
		AbstractPreAuthenticatedProcessingFilter {

	private static final Logger logger = LoggerFactory
			.getLogger(EDSAuthenticationFilter.class);
	
	@Autowired
	private AuditLogger auditLogger;
	
	@Autowired
	UserIdentityUtil userIdentityUtil;

	@Override
	protected Object getPreAuthenticatedCredentials(HttpServletRequest request) {
		return "";
	}

	@Override
	protected Object getPreAuthenticatedPrincipal(HttpServletRequest request) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : getPreAuthenticatedPrincipal");
		}

		UserDTO user = null;

		try {
			user = userIdentityUtil.getUserFromSAML();
		} catch (EDSException e) {
			logger.debug("SAML Parsing Error: " + e.getMessage());

		}

		if (logger.isDebugEnabled()) {
			logger.debug("Exit From Method : getUserDetails");
		}

		return user;
	}

	@Override
	public void doFilter(final ServletRequest req, final ServletResponse res,
			final FilterChain chain) throws IOException, ServletException {
		final HttpServletRequest request = (HttpServletRequest) req;
		final HttpServletResponse response = (HttpServletResponse) res;

		UserDTO user = null;

		try {
			user = userIdentityUtil.getUserFromSAML();
		} catch (EDSException e) {
			logger.debug("SAML Parsing Error: " + e.getMessage());

		}
		
		logger.info("user.getUserId() **** : " + user.getUserId());
		
		auditLogger.setAll(request, user.getUserId());
        auditLogger.logAuthenticationInfo("User authenticated successfully");
		auditLogger.removeAll();
		
		super.doFilter((ServletRequest) request, (ServletResponse) response,
				chain);
	}

	@Autowired
	public void setAuthenticationManager(
			final AuthenticationManager authenticationManager) {
		super.setAuthenticationManager(authenticationManager);
	}
}