
package com.mastercard.ess.eds.controllers;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mastercard.ess.eds.constant.ApplicationLiterals;
import com.mastercard.ess.eds.dao.EventDAO;
import com.mastercard.ess.eds.model.Event;

/**
 * @author e069468
 *
 */
@Api(value = ApplicationLiterals.EVENT_SERVICE, description = ApplicationLiterals.EVENT_SERVICE_DESCRIPTION)
@RestController
@Component 
public class EventServiceController {

	private static final Logger logger = LoggerFactory.getLogger(EventServiceController.class);

	@Autowired
	private EventDAO eventDAO;

	// for Junit
	public void setEventService(EventDAO eventDAO) {
		this.eventDAO = eventDAO;
	}

	/**This controller is to return the list of events present in EDS_Event Table
	 * @return
	 * @throws SQLException
	 */
	
	@PreAuthorize("hasRole(T(com.mastercard.ess.eds.constant.ApplicationLiterals).ROLE_EDS_CUST_ADMIN)")
	@ApiOperation(value = ApplicationLiterals.EVENT_SERVICE_LIST)
	@RequestMapping(value ="/eds/v1/events", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<List<Event>> getEvents() throws SQLException{		

		if (logger.isDebugEnabled()) {
			logger.debug("Enter From Method : getEvents");
		}

		List<Event> eventList = eventDAO.getEvents();

		if (logger.isDebugEnabled()) {
			logger.debug("Exit From Method : getEvents");
		}
		return new ResponseEntity<>(eventList, HttpStatus.OK);
	}

}
