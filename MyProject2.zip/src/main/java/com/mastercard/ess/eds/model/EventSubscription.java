package com.mastercard.ess.eds.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author e069468
 *
 */
@Entity // entity should be created via "new" and not injected as spring bean
@Table(name = "EDS_EVENT_SUBSC", schema = "EDS_OWNER")
public class EventSubscription {

	@Id
	@Column(name="EDS_EVENT_SUBSC_ID",unique=true,nullable=false)
	@SequenceGenerator(name = "seq", sequenceName = "EDS_EVENT_SUBSC_ID_SEQ")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	private int eventSubsId;
	
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}
	@Column(name="LST_UPDT_USER_ID")
	private String lstUpdtUserId;
	
	@Column(name="ENBL_SW")
	private String enabledSW;
	
	@Column(name="LST_UPDT_DT")
	private Date lstUpdtdt;
	
	@Column(name="EVENT_ID")
	private Integer eventId;
	
	@Column(name="ORG_NAM")
	private String orgName;
	
	@Column(name="EMAIL_ID")
	private String emailId;
	
	@Column(name="ICA_NUM")
	private Integer ica;
	
	@Column(name="CRTE_DT")
	private Date createDate;
	
	@Column(name="CRTE_USER_ID")
	private String createUserId;
	
	@Column(name="EDS_SRC_TYPE_ID")
	private Integer edsSourceTypeId;
	
	@ManyToOne
	@JoinColumn(name = "EVENT_ID", insertable=false , updatable =false)
	private Event event ;

	@ManyToOne
	@JoinColumn(name = "EDS_SRC_TYPE_ID", insertable=false , updatable =false)
	private EDSSourceType edsSourceType ;
	
	public EDSSourceType getEdsSourceType() {
		return edsSourceType;
	}
	public void setEdsSourceType(EDSSourceType edsSourceType) {
		this.edsSourceType = edsSourceType;
	}
	
	public Event getEvent() {
		return event;
	}
	public void setEvent(Event event) {
		this.event = event;
	}
	public Integer getEventId() {
		return eventId;
	}
	public String getEventName() {
		return orgName;
	}
	public void setEventName(String eventName) {
		this.orgName = eventName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Integer getIca() {
		return ica;
	}
	public void setIca(Integer ica) {
		this.ica = ica;
	}
	public int getEventSubsId() {
		return eventSubsId;
	}
	public void setEventSubsId(int eventSubsId) {
		this.eventSubsId = eventSubsId;
	}
	public String getLstUpdtUserId() {
		return lstUpdtUserId;
	}
	public void setLstUpdtUserId(String lstUpdtUserId) {
		this.lstUpdtUserId = lstUpdtUserId;
	}
	public String getEnabledSW() {
		return enabledSW;
	}
	public void setEnabledSW(String enabledSW) {
		this.enabledSW = enabledSW;
	}
	public Date getLstUpdtdt() {
		return lstUpdtdt;
	}
	public void setLstUpdtdt(Date lstUpdtdt) {
		this.lstUpdtdt = lstUpdtdt;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getCreateUserId() {
		return createUserId;
	}
	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}
	public Integer getEdsSourceTypeId() {
		return edsSourceTypeId;
	}
	public void setEdsSourceTypeId(Integer edsSourceTypeId) {
		this.edsSourceTypeId = edsSourceTypeId;
	}

}
