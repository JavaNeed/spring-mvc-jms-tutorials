package com.mastercard.ess.eds.audit;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Logger class to manage audit logging.
 */
@Component
public class AuditLogger {
	private static final Logger LOGGER = LoggerFactory.getLogger(AuditLogger.class);
	private static final Logger AUDIT_LOGGER = LoggerFactory.getLogger("MCAuditLogger");

	/**
	 * Initialize local thread variables used for audit logging.
	 */
	public void setAll(HttpServletRequest request, String userId) {
		MCAuditUtil.setSourceMachine(request.getRemoteAddr(), Integer.toString(request.getRemotePort()));
		MCAuditUtil.setDestMachine(request.getLocalAddr(), Integer.toString(request.getLocalPort()));
		if (userId != null) {
			MCAuditUtil.setUserName(userId);
		}
		Date reqDtTm = new Date();
		MCAuditUtil.setDateField(PopulatableField.REQUEST_DATE_TIME, reqDtTm);
		MCAuditUtil.setField(PopulatableField.ORIGN_SYSTEM, request.getServerName());
	}

	public void logInvalidRequest(HttpServletRequest request, String errorMessage) {
		LOGGER.error(errorMessage);
		String path = request.getRequestURL().toString();
		LOGGER.error("Access Denied for request " + path);	
		LOGGER.info("Logging Invalid Request Audit Event...");
		AUDIT_LOGGER.warn(AuditLogUtility.buildAuditRecord(EventType.INVALID_LOGICAL_ACCESS_ATTEMPT, "Access to path", path, errorMessage, Integer.toString(HttpServletResponse.SC_FORBIDDEN)));
	}

	public void logSessionCreation(String sessionId) {
		LOGGER.info("Logging Session Creation Audit Event...");
		AUDIT_LOGGER.warn(AuditLogUtility.buildAuditRecord(EventType.INIT_AUDIT_TRAIL, "Session created", sessionId, "Audit trail initialized", Integer.toString(HttpServletResponse.SC_OK)));
	}

	public void logAuthenticationInfo(String message) {
		LOGGER.info("Logging Authentication Audit Event...");
		AUDIT_LOGGER.info(AuditLogUtility.buildAuditRecord(EventType.AUTHENTICATION_MECHANISM, null, null, message, Integer.toString(HttpServletResponse.SC_OK)));
	}
	
	/**
	 * Remove thread local variables used for audit logging.
	 */
	public void removeAll() {
		MCAuditUtil.removeAll();
	}
}
