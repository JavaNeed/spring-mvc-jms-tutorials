package com.mastercard.ess.eds.controllers;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mastercard.ess.eds.constant.ApplicationLiterals;
import com.mastercard.ess.eds.exceptions.EDSException;
import com.mastercard.ess.eds.model.UserDTO;
import com.mastercard.ess.eds.util.UserIdentityUtil;

@RestController
@Component 
@Api(value = ApplicationLiterals.AUTH_SERVICE, description = ApplicationLiterals.AUTH_SERVICE_DESCRIPTION)
public class AuthorizationServiceController {

	private static final Logger logger = LoggerFactory.getLogger(AuthorizationServiceController.class);

	@Autowired
	private UserIdentityUtil userIdentityUtil;
	
	@ApiOperation(value = ApplicationLiterals.AUTH_SERVICE_USER)
	@RequestMapping(value ="/eds/v1/user", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<UserDTO> getUserDetails() throws EDSException{

		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : getUserDetails");
		}

		UserDTO user  = null;

		user =  userIdentityUtil.getUserFromSAML();  
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit From Method : getUserDetails");
		}
		
		return new ResponseEntity<UserDTO>(user, HttpStatus.OK);
	}


}
