package com.mastercard.ess.eds.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.request.ICAData;
import com.mastercard.ess.eds.response.ReferenceResponse;
import com.mastercard.ess.eds.util.HibernateUtils;

/**
 * @author e069468
 *
 */
@Component
public class ICAListDAO {

	private static final Logger logger = LoggerFactory.getLogger(ICAListDAO.class);
	
	private static final String FETCH_ICAS_DESC = "select accessName FROM com.mastercard.ess.eds.model.EDSMemberHier ICA WHERE ICA.icaCode= :icaNum";

	private static final String FETCH_CUSTMASTER_ICAS="select icaNum from com.mastercard.ess.eds.model.EDSCustMaster ICA where ICA.icaNum = :icaNum and isActivSW = 'Y'";
	
	private static final String FETCH_ICAS = "SELECT DISTINCT (cust_mstr.icaNum) , mbr_hier.accessName FROM com.mastercard.ess.eds.model.EDSCustMaster cust_mstr, " +
												 "com.mastercard.ess.eds.model.EDSMemberHier mbr_hier where mbr_hier.icaCode = cust_mstr.icaNum" ;
	
	/**
	 * This method is to fetch the list of icas present in EDS_CUST_MSTR table
	 * 
	 * @param resource
	 * @return
	 * @throws SQLException
	 */
	@SuppressWarnings("unchecked")
	public ReferenceResponse getSignedICAList(String resource) {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : getSignedICAList");
		}

		SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
		Session session = sessionFactory.openSession();

		ReferenceResponse icaListResp = new ReferenceResponse();
		Map<String, String> icasMapper = new HashMap<String, String>();
		icaListResp.setReferenceType(resource);
		List<Object[]> icasDetailsArray =  session.createQuery(FETCH_ICAS).list();
		for (Object[] icaDetails : icasDetailsArray) {
			Integer ica = (Integer) icaDetails[0];
			icasMapper.put(String.valueOf(ica), (String) icaDetails[1]);

		}

		icaListResp.setReferences(icasMapper);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit From  : getSignedICAList");
		}
		return icaListResp;
	}

	
	@SuppressWarnings("unchecked")
	public ICAData getUnsignedICAList(String resource, String ica) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : getUnsignedICAList");
		}
		ICAData icaResponse  =  new ICAData();
		if(StringUtils.isNotBlank(ica)){
			
			icaResponse.setIcaNum(Integer.valueOf(ica));
			icaResponse.setValid(false);
			icaResponse.setOnboarded(false);
			
			SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
			Session session = sessionFactory.openSession();
			
			Query custQuery = session.createQuery(FETCH_CUSTMASTER_ICAS);
			custQuery.setParameter("icaNum", Integer.parseInt(ica));
			
			List<Integer> icas = (List<Integer>) custQuery.list();
			if (icas != null && !icas.isEmpty()) {
				icaResponse.setOnboarded(true);
			} 
			
			if(!icaResponse.isOnboarded()){
				Query hqlquery = session.createQuery(FETCH_ICAS_DESC);
				hqlquery.setParameter("icaNum", Integer.parseInt(ica));
				
				List<String> accessName = (List<String>) hqlquery.list();			
				if (accessName != null && !accessName.isEmpty()) {
					icaResponse.setIcaDescription(accessName.get(0));
					icaResponse.setValid(true);
				}
			}
	
			if (logger.isDebugEnabled()) {
				logger.debug("Exit From  : getUnsignedICAList");
			}
		}
 
		return icaResponse;
	}
	

}
