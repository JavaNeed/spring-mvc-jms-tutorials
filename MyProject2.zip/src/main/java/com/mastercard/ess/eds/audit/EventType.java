package com.mastercard.ess.eds.audit;

import java.io.Serializable;

public final class EventType implements Serializable {
	public static final EventType DEFAULT = new EventType(0, "Default");

	public static final EventType ACCESS_CARDHOLDER_DATA = new EventType(10000,
			"All individual access to cardholder data");

	public static final EventType ADMINISTRATIVE_ACTIONS = new EventType(20000,
			"All actions taken by any individual with administrative privileges");

	public static final EventType ACCESS_AUDIT_TRAILS = new EventType(30000,
			"Access to all audit trails");

	public static final EventType INVALID_LOGICAL_ACCESS_ATTEMPT = new EventType(
			40000, "Invalid logical access attempt");

	public static final EventType AUTHENTICATION_MECHANISM = new EventType(
			50000, "Use of identification and authentication mechanism");

	public static final EventType ACCOUNT_CRUD = new EventType(60000,
			"Account creation/modification/deletion");

	public static final EventType INIT_AUDIT_TRAIL = new EventType(70000,
			"Initialization of Audit trail");

	public static final EventType CRT_DEL_SYSTEM_OBJECTS = new EventType(80000,
			"Creation and deletion of system level objects");

	public static final EventType APPLICATION_SPEC = new EventType(90000,
			"Reserved for application use");

	private int eventType = 0;
	private String description;
	private static final long serialVersionUID = 3775052161150789189L;

	private EventType(int eventType, String description)
			throws IllegalArgumentException {
		int et = eventType / 10000;

		if (((et > 0) && (et < 10)) || (eventType == 0)) {
			this.eventType = eventType;
		} else {
			throw new IllegalArgumentException(
					"Invalid Event Id passed as parameter");
		}

		this.description = description;
	}

	public String getEventType() {
		if (this.eventType > 0) {
			return Integer.toString(this.eventType);
		}
		return "00000";
	}

	public String getDescription() {
		return this.description;
	}

	public int getEventTypeCode() {
		return this.eventType;
	}

	public String toString() {
		return getEventType();
	}

	public boolean equals(Object obj) {
		if (obj instanceof EventType) {
			return (((EventType) obj).eventType == this.eventType);
		}
		return false;
	}

	public int hashCode() {
		return this.eventType;
	}
}
