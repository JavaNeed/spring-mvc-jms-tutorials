package com.mastercard.ess.eds.config;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.access.AccessDeniedHandlerImpl;
import org.springframework.security.web.authentication.Http403ForbiddenEntryPoint;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationProvider;

import com.mastercard.ess.eds.authentication.PreAuthenticatedUserDetailsService;
import com.mastercard.ess.eds.filter.EDSAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {
	
	private static final Logger log = LoggerFactory.getLogger(SecurityConfiguration.class);

	@Inject
	private EDSAuthenticationFilter edsAuthenticationFilter;

	@Inject
	private PreAuthenticatedUserDetailsService userDetailsService;
	
	 
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		log.info("Configuring Http Security..."); 
		
		edsAuthenticationFilter.setCheckForPrincipalChanges(true);
		edsAuthenticationFilter.setInvalidateSessionOnPrincipalChange(true);
		edsAuthenticationFilter.setContinueFilterChainOnUnsuccessfulAuthentication(false);
		
		http
			.addFilter(edsAuthenticationFilter)
			.authorizeRequests()	
					.anyRequest().authenticated()
					.and()
				.exceptionHandling()
					.authenticationEntryPoint(new Http403ForbiddenEntryPoint())
					.accessDeniedHandler(new AccessDeniedHandlerImpl())
					.and()
				.logout()
					.permitAll()
					.and()
				.csrf().disable();				
		 
		
		log.info("Done configuring Http Security"); 
	}

	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		PreAuthenticatedAuthenticationProvider authenticationProvider = new PreAuthenticatedAuthenticationProvider();
		authenticationProvider.setPreAuthenticatedUserDetailsService(userDetailsService);
		auth
			.authenticationProvider(authenticationProvider);
	}
	
	 @Bean(name="authenticationManager")
	 @Override
	 @Order(Ordered.LOWEST_PRECEDENCE)
	 public AuthenticationManager authenticationManagerBean() throws Exception {
		 return super.authenticationManagerBean();
	 }
	

}
