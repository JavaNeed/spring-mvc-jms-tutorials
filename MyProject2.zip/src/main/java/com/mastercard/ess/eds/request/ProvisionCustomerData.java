package com.mastercard.ess.eds.request;

import java.util.Date;

public class ProvisionCustomerData {

	private Integer edsCustMasterId;
	private Integer ica;
	private String icaDescription;
	private String endPoint;
	private String defaultNotficationEmail;
	private Date createdDate;
	private Date renewalDate;
	private String bulkId;
	private String isActiveSW;
	private boolean isDuplicate ;
	
	public boolean isDuplicate() {
		return isDuplicate;
	}
	public void setDuplicate(boolean isDuplicate) {
		this.isDuplicate = isDuplicate;
	}
	public Integer getEdsCustMasterId() {
		return edsCustMasterId;
	}
	public void setEdsCustMasterId(Integer edsCustMasterId) {
		this.edsCustMasterId = edsCustMasterId;
	}
	public Integer getIca() {
		return ica;
	}
	public void setIca(Integer ica) {
		this.ica = ica;
	}
	public String getIcaDescription() {
		return icaDescription;
	}
	public void setIcaDescription(String icaDescription) {
		this.icaDescription = icaDescription;
	}
	public String getEndPoint() {
		return endPoint;
	}
	public void setEndPoint(String endPoint) {
		this.endPoint = endPoint;
	}
	public String getDefaultNotficationEmail() {
		return defaultNotficationEmail;
	}
	public void setDefaultNotficationEmail(String defaultNotficationEmail) {
		this.defaultNotficationEmail = defaultNotficationEmail;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getRenewalDate() {
		return renewalDate;
	}
	public void setRenewalDate(Date renewalDate) {
		this.renewalDate = renewalDate;
	}
	public String getBulkId() {
		return bulkId;
	}
	public void setBulkId(String bulkId) {
		this.bulkId = bulkId;
	}
	public String getIsActiveSW() {
		return isActiveSW;
	}
	public void setIsActiveSW(String isActiveSW) {
		this.isActiveSW = isActiveSW;
	}
	
}
