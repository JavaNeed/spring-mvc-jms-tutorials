package com.mastercard.ess.eds.controllers;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mastercard.ess.eds.constant.ApplicationLiterals;
import com.mastercard.ess.eds.constant.ValidationParameter;
import com.mastercard.ess.eds.exceptions.EDSException;
import com.mastercard.ess.eds.request.ProvisionCustomerData;
import com.mastercard.ess.eds.request.ProvisionCustomerRequest;
import com.mastercard.ess.eds.response.ProvisionCustomerResponse;
import com.mastercard.ess.eds.service.CustomerHelper;
@Api(value = ApplicationLiterals.CUST_SERVICE, description = ApplicationLiterals.CUST_SERVICE_DESCRIPTION)
@RestController
@Component

public class CustomerServiceController extends BaseController {

	private static final Logger logger = LoggerFactory.getLogger(CustomerServiceController.class);
	
	@Autowired
	private CustomerHelper customerHelper;

	 
	//For Junit
	public void setCustomerHelper(CustomerHelper customerHelper) {
		this.customerHelper = customerHelper;
	}


	@PreAuthorize("hasRole(T(com.mastercard.ess.eds.constant.ApplicationLiterals).ROLE_EDS_CUST_ADMIN)")
	@ApiOperation(value = ApplicationLiterals.CUST_SERVICE_SAVE)
	@RequestMapping(value = "/eds/v1/customer", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ProvisionCustomerData> saveProvisionCustomer(
			@RequestBody ProvisionCustomerData provisionCustomerData,  HttpServletRequest request ) throws EDSException {
		
		if (logger.isInfoEnabled()) {
			logger.info("Enter In Method : saveProvisionCustomer");
		}
		Map<String, String> requestMap = new HashMap<String,String>();
		requestMap.put(ValidationParameter.ENDPOINT, provisionCustomerData.getEndPoint());
		validateParameters(requestMap);
		
		ProvisionCustomerData  provisionCustomerDataOutput =  customerHelper.saveProvisionCustomer(provisionCustomerData, request);
		return new ResponseEntity<ProvisionCustomerData>(provisionCustomerDataOutput, HttpStatus.OK);

	}
	
	@PreAuthorize("hasRole(T(com.mastercard.ess.eds.constant.ApplicationLiterals).ROLE_EDS_CUST_ADMIN)")
	@ApiOperation(value = ApplicationLiterals.CUST_SERVICE_DISPLAY)
	@RequestMapping(value ="/eds/v1/customer/search", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity displayProvisionCustomer(@RequestBody ProvisionCustomerRequest provisionCustReq) throws EDSException{
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : displayEvents");
		}
		
		ProvisionCustomerResponse resp = customerHelper.getProvisionCustomerData(provisionCustReq);
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit From Method : displayEvents");
		}
		return new ResponseEntity(resp, HttpStatus.OK);
	}
	
	@ApiOperation(value = ApplicationLiterals.CUST_SERVICE_DELETE)
	@RequestMapping(value ="/eds/v1/customer/delete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity deleteProvisionCustomer(@RequestBody List<Integer> custIds , HttpServletRequest request) throws EDSException{

		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : deleteProvisionCustomer");
		}

		validateList(custIds);
		
		String userId = request.getHeader("userId");
	
		customerHelper.deleteProvisionCustomer(custIds ,userId);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit From Method : deleteProvisionCustomer");
		}
		return new ResponseEntity(HttpStatus.OK);
	}

	@ApiOperation(value = ApplicationLiterals.CUST_SERVICE_EDIT)
	@RequestMapping(value = "/eds/v1/customer/edit", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity editProvisionCustomer(@RequestBody ProvisionCustomerData provisionCustomerData,  HttpServletRequest request ) throws EDSException {
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : editProvisionCustomer");
		}
		Map<String, String> requestMap = new HashMap<String,String>();
		requestMap.put(ValidationParameter.ENDPOINT, provisionCustomerData.getEndPoint());
		validateParameters(requestMap);
		
		int updateStatus =  customerHelper.editProvisionCustomer(provisionCustomerData, request);
		return new ResponseEntity(HttpStatus.OK);

	}
}
