package com.mastercard.ess.eds.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.model.EDSSourceType;
import com.mastercard.ess.eds.response.ReferenceResponse;
import com.mastercard.ess.eds.util.HibernateUtils;

/**
 * @author e069468
 *
 */
@Component
public class VendorListDAO {
	private static final Logger logger = LoggerFactory.getLogger(VendorListDAO.class);

	private static final String FETCH_VENDOR = "select srcTypeId, providerName FROM " + EDSSourceType.class.getSimpleName() + " st where st.isVendor= :isVendor";

	/**This method is fetch the vendor list from the EDS_SRC_TYPE table
	 * @param resource
	 * @return
	 * @throws SQLException
	 */
	public ReferenceResponse getVendorList(String resource)   {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : getVendorList");
		}

		SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
		Session session = sessionFactory.openSession();		
		ReferenceResponse vendorListResp = new ReferenceResponse();
		Map<String, String> vendorsMapper = new HashMap<String, String>();

		Query query = session.createQuery(FETCH_VENDOR);
		query.setParameter("isVendor", "Y");
		List<Object[]> vendors = query.list();
		vendorListResp.setReferenceType(resource);
		for(Object[] vendor: vendors){
			vendorsMapper.put(String.valueOf((Integer)vendor[0]), (String)vendor[1]);
		}
		vendorListResp.setReferences(vendorsMapper);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit From  : getVendorList");
		}
		return vendorListResp;
	}

}
