package com.mastercard.ess.eds.controllers;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import com.mastercard.ess.eds.constant.ErrorMessages;
import com.mastercard.ess.eds.constant.ValidationParameter;
import com.mastercard.ess.eds.exceptions.EDSException;
import com.mastercard.ess.eds.exceptions.EDSException.ExceptionType;
 

public class BaseController {
	
	private static final Logger logger = LoggerFactory.getLogger(BaseController.class);

	protected void validateParameters(Map<String, String> requestMap) throws EDSException {
		boolean validationFlag = true;
		ErrorMessages message = null ;
		for ( Entry<String, String> entry : requestMap.entrySet() ) {
			String key = entry.getKey();
			String value = entry.getValue();
			switch (key) {
				case ValidationParameter.RESOURCE:
					validationFlag=	validateResource(value);
					message = ErrorMessages.RESOURCE_VALIDATION ;
					break ;
				case ValidationParameter.ICA:
					validationFlag=	validateICA(value);
					message = ErrorMessages.RESOURCE_ICA;
					break ;
				case ValidationParameter.ENDPOINT:
					validationFlag=	validateEndpoint(value);
					message = ErrorMessages.RESOURCE_ENDPOINT ;
					break;
				default:
					validationFlag = false ;
					message = ErrorMessages.MANDATORY_PARAMETER ;
				}
			
		}
		
		if(!validationFlag){
			logger.info("Validation Exception Occured");
			throw new EDSException(message,ExceptionType.VALIDATION_EXCEPTION );
		}
		       
	}

	private boolean validateEndpoint( String value) {
		if( StringUtils.isNotBlank(value)){
		     return true ;
		}
		return false ;
	}

	private boolean validateICA(String value) {
		if( StringUtils.isNotBlank(value)){
		     return true ;
		}
		return false ;
	}

	private boolean validateResource(String value) {
		if(StringUtils.isNotBlank(value) && (
		      ("icas").equalsIgnoreCase(value) || ("country").equalsIgnoreCase(value) || 
						("vendors").equalsIgnoreCase(value) )){
			return true ;
		}
		return false ;
	}
	
	public void validateList(List<Integer> list) throws EDSException {
		if(list.isEmpty()){
			throw new EDSException(ErrorMessages.EMPTY_SUBSCRIPTION_ID_LIST,ExceptionType.VALIDATION_EXCEPTION );
		}
	}
	
	 public  void validateFile(MultipartFile uploadfile   ) throws EDSException {

	    	if (logger.isDebugEnabled()) {
	            logger.debug("Enter In Method : validateFile");
	        }
	        String filename = uploadfile.getOriginalFilename();

	        if (!(filename.endsWith(".csv"))) {
	            throw new EDSException(ErrorMessages.INVALID_FILE_FORMAT, ExceptionType.VALIDATION_EXCEPTION);
	        }
	        // checking for File Size. it should not be more then 80MB
	        
	        
	        if (logger.isDebugEnabled()) {
	            logger.debug("Exit from Method : validateFile");
	        }

	    }
}
