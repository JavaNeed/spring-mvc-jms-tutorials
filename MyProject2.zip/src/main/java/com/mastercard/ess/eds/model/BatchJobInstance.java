package com.mastercard.ess.eds.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity // entity should be created via "new" and not injected as spring bean
@Table(name = "BATCH_JOB_INSTANCE", schema = "EDS_OWNER")
public class BatchJobInstance implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "JOB_INSTANCE_ID")
	private BigDecimal jobInstanceId;

	@Column(name = "JOB_NAME")
	private String jobName;
	
	@Column(name = "JOB_KEY")
	private String jobKey;
	
	@Column(name = "VERSION")
	private String version;
	
	@ManyToOne
	@NotFound(action = NotFoundAction.IGNORE)
	@JoinColumn(name = "JOB_INSTANCE_ID" , referencedColumnName = "JOB_INSTANCE_ID", insertable=false , updatable =false)
	private BatchJobExecution batchJobExecution;

	public BigDecimal getJobInstanceId() {
		return jobInstanceId;
	}

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getJobKey() {
		return jobKey;
	}

	public void setJobKey(String jobKey) {
		this.jobKey = jobKey;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public BatchJobExecution getBatchJobExecution() {
		return batchJobExecution;
	}

	public void setBatchJobExecution(BatchJobExecution batchJobExecution) {
		this.batchJobExecution = batchJobExecution;
	}
	
	
	
}
