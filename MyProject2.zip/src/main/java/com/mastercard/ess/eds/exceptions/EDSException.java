package com.mastercard.ess.eds.exceptions;

import com.mastercard.ess.eds.constant.ErrorMessages;

public class EDSException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ExceptionType exceptionType;
	private String errorCode;

	public EDSException(ErrorMessages message, ExceptionType exceptionType) {
		super(message.getErrorMessage());
		this.errorCode = message.getErrorCode();
		this.exceptionType = exceptionType;
	}
	
	public EDSException(Exception error , ErrorMessages messages, ExceptionType exceptionType) {
		super(messages.getErrorMessage(), error);
		this.exceptionType = exceptionType;
	}

	public enum ExceptionType {
		VALIDATION_EXCEPTION, BUSINESS_EXCEPTION, AUTHORIZATION_EXCEPTION;
	}

	/**
	 * @return the type
	 */
	public ExceptionType getExceptionType() {
		return exceptionType;
	}

	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}
	
}
