package com.mastercard.ess.eds.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.dao.ProvisionCustomerDAO;
import com.mastercard.ess.eds.request.ProvisionCustomerData;
import com.mastercard.ess.eds.request.ProvisionCustomerRequest;
import com.mastercard.ess.eds.response.ProvisionCustomerResponse;

@Component
public class CustomerHelper {

	private static final Logger logger = LoggerFactory
			.getLogger(CustomerHelper.class);

	@Autowired
	private ProvisionCustomerDAO   provisionCustomerDao ;
	
	//for Junit
	public void setProvisionCustomerDao(
			ProvisionCustomerDAO provisionCustomerDao) {
		this.provisionCustomerDao = provisionCustomerDao;
		
	}
	
	public ProvisionCustomerData saveProvisionCustomer(
			ProvisionCustomerData provisionCustomerData , HttpServletRequest request) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : saveProvisionCustomer");
		}

		ProvisionCustomerData provisionCustomerDataOutput = provisionCustomerDao
				.saveProvisionCustomer(provisionCustomerData , request);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit From Method : saveProvisionCustomer");
		}

		return provisionCustomerDataOutput;
	}
	
	public ProvisionCustomerResponse getProvisionCustomerData(
			ProvisionCustomerRequest provisionCustReq) {
		if(logger.isDebugEnabled()){
			logger.debug("Enter In Method : displayProvisionCustomer");
		}

		ProvisionCustomerResponse provisionCustResp = provisionCustomerDao.getProvisionCustomerData(provisionCustReq);

		if(logger.isDebugEnabled()){
			logger.debug("Exit From Method : displayProvisionCustomer");
		}
		
		return provisionCustResp;
	}
	
	public void deleteProvisionCustomer(List<Integer> custIds, String userId) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : deleteProvisionCustomer");
		}

		provisionCustomerDao.deleteProvisionCustomer(custIds, userId);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit From Method : deleteProvisionCustomer");
		}
	}
	
	public int editProvisionCustomer(ProvisionCustomerData provisionCustomerData , HttpServletRequest request) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : editProvisionCustomer");
		}

		int updateStatus = provisionCustomerDao
				.editProvisionCustomer(provisionCustomerData , request);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit From Method : editProvisionCustomer");
		}

		return updateStatus;
	}
	
}
