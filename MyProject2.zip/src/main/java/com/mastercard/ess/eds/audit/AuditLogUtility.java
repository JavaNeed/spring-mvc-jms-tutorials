package com.mastercard.ess.eds.audit;

import org.slf4j.helpers.MessageFormatter;

/**
 * Static utility to assist with Audit Logging.
 */
public class AuditLogUtility {

	private static final String AUDIT_LOGGER_NAME = "MCAuditLogger";

	private static final String APPNAME = "EDSAdmin";
	
	private static final String msgTemplate = "{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}";

	public static String buildAuditRecord(EventType eventType, String dataId, String resourceId, String eventMessage, String responseCode) {
		
		String[] msgParameters = new String[]{
				(String) MCAuditUtil.getField(PopulatableField.REQUEST_DATE_TIME),
				format(eventType.getEventTypeCode()),
				APPNAME,
				format(MCAuditUtil.getField(PopulatableField.USER_NAME)),
				format(MCAuditUtil.getField(PopulatableField.ORIGN_SYSTEM)),
				format(MCAuditUtil.getField(PopulatableField.SOURCE_IP)),
				format(MCAuditUtil.getField(PopulatableField.DEST_IP)),
				format(MCAuditUtil.getField(PopulatableField.SOURCE_PORT)),
				format(MCAuditUtil.getField(PopulatableField.DEST_PORT)),
				format(dataId),
				format(AUDIT_LOGGER_NAME),
				format(resourceId),
				format(eventMessage),
				format(responseCode)};
		
		String message = MessageFormatter.arrayFormat(msgTemplate, msgParameters).getMessage();

		return message;
	}

	/**
	 * replace empty or null values with '-'
	 */
	private static String format(Object o) {
		if (o == null) {
			return "-";
		}
		String s = o.toString();
		if (s.length() == 0) {
			return "-";
		}
		return s;
	}

}
