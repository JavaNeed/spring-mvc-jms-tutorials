package com.mastercard.ess.eds.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.constant.CommonConstants;
import com.mastercard.ess.eds.model.EDSSourceType;
import com.mastercard.ess.eds.model.EventSubscription;
import com.mastercard.ess.eds.model.EventSubscriptionHist;
import com.mastercard.ess.eds.request.EventCriteria;
import com.mastercard.ess.eds.request.EventSubscriptionRequest;
import com.mastercard.ess.eds.request.EventSubscriptions;
import com.mastercard.ess.eds.response.EventSubscriptionResponse;
import com.mastercard.ess.eds.response.EventSubscriptionSearchResponse;
import com.mastercard.ess.eds.util.HibernateUtils;
import com.mastercard.ess.eds.util.SortingCriteria;

/**
 * @author e069468
 *
 */
@Component
public class EventSubscriptionDAO {
	private static final Logger logger = LoggerFactory.getLogger(EventSubscriptionDAO.class);

	/**Method to save data in EDS_EVENT_SUBSC Table
	 * @param evntSubs
	 */
	public List<EventSubscription> saveOrUpdateEventSubscription(
			EventSubscriptions evntSubs, HttpServletRequest request) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : saveOrUpdateEventSubscription");
		}
		List<EventSubscription> list = new ArrayList<>();
		List<EventSubscription> duplicateList = new ArrayList<>();

		SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
		Session session  = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		for(String email : evntSubs.getEmailId()){
			email = email.toLowerCase();
			if(evntSubs.getVendorId() != null){
				setVendorEventData(evntSubs, list, duplicateList, session,
						email);
			}else if(CollectionUtils.isNotEmpty(evntSubs.getIcas())){		
				setExternalEventData(evntSubs, list, duplicateList, session,
						email);		
			}else{
				setInternalEventData(evntSubs, list, duplicateList, session,
						email);
			}
		}

		String userId = request.getHeader("userId");
		
		for(EventSubscription es : list){
			Date currentTime = new Date();
			es.setCreateUserId(userId);
			es.setCreateDate(currentTime);
			es.setLstUpdtUserId(userId);
			es.setLstUpdtdt(currentTime);
			session.save(es);
		}

		tr.commit();
		session.close();

		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : saveOrUpdateEventSubscription");
		}
		return duplicateList;
	}

	private void setInternalEventData(EventSubscriptions evntSubs,
			List<EventSubscription> list,
			List<EventSubscription> duplicateList, Session session, String email) {
		EventSubscription evnt;
		Criteria intCrt = session.createCriteria(EventSubscription.class);
		intCrt.add(Restrictions.eq(CommonConstants.EVENT_ID, evntSubs.getEventId()));
		intCrt.add(Restrictions.ilike(CommonConstants.EMAIL_ID, email));
		List<EventSubscription> intList = intCrt.list();
		if(CollectionUtils.isNotEmpty(intList)){
			duplicateList.addAll(intList);
		} else {
			evnt = new EventSubscription();
			setEventSubscriptionData(evntSubs, list, evnt, email, null, null,null);
		}
	}

	private void setExternalEventData(EventSubscriptions evntSubs,
			List<EventSubscription> list,
			List<EventSubscription> duplicateList, Session session, String email) {
		EventSubscription evnt;
		for(Integer ica : evntSubs.getIcas()){
			Criteria icaCrt = session.createCriteria(EventSubscription.class);
			icaCrt.add(Restrictions.eq(CommonConstants.EVENT_ID, evntSubs.getEventId()));
			icaCrt.add(Restrictions.eq(CommonConstants.ICA, ica));
			icaCrt.add(Restrictions.ilike(CommonConstants.EMAIL_ID, email));
			List<EventSubscription> icaList = icaCrt.list();
			if(CollectionUtils.isNotEmpty(icaList)){
				duplicateList.addAll(icaList);
			} else {
				evnt = new EventSubscription();
				setEventSubscriptionData(evntSubs, list, evnt, email, ica, null, null);
			}
		}
	}

	private void setVendorEventData(EventSubscriptions evntSubs,
			List<EventSubscription> list,
			List<EventSubscription> duplicateList, Session session, String email) {
		EventSubscription evnt;
		Criteria vendCrt = session.createCriteria(EventSubscription.class);
		vendCrt.add(Restrictions.eq(CommonConstants.EVENT_ID, evntSubs.getEventId()));
		vendCrt.add(Restrictions.eq(CommonConstants.EDS_SOURCE_TYPE_ID, evntSubs.getVendorId()));
		vendCrt.add(Restrictions.ilike(CommonConstants.EMAIL_ID, email));
		List<EventSubscription> vendList = vendCrt.list();
		if(CollectionUtils.isNotEmpty(vendList)){
			duplicateList.addAll(vendList);
		} else {
			evnt = new EventSubscription();
			Criteria crt = session.createCriteria(EDSSourceType.class);
			crt.add(Restrictions.eq("srcTypeId", evntSubs.getVendorId()));
			List<EDSSourceType> srcList = crt.list();
			String orgName = null;
			if(CollectionUtils.isNotEmpty(srcList)){
				orgName = srcList.get(0).getProviderName();
			}
			setEventSubscriptionData(evntSubs, list, evnt, email, null, evntSubs.getVendorId(), orgName);
		}
	}

	private void setEventSubscriptionData(EventSubscriptions evntSubs,
			List<EventSubscription> list, EventSubscription evnt, String email,
			Integer ica, Integer vendorId, String orgName) {
		evnt.setIca(ica);
		evnt.setCreateDate(new Date());
		evnt.setEdsSourceTypeId(vendorId);
		evnt.setOrgName(orgName);
		evnt.setEmailId(email);
		evnt.setEnabledSW(CommonConstants.YES);
		evnt.setEventId(evntSubs.getEventId());
		evnt.setLstUpdtdt(new Date());
		list.add(evnt);
	}

	public EventSubscriptionSearchResponse searchEventSubscription(
			EventSubscriptionRequest request) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : searchEventSubscription");
		}
		SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
		Session session = sessionFactory.openSession();
		Criteria criteria = session.createCriteria(EventSubscription.class);

		EventCriteria evntCriteria = request.getEventCriteria();
		setEventCriteriaData(criteria, evntCriteria);

		SortingCriteria sortCriteria = request.getSort();
		setSortingCriteriaData(criteria, sortCriteria);
		
		if(request.getChunk() == null){
			request.setChunk(CommonConstants.DEF_CHUNK_MIN_VAL);
		} 
		if(request.getChunkSize() == null){
			request.setChunkSize(CommonConstants.DEF_CHUNK_MAX_VAL);
		}

		int startLimit = (request.getChunk() - 1) * request.getChunkSize();
		int endLimit = request.getChunkSize() * request.getChunk();
		criteria.createAlias(CommonConstants.EVENT, CommonConstants.EVENT);
		criteria.createAlias(CommonConstants.EDS_SOURCE_TYPE, CommonConstants.VENDOR, CriteriaSpecification.LEFT_JOIN);

		List<EventSubscription> evntSubs = criteria.list();

		if(endLimit>evntSubs.size()){
			endLimit = evntSubs.size();
		}

		EventSubscriptionResponse esr;
		List<EventSubscriptionResponse> esrList = new ArrayList<>();
		if(startLimit<endLimit){
			for(int i = startLimit; i<endLimit; i++){
				esr = populateEventSubscriptionResponse(evntSubs, i);				
				esrList.add(esr);
			}
		}

		EventSubscriptionSearchResponse searchResponse = new EventSubscriptionSearchResponse();
		searchResponse.setChunk(request.getChunk());
		searchResponse.setChunkSize(request.getChunkSize());
		searchResponse.setEventSubscriptionResponse(esrList);
		searchResponse.setTotalCount(evntSubs.size());

		session.close();

		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : searchEventSubscription");
		}

		return searchResponse;
	}

	private EventSubscriptionResponse populateEventSubscriptionResponse(
			List<EventSubscription> evntSubs, int i) {
		EventSubscriptionResponse evntSubsResp = new EventSubscriptionResponse();
		evntSubsResp.setCreatedDate(evntSubs.get(i).getCreateDate());
		evntSubsResp.setEmailId(evntSubs.get(i).getEmailId());
		if(evntSubs.get(i).getEventSubsId()!=0){			
			evntSubsResp.setEventSubscriptionId(String.valueOf(evntSubs.get(i).getEventSubsId()));
		}
		evntSubsResp.setIca(String.valueOf(evntSubs.get(i).getIca()));
		evntSubsResp.setEventId(String.valueOf(evntSubs.get(i).getEventId()));
		if(evntSubs.get(i).getEvent() != null){
			evntSubsResp.setEventName(evntSubs.get(i).getEvent().getEventName());
			evntSubsResp.setEventType(evntSubs.get(i).getEvent().getEventType());
		}
		if(evntSubs.get(i).getEdsSourceType()!=null){
			evntSubsResp.setVendorName(evntSubs.get(i).getEdsSourceType().getProviderName());
		}
		return evntSubsResp;
	}

	private void setSortingCriteriaData(Criteria criteria, SortingCriteria sortingCriteria) {
		if(sortingCriteria != null){
			if((CommonConstants.SORT_ASCENDING).equalsIgnoreCase(sortingCriteria.getSortOrder())){
				criteria.addOrder(Order.asc(sortingCriteria.getSortBy()).ignoreCase());
			}
			if((CommonConstants.SORT_DESCENDING).equalsIgnoreCase(sortingCriteria.getSortOrder())){
				criteria.addOrder(Order.desc(sortingCriteria.getSortBy()).ignoreCase());
			}
		}
	}

	private void setEventCriteriaData(Criteria criteria, EventCriteria evntCriteria) {
		if(evntCriteria != null){
			if(CollectionUtils.isNotEmpty(evntCriteria.getEventId())){
				criteria.add(Restrictions.in(CommonConstants.EVENT_ID, evntCriteria.getEventId()));
			}
			if(CollectionUtils.isNotEmpty(evntCriteria.getEmailId())){
				criteria.add(Restrictions.in(CommonConstants.EMAIL_ID, evntCriteria.getEmailId()));
			}
			if(CollectionUtils.isNotEmpty(evntCriteria.getIca())){
				criteria.add(Restrictions.in(CommonConstants.ICA, evntCriteria.getIca()));
			}
			if(evntCriteria.getVendorName() != null){
				criteria.add(Restrictions.eq(CommonConstants.VENDOR_NAME, evntCriteria.getVendorName()));
			}
		}
	}

	public void deleteEventSubscription(List<Integer> subsIds) {
		SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();

		for(Integer subscriptionId : subsIds){
			Criteria crt = session.createCriteria(EventSubscription.class);
			crt.add(Restrictions.eq(CommonConstants.EVENT_SUBSCRIPTION_ID, subscriptionId));
			List<EventSubscription> eventSubscriptionList = crt.list();
			if(CollectionUtils.isNotEmpty(eventSubscriptionList)){
				EventSubscription eventSubscription = eventSubscriptionList.get(0);
				saveEventSubscriptionHist(eventSubscription, session);
				session.delete(eventSubscription);
			}
		}
		transaction.commit();
		session.close();
	}

	private void saveEventSubscriptionHist(EventSubscription eventSubscription, Session session) {
		EventSubscriptionHist history = new EventSubscriptionHist();
		history.setEventSubsId(eventSubscription.getEventSubsId());
		history.setEdsSourceTypeId(eventSubscription.getEdsSourceTypeId());
		history.setEmailId(eventSubscription.getEmailId());
		history.setEnabledSW(eventSubscription.getEnabledSW());
		history.setEventId(eventSubscription.getEventId());
		history.setIca(eventSubscription.getIca());
		history.setOrgName(eventSubscription.getOrgName());
		history.setCreateDate(eventSubscription.getCreateDate());
		history.setCreateUserId(eventSubscription.getCreateUserId());
		history.setHistCrteDt(new Date());
		history.setLstUpdtdt(eventSubscription.getLstUpdtdt());
		history.setLstUpdtUserId(eventSubscription.getLstUpdtUserId());
		session.save(history);
	}

}
