package com.mastercard.ess.eds.audit;

public final class PopulatableField {
	private int key;
	private String mdcName;
	public static final PopulatableField USER_NAME = new PopulatableField(1,
			"AUDIT_LOGGED_IN_USER");

	public static final PopulatableField DEST_IP = new PopulatableField(2,
			"AUDIT_DEST_IP");

	public static final PopulatableField DEST_PORT = new PopulatableField(3,
			"AUDIT_DEST_PORT");

	public static final PopulatableField SOURCE_IP = new PopulatableField(4,
			"AUDIT_SOURCE_IP");

	public static final PopulatableField SOURCE_PORT = new PopulatableField(5,
			"AUDIT_SOURCE_PORT");

	public static final PopulatableField REQUEST_DATE_TIME = new PopulatableField(
			6, "AUDIT_REQUEST_DT_TM");

	public static final PopulatableField ORIGN_APP = new PopulatableField(7,
			"AUDIT_ORIGN_APP");
	
	public static final PopulatableField ORIGN_SYSTEM = new PopulatableField(8,
			"AUDIT_ORIGN_SYSTEM");

	private PopulatableField(int key, String mdcName) {
		this.key = key;
		this.mdcName = mdcName;
	}

	String valueOf() {
		return this.mdcName;
	}

	public boolean equals(Object obj) {
		if (obj instanceof PopulatableField) {
			return (((PopulatableField) obj).key == this.key);
		}
		return false;
	}

	public int hashCode() {
		return this.key;
	}
}