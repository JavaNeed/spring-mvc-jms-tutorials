package com.mastercard.ess.eds.request;

import java.util.List;

public class EventCriteria {
	List<Integer> eventId;
	List<String> emailId;
	List<Integer> ica;
	String vendorName;
	
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public void setEventId(List<Integer> eventId) {
		this.eventId = eventId;
	}
	public void setIca(List<Integer> ica) {
		this.ica = ica;
	}
	public List<Integer> getEventId() {
		return eventId;
	}
	public List<Integer> getIca() {
		return ica;
	}
	public List<String> getEmailId() {
		return emailId;
	}
	public void setEmailId(List<String> emailId) {
		this.emailId = emailId;
	}
}
