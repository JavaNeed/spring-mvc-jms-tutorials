package com.mastercard.ess.eds.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.mastercard.ess.eds.model.CPPRules;
import com.mastercard.ess.eds.response.Response;
import com.mastercard.ess.eds.util.SortingCriteria;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class SearchResponse extends Response implements Serializable {

	private static final long serialVersionUID = 1L;
	private String totalRecordCount;
	private String chunk;
	private String chunkSize;
	private SortingCriteria sort;
	private List<CPPRules> ruleList;
	
	public SearchResponse() {
		super();
	}
	
	
	/**
	 * @return the totalRecordCount
	 */
	public String getTotalRecordCount() {
		return totalRecordCount;
	}
	/**
	 * @param totalRecordCount the totalRecordCount to set
	 */
	public void setTotalRecordCount(String totalRecordCount) {
		this.totalRecordCount = totalRecordCount;
	}
	/**
	 * @return the chunk
	 */
	public String getChunk() {
		return chunk;
	}
	/**
	 * @param chunk the chunk to set
	 */
	public void setChunk(String chunk) {
		this.chunk = chunk;
	}
	/**
	 * @return the chunkSize
	 */
	public String getChunkSize() {
		return chunkSize;
	}
	/**
	 * @param chunkSize the chunkSize to set
	 */
	public void setChunkSize(String chunkSize) {
		this.chunkSize = chunkSize;
	}
	/**
	 * @return the sort
	 */
	public SortingCriteria getSort() {
		return sort;
	}
	/**
	 * @param sort the sort to set
	 */
	public void setSort(SortingCriteria sort) {
		this.sort = sort;
	}	
	
	@Override
	public String toString() {
		return "SearchResponse [totalRecordCount=" + totalRecordCount
				+ ", chunk=" + chunk + ", chunkSize=" + chunkSize + ", sort="
				+ sort + ", ruleList=" + ruleList + "]";
	}


	public List<CPPRules> getRuleList() {
		return ruleList;
	}


	public void setRuleList(List<CPPRules> ruleList) {
		this.ruleList = ruleList;
	}
	
	
}
