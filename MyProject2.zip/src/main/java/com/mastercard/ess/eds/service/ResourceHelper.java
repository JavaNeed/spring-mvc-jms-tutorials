package com.mastercard.ess.eds.service;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.dao.CountryListDAO;
import com.mastercard.ess.eds.dao.ICAListDAO;
import com.mastercard.ess.eds.dao.VendorListDAO;
import com.mastercard.ess.eds.model.Country;
import com.mastercard.ess.eds.request.ICAData;
import com.mastercard.ess.eds.response.ReferenceResponse;

/**
 * @author e069468
 *
 */
@Component
public class ResourceHelper {

	private static final Logger logger = LoggerFactory.getLogger(ResourceHelper.class);

	@Autowired
	private VendorListDAO vendorListDAO;

	@Autowired
	private ICAListDAO icaListDAO;

	@Autowired
	private CountryListDAO countryListDAO;
	
	//for Junit
	public void setDao(ICAListDAO icaListDAO, VendorListDAO vendorListDAO,
			CountryListDAO countryListDAO) {
		this.icaListDAO = icaListDAO;
		this.vendorListDAO = vendorListDAO;
		this.countryListDAO = countryListDAO;
		
	}

	/**This method checks which list to be returned based on input.
	 * @param resource
	 * @return
	 * @throws SQLException
	 */
	public ReferenceResponse getResource(String resource)  {

		if(logger.isDebugEnabled()){
			logger.debug("Enter In Method : getResource");
		}
		Map<String, String> countryMapper = new LinkedHashMap<String, String>();

		ReferenceResponse refResp = null;
		if("country".equals(resource)){
			try{
			List<Country> countryList = countryListDAO.getCountryList();
			refResp = new ReferenceResponse();
			
			refResp.setReferenceType(resource);
			if(countryList!=null){				
				for(Country country :countryList){
					countryMapper.put(country.getAlpha3Code(), country.getCntryName());
				}
			}
			}catch(Exception e){
				e.printStackTrace();
			}
			refResp.setReferences(countryMapper);
		}else if("icas".equals(resource)){
			refResp = icaListDAO.getSignedICAList(resource);
		}else if("vendors".equals(resource)){
			refResp = vendorListDAO.getVendorList(resource);
		}

		return refResp;
	}
	
	
	/**This method checks which list to be returned based on input.
	 * @param resource
	 * @return
	 */
	public ICAData getUnsignedIca(String ica)  {

		if(logger.isDebugEnabled()){
			logger.debug("Enter In Method : getUnsignedIca");
		}
		return icaListDAO.getUnsignedICAList("unSignedIca", ica);
	}


	

}
