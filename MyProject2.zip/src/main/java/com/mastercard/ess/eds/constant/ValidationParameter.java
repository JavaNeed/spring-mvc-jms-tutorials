package com.mastercard.ess.eds.constant;

public final class ValidationParameter {
	
	public static final String RESOURCE = "resource";
	public static final String SUBSCRIPTION_ID_LIST = "subsIdList";
	public static final String ICA = "ica";
	public static final String ENDPOINT = "endpoint";
	 
	
}
