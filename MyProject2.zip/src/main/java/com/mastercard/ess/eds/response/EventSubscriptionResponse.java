package com.mastercard.ess.eds.response;

import java.util.Date;

public class EventSubscriptionResponse {
	
	private String eventSubscriptionId;
	private String eventId;
	private String eventName;
	private String emailId;
	private String ica;
	private String vendorName;
	
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	private Date createdDate;
	private String eventType;
	public String getEventSubscriptionId() {
		return eventSubscriptionId;
	}
	public void setEventSubscriptionId(String eventSubscriptionId) {
		this.eventSubscriptionId = eventSubscriptionId;
	}
	public String getEventId() {
		return eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getIca() {
		return ica;
	}
	public void setIca(String ica) {
		this.ica = ica;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}
