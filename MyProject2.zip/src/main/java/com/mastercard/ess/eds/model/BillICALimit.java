package com.mastercard.ess.eds.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity // entity should be created via "new" and not injected as spring bean
@Table(name = "EDS_BILL_ICA_LIMIT", schema = "EDS_OWNER")
public class BillICALimit {
	
	@Id
	@Column(name="EDS_BILL_ICA_LIMIT_ID",unique=true,nullable=false)
	private int billIcaLimitId;
	
	@Column(name="PRNT_ICA_NUM")
	private int printIcaNum;
	
	@Column(name="ICA_NUM")
	private int icaNum;
	
	@Column(name="BILL_YR")
	private String billYear;
	
	@Column(name="CRTE_USER_ID")
	private String createUserId;
	
	@Column(name="CRTE_DT")
	private Date createDate;

	public int getBillIcaLimitId() {
		return billIcaLimitId;
	}

	public void setBillIcaLimitId(int billIcaLimitId) {
		this.billIcaLimitId = billIcaLimitId;
	}

	public int getPrintIcaNum() {
		return printIcaNum;
	}

	public void setPrintIcaNum(int printIcaNum) {
		this.printIcaNum = printIcaNum;
	}

	public int getIcaNum() {
		return icaNum;
	}

	public void setIcaNum(int icaNum) {
		this.icaNum = icaNum;
	}

	public String getBillYear() {
		return billYear;
	}

	public void setBillYear(String billYear) {
		this.billYear = billYear;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	
}
