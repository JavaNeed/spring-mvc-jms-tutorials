package com.mastercard.ess.eds.response;

import java.util.List;

import com.mastercard.ess.eds.model.CPPRules;

public class FileUploadCPPSuccessResponse {

	private int line;
	private int ruleId;
	private String isDuplicate;
	private List<CPPRules> cppRules;
	private Integer[] cppArray;	
	
	public List<CPPRules> getCppRules() {
		return cppRules;
	}
	public void setCppRules(List<CPPRules> cppRules) {
		this.cppRules = cppRules;
	}
	public Integer[] getCppArray() {
		return cppArray;
	}
	public void setCppArray(Integer[] cppArray) {
		this.cppArray = cppArray;
	}
	public int getLine() {
		return line;
	}
	public void setLine(int line) {
		this.line = line;
	}
	public int getRuleId() {
		return ruleId;
	}
	public void setRuleId(int ruleId) {
		this.ruleId = ruleId;
	}
	public String getIsDuplicate() {
		return isDuplicate;
	}
	public void setIsDuplicate(String isDuplicate) {
		this.isDuplicate = isDuplicate;
	}
}
