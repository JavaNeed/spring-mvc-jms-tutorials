package com.mastercard.ess.eds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.web.MultipartAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;

import com.mastercard.ess.eds.config.SwaggerProperties;

@SpringBootApplication
@EnableConfigurationProperties({ SwaggerProperties.class})
@EnableAutoConfiguration(exclude = { MultipartAutoConfiguration.class})
@ComponentScan("com.mastercard.ess.eds")
public class ServicesConfiguration {
	
	public ServicesConfiguration(){ //NOSONAR
	}

	public static void main(String[] args) {
		SpringApplication.run(ServicesConfiguration.class, args);//NOSONAR
	}
	}



