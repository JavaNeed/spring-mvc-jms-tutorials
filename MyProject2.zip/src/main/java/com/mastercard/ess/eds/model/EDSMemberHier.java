package com.mastercard.ess.eds.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity // entity should be created via "new" and not injected as spring bean
@Table(name = "EDS_MBR_HIER", schema = "EDS_OWNER")
public class EDSMemberHier {

	@Id
	@Column(name="ICA_CODE",unique=true,nullable=false)
	private Integer icaCode ;
	
	@Column(name="PARENT_ICA_ID")
	private Integer parentIcaId ;
	
	@Column(name="ACCESS_NAME")
	private String accessName ;

	
	public Integer getIcaCode() {
		return icaCode;
	}

	public void setIcaCode(Integer icaCode) {
		this.icaCode = icaCode;
	}

	public Integer getParentIcaId() {
		return parentIcaId;
	}

	public void setParentIcaId(Integer parentIcaId) {
		this.parentIcaId = parentIcaId;
	}

	public String getAccessName() {
		return accessName;
	}

	public void setAccessName(String accessName) {
		this.accessName = accessName;
	}
	 
}


 