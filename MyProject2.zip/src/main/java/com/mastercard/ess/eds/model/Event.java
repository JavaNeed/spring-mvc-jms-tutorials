package com.mastercard.ess.eds.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author e069468
 *
 */
@Entity // entity should be created via "new" and not injected as spring bean
@Table(name = "EDS_EVENT", schema = "EDS_OWNER")
public class Event {
	
	@Id
	@Column(name="EDS_EVENT_ID",unique=true,nullable=false)
	private int eventId;
	
	@Column(name = "TYPE_TXT")
	private String eventType;
	
	@Column(name = "EVENT_NAM")
	private String eventName;
	
	@Column(name = "EVENT_DESC")
	private String eventDesc;
	
	@Column(name = "ENBL_SW")
	private String enblSW;
	
	@Column(name = "EDS_MSG_FROM_ADDR")
	private String edsMsgFrom;
	
	@Column(name = "LST_UPDT_DT")
	private Date lstUpdtDt;
	
	@Column(name = "LST_UPDT_USER_ID")
	private String lstUpdtUserId;
	
	@Column(name = "EDS_TMPLT_ID")
	private int edsTmpltId;
	
	@Column(name = "DISP_SW")
	private String dispSW;
	
	public int getEventId() {
		return eventId;
	}
	public void setEventId(int eventId) {
		this.eventId = eventId;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getDispSW() {
		return dispSW;
	}
	public void setDispSW(String dispSW) {
		this.dispSW = dispSW;
	}

}
