package com.mastercard.ess.eds.response;

import java.util.List;

public class EventSubscriptionSearchResponse {

	private Integer chunk;
	private Integer chunkSize;
	private Integer totalCount;
	List<EventSubscriptionResponse> eventSubscriptionResponse;
	public Integer getChunk() {
		return chunk;
	}
	public void setChunk(Integer chunk) {
		this.chunk = chunk;
	}
	public Integer getChunkSize() {
		return chunkSize;
	}
	public void setChunkSize(Integer chunkSize) {
		this.chunkSize = chunkSize;
	}
	public Integer getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}
	public List<EventSubscriptionResponse> getEventSubscriptionResponse() {
		return eventSubscriptionResponse;
	}
	public void setEventSubscriptionResponse(
			List<EventSubscriptionResponse> eventSubscriptionResponse) {
		this.eventSubscriptionResponse = eventSubscriptionResponse;
	}
	
	
}
