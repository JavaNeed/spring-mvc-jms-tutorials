package com.mastercard.ess.eds.controllers;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mastercard.ess.eds.constant.ApplicationLiterals;
import com.mastercard.ess.eds.dao.EventSubscriptionDAO;
import com.mastercard.ess.eds.exceptions.EDSException;
import com.mastercard.ess.eds.model.EventSubscription;
import com.mastercard.ess.eds.request.EventSubscriptionRequest;
import com.mastercard.ess.eds.request.EventSubscriptions;
import com.mastercard.ess.eds.response.EventSubscriptionSearchResponse;

/**
 * @author e069468
 *
 */
@Api(value = ApplicationLiterals.EVENT_SUBS_SERVICE, description = ApplicationLiterals.EVENT_SUBS_SERVICE_DESCRIPTION)
@RestController
@Component 

public class EventSubscriptionServiceController extends BaseController {

	private static final Logger logger = LoggerFactory.getLogger(EventSubscriptionServiceController.class);

	@Autowired
	private EventSubscriptionDAO eventSubscriptionDAO;

	// for Junit
	public void setEventSubscriptionService(EventSubscriptionDAO eventSubscriptionDAO) {
		this.eventSubscriptionDAO = eventSubscriptionDAO;
	}

	/**Controller to get the save event subscription
	 * @param evntSubs
	 * @return
	 * @throws EDSException 
	 */
	
	@PreAuthorize("hasRole(T(com.mastercard.ess.eds.constant.ApplicationLiterals).ROLE_EDS_CUST_ADMIN)")
	@ApiOperation(value = ApplicationLiterals.EVENT_SUBS_SAVE)
	@RequestMapping(value ="/eds/v1/event/subscriptions", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity saveOrUpdateEventSubscription(@RequestBody EventSubscriptions evntSubs , HttpServletRequest request) throws EDSException{

		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : saveOrUpdateEventSubscrition");
		}

		List<EventSubscription> evntSubsList = eventSubscriptionDAO.saveOrUpdateEventSubscription(evntSubs , request);
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit From Method : saveOrUpdateEventSubscrition");
		}
		return new ResponseEntity(evntSubsList, HttpStatus.OK);
	}

	@PreAuthorize("hasRole(T(com.mastercard.ess.eds.constant.ApplicationLiterals).ROLE_EDS_CUST_ADMIN)")
	@ApiOperation(value = ApplicationLiterals.EVENT_SUBS_DISPLAY)
	@RequestMapping(value ="/eds/v1/event/subscriptions/search", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity displayEvents(@RequestBody EventSubscriptionRequest request) throws EDSException{

		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : displayEvents");
		}

		EventSubscriptionSearchResponse resp = eventSubscriptionDAO.searchEventSubscription(request);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit From Method : displayEvents");
		}
		return new ResponseEntity(resp, HttpStatus.OK);
	}
	
	@PreAuthorize("hasRole(T(com.mastercard.ess.eds.constant.ApplicationLiterals).ROLE_EDS_CUST_ADMIN)")
	@ApiOperation(value = ApplicationLiterals.EVENT_SUBS_DELETE)
	@RequestMapping(value ="/eds/v1/event/subscriptions/delete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity deleteEventSubscription(@RequestBody List<Integer> subsIds) throws EDSException{

		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : deleteEventSubscription");
		}

		validateList(subsIds);

		eventSubscriptionDAO.deleteEventSubscription(subsIds);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit From Method : deleteEventSubscription");
		}
		return new ResponseEntity(HttpStatus.OK);
	}
}
