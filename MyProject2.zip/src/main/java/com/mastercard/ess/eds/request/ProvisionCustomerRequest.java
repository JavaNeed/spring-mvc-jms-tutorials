package com.mastercard.ess.eds.request;

import com.mastercard.ess.eds.util.SortingCriteria;

public class ProvisionCustomerRequest {
	
	private Integer chunk;
	private Integer chunkSize;
	private EventCriteria eventCriteria;
	private SortingCriteria sort;
	private SearchCriteria searchCriteria;
	
	
	public Integer getChunk() {
		return chunk;
	}
	public void setChunk(Integer chunk) {
		this.chunk = chunk;
	}
	public Integer getChunkSize() {
		return chunkSize;
	}
	public void setChunkSize(Integer chunkSize) {
		this.chunkSize = chunkSize;
	}
	public EventCriteria getEventCriteria() {
		return eventCriteria;
	}
	public void setEventCriteria(EventCriteria eventCriteria) {
		this.eventCriteria = eventCriteria;
	}
	public SortingCriteria getSort() {
		return sort;
	}
	public void setSort(SortingCriteria sort) {
		this.sort = sort;
	}
	public SearchCriteria getSearchCriteria() {
		return searchCriteria;
	}
	public void setSearchCriteria(SearchCriteria searchCriteria) {
		this.searchCriteria = searchCriteria;
	}
	
	
	

}
