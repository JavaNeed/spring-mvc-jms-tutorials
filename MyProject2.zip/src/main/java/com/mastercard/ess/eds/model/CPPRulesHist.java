package com.mastercard.ess.eds.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity // entity should be created via "new" and not injected as spring bean
@Table(name = "EDS_CPP_RULE_HIST", schema = "EDS_OWNER")
public class CPPRulesHist implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="EDS_CPP_RULE_HIST_ID",unique=true,nullable=false)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	@SequenceGenerator(name = "seq", sequenceName = "EDS_CPP_RULE_HIST_ID_SEQ", allocationSize=1)
	private Integer ruleHistId;
	
	@Column(name = "EDS_CPP_RULE_ID")
	private Integer ruleId;

	@Column(name = "VAL_LOC_TRAN_AMT")
	private BigDecimal localTxnAmountVal;

	@Column(name = "CLS_LOC_TRAN_AMT")
	private String localTxnAmountClause;

	@Column(name = "VAL_TM_CNT")
	private BigDecimal timeValue;

	@Column(name = "UNIT_TM_CNT")
	private String timeUnit;
	
	@Column(name = "VAL_MERCH_LOC_ID")
	private BigDecimal locationIdValue;

	@Column(name = "CLS_MERCH_LOC_ID")
	private String locationIdClause;

	@Column(name = "VAL_ISSR_CNTRY_ID")
	private String issuerCntryValue;

	@Column(name = "CLS_ISSR_CNTRY_ID")
	private String issuerCntryClause;
	  
	@Column(name = "ACTV_SW")
	private String activeSW;
	
	@Column(name = "FIRST_RUN_SW")
	private String firstRunSW;
	
	@Column(name = "CRTE_DT")
	private Date createDate;
	
	@Column(name = "CRTE_USER_ID")
	private String createUserId;
	
	@Column(name = "LST_UPDT_DT")
	private Date lastUpdatedDate;
	
	@Column(name = "LST_UPDT_USER_ID")
	private String lastUpdatedUserId;
	
	@Column(name = "HIST_CRTE_DT")
	private Date histCrteDt;
	
	
	

	public Date getHistCrteDt() {
		return histCrteDt;
	}

	public void setHistCrteDt(Date histCrteDt) {
		this.histCrteDt = histCrteDt;
	}

	public String getActiveSW() {
		return activeSW;
	}

	public void setActiveSW(String activeSW) {
		this.activeSW = activeSW;
	}

	public String getFirstRunSW() {
		return firstRunSW;
	}

	public void setFirstRunSW(String firstRunSW) {
		this.firstRunSW = firstRunSW;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getLastUpdatedUserId() {
		return lastUpdatedUserId;
	}

	public void setLastUpdatedUserId(String lastUpdatedUserId) {
		this.lastUpdatedUserId = lastUpdatedUserId;
	}

	/**
	 * @return the timeValue
	 */
	public BigDecimal getTimeValue() {
		return timeValue;
	}

	/**
	 * @param timeValue
	 *            the timeValue to set
	 */
	public void setTimeValue(BigDecimal timeValue) {
		this.timeValue = timeValue;
	}

	public BigDecimal getLocalTxnAmountVal() {
		return localTxnAmountVal;
	}

	public void setLocalTxnAmountVal(BigDecimal localTxnAmountVal) {
		this.localTxnAmountVal = localTxnAmountVal;
	}

	public BigDecimal getLocationIdValue() {
		return locationIdValue;
	}

	public void setLocationIdValue(BigDecimal locationIdValue) {
		this.locationIdValue = locationIdValue;
	}

	/**
	 * @return the timeUnit
	 */
	public String getTimeUnit() {
		return timeUnit;
	}

	/**
	 * @param timeUnit
	 *            the timeUnit to set
	 */
	public void setTimeUnit(String timeUnit) {
		this.timeUnit = timeUnit;
	}

	/**
	 * @return the localTxnAmountClause
	 */
	public String getLocalTxnAmountClause() {
		return localTxnAmountClause;
	}

	/**
	 * @param localTxnAmountClause
	 *            the localTxnAmountClause to set
	 */
	public void setLocalTxnAmountClause(String localTxnAmountClause) {
		this.localTxnAmountClause = localTxnAmountClause;
	}

	/**
	 * @return the locationIdClause
	 */
	public String getLocationIdClause() {
		return locationIdClause;
	}

	/**
	 * @param locationIdClause
	 *            the locationIdClause to set
	 */
	public void setLocationIdClause(String locationIdClause) {
		this.locationIdClause = locationIdClause;
	}

	/**
	 * @return the ruleId
	 */
	public Integer getRuleId() {
		return ruleId;
	}

	/**
	 * @param ruleId
	 *            the ruleId to set
	 */
	public void setRuleId(Integer ruleId) {
		this.ruleId = ruleId;
	}
	
	/**
	 * @return the issuerCntry
	 */
	public String getIssuerCntryValue() {
		return issuerCntryValue;
	}

	/**
	 * @param issuerCntry
	 *            the issuerCntry to set
	 */
	public void setIssuerCntryValue(String issuerCntry) {
		this.issuerCntryValue = issuerCntry;
	}

	/**
	 * @return the clause
	 */
	public String getIssuerCntryClause() {
		return issuerCntryClause;
	}

	/**
	 * @param clause
	 *            the clause to set
	 */
	public void setIssuerCntryClause(String clause) {
		this.issuerCntryClause = clause;
	}

	public Integer getRuleHistId() {
		return ruleHistId;
	}

	public void setRuleHistId(Integer ruleHistId) {
		this.ruleHistId = ruleHistId;
	}
}
