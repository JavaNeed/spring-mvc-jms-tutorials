package com.mastercard.ess.eds.constant;


public enum ErrorMessages {
	
	HEADER_VALIDATION("FLT0001", "Please check provided Header Info. UserId and content-type is mandatory."),
	HEADER_USER_ID_VALIDATION("FLT0002", "Invalid header, User Id is missing. Please provide userId: XXXXXX."),
	HEADER_CONTENT_TYPE_VALIDATION("FLT0003", "Invalid header, Content Type is missing. Please provide content-Type: application/json."),
	CONTENT_TYPE_FORMAT_VALIDATION("FLT0004", "content-type Format Provided is not Valid. Please provide content-type: application/json."),
	STUB_MODE_VALIDATION("FLT0005", "Provided Value of Stub mode is not Valid.Allowed formats are stubMode: S , stubMode: s , stubMode: F , stubMode: f."),
	UNKNOWN_ERROR("FLT0006", "Please provide valid Request Header."),

	MANDATORY_PARAMETER("EC0001", "Request received with missing mandatory parameters."),
	PAN_VALIDATION("EC0002", "Value of PAN in request not a 6-19 digit numeric value."),
	DATE_VALIDATION("EC0003", "Invalid Date format."),
	DATE_RANGE_VALIDATION("EC0004" ,"End Date should be greater than Start Date."),
	ICA_VALIDATION("EC0005", "ICA is not valid. It should be 3-7 digits numeric value."),
	ICA_ACCESS_VALIDATION("EC0006", "User does not have access to requested ICA or RTN."),
	AMOUNT_RANGE_VALIDATION("EC0007", "MaxAmount should greater than MinAmount."),
	BRN_VALIDATION("EC0008", "BRN length should be 6-9 characters long."), 
	ARN_VALIDATION("EC0009", "ARN should be minimum 23 digits."),
	AUTHCODE_VALIDATION("EC0010", "AuthCode should not contain Special Characters."),
	SORT_ORDER_VALIDATION("EC0011", "SortOrder should be 'ASC' or 'DESC'."),
	AMOUNT_VALIDATION("EC0012", "Use Either single transaction amount Or amount range."),
	DATE_TYPE_VALIDATION("EC0013", "DateType and Process Date combination is Mandatory. DateType should be GCMS_DATE or AUTH_DATE."),
	GLOBAL_COLLECTION_FLAG_VALIDATION("EC0014", "Global Collection Flag should be GCF_TRUE."),
	RECURRING_PAYMENT_FLAG_VALIDATION("EC0015", "Recurring Payment Flag should be RP_TRUE."),
	SORT_BY_VALIDATION("EC0016", "SortBy Value is not valid."),
	NUMERIC_VALUE_VALIDATION("EC0017", "Value should be numeric."),
	PAN_LENGTH_VALIDATION("EC0018", "Value of PAN in request not a 16-19 digit numeric value."),
	SETTLEMENT_DATE_VALIDATION("EC0019", "Date format should be 'MMDDYY'"),
 
    INVALID_VIEW_REQUEST("EC0020","invalid view request"),
	EXCEEDED_VIEW_DEFINITION("EC0021","Number of requested columns exceed available columns for the view"),
	DUPLICATE_COLUMN_ENTRY("EC0022","Column names must be unique"),
	EMPTY_VIEWTYPE("EC0023","View type cannot be empty"),
	INVALID_COLUMN_ORDER_SEQUENCE("EC0024","Invalid column order sequence"),
	INVALID_COLUMNNAME("EC0025","Invalid Column name"),
	INPUT_MISMATCH("EC0026","Payload should contain data only for the views passed in url"),
	INVALID_FILE_FORMAT("EC0027","File upload failed. Invalid file format."), 
	INVALID_FILE_TYPE("EC0028"," Invalid File Type.It should be 'P' for Partial or 'C' for Complete. "),
	INVALID_FILE_SIZE("EC0029", "Invalid File Size. File Size should be less than 80Mb."),
	INVALID_FILE_NAME_SIZE("EC0030", "Invalid File Name Length. File Length should be less than 200 Character."),
   
    FRAUD_REPORTED_DATE_RANGE_VALIDATION("EC0033" ,"Fraud Reported Date should be before than today's Date."),
    FRAUD_POSTED_DATE_RANGE_VALIDATION("EC0034" ,"Fraud Posted Date should be before than today's Date."),
    NO_RECORD_FOUND("EC0032", "No Records Found."),
    VALID_TXN_TYPE("EC0031","Invalid Txn Type. Valid data is AUTH, DEBIT, CLEARING."),
	RESOURCE_VALIDATION("EC0032","Invalid resource passed"), 
	EMPTY_SUBSCRIPTION_ID_LIST("EC0033","Empty Subscription Id List"),
	RESOURCE_ICA("EC0034","Invalid ICA passed"), 
	RESOURCE_ENDPOINT("EC0035","Invalid End Point passed"), 
	INVALID_ROLE("EC0036","Invalid Role"),
	SAML_PARSE_ERROR("EC0037","Error Occured while Parsing the SAML token"),
	FILE_PARSE_ERROR("EC0038","Error Occured while Parsing the File"),
	LOCATION_ID_NUMERIC_ERROR("EC0039","Location value should be Numeric"),
	LOCATION_ID_LENGTH_ERROR("EC0040","Location value should be maximum of 9 digits"),
	LOCATION_TXN_AMOUNT_NUMERIC_ERROR("EC0041","Amount value must be numeric"),
	LOCATION_TXN_AMOUNT_LENGTH_ERROR("EC0042","Amount should be maximum of 19 digits"),
	UNIT_VALUE_NUMERIC_ERROR("EC0043","Unit time value should be Numeric"),
	UNIT_TIME_ERROR("EC0044","Unit time should be 'days' or 'week' or 'month'"),
	CATOGERY_CODE_ERROR("EC0045","Rule Type should be 'E' or 'I' "), 
	COUNTRY_CODE_NOT_FOUND_ERROR("EC0046","Country code does not exist"), 
	CATEGORY_CODE_BLANK_ERROR("EC0047","Rule Type should not be blank"), 
	LOCATION_ID_BLANK_ERROR("EC0048","Location Id should not be blank"), 
	COUNTRY_CONDITION_ERROR("EC0049","Country condition is not correct"),
	AMOUNT_CONDITION_ERROR("EC0050","Amount condition is not correct"), 
	TIME_VALUE_RANGE_ERROR("EC0051","Unit time value range should be less than or equal to (366 for days and 52 for weeks and 12 for months)"),
	EMPTY_RULE_ID("EC0052","Rule Id should not be blank"),
	RULE_ID_NOT_EXISTS("EC0053","Rule Id does not exists or already in deactivated or pending status"), 
	RULE_ID_NOT_NUMERIC("EC0054","Rule Id should be numeric"),
	INVALID_HEADER("EC0055","File Template is not in correct format"), 
	DUPLICATE_ENTRY_FOUND("EC0056","Duplicate entry found of valid rule id");
	
	private String errorCode;
	private String errorMessage;
	
	
	private ErrorMessages(String errorCode, String errorMessage) {
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	
	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}


	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}
    

}
