package com.mastercard.ess.eds.dao;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.constant.CommonConstants;
import com.mastercard.ess.eds.model.BatchJobInstance;
import com.mastercard.ess.eds.util.HibernateUtils;

@Component
public class JobExecutionDAO {

	private static final Logger logger = LoggerFactory.getLogger(JobExecutionDAO.class);

	public String getJobRunningStatus() {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : JobExecutionDAO - getJobRunningStatus");
		}
		String status = null;
		try{
			SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
			Session session  = sessionFactory.openSession();	
			Criteria criteria = session.createCriteria(BatchJobInstance.class);
			criteria.add(Restrictions.eq(CommonConstants.JOB_NAME, CommonConstants.CPP_EXEC_JOB));
			criteria.createAlias("batchJobExecution", "batchJobExecution", CriteriaSpecification.LEFT_JOIN);
			Date date = new Date();
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			calendar.add(Calendar.DATE, -1);
			Date yesterday = calendar.getTime();
			criteria.add(Restrictions.gt("batchJobExecution.createTime", yesterday));
			criteria.addOrder(Order.desc("batchJobExecution.createTime"));
			List<BatchJobInstance> list = (List<BatchJobInstance>) criteria.list();
			if(list.size()>0){
				status = list.get(0).getBatchJobExecution().getStatus();
			}
			session.close();
		}catch(Exception e){
			logger.info("Error while fetching cpp rules : "+e.getMessage());
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : JobExecutionDAO - getJobRunningStatus");
		}
		return status;
	}


}
