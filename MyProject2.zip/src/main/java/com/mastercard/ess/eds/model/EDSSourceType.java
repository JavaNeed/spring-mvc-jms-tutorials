package com.mastercard.ess.eds.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author e069468
 *
 */
@Entity // entity should be created via "new" and not injected as spring bean
@Table(name = "EDS_SRC_TYPE", schema = "EDS_OWNER")
public class EDSSourceType {
	
	@Id
	@Column(name = "EDS_SRC_TYPE_ID")
	private int srcTypeId;
	
	@Column(name = "PRVDR_NAM")
	private String providerName;
	
	@Column(name = "VNDR_SW")
	private String isVendor;
	
	public int getSrcTypeId() {
		return srcTypeId;
	}

	public void setSrcTypeId(int srcTypeId) {
		this.srcTypeId = srcTypeId;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getIsVendor() {
		return isVendor;
	}

	public void setIsVendor(String isVendor) {
		this.isVendor = isVendor;
	}

}
