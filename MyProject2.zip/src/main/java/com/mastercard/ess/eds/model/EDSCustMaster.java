package com.mastercard.ess.eds.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity // entity should be created via "new" and not injected as spring bean
@Table(name = "EDS_CUST_MSTR", schema = "EDS_OWNER")
public class EDSCustMaster {
	
	@Id
	@Column(name="EDS_CUST_MSTR_ID",unique=true,nullable=false)
	@SequenceGenerator(name = "seq", sequenceName = "EDS_OWNER.EDS_CUST_MSTR_ID_SEQ", allocationSize=1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	private int custMstrId;
	
	@Column(name="ICA_NUM")
	private int icaNum;
	
	@Column(name="CUST_TYPE_CD")
	private String custTypeCd;
	
	@Column(name="CUST_NAM")
	private String custName;
	
	@Column(name="ACTV_SW")
	private String isActivSW;
	
	@Column(name="SILENT_SW")
	private String isSilentSW; 
	 
	@Column(name="DEFLT_NOTIF_EMAIL_ADDR")
	private String defaultNotficationEmail;
	
	@Column(name="ENDPNT_ID")
	private String endPoint;
	
	@Column(name="LST_UPDT_USER_ID")
	private String lastUpdtUserId;
	
	@Column(name="CRTE_USER_ID")
	private String createUserId;
	
	@Column(name="LST_UPDT_DT")
	private Date lastUpdtDate;
	
	@Column(name="CRTE_DT")
	private Date createdDate;
	
	@Column(name="RNWL_DT")
	private Date renewalDate;
	
	@Column(name = "BULK_ID")
	private String bulkId;
	
	@Column(name = "OPT_OUT_DT")
	private Date optOutDt;
	
	@ManyToOne
	@JoinColumn(name = "ICA_NUM", insertable=false , updatable =false)
	private EDSMemberHier edsMemberHier;

	public int getCustMstrId() {
		return custMstrId;
	}

	public void setCustMstrId(int custMstrId) {
		this.custMstrId = custMstrId;
	}

	public int getIcaNum() {
		return icaNum;
	}

	public void setIcaNum(int icaNum) {
		this.icaNum = icaNum;
	}

	public EDSMemberHier getEdsMemberHier() {
		return edsMemberHier;
	}

	public void setEdsMemberHier(EDSMemberHier edsMemberHier) {
		this.edsMemberHier = edsMemberHier;
	}

	public String getCustTypeCd() {
		return custTypeCd;
	}

	public void setCustTypeCd(String custTypeCd) {
		this.custTypeCd = custTypeCd;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getIsActivSW() {
		return isActivSW;
	}

	public void setIsActivSW(String isActivSW) {
		this.isActivSW = isActivSW;
	}

	public String getIsSilentSW() {
		return isSilentSW;
	}

	public void setIsSilentSW(String isSilentSW) {
		this.isSilentSW = isSilentSW;
	}

	public String getLastUpdtUserId() {
		return lastUpdtUserId;
	}

	public void setLastUpdtUserId(String lastUpdtUserId) {
		this.lastUpdtUserId = lastUpdtUserId;
	}

	public Date getLastUpdtDate() {
		return lastUpdtDate;
	}

	public void setLastUpdtDate(Date lastUpdtDate) {
		this.lastUpdtDate = lastUpdtDate;
	}

	public Date getRenewalDate() {
		return renewalDate;
	}

	public void setRenewalDate(Date renewalDate) {
		this.renewalDate = renewalDate;
	}

	public String getBulkId() {
		return bulkId;
	}

	public void setBulkId(String bulkId) {
		this.bulkId = bulkId;
	}

	public String getDefaultNotficationEmail() {
		return defaultNotficationEmail;
	}

	public void setDefaultNotficationEmail(String defaultNotficationEmail) {
		this.defaultNotficationEmail = defaultNotficationEmail;
	}

	public String getEndPoint() {
		return endPoint;
	}

	public void setEndPoint(String endPoint) {
		this.endPoint = endPoint;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getOptOutDt() {
		return optOutDt;
	}

	public void setOptOutDt(Date optOutDt) {
		this.optOutDt = optOutDt;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}
}
