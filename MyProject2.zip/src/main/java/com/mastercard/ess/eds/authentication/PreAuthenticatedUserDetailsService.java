package com.mastercard.ess.eds.authentication;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.constant.ApplicationLiterals;
import com.mastercard.ess.eds.model.UserDTO;

@Component
public class PreAuthenticatedUserDetailsService implements AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken>{

	private static final Logger logger = LoggerFactory.getLogger(PreAuthenticatedUserDetailsService.class);
	
	public UserDetails loadUserDetails(PreAuthenticatedAuthenticationToken user) throws UsernameNotFoundException {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter From Method : loadUserDetails");
		}
		
		if (user.getPrincipal() != null) {
			UserDTO userDTO = (UserDTO) user.getPrincipal() ;
			Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
			Map<String,String> memberships = userDTO.getMemberships();
			if(memberships.get(ApplicationLiterals.EDS_RULE_ADMIN) != null && memberships.get(ApplicationLiterals.EDS_RULE_ADMIN).equalsIgnoreCase("true")){
				authorities.add(new SimpleGrantedAuthority(ApplicationLiterals.ROLE_EDS_RULE_ADMIN));
			}
			
			if(memberships.get(ApplicationLiterals.EDS_CUST_ADMIN) != null && memberships.get(ApplicationLiterals.EDS_CUST_ADMIN).equalsIgnoreCase("true")){
				authorities.add(new SimpleGrantedAuthority(ApplicationLiterals.ROLE_EDS_CUST_ADMIN));
			}
			
			logger.info("UserId : " +userDTO.getUserId());
			return new User(userDTO.getUserId(), "none", true, true, true, true, authorities);
		}
		return null;
	}


	 
}