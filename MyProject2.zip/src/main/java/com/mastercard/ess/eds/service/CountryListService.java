package com.mastercard.ess.eds.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.dao.CountryListDAO;
import com.mastercard.ess.eds.model.Country;

@Component
public class CountryListService {

	@Autowired
	CountryListDAO cntryListDAO;
	
	// for Junit

	public void setCountryListService(CountryListDAO cntryListDAO) {
		this.cntryListDAO = cntryListDAO;
	}


	public List<Country> getCountryList() {
		return cntryListDAO.getCountryList();
	}


	public void CountryListDAO(CountryListDAO cntryListDAO) {
	this.cntryListDAO = cntryListDAO;
		
	}

}
