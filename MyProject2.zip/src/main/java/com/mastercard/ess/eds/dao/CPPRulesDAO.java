package com.mastercard.ess.eds.dao;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Junction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.constant.ApplicationLiterals;
import com.mastercard.ess.eds.constant.CommonConstants;
import com.mastercard.ess.eds.model.CPPRules;
import com.mastercard.ess.eds.request.SearchRequest;
import com.mastercard.ess.eds.response.SearchResponse;
import com.mastercard.ess.eds.util.HibernateUtils;
import com.mastercard.ess.eds.util.SortingCriteria;

/**
 * This class is used to perform Database operations.
 * The result is send back to Service layer.
 *
 *@author e066879	
 *@since 22-0-2017
 */

@Component
public class CPPRulesDAO {
	private static final Logger logger = LoggerFactory.getLogger(CPPRulesDAO.class);
	private static final String PAN_COUNT = "SELECT panCount, merchantName FROM com.mastercard.ess.eds.model.CPPSimData CSD WHERE CSD.edsCPPRuleId= :edsCPPRuleId order by createDate desc";


	/**
	 * This method is used for fetching the list of rules from database.	  
	 * @return CPPRules
	 * @throws SQLException 
	 */

	public SearchResponse getRules(SearchRequest searchRequest) {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : getRules");
		}
		SearchResponse searchResponse = new SearchResponse();
		SortingCriteria sort = searchRequest.getSort();

		Integer startLimit;
		String sortBy = null;
		String sortOrder = null;
		String chunk = (String) searchRequest.getruleData().get("CHUNK");
		String chunkSize = (String) searchRequest.getruleData().get("CHUNK_SIZE");
		Integer chunkValue;
		Integer totalCount;

		Map<String, Object> ruleData = searchRequest.getruleData();

		if (null != sort) {
			sortBy = sort.getSortBy();
			sortOrder = sort.getSortOrder();
		} else {
			sort = new SortingCriteria();
			sort.setSortBy(CommonConstants.RULE_ID);
			sort.setSortOrder(CommonConstants.SORT_ASCENDING);
		}

		// Calculate start limit for records.
		chunkValue = Integer.parseInt(chunk);
		startLimit = (chunkValue - 1) * Integer.parseInt(chunkSize) + 1;

		SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();	

		// Execute HQL query for total count, will execute for 1st page only.
		if (chunkValue <= ApplicationLiterals.MINIMUM_CHUNK_VALUE) {
			Criteria totalCountQuery= session.createCriteria(CPPRules.class);
			totalCountQuery = addCriteria(ruleData, totalCountQuery);
			if(CommonConstants.PENDING_STATE.equals(ruleData.get(CommonConstants.ACTV_SW))){
				totalCountQuery.add(Restrictions.eq(CommonConstants.SIMULATION_SWITCH, CommonConstants.YES));
			}
			totalCount = totalCountQuery.list().size();
			searchResponse.setTotalRecordCount(totalCount.toString());
			searchResponse.setChunk(ApplicationLiterals.MINIMUM_CHUNK_VALUE
					.toString());
		}

		Criteria ruleCriteria = session.createCriteria(CPPRules.class);
		ruleCriteria = addCriteria(ruleData, ruleCriteria);

		if(ruleData.get(CommonConstants.CPP_ARRAY) != null) {
			List<Integer> cppIds = (List<Integer>) ruleData.get(CommonConstants.CPP_ARRAY);
			Integer size = cppIds.size();
			Integer splitSize = size/CommonConstants.MAX_LIMIT_IN_CLAUSE;
			boolean critExists = false;

			Junction conditionGroup = Restrictions.disjunction();
			for(int cnt=0; cnt<=splitSize; cnt++){
				Criterion criterion = null;
				if(cnt < splitSize){
					criterion = Restrictions.in(CommonConstants.RULE_ID,cppIds.subList((CommonConstants.MAX_LIMIT_IN_CLAUSE * cnt), CommonConstants.MAX_LIMIT_IN_CLAUSE * (cnt+1)));
				} else {
					criterion = Restrictions.in(CommonConstants.RULE_ID,cppIds.subList((CommonConstants.MAX_LIMIT_IN_CLAUSE * cnt), size));
				}
				conditionGroup.add(criterion);
				critExists = true;
			}
			if(critExists){
				ruleCriteria.add(conditionGroup);
			}
		} 

		// Sort the rules based on sorting params
		if(!(CommonConstants.PAN_COUNT.equals(sortBy)||CommonConstants.MERCHANT_NAME.equals(sortBy))) {
			if (CommonConstants.SORT_ASCENDING.equalsIgnoreCase(sortOrder)) {
				ruleCriteria.addOrder(Order.asc(sortBy));
			} else {
				ruleCriteria.addOrder(Order.desc(sortBy));
			}

			if (!CommonConstants.EDS_CPP_RULE_ID_SORT.equalsIgnoreCase(sortBy)) {
				if (CommonConstants.SORT_ASCENDING.equalsIgnoreCase(sortOrder)) {
					ruleCriteria.addOrder(Order.asc(CommonConstants.EDS_CPP_RULE_ID_SORT));
				} else {
					ruleCriteria.addOrder(Order.desc(CommonConstants.EDS_CPP_RULE_ID_SORT));
				}
			}	
			// Pagination based on pagination params
			ruleCriteria.setMaxResults(Integer.parseInt(chunkSize));
			ruleCriteria.setFirstResult(startLimit - 1);
		}

		if (logger.isDebugEnabled()) {
			logger.debug("ruleCriteria :" + ruleCriteria);
		}

		if(CommonConstants.PENDING_STATE.equals(ruleData.get(CommonConstants.ACTV_SW))){
			ruleCriteria.add(Restrictions.eq(CommonConstants.SIMULATION_SWITCH, CommonConstants.YES));
		}

		List<CPPRules> userRulesList = ruleCriteria.list();

		if(CommonConstants.PAN_COUNT.equals(sortBy) || CommonConstants.MERCHANT_NAME.equals(sortBy) || CommonConstants.PENDING_STATE.equals(ruleData.get(CommonConstants.ACTV_SW))){
			for(CPPRules rule : userRulesList) {
				Query query = session.createQuery(PAN_COUNT);            
				query.setParameter(CommonConstants.EDS_CPP_RULE_ID, new BigDecimal(rule.getRuleId()));
				List<Object[]> user = query.list();
				if(user.size()>0){
					for(Object[] usr: user){
						rule.setPanCount(Integer.valueOf((String) usr[0]));
						rule.setMerchantName((String) usr[1]);
					}
				} else {
					rule.setPanCount(0);
					rule.setMerchantName("");
				}
			}
		}

		if(CommonConstants.PAN_COUNT.equals(sortBy)||CommonConstants.MERCHANT_NAME.equals(sortBy)) {
			userRulesList = sortUsingPanAndMerchantName(sortBy, sortOrder, ruleData, userRulesList, chunkSize, startLimit-1);
		}
		searchResponse.setRuleList(userRulesList);
		searchResponse.setSort(sort);
		searchResponse.setChunkSize(chunkSize);
		searchResponse.setChunk(chunk);
		session.close();

		if (logger.isDebugEnabled()) {
			logger.debug("Exit From  : getRules");
		}
		return searchResponse;
	}


	private List<CPPRules> sortUsingPanAndMerchantName(String sortBy, String sortOrder,
			Map<String, Object> ruleData, List<CPPRules> userRulesList, String chunkSize, int startLimit) {

		boolean isSorted = false;
		if(CommonConstants.PAN_COUNT.equals(sortBy) && CommonConstants.SORT_ASCENDING.equalsIgnoreCase(sortOrder)){
			Collections.sort(userRulesList, new Comparator<CPPRules>() {
				@Override
				public int compare(CPPRules c1, CPPRules c2) {
					return c1.getPanCount() - c2.getPanCount();
				}
			});
			isSorted = true;
		}

		if(CommonConstants.MERCHANT_NAME.equals(sortBy) && CommonConstants.SORT_ASCENDING.equalsIgnoreCase(sortOrder)){
			Collections.sort(userRulesList, new Comparator<CPPRules>() {
				@Override
				public int compare(CPPRules c1, CPPRules c2) {
					return c1.getMerchantName().compareTo(c2.getMerchantName());
				}
			});
			isSorted = true;

		}

		if(CommonConstants.PAN_COUNT.equals(sortBy) && CommonConstants.SORT_DESCENDING.equalsIgnoreCase(sortOrder)){
			Collections.sort(userRulesList, Collections.reverseOrder(new Comparator<CPPRules>() {
				@Override
				public int compare(CPPRules c1, CPPRules c2) {
					return c1.getPanCount() - c2.getPanCount();
				}
			}));
			isSorted = true;
		}

		if(CommonConstants.MERCHANT_NAME.equals(sortBy) && CommonConstants.SORT_DESCENDING.equalsIgnoreCase(sortOrder)){
			Collections.sort(userRulesList, Collections.reverseOrder(new Comparator<CPPRules>() {
				@Override
				public int compare(CPPRules c1, CPPRules c2) {
					return c1.getMerchantName().compareTo(c2.getMerchantName());
				}
			}));
			isSorted = true;
		}

		int endLimit = 0;
		if(isSorted){
			endLimit = startLimit+Integer.parseInt(chunkSize);
		} else {
			endLimit = startLimit+Integer.parseInt(chunkSize)-1;
		}
		if(userRulesList.size()>=endLimit){
			userRulesList =  userRulesList.subList(startLimit, endLimit);
		}else{
			userRulesList =  userRulesList.subList(startLimit, userRulesList.size());
		}

		return userRulesList;
	}


	/**
	 * This method used for creating overall criteria
	 * @param ruleData
	 * @return ruleCriteria
	 */ 

	public Criteria addCriteria (Map<String, Object> ruleData, Criteria ruleCriteria) {
		addCriteria(ruleData, CommonConstants.ACTV_SW, CommonConstants.EQLS, ruleCriteria);
		addCriteria(ruleData, CommonConstants.RULE_ID, CommonConstants.EQLS, ruleCriteria);
		addCriteria(ruleData, CommonConstants.VAL_LOC_ID, CommonConstants.EQLS, ruleCriteria);
		addCriteria(ruleData, CommonConstants.UNIT_TM, CommonConstants.EQLS, ruleCriteria);
		addCriteria(ruleData, CommonConstants.VAL_TM, CommonConstants.EQLS, ruleCriteria);
		if(!CommonConstants.NOT_EQUALS.equals(ruleData.get(CommonConstants.CLS_ISSR_CNTRY))){
			addCriteria(ruleData, CommonConstants.CLS_ISSR_CNTRY, CommonConstants.EQLS, ruleCriteria);
		}
		if(!CommonConstants.NOT_EQUALS.equals(ruleData.get(CommonConstants.CLS_LOC_TRAN_AMT))) {
			addCriteria(ruleData, CommonConstants.CLS_LOC_TRAN_AMT, CommonConstants.EQLS, ruleCriteria);
		}
		addCriteria(ruleData, CommonConstants.VAL_ISSR_CNTRY, ruleData.get(CommonConstants.CLS_ISSR_CNTRY), ruleCriteria);
		addCriteria(ruleData, CommonConstants.VAL_LOC_TRAN_AMT,  ruleData.get(CommonConstants.CLS_LOC_TRAN_AMT), ruleCriteria);	
		return ruleCriteria;
	}	



	/**
	 * This method used for creating criteria for Specific clause and fieldName
	 * @param ruleData , fieldName 
	 * @return ruleCriteria
	 */ 

	public Criteria addCriteria(Map<String, Object> ruleData, String fieldName, Object clause, Criteria ruleCriteria) {

		Object fieldValue = ruleData.get(fieldName);

		if (null != fieldValue && null != clause) {

			fieldValue = addCriteria(ruleData, fieldName);

			switch (clause.toString()) {
			case "notequals":
				Junction conditionGroup = Restrictions.disjunction();
				conditionGroup.add(Restrictions.ne(fieldName, fieldValue));
				conditionGroup.add(Restrictions.isNull(fieldName));
				ruleCriteria.add(conditionGroup);
				break;

			case "oneof":
				setOneOfCriteria(fieldName, ruleCriteria, fieldValue);
				break;

			case "other":
				setOtherCriteria(fieldName, ruleCriteria, fieldValue);
				break;

			default:
				ruleCriteria.add(Restrictions.eq(fieldName, fieldValue));
				break;
			}
		}
		return ruleCriteria;
	}


	private void setOtherCriteria(String fieldName, Criteria ruleCriteria,
			Object fieldValue) {
		if (StringUtils.isNotBlank(fieldValue.toString())) {
			String[] result = fieldValue.toString().split(",");
			Junction conditionGroup = Restrictions.disjunction();
			for(String str : result){
				Criterion criterion = null;
				criterion = Restrictions.like(fieldName, CommonConstants.PERCENTAGE + str + CommonConstants.PERCENTAGE);
				conditionGroup.add(criterion);
			}
			ruleCriteria.add(conditionGroup);
		} 
	}


	private void setOneOfCriteria(String fieldName, Criteria ruleCriteria,
			Object fieldValue) {
		if (StringUtils.isNotBlank(fieldValue.toString())) {
			String[] strArray = fieldValue.toString().split(",");
			Junction conditionGroup = Restrictions.disjunction();
			for(String str : strArray){
				Criterion criterion = null;
				criterion = Restrictions.like(fieldName, CommonConstants.PERCENTAGE + str + CommonConstants.PERCENTAGE);
				conditionGroup.add(criterion);
			}
			ruleCriteria.add(conditionGroup);
		} 
	}

	/**
	 * This method used for converting field value to specific dataType based on fieldName
	 * @param ruleData , fieldName , fieldValue
	 * @return fieldValue
	 */	

	public Object addCriteria (Map<String, Object> ruleData, String fieldName) {

		Object fieldValue;

		if (CommonConstants.VAL_LOC_ID.equalsIgnoreCase(fieldName)
				|| CommonConstants.VAL_LOC_TRAN_AMT.equalsIgnoreCase(fieldName)
				|| CommonConstants.VAL_TM.equalsIgnoreCase(fieldName)) {

			fieldValue = new BigDecimal(ruleData.get(fieldName).toString());

		} else if (CommonConstants.RULE_ID.equalsIgnoreCase(fieldName)) {

			fieldValue = new Integer(ruleData.get(fieldName).toString());

		} else {

			fieldValue = ruleData.get(fieldName);

		}
		return fieldValue;
	}


	/**
	 * This method used for Save and update the rules.
	 * @param listUserRules
	 * @return 
	 * @return CPPRules
	 */ 

	public List<CPPRules> saveOrUpdateRules(List<CPPRules> listUserRules, HttpServletRequest request) throws SQLException {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : saveOrUpdateRules");
		}

		SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
		Session session  = sessionFactory.openSession();	

		List <CPPRules> list= new ArrayList<>();
		for (CPPRules cppRule : listUserRules) {
			List<CPPRules> fetchRuleList;
			int size;
			Criteria fetchCrt = session.createCriteria(CPPRules.class);
			if(!CommonConstants.NO.equals(cppRule.getActiveSW()) && !CommonConstants.PENDING_STATE.equals(cppRule.getActiveSW())) {
				fetchCrt.add(Restrictions.eq(CommonConstants.VAL_LOC_ID, cppRule.getLocationIdValue()));
				fetchCrt.add(Restrictions.eq(CommonConstants.CLS_LOC_ID, cppRule.getLocationIdClause()));
				fetchCrt.add(Restrictions.eq(CommonConstants.VAL_TM, cppRule.getTimeValue()));
				fetchCrt.add(Restrictions.eq(CommonConstants.UNIT_TM, cppRule.getTimeUnit()));
				fetchCrt.add(StringUtils.isBlank(cppRule.getIssuerCntryValue()) ? Restrictions.isNull(CommonConstants.VAL_ISSR_CNTRY) : Restrictions.eq(CommonConstants.VAL_ISSR_CNTRY, cppRule.getIssuerCntryValue()));
				fetchCrt.add(StringUtils.isBlank(cppRule.getIssuerCntryClause()) ? Restrictions.isNull(CommonConstants.CLS_ISSR_CNTRY) : Restrictions.eq(CommonConstants.CLS_ISSR_CNTRY, cppRule.getIssuerCntryClause()));
				fetchCrt.add(cppRule.getLocalTxnAmountVal() == null ? Restrictions.isNull(CommonConstants.VAL_LOC_TRAN_AMT) : Restrictions.eq(CommonConstants.VAL_LOC_TRAN_AMT, cppRule.getLocalTxnAmountVal()));
				fetchCrt.add(StringUtils.isBlank(cppRule.getLocalTxnAmountClause()) ? Restrictions.isNull(CommonConstants.CLS_LOC_TRAN_AMT) : Restrictions.eq(CommonConstants.CLS_LOC_TRAN_AMT, cppRule.getLocalTxnAmountClause()));
				fetchCrt.add(StringUtils.isBlank(cppRule.getCategoryType()) ? Restrictions.isNull(CommonConstants.CATEGORY_TYPE) : Restrictions.eq(CommonConstants.CATEGORY_TYPE, cppRule.getCategoryType()));
				fetchCrt.add(Restrictions.eq(CommonConstants.ACTV_SW, CommonConstants.YES));
				fetchRuleList = fetchCrt.list();
				size = fetchRuleList.size();
			} else {
				size = 0;
			}					
			logger.info("2. size = " + size);
			try{
				session.beginTransaction();
				Integer ruleId = cppRule.getRuleId();
				logger.info("3. ruleId = " + ruleId);
				if(size > 0) {
					cppRule.setIsDuplicate(CommonConstants.YES);
				} else if(ruleId == 0 && size == 0) {
					cppRule.setCreateDate(new Date());
					cppRule.setCreateUserId(request.getHeader("userId") );
					cppRule.setFirstRunSW(CommonConstants.YES);
					cppRule.setActiveSW(CommonConstants.PENDING_STATE);
					session.save(cppRule);
					logger.info("3. ruleId = " + cppRule.getRuleId());
					cppRule.setIsDuplicate(CommonConstants.NO);
				} else {
					Session histSess  = sessionFactory.openSession();
					Criteria crt = histSess.createCriteria(CPPRules.class);
					crt.add(Restrictions.eq(CommonConstants.RULE_ID, cppRule.getRuleId()));
					List<CPPRules> ruleList = crt.list();
					if(CollectionUtils.isNotEmpty(ruleList)){
						cppRule.setCreateUserId(ruleList.get(0).getCreateUserId());
						cppRule.setCreateDate(ruleList.get(0).getCreateDate());
						cppRule.setFirstRunSW(ruleList.get(0).getFirstRunSW());
					}
					cppRule.setLastUpdatedUserId(request.getHeader("userId"));
					cppRule.setLastUpdatedDate(new Date());					
					session.update(cppRule);
					cppRule.setIsDuplicate(CommonConstants.NO);
				}
				session.getTransaction().commit();
			}catch(ConstraintViolationException cve){
				session.getTransaction().rollback();
				logger.info("Potential duplicate rule addition" + cve);
				cppRule.setIsDuplicate(CommonConstants.YES);
			} finally{
				list.add(cppRule);
			}
		}	
		session.close();

		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : saveOrUpdateRules");
		}
		return list;
	}
	public List<CPPRules> fetchCPPRules(List<Integer> cppIds) throws SQLException {

		List<CPPRules> list = null;
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : CPPRulesDAO - fetchCPPRules");
		}
		try{
			SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
			Session session  = sessionFactory.openSession();	
			Criteria crt = session.createCriteria(CPPRules.class);
			crt.add(Restrictions.in(CommonConstants.RULE_ID, cppIds));
			list = crt.list();
			session.close();
		}catch(Exception e){
			logger.info("Error while fetching cpp rules : "+e.getMessage());
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : CPPRulesDAO - fetchCPPRules");
		}
		return list;
	}


	/**
	 * This method is used to fetch the cpp rules based on cpp id which to be viewed to user before deactivating
	 * @param cppIdList - contains list of cppIds
	 * @return - returns the cpp rule details for the given list of cppIds 
	 */
	public List<CPPRules> viewCPPRules(List<Integer> cppIdList) {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : CPPRulesDAO - viewCPPRules");
		}

		SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
		List<CPPRules> cppList = new ArrayList<CPPRules>();
		Collections.sort(cppIdList);
		if(cppIdList.size() > 0){
			try{
			Integer size = cppIdList.size();
			Integer splitSize = size / CommonConstants.MAX_LIMIT_IN_CLAUSE;
			Session session  = sessionFactory.openSession();	
			Criteria cppSelectCrt = session.createCriteria(CPPRules.class);
			cppSelectCrt.add(Restrictions.eq(CommonConstants.ACTV_SW, CommonConstants.YES));
			Junction conditionGroup = Restrictions.disjunction();
			for(int cnt=0; cnt<=splitSize; cnt++){
				Criterion criterion = null;
				if(cnt < splitSize){
					criterion = Restrictions.in(CommonConstants.RULE_ID, cppIdList.subList((CommonConstants.MAX_LIMIT_IN_CLAUSE * cnt), CommonConstants.MAX_LIMIT_IN_CLAUSE * (cnt+1)));
				} else {
					criterion = Restrictions.in(CommonConstants.RULE_ID, cppIdList.subList((CommonConstants.MAX_LIMIT_IN_CLAUSE * cnt), size));
				}
				conditionGroup.add(criterion);
			}
			cppSelectCrt.add(conditionGroup);
			cppSelectCrt.addOrder(Order.asc(CommonConstants.RULE_ID));
			cppList = cppSelectCrt.list();
			session.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		}

		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : CPPRulesDAO - viewCPPRules");
		}

		return cppList;
	}

	/**
	 * This method is used to update status of cpp rule which supports bulk updation as well
	 * @param cppIds - To update the status of the list of cppIds
	 * @param lastUpdatedUserId - to update the last updated user Id
	 * @param ruleStatus - contains the status value
	 * @return - Returns the number of updated rules
	 */
	public Integer updateRuleStatus(List<Integer> cppIds, String lastUpdatedUserId, String ruleStatus) {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : CPPRulesDAO - updateRuleStatus");
		}
		SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
		Session session  = sessionFactory.openSession();
		session.beginTransaction();
		for(Integer id : cppIds){
			Criteria crt = session.createCriteria(CPPRules.class);
			crt.add(Restrictions.eq(CommonConstants.RULE_ID, id));
			List<CPPRules> crtList = crt.list();
			if(CollectionUtils.isNotEmpty(crtList)){
				CPPRules rule = crtList.get(0);
				rule.setActiveSW(ruleStatus);
				rule.setLastUpdatedUserId(lastUpdatedUserId);
				rule.setLastUpdatedDate(new Date());
				session.update(rule);
			}
		}
		session.getTransaction().commit();
		session.close();

		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : CPPRulesDAO - updateRuleStatus");
		}
		return cppIds.size();
	}

	public Integer updateRuleStatusWithFlag(List<Integer> cppIds,
			String lastUpdatedUserId, String ruleStatus) {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : CPPRulesDAO - updateRuleStatusWithFlag");
		}
		SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
		Session session  = sessionFactory.openSession();
		Criteria crt = session.createCriteria(CPPRules.class);
		crt.add(Restrictions.eq(CommonConstants.ACTV_SW, CommonConstants.PENDING_STATE));
		crt.add(Restrictions.eq(CommonConstants.SIMULATION_SWITCH, CommonConstants.YES));
		List<CPPRules> crtList = crt.list();

		for(CPPRules rule : crtList){
			if(!cppIds.contains(rule.getRuleId())){
				session.beginTransaction();
				rule.setActiveSW(ruleStatus);
				rule.setLastUpdatedUserId(lastUpdatedUserId);
				rule.setLastUpdatedDate(new Date());
				session.update(rule);
				session.getTransaction().commit();
			}
		}		
		session.close();

		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : CPPRulesDAO - updateRuleStatusWithFlag");
		}
		return cppIds.size();
	}
	
	public Integer getRuleCount(String ruleStatus) {
		int cppRuleSize = 0;
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : CPPRulesDAO - getRuleCount");
		}
		try{
			SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
			Session session  = sessionFactory.openSession();	
			Criteria crt = session.createCriteria(CPPRules.class);
			crt.add(Restrictions.eq(CommonConstants.ACTV_SW, ruleStatus));
			crt.add(Restrictions.eq(CommonConstants.SIMULATION_SWITCH, CommonConstants.YES));
			cppRuleSize = crt.list().size();
			session.close();
		}catch(Exception e){
			logger.info("Error while fetching cpp rules : "+e.getMessage());
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : CPPRulesDAO - getRuleCount");
		}
		return cppRuleSize;
	}

}
