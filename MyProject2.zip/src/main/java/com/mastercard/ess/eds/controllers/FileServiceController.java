package com.mastercard.ess.eds.controllers;

import io.swagger.annotations.ApiOperation;

import java.io.OutputStream;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.mastercard.ess.eds.constant.ApplicationLiterals;
import com.mastercard.ess.eds.constant.CommonConstants;
import com.mastercard.ess.eds.exceptions.EDSException;
import com.mastercard.ess.eds.model.CPPRules;
import com.mastercard.ess.eds.response.FileUploadCPPResponse;
import com.mastercard.ess.eds.service.CPPRulesService;
import com.mastercard.ess.eds.service.FileUploadHelper;
/**
 * Handles requests for the application file upload requests
 */

@RestController
@Component 
public class FileServiceController  extends BaseController{

	private static final Logger logger = LoggerFactory.getLogger(FileServiceController.class);

	public static final String CPP_COLS = "Rule ID, Location ID,Issuer Country,Country Condition,Amount,Amount Condition,Internal Rule,Date Range,Date Unit,Status";
	public static final String COMMA = ",";
	public static final String NOT_APPLICABLE = "NA";

	@Autowired
	private FileUploadHelper fileUploadHelper ;

	@Autowired
	private CPPRulesService cppRulesService;

	/**
	 * Upload single file using Spring Controller
	 * @throws EDSException 
	 */
	@RequestMapping(value ="/eds/v1/cpp/upload", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE )
	public  ResponseEntity  uploadCPPFile( @RequestParam(name="uploadfile")  MultipartFile uploadfile , HttpServletRequest request) 
			throws EDSException , SQLException {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : uploadCPPFile");
		}

		FileUploadCPPResponse result = null;
		if (!uploadfile.isEmpty()) {
			validateFile(uploadfile);
			result =   fileUploadHelper.importAndSaveCPPRecordFromFile(uploadfile, request) ;
		}

		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : uploadCPPFile");
		}

		return new ResponseEntity(result, HttpStatus.OK); 

	}

	@RequestMapping(value ="/eds/v1/cpp/download", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE )
	public void downloadMethod(@RequestBody List<Integer> cppIds, HttpServletResponse response)
	{
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : File Service - downloadMethod");
		}
		response.setContentType("text/csv");
		response.setHeader("Content-Disposition", "attachment; filename=\"data.csv\"");
		try
		{
			OutputStream outputStream = response.getOutputStream();
			StringBuffer outputResult = new StringBuffer(CPP_COLS);	        
			List<CPPRules> list = cppRulesService.fetchCPPRules(cppIds);
			for(CPPRules rule : list){
				outputResult
				.append("\n")
				.append(String.valueOf(rule.getRuleId())).append(COMMA)
				.append(String.valueOf(rule.getLocationIdValue()).equals("null") ? NOT_APPLICABLE:String.valueOf(rule.getLocationIdValue())).append(COMMA)
				.append(StringUtils.isNotBlank(rule.getIssuerCntryValue()) ? (rule.getIssuerCntryValue().contains(",")?"\"" +rule.getIssuerCntryValue()+"\"":rule.getIssuerCntryValue()):NOT_APPLICABLE).append(COMMA)
				.append(StringUtils.isNotBlank(rule.getIssuerCntryClause()) ? rule.getIssuerCntryClause():NOT_APPLICABLE).append(COMMA)
				.append(String.valueOf(rule.getLocalTxnAmountVal()).equals("null") ? NOT_APPLICABLE:String.valueOf(rule.getLocalTxnAmountVal())).append(",")
				.append(StringUtils.isNotBlank(rule.getLocalTxnAmountClause()) ? rule.getLocalTxnAmountClause():NOT_APPLICABLE).append(COMMA)	   
				.append(StringUtils.isNotBlank(rule.getCategoryType()) ? rule.getCategoryType():NOT_APPLICABLE).append(COMMA)       	
				.append(String.valueOf(rule.getTimeValue()).equals("null") ? NOT_APPLICABLE:String.valueOf(rule.getTimeValue())).append(COMMA)
				.append(StringUtils.isNotBlank(rule.getTimeUnit()) ? rule.getTimeUnit():NOT_APPLICABLE).append(COMMA)
				.append(StringUtils.isNotBlank(rule.getActiveSW()) ? (rule.getActiveSW().equalsIgnoreCase("Y") ? "ACTIVE": "Inactive"):NOT_APPLICABLE);   	
			}
			outputStream.write(outputResult.toString().getBytes());
			outputStream.flush();
			outputStream.close();
		}
		catch(Exception e)
		{
			logger.info("Error while downloading cpp rules file : "+ e.getMessage());
		}

		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : FileService - downloadMethod");
		}

	}

	/**
	 * This controller is to deactivate rules using fileUpload
	 * @param uploadfile - parameter contain the file with cppId's which to be viewed to user before deactivation
	 * @param chunk - chunk value will be used to send the chunk number of cpp rule details
	 * @return This returns response which contains the success and error details of cppId
	 */
	@PreAuthorize("hasRole(T(com.mastercard.ess.eds.constant.ApplicationLiterals).ROLE_EDS_RULE_ADMIN)")
	@ApiOperation(value = ApplicationLiterals.CPP_RULES_VIEW)
	@RequestMapping(value ="/eds/v1/cpp/bulk/list", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE )
	public  ResponseEntity  viewCPPRules( @RequestParam(name="uploadfiletodelete")  MultipartFile uploadfile , @RequestParam("chunk") String chunk) {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : viewCPPRules");
		}

		FileUploadCPPResponse result = null;
		
		if (uploadfile.isEmpty() || !(uploadfile.getOriginalFilename().endsWith(CommonConstants.CSV_FORMAT))) {
			return new ResponseEntity(HttpStatus.BAD_REQUEST);
		}
			
		try {
			result =   fileUploadHelper.viewCPPRules(uploadfile, chunk) ;
		} catch (EDSException e) {
			//Incase of improper content
			return new ResponseEntity(HttpStatus.PARTIAL_CONTENT);
		}
		

		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : viewCPPRules");
		}

		return new ResponseEntity(result, HttpStatus.OK); 

	}



}

