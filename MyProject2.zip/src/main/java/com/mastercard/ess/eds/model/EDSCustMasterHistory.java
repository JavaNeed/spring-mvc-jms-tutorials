package com.mastercard.ess.eds.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity // entity should be created via "new" and not injected as spring bean
@Table(name = "EDS_CUST_MSTR_HIST", schema = "EDS_OWNER")
public class EDSCustMasterHistory {
	
	@Id
	@Column(name="EDS_CUST_MSTR_HIST_ID",unique=true,nullable=false)
	@SequenceGenerator(name = "seq", sequenceName = "EDS_CUST_MSTR_HIST_ID_SEQ")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	private Integer custMstrHistId;
	
	@Column(name="EDS_CUST_MSTR_ID")
	private Integer custMstrId;
	
	@Column(name="CUST_TYPE_CD")
	private String custTypeCd;
	
	@Column(name="CUST_NAM")
	private String custName;
	
	@Column(name="ACTV_SW")
	private String isActivSW;
	
	@Column(name="SILENT_SW")
	private String isSilentSW; 
	
	@Column(name="ICA_NUM")
	private Integer icaNum;
	
	@Column(name="DEFLT_NOTIF_EMAIL_ADDR")
	private String defaultNotficationEmail;
	
	@Column(name="ENDPNT_ID")
	private String endPoint;
	
	@Column(name="RNWL_DT")
	private Date renewalDate;
	
	@Column(name = "BULK_ID")
	private String bulkId;
	
	@Column(name="LST_UPDT_USER_ID")
	private String lastUpdtUserId;
	
	@Column(name="LST_UPDT_DT")
	private Date lastUpdtDate;
	
	@Column(name="CRTE_DT")
	private Date createdDate;
	
	@Column(name= "HIST_CRTE_DT")
	private Date histCrteDt;

	public Integer getCustMstrHistId() {
		return custMstrHistId;
	}

	public void setCustMstrHistId(Integer custMstrHistId) {
		this.custMstrHistId = custMstrHistId;
	}

	public Integer getCustMstrId() {
		return custMstrId;
	}

	public void setCustMstrId(Integer custMstrId) {
		this.custMstrId = custMstrId;
	}

	public String getCustTypeCd() {
		return custTypeCd;
	}

	public void setCustTypeCd(String custTypeCd) {
		this.custTypeCd = custTypeCd;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getIsActivSW() {
		return isActivSW;
	}

	public void setIsActivSW(String isActivSW) {
		this.isActivSW = isActivSW;
	}

	public String getIsSilentSW() {
		return isSilentSW;
	}

	public void setIsSilentSW(String isSilentSW) {
		this.isSilentSW = isSilentSW;
	}

	public Integer getIcaNum() {
		return icaNum;
	}

	public void setIcaNum(Integer icaNum) {
		this.icaNum = icaNum;
	}

	public String getDefaultNotficationEmail() {
		return defaultNotficationEmail;
	}

	public void setDefaultNotficationEmail(String defaultNotficationEmail) {
		this.defaultNotficationEmail = defaultNotficationEmail;
	}

	public String getEndPoint() {
		return endPoint;
	}

	public void setEndPoint(String endPoint) {
		this.endPoint = endPoint;
	}

	public Date getRenewalDate() {
		return renewalDate;
	}

	public void setRenewalDate(Date renewalDate) {
		this.renewalDate = renewalDate;
	}

	public String getBulkId() {
		return bulkId;
	}

	public void setBulkId(String bulkId) {
		this.bulkId = bulkId;
	}

	public String getLastUpdtUserId() {
		return lastUpdtUserId;
	}

	public void setLastUpdtUserId(String lastUpdtUserId) {
		this.lastUpdtUserId = lastUpdtUserId;
	}

	public Date getLastUpdtDate() {
		return lastUpdtDate;
	}

	public void setLastUpdtDate(Date lastUpdtDate) {
		this.lastUpdtDate = lastUpdtDate;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getHistCrteDt() {
		return histCrteDt;
	}

	public void setHistCrteDt(Date histCrteDt) {
		this.histCrteDt = histCrteDt;
	}

}
