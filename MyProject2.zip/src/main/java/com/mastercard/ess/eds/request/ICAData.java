package com.mastercard.ess.eds.request;

public class ICAData {
		
	private Integer icaNum ;
	private String  icaDescription;
	private boolean  isOnboarded;
	private boolean  isValid;
	
	public Integer getIcaNum() {
		return icaNum;
	}
	public void setIcaNum(Integer icaNum) {
		this.icaNum = icaNum;
	}
	public String getIcaDescription() {
		return icaDescription;
	}
	public void setIcaDescription(String icaDescription) {
		this.icaDescription = icaDescription;
	}
	public boolean isOnboarded() {
		return isOnboarded;
	}
	public void setOnboarded(boolean isOnboarded) {
		this.isOnboarded = isOnboarded;
	}
	public boolean isValid() {
		return isValid;
	}
	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}
	
	 
}
