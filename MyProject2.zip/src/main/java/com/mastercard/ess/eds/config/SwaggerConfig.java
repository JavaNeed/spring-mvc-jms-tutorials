package com.mastercard.ess.eds.config;

import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.RequestMethod;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ResponseMessage;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.google.common.base.Predicates;

@Configuration
@EnableSwagger2
public class SwaggerConfig {

	public static final String DEFAULT_INCLUDE_PATTERN = "/api/v1/.*";

	/**
	 * Swagger Springfox configuration.
	 */
	@Bean
	public Docket swaggerSpringfoxDocket(SwaggerProperties swaggerProperties) {
		StopWatch watch = new StopWatch();
		watch.start();
		@SuppressWarnings("deprecation")
		ApiInfo apiInfo = new ApiInfo(
				swaggerProperties.getSwagger().getTitle(), swaggerProperties
						.getSwagger().getDescription(), swaggerProperties
						.getSwagger().getVersion(), swaggerProperties
						.getSwagger().getTermsOfServiceUrl(), swaggerProperties
						.getSwagger().getContact(), swaggerProperties
						.getSwagger().getLicense(), swaggerProperties
						.getSwagger().getLicenseUrl());

		Docket docket = new Docket(DocumentationType.SWAGGER_2)
				.apiInfo(apiInfo)
				.forCodeGeneration(true)
				.useDefaultResponseMessages(true)
				.enableUrlTemplating(true)
				.globalResponseMessage(RequestMethod.GET,
						new ArrayList<ResponseMessage>() {
							private static final long serialVersionUID = 1L;
							{
								add(new ResponseMessageBuilder().code(500)
										.message("Internal Server Error")
										.responseModel(new ModelRef("Error"))
										.build());
								add(new ResponseMessageBuilder().code(405)
										.message("Method Not Allowed")
										.responseModel(new ModelRef("Error"))
										.build());
								add(new ResponseMessageBuilder().code(401)
										.message("Unauthorized")
										.responseModel(new ModelRef("Error"))
										.build());
								add(new ResponseMessageBuilder().code(400)
										.message("Bad Request")
										.responseModel(new ModelRef("Error"))
										.build());
								add(new ResponseMessageBuilder()
										.code(412)
										.message("Initial Validation Failed")
										.responseModel(new ModelRef("Error"))
										.build());
							}
						})
				.globalResponseMessage(RequestMethod.POST,
						new ArrayList<ResponseMessage>() {
							private static final long serialVersionUID = 1L;
							{
								add(new ResponseMessageBuilder().code(500)
										.message("Internal Server Error")
										.responseModel(new ModelRef("Error"))
										.build());
								add(new ResponseMessageBuilder().code(405)
										.message("Method Not Allowed")
										.responseModel(new ModelRef("Error"))
										.build());
								add(new ResponseMessageBuilder().code(401)
										.message("Unauthorized")
										.responseModel(new ModelRef("Error"))
										.build());
								add(new ResponseMessageBuilder().code(400)
										.message("Bad Request")
										.responseModel(new ModelRef("Error"))
										.build());
								add(new ResponseMessageBuilder()
										.code(412)
										.message("Initial Validation Failed")
										.responseModel(new ModelRef("Error"))
										.build());
							}
						}).select()
				.paths(Predicates.not(PathSelectors.regex("/error"))).build();
		watch.stop();
		return docket;
	}
}
