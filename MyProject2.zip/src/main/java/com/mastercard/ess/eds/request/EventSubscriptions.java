package com.mastercard.ess.eds.request;

import java.util.List;

/**
 * @author e069468
 *
 */
public class EventSubscriptions {
	
	private Integer eventId ;
	private List<String> emailId;
	private List<Integer> icas;
	private Integer vendorId;
	
	public Integer getEventId() {
		return eventId;
	}
	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}
	public List<String> getEmailId() {
		return emailId;
	}
	public void setEmailId(List<String> emailId) {
		this.emailId = emailId;
	}
	public List<Integer> getIcas() {
		return icas;
	}
	public void setIcas(List<Integer> icas) {
		this.icas = icas;
	}
	public Integer getVendorId() {
		return vendorId;
	}
	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}
	
}
