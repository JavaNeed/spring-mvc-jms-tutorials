package com.mastercard.ess.eds.request;

import java.io.Serializable;

public class RequestHeader implements Serializable {

	private static final long	serialVersionUID	= 1L;

	private String	           contentType;
	private String	           stubMode;	

	public static final String	SUCCESS_RESPONSE	= "S";
	public static final String	FAILURE_RESPONSE	= "F";

	/**
	 * @param contentType
	 * @param stubMode
	 * @param userProfile
	 */
	public RequestHeader(String contentType, String stubMode) {
		super();
		this.contentType = contentType;
		this.stubMode = stubMode;		
	}

	/**
	 * @return the contentType
	 */
	public String getContentType() {
		return contentType;
	}

	/**
	 * @return the stubMode
	 */
	public String getStubMode() {
		return stubMode;
	}	

	/**
	 * @return whether service consumer has requested stubbed responses
	 */
	public boolean isStubbed() {
		if (null != stubMode) {
			return Boolean.TRUE;
		} else {
			return Boolean.FALSE;
		}
	}

	/**
	 * @return success or failure param for simulation
	 */
	public String getStubCondition() {
		String condition = SUCCESS_RESPONSE;
		if (null != stubMode && FAILURE_RESPONSE.equalsIgnoreCase(stubMode)) {
			condition = FAILURE_RESPONSE;
			return condition;
		} else {
			return condition;
		}
	}

	public RequestHeader() {
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "RequestHeader [contentType=" + contentType + ", stubMode=" + stubMode + "]";
	}

}
