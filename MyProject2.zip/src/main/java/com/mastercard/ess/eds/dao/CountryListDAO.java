package com.mastercard.ess.eds.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.model.Country;
import com.mastercard.ess.eds.util.HibernateUtils;

@Component
public class CountryListDAO {
	
	
	public List<Country> getCountryList() {
		SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
		Session session = sessionFactory.openSession();	
		return session.createCriteria(Country.class).addOrder(Order.asc("cntryName")).list();	
	}
	
	public List<Country> getCountryCode(String countryCode) {
		SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
		Session session = sessionFactory.openSession();	
		Criteria criteria = session.createCriteria(Country.class);
		criteria.add(Restrictions.eq("alpha3Code", countryCode));
		return criteria.list();	
	}

	public CountryListDAO() {
		super();
		// TODO Auto-generated constructor stub
	}
}
