package com.mastercard.ess.eds.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.NaturalId;

@Entity // entity should be created via "new" and not injected as spring bean
@Table(name = "BATCH_JOB_EXECUTION", schema = "EDS_OWNER")
public class BatchJobExecution implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "JOB_EXECUTION_ID")
	private BigDecimal jobExecutionId;
	
	@NaturalId
	@Column(name = "JOB_INSTANCE_ID")
	private BigDecimal jobInstanceId;
	
	@Column(name = "CREATE_TIME")
	private Date createTime;
	
	@Column(name = "START_TIME")
	private Date startTime;
	
	@Column(name = "END_TIME")
	private Date endTime;
	
	@Column(name = "STATUS")
	private String status;
	
	public BigDecimal getJobExecutionId() {
		return jobExecutionId;
	}

	public void setJobExecutionId(BigDecimal jobExecutionId) {
		this.jobExecutionId = jobExecutionId;
	}

	public BigDecimal getJobInstanceId() {
		return jobInstanceId;
	}

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}
