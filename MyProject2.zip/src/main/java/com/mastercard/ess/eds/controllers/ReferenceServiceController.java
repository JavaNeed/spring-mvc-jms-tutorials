package com.mastercard.ess.eds.controllers;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mastercard.ess.eds.constant.ApplicationLiterals;
import com.mastercard.ess.eds.constant.ValidationParameter;
import com.mastercard.ess.eds.controllers.BaseController;
import com.mastercard.ess.eds.exceptions.EDSException;
import com.mastercard.ess.eds.request.ICAData;
import com.mastercard.ess.eds.response.ReferenceResponse;
import com.mastercard.ess.eds.service.ResourceHelper;

/**
 * @author e069468
 *
 */
@Api(value = ApplicationLiterals.REFERENCE_SERVICE, description = ApplicationLiterals.REFERENCE_SERVICE_DESCRIPTION)
@RestController
@Component
public class ReferenceServiceController extends BaseController {

	private static final Logger logger = LoggerFactory
			.getLogger(ReferenceServiceController.class);

	@Autowired
	private ResourceHelper resourceService;

	// for Junit
	public void setResourceService(ResourceHelper resourceService) {
		this.resourceService = resourceService;
	}

	/**
	 * This method is used to return list of countries, vendors and icas The
	 * output will be wrapped in ReferenceResponse object
	 * 
	 * @param resource
	 * @return *
	 * @throws EDSException
	 */
	
	@PreAuthorize("hasAnyRole(T(com.mastercard.ess.eds.constant.ApplicationLiterals).ROLE_EDS_RULE_ADMIN ,T(com.mastercard.ess.eds.constant.ApplicationLiterals).ROLE_EDS_CUST_ADMIN)")
	@ApiOperation(value = ApplicationLiterals.REFERENCE_SERVICE_RESPONSE)
	@RequestMapping(value = "/eds/v1/reference/{resource}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ReferenceResponse> getResource(
			@PathVariable("resource") String resource) throws EDSException {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter From Method : getResource");
		}

		Map<String, String> requestMap = new HashMap<String, String>();
		requestMap.put(ValidationParameter.RESOURCE, resource);
		validateParameters(requestMap);

		ReferenceResponse response = resourceService.getResource(resource);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit From Method : getResource");
		}
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	/**
	 * This method is used to return list of countries, vendors and icas The
	 * output will be wrapped in ReferenceResponse object
	 * 
	 * @param resource
	 * @return *
	 * @throws EDSException
	 */
	
	@PreAuthorize("hasAnyRole(T(com.mastercard.ess.eds.constant.ApplicationLiterals).ROLE_EDS_RULE_ADMIN ,T(com.mastercard.ess.eds.constant.ApplicationLiterals).ROLE_EDS_CUST_ADMIN)")
	@ApiOperation(value = ApplicationLiterals.REFERENCE_SERVICE_UNSIGNEDICA)
	@RequestMapping(value = "/eds/v1/reference/unsignedIca", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ICAData> getUnsignedIca(
			@RequestParam("ica") String ica) throws EDSException {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter From Method : getUnsignedIca");
		}

		Map<String, String> requestMap = new HashMap<String, String>();
		requestMap.put(ValidationParameter.ICA, ica);
		validateParameters(requestMap);

		ICAData icaData = resourceService.getUnsignedIca(ica);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit From Method : getUnsignedIca");
		}
		return new ResponseEntity<ICAData>(icaData, HttpStatus.OK);
	}

}
