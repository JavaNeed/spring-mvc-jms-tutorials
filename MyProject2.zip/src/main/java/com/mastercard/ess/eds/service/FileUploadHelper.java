package com.mastercard.ess.eds.service;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.mastercard.ess.eds.constant.CommonConstants;
import com.mastercard.ess.eds.constant.ErrorMessages;
import com.mastercard.ess.eds.dao.CountryListDAO;
import com.mastercard.ess.eds.exceptions.EDSException;
import com.mastercard.ess.eds.exceptions.EDSException.ExceptionType;
import com.mastercard.ess.eds.model.CPPRules;
import com.mastercard.ess.eds.model.Country;
import com.mastercard.ess.eds.response.FileUploadCPPErrorResponse;
import com.mastercard.ess.eds.response.FileUploadCPPResponse;
import com.mastercard.ess.eds.response.FileUploadCPPSuccessResponse;
import com.opencsv.CSVReader;

@Component
public class FileUploadHelper {

	private static final Logger logger = LoggerFactory
			.getLogger(FileUploadHelper.class);

	@Autowired
	private CountryListDAO countryListDAO;

	@Autowired
	private CPPRulesService cppRulesService;

	/**
	 * This method is to store new cpp rule in DB
	 * @param uploadFile - uploadFile contains the data containing in the file which was uploaded by user from UI
	 * @param request - request method is used here to get the user details
	 * @return - It returns with respone of successfully added rule Ids and the error description if any
	 * @throws EDSException
	 * @throws SQLException
	 */
	public FileUploadCPPResponse importAndSaveCPPRecordFromFile(MultipartFile uploadFile, HttpServletRequest request)
			throws EDSException, SQLException {
		FileUploadCPPResponse fileUploadResponse = new FileUploadCPPResponse();
		List<CPPRules> cppRulesList = new ArrayList();
		List<FileUploadCPPSuccessResponse> fileSuccessResponseList = new ArrayList();
		List<FileUploadCPPErrorResponse> errorResponseList = new ArrayList<FileUploadCPPErrorResponse>();
		Integer countrySize = countryListDAO.getCountryList().size() ;
		InputStream is = null;
		BufferedReader bfReader = null;
		List<CPPRules> resultList  = null;	
		try {
			is = new ByteArrayInputStream(uploadFile.getBytes());
			bfReader = new BufferedReader(new InputStreamReader(is));
			CSVReader reader = new CSVReader(bfReader, ',', '"', 1);

			String[] nextLine;
			int index = 0;
			while ((nextLine = reader.readNext()) != null) {
				index++;
				String message = validateRow(nextLine);
				if(message!=null){
					FileUploadCPPErrorResponse errResponse = new FileUploadCPPErrorResponse();
					errResponse.setErrorDescription(message);
					errResponse.setLine(index);
					errorResponseList.add(errResponse);
				}else{
					CPPRules cPPRules = populateCPPRuleFromCell(nextLine, countrySize);
					cPPRules.setLine(index);
					cppRulesList.add(cPPRules);
				}
			}

			if(!cppRulesList.isEmpty()){
				resultList = cppRulesService.saveOrUpdateRules(cppRulesList, request);
				if(!resultList.isEmpty()){
					for(CPPRules cppRule: resultList){
						FileUploadCPPSuccessResponse fileSuccessResponse = new FileUploadCPPSuccessResponse();
						fileSuccessResponse.setLine(cppRule.getLine());
						fileSuccessResponse.setRuleId(cppRule.getRuleId());
						fileSuccessResponse.setIsDuplicate(cppRule.getIsDuplicate());
						fileSuccessResponseList.add(fileSuccessResponse);
					}
				}
			}
			fileUploadResponse.setFileSuccessResponse(fileSuccessResponseList);
			fileUploadResponse.setFileErrorResponse(errorResponseList);
		} catch (IOException ex) {
			logger.error("Error occured while parsing the CSV file" + ex);
			throw new EDSException(ErrorMessages.FILE_PARSE_ERROR,
					ExceptionType.BUSINESS_EXCEPTION);
		}
		return fileUploadResponse;

	}

	/**
	 * @param nextLine - It is array variable and contains the data of every column of a single rule
	 * @param countrySize 
	 * @return - It sets all the data of a particular rule and return cpp object
	 * @throws EDSException
	 */
	private CPPRules populateCPPRuleFromCell(String[] nextLine, Integer countrySize)  throws EDSException{
		CPPRules cPPRules = new CPPRules();
		cPPRules.setLocationIdValue(new BigDecimal(nextLine[0]));

		if(StringUtils.isNotBlank(nextLine[1])){
			cPPRules.setIssuerCntryClause(nextLine[2]);
			Integer result = nextLine[1].split(",").length;
			if(countrySize.equals(result)){
				cPPRules.setIssuerCntryValue(CommonConstants.ALL);
			} else {
				cPPRules.setIssuerCntryValue(nextLine[1]);
			}
		}		

		if(StringUtils.isNotBlank(nextLine[3])){
			cPPRules.setLocalTxnAmountVal(new BigDecimal(nextLine[3]));
			cPPRules.setLocalTxnAmountClause(nextLine[4]);
		}


		cPPRules.setCategoryType(nextLine[5].toUpperCase());
		if(StringUtils.isNotBlank(nextLine[6])){
			cPPRules.setTimeValue(new BigDecimal(nextLine[6]));
			cPPRules.setTimeUnit(nextLine[7].toLowerCase());
		}else{
			cPPRules.setTimeValue(new BigDecimal(CommonConstants.NINTY));
			cPPRules.setTimeUnit(CommonConstants.DAYS);
		}

		cPPRules.setActiveSW(CommonConstants.PENDING_STATE);
		cPPRules.setLocationIdClause(CommonConstants.EQLS);
		return cPPRules;
	}



	/**
	 * @param nextLine - array of element of all column of a single cpp rule
	 * @return - used this method for validation and it return string which contains the error if any
	 */
	private String validateRow(String[] nextLine){

		String message = validateLocationValue(nextLine[0]);
		if(message!=null){
			return message ;
		}

		message = validateCountry(nextLine[1]);
		if(message!=null){
			return message ;
		}

		message = validateCountryCode(nextLine[2]);
		if(message!=null){
			return message ;
		}

		message = validateLocationTxnAmount(nextLine[3]);
		if(message!=null){
			return message ;
		}

		message = validateLocationTxnAmountCondition(nextLine[4]);
		if(message!=null){
			return message ;
		}

		message = validateCatogeryCode(nextLine[5]);
		if(message!=null){
			return message ;
		}

		message = validateTimeValue(nextLine[6]);
		if(message!=null){
			return message ;
		}

		message = validateTimeUnit(nextLine[7], nextLine[6]);
		if(message!=null){
			return message ;
		}

		return null;
	}

	private String validateLocationTxnAmountCondition(String amountCondition) {
		String message = null ;
		if(StringUtils.isNotBlank(amountCondition)){
			if(!StringUtils.equalsIgnoreCase(amountCondition, CommonConstants.EQLS) && !StringUtils.equalsIgnoreCase(amountCondition, CommonConstants.NOT_EQUALS)){
				message = ErrorMessages.AMOUNT_CONDITION_ERROR.getErrorMessage();
			}
		}
		return message;
	}

	private String validateCountryCode(String countryCondition) {
		String message = null ;
		if(StringUtils.isNotBlank(countryCondition)){
			if(!StringUtils.equalsIgnoreCase(countryCondition, CommonConstants.EQLS) && !StringUtils.equalsIgnoreCase(countryCondition, CommonConstants.OTHER) &&
					!StringUtils.equalsIgnoreCase(countryCondition, CommonConstants.ONE_OF) && !StringUtils.equalsIgnoreCase(countryCondition, CommonConstants.NOT_EQUALS)){
				message = ErrorMessages.COUNTRY_CONDITION_ERROR.getErrorMessage();
			}
		}
		return message;
	}

	private String validateLocationTxnAmount(String transactionAmount) {
		String message = null ;
		if(StringUtils.isNotBlank(transactionAmount)){
			if(!NumberUtils.isParsable(transactionAmount)){
				message = ErrorMessages.LOCATION_TXN_AMOUNT_NUMERIC_ERROR.getErrorMessage();
			}

			if(StringUtils.length(transactionAmount)>19){
				message = ErrorMessages.LOCATION_TXN_AMOUNT_LENGTH_ERROR.getErrorMessage();
			}
		}
		return message;
	}

	private String validateCountry(String countryCode) {
		String message = null ;
		if(StringUtils.isNotBlank(countryCode)){
			String[] result = countryCode.split(",");

			for(String country : result){
				List<Country> countryList = countryListDAO.getCountryCode(country);
				if(!CollectionUtils.isNotEmpty(countryList)){
					message = ErrorMessages.COUNTRY_CODE_NOT_FOUND_ERROR.getErrorMessage();
				}
			}

		}
		return message;
	}

	private String validateLocationValue(String locationValue) {
		String message = null ;
		if (StringUtils.isBlank(locationValue)) {
			message = ErrorMessages.LOCATION_ID_BLANK_ERROR.getErrorMessage();
		}else if(!StringUtils.isNumeric(locationValue)){
			message = ErrorMessages.LOCATION_ID_NUMERIC_ERROR.getErrorMessage();
		} else if ( StringUtils.length(locationValue) >9){
			message = ErrorMessages.LOCATION_ID_LENGTH_ERROR.getErrorMessage();
		} 
		return message;
	}


	private static String validateTimeValue(String timeValue){
		String message = null ;
		if(StringUtils.isNotBlank(timeValue)){
			if(!StringUtils.isNumeric(timeValue)){
				message = ErrorMessages.UNIT_VALUE_NUMERIC_ERROR.getErrorMessage();
			}
		}
		return message;
	}

	private String validateTimeUnit(String timeUnit, String timeValue){
		String message = null ;
		Integer value = Integer.parseInt(timeValue);
		if(StringUtils.isNotBlank(timeUnit)){
			if(!StringUtils.equalsIgnoreCase(timeUnit, CommonConstants.DAYS) && !StringUtils.equalsIgnoreCase(timeUnit, CommonConstants.MONTHS) &&
					!StringUtils.equalsIgnoreCase(timeUnit, CommonConstants.WEEKS)){
				message = ErrorMessages.UNIT_TIME_ERROR.getErrorMessage();
			}

			if(!(StringUtils.equalsIgnoreCase(timeUnit, CommonConstants.DAYS) && value <= 366) && !(StringUtils.equalsIgnoreCase(timeUnit, CommonConstants.MONTHS) && value <= 12)&&
					!(StringUtils.equalsIgnoreCase(timeUnit, CommonConstants.WEEKS)&& value <= 52)){
				message = ErrorMessages.TIME_VALUE_RANGE_ERROR.getErrorMessage();
			}
		}
		return message;
	}

	private String validateCatogeryCode(String catogeryCode){
		String message = null ;
		if(StringUtils.isNotBlank(catogeryCode)){
			if(!StringUtils.equals(catogeryCode, CommonConstants.E) && !StringUtils.equals(catogeryCode, CommonConstants.I) ){
				message = ErrorMessages.CATOGERY_CODE_ERROR.getErrorMessage();
			}
		} else{
			message = ErrorMessages.CATEGORY_CODE_BLANK_ERROR.getErrorMessage();
		}
		return message;
	}

	/**
	 * This method is used to read the data in file and put cppId List and to pass it to service layer for DB operation
	 * @param uploadFile - uploadFile contains file with list of cppId's which we are going to pass to DAO class
	 * @return - we are returning the file upload response object which contains the detail of all the cppId's present in uploaded file
	 * @throws EDSException
	 */
	public FileUploadCPPResponse viewCPPRules(
			MultipartFile uploadFile, String chunk) throws EDSException {
		FileUploadCPPResponse fileUploadResponse = new FileUploadCPPResponse();
		List<FileUploadCPPSuccessResponse> fileSuccRespList = new ArrayList<FileUploadCPPSuccessResponse>();
		List<FileUploadCPPErrorResponse> fileErrRespList = new ArrayList<FileUploadCPPErrorResponse>();
		List<Integer> cppIdList = new ArrayList<>();
		InputStream is = null;
		BufferedReader bfReader = null;
		try {
			is = new ByteArrayInputStream(uploadFile.getBytes());
			bfReader = new BufferedReader(new InputStreamReader(is));
			CSVReader reader = new CSVReader(bfReader);
			String[] nextLine;
			FileUploadCPPSuccessResponse successResponse = null;
			Map<Integer, Integer> map = new HashMap<>();
			int line = 0;
			boolean validHeader = true;
			while ((nextLine = reader.readNext()) != null) {
				line++;
				String cppId = nextLine[0];

				if(line>1){
					if(StringUtils.isBlank(cppId)){
						setErrorMessage(fileErrRespList, line, ErrorMessages.EMPTY_RULE_ID.getErrorMessage(), "");
					} else if (!StringUtils.isNumeric(cppId)) {
						setErrorMessage(fileErrRespList, line, ErrorMessages.RULE_ID_NOT_NUMERIC.getErrorMessage(), cppId);
					} else {
						cppIdList.add(Integer.valueOf(cppId));
						map.put(line, Integer.valueOf(cppId));
					}
				} else {
					if(!CommonConstants.DELETE_CPP_HEADER.equalsIgnoreCase(cppId.trim())){
						setErrorMessage(fileErrRespList, line, ErrorMessages.INVALID_HEADER.getErrorMessage(), cppId);
						validHeader = false;
						break;
					}
				}
			}
			if(validHeader){
				List<Integer> cppIds = new ArrayList<Integer>();
				Set<Integer> dup = new HashSet<Integer>();
				List<CPPRules> cppRules = cppRulesService.viewCPPRuleList(cppIdList);
				Integer chunkSize = Integer.parseInt(chunk);
				Integer cppRulesSize = cppRules.size();

				for(int index=0; index<cppRulesSize; index++){
					cppIds.add(cppRules.get(index).getRuleId());
				}

				for(Integer ruleId : cppIdList){
					Integer lineNo = 0;
					boolean dupExists = false;
					for(Entry<Integer, Integer> errDesc : map.entrySet()) {
						if(String.valueOf(ruleId).equals(String.valueOf(errDesc.getValue()))) {
							lineNo = errDesc.getKey();
							break;
						}
					}

					if(!dup.add(ruleId)){
						dupExists = true;
					}
					if(!cppIds.contains(ruleId)) {
						setErrorMessage(fileErrRespList, lineNo, ErrorMessages.RULE_ID_NOT_EXISTS.getErrorMessage(), String.valueOf(ruleId));
					} else if(dupExists) {
						setErrorMessage(fileErrRespList, lineNo, ErrorMessages.DUPLICATE_ENTRY_FOUND.getErrorMessage(), String.valueOf(ruleId));
					}
					map.remove(lineNo);
				}
				Integer errorResp = fileErrRespList.size();

				Integer cz = chunkSize - errorResp;
				Integer startLimit = 0;
				successResponse = new FileUploadCPPSuccessResponse();
				if(cppRulesSize > 0 && cz > 0){
					successResponse.setCppRules(cppRules.subList(0, cz < cppRulesSize ? cz : cppRulesSize));
					startLimit = cz;
				}
				if(cppRulesSize > cz){
					successResponse.setCppArray(cppIds.subList(startLimit, cppIds.size()).toArray(new Integer[cppIds.size()-startLimit]));
				}
				fileSuccRespList.add(successResponse);
			}

			fileUploadResponse.setFileErrorResponse(fileErrRespList);
			fileUploadResponse.setFileSuccessResponse(fileSuccRespList);

		} catch (IOException ex) {
			ex.printStackTrace();
			logger.error("Error occured while parsing the CSV file" + ex);
			throw new EDSException(ErrorMessages.FILE_PARSE_ERROR,
					ExceptionType.BUSINESS_EXCEPTION);
		}
		return fileUploadResponse;

	}

	/**
	 * @param fileErrRespList - this object contains the list of incorrect cppId's
	 * @param line - contains the incorrect cppId's line number
	 * @param errorMsg - incorrect cppId's error description
	 * @param ruleId 
	 */
	private void setErrorMessage(List<FileUploadCPPErrorResponse> fileErrRespList, int line, String errorMsg, String ruleId) {
		FileUploadCPPErrorResponse errorResponse = new FileUploadCPPErrorResponse();
		errorResponse.setLine(line);
		errorResponse.setErrorDescription(errorMsg);
		errorResponse.setRuleId(ruleId);
		fileErrRespList.add(errorResponse);
	}
}
