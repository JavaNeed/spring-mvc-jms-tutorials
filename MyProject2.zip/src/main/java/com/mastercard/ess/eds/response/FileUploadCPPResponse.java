package com.mastercard.ess.eds.response;

import java.util.List;

public class FileUploadCPPResponse {
	
	private List<FileUploadCPPSuccessResponse> fileSuccessResponse;
	private List<FileUploadCPPErrorResponse> fileErrorResponse;
	
	 
	public List<FileUploadCPPSuccessResponse> getFileSuccessResponse() {
		return fileSuccessResponse;
	}
	public void setFileSuccessResponse(List<FileUploadCPPSuccessResponse> fileSuccessResponse) {
		this.fileSuccessResponse = fileSuccessResponse;
	}
	public List<FileUploadCPPErrorResponse> getFileErrorResponse() {
		return fileErrorResponse;
	}
	public void setFileErrorResponse(List<FileUploadCPPErrorResponse> fileErrorResponse) {
		this.fileErrorResponse = fileErrorResponse; 
	}
	

}
