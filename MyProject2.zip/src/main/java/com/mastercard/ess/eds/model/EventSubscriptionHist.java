package com.mastercard.ess.eds.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity // entity should be created via "new" and not injected as spring bean
@Table(name = "EDS_EVENT_SUBSC_HIST", schema = "EDS_OWNER")
public class EventSubscriptionHist implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="EDS_EVENT_SUBSC_HIST_ID",unique=true,nullable=false)
	@SequenceGenerator(name = "seq", sequenceName = "EDS_EVENT_SUBSC_HIST_ID_SEQ")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	private Integer evntSubsHistId;
	
	@Column(name="EDS_EVENT_SUBSC_ID")
	private Integer eventSubsId;
	
	@Column(name="EVENT_ID")
	private Integer eventId;
	
	@Column(name="EMAIL_ID")
	private String emailId;
	
	@Column(name="ORG_NAM")
	private String orgName;
	
	@Column(name="ENBL_SW")
	private String enabledSW;
	
	@Column(name="LST_UPDT_DT")
	private Date lstUpdtdt;
	
	@Column(name="LST_UPDT_USER_ID")
	private String lstUpdtUserId;
	
	@Column(name="ICA_NUM")
	private Integer ica;
	
	@Column(name="CRTE_DT")
	private Date createDate;
	
	@Column(name="CRTE_USER_ID")
	private String createUserId;
	
	@Column(name="EDS_SRC_TYPE_ID")
	private Integer edsSourceTypeId;
	
	@Column(name="HIST_CRTE_DT")
	private Date histCrteDt;

	public Integer getEvntSubsHistId() {
		return evntSubsHistId;
	}

	public void setEvntSubsHistId(Integer evntSubsHistId) {
		this.evntSubsHistId = evntSubsHistId;
	}

	public Integer getEventSubsId() {
		return eventSubsId;
	}

	public void setEventSubsId(Integer eventSubsId) {
		this.eventSubsId = eventSubsId;
	}

	public Integer getEventId() {
		return eventId;
	}

	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getEnabledSW() {
		return enabledSW;
	}

	public void setEnabledSW(String enabledSW) {
		this.enabledSW = enabledSW;
	}

	public Date getLstUpdtdt() {
		return lstUpdtdt;
	}

	public void setLstUpdtdt(Date lstUpdtdt) {
		this.lstUpdtdt = lstUpdtdt;
	}

	public String getLstUpdtUserId() {
		return lstUpdtUserId;
	}

	public void setLstUpdtUserId(String lstUpdtUserId) {
		this.lstUpdtUserId = lstUpdtUserId;
	}

	public Integer getIca() {
		return ica;
	}

	public void setIca(Integer ica) {
		this.ica = ica;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Integer getEdsSourceTypeId() {
		return edsSourceTypeId;
	}

	public void setEdsSourceTypeId(Integer edsSourceTypeId) {
		this.edsSourceTypeId = edsSourceTypeId;
	}

	public Date getHistCrteDt() {
		return histCrteDt;
	}

	public void setHistCrteDt(Date histCrteDt) {
		this.histCrteDt = histCrteDt;
	}

}
