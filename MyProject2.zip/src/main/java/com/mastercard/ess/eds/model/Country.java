package com.mastercard.ess.eds.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TGPACYD", schema = "EDS_OWNER")
public class Country {

	@Id
	@Column(name = "NUM_CNTRY_CD")
	private String cntryCode;
	@Column(name = "ALPHA2_CD")
	private String alpha2Code;
	@Column(name = "ALPHA3_CD")
	private String alpha3Code;
	@Column(name = "CNTRY_NAM")
	private String cntryName;

	/**
	 * @return the cntryCode
	 */
	public String getCntryCode() {
		return cntryCode;
	}

	/**
	 * @param cntryCode
	 *            the cntryCode to set
	 */
	public void setCntryCode(String cntryCode) {
		this.cntryCode = cntryCode;
	}

	/**
	 * @return the alpha2Code
	 */
	public String getAlpha2Code() {
		return alpha2Code;
	}

	/**
	 * @param alpha2Code
	 *            the alpha2Code to set
	 */
	public void setAlpha2Code(String alpha2Code) {
		this.alpha2Code = alpha2Code;
	}

	/**
	 * @return the alpha3Code
	 */
	public String getAlpha3Code() {
		return alpha3Code;
	}

	/**
	 * @param alpha3Code
	 *            the alpha3Code to set
	 */
	public void setAlpha3Code(String alpha3Code) {
		this.alpha3Code = alpha3Code;
	}

	/**
	 * @return the cntryName
	 */
	public String getCntryName() {
		return cntryName;
	}

	/**
	 * @param cntryName
	 *            the cntryName to set
	 */
	public void setCntryName(String cntryName) {
		this.cntryName = cntryName;
	}

}
