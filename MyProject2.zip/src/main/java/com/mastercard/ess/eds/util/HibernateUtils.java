package com.mastercard.ess.eds.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HibernateUtils {

	private static volatile SessionFactory sessionFactory;
	private static final Logger logger = LoggerFactory.getLogger(HibernateUtils.class);
	
	private HibernateUtils(){
    	super();
    }
	public static SessionFactory getSessionFactory() {
		try{
        if (sessionFactory == null) {
        	if (logger.isDebugEnabled()) {
    			logger.debug("Enter In Method : getSessionFactory");
    		}
            AnnotationConfiguration configuration = new AnnotationConfiguration();
            configuration = configuration.configure("hibernate.cfg.xml");
            sessionFactory = configuration.buildSessionFactory();           
        } }
		catch(Exception e){
			e.printStackTrace();
			logger.error("Exception Occured in HibernateUtil",e);
		}
        
        return sessionFactory;
    }
}
