package com.mastercard.ess.eds.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.mastercard.ess.eds.constant.ApplicationLiterals;
import com.mastercard.ess.eds.response.ErrorResponse;

@ControllerAdvice
public class ExceptionController {

	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponse> exceptionHandler(Exception ex) {

		ErrorResponse response = new ErrorResponse();
		if (ex instanceof EDSException) {
			switch (((EDSException) ex).getExceptionType()) {
			case VALIDATION_EXCEPTION:
				response.setErrorCode(((EDSException) ex).getErrorCode());
				response.setErrorMessage(ex.getMessage());
				return new ResponseEntity<ErrorResponse>(response,HttpStatus.PRECONDITION_FAILED);
			case BUSINESS_EXCEPTION:
				response.setErrorCode(((EDSException) ex).getErrorCode());
				response.setErrorMessage(ex.getMessage());
				return new ResponseEntity<ErrorResponse>(response,HttpStatus.NOT_FOUND);
			case AUTHORIZATION_EXCEPTION:
				response.setErrorCode(((EDSException) ex).getErrorCode());
				response.setErrorMessage(ex.getMessage());
				return new ResponseEntity<ErrorResponse>(response,HttpStatus.UNAUTHORIZED);
            default:
                response.setErrorCode(((EDSException) ex).getErrorCode());
                response.setErrorMessage(ex.getMessage());
                return new ResponseEntity<ErrorResponse>(response,HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else if (ex instanceof MissingServletRequestParameterException) {
			response.setErrorMessage(ex.getMessage());
			return new ResponseEntity<ErrorResponse>(response,HttpStatus.BAD_REQUEST);
		} else if (ex instanceof HttpRequestMethodNotSupportedException) {
			response.setErrorMessage(ex.getMessage());
			return new ResponseEntity<ErrorResponse>(response,HttpStatus.METHOD_NOT_ALLOWED);
		}

		response.setErrorMessage(ApplicationLiterals.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<ErrorResponse>(response,HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
