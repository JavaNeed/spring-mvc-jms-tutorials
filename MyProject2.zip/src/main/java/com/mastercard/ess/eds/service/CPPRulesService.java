package com.mastercard.ess.eds.service;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.constant.CommonConstants;
import com.mastercard.ess.eds.dao.CPPRulesDAO;
import com.mastercard.ess.eds.dao.JobExecutionDAO;
import com.mastercard.ess.eds.exceptions.EDSException;
import com.mastercard.ess.eds.model.CPPRules;
import com.mastercard.ess.eds.request.SearchRequest;
import com.mastercard.ess.eds.response.SearchResponse;

/**
 *This class is used for calling the DAO classes for saveOrUpdateRules and getRules.
 *The result of the methods is sent back to Controller class.. 
 *
 *@author e066879	
 *@since 22-02-2017
 */

@Component
public class CPPRulesService {

	private static final Logger logger = LoggerFactory.getLogger(CPPRulesService.class);

	@Autowired
	CPPRulesDAO cppRulesDAO;
	
	@Autowired
	JobExecutionDAO jobExecutionDAO;

	//for Junit
	public void setCPPRulesService(CPPRulesDAO cppRulesDAO) {
		this.cppRulesDAO = cppRulesDAO;
	}

	/**
	 * This method call DAO layer.
	 * This method pass the request object to DAO layer and get the rules.	
	 * @throws SQLException 
	 */

	public SearchResponse getRules(SearchRequest searchRequest){

		if(logger.isDebugEnabled()){
			logger.debug("Enter In Method : getRules");
		}		


		SearchResponse searchResponse  = cppRulesDAO.getRules(searchRequest);

		if(logger.isDebugEnabled()){
			logger.debug("Exit from Method : getRules");
		}

		return searchResponse;
	}

	/**
	 * This method call DAO layer.
	 * This method pass the request object to DAO layer and save and update the rules.
	 * @param listUserRules	
	 * @return 
	 * @throws SQLException 
	 */


	public List<CPPRules> saveOrUpdateRules(List<CPPRules> listUserRules, HttpServletRequest request) throws SQLException {
		if(logger.isDebugEnabled()){
			logger.debug("Enter In Method : saveOrUpdateRules");
		}

		List<CPPRules> result = cppRulesDAO.saveOrUpdateRules(listUserRules , request);

		if(logger.isDebugEnabled()){
			logger.debug("Exit From Method : saveOrUpdateRules");
		}

		return result;

	}	

	/**
	 * @param cppIds
	 * @return
	 * @throws SQLException
	 */
	public List<CPPRules> fetchCPPRules(List<Integer> cppIds) throws SQLException {

		List<CPPRules> list = null;
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : CPPRulesService - fetchCPPRules");
		}

		list = cppRulesDAO.fetchCPPRules(cppIds);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : CPPRulesService - fetchCPPRules");
		}
		return list;
	}

	/**
	 * This method call DAO layer.
	 * This method pass the request object to DAO layer and deactivate the rules.
	 * @param cppIdList - list of cppId's to be deactivated
	 * @param lastUpdatedUserId - contains userId to be updated in cpp rule table
	 * @return
	 */
	public List<CPPRules> viewCPPRuleList(List<Integer> cppIdList) {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : CPPRulesService - viewCPPRuleList");
		}

		List<CPPRules> cppList = cppRulesDAO.viewCPPRules(cppIdList);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : CPPRulesService - viewCPPRuleList");
		}
		return cppList;
	}

	/**
	 * This method used to call dao layer
	 * @param cppIds - To update the status of the list of cppIds
	 * @param lastUpdatedUserId - to update the last updated user Id
	 * @param ruleStatus - contains the status value
	 * @return - return the count of updated rules.
	 */
	public String updateRuleStatus(List<Integer> cppIds, String lastUpdatedUserId, String ruleStatus) throws EDSException {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : CPPRulesService - updateRuleStatus");
		}

		if(CommonConstants.YES.equals(ruleStatus)){
			String status = jobExecutionDAO.getJobRunningStatus();
			if(StringUtils.isNotBlank(status)&&!(CommonConstants.COMPLETED.equals(status) || CommonConstants.FAILED.equals(status) || CommonConstants.UNKNOWN.equals(status) || CommonConstants.STOPPED.equals(status))) {
				return "error";
			}
		}

		Integer result = cppRulesDAO.updateRuleStatus(cppIds, lastUpdatedUserId, ruleStatus);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : CPPRulesService - updateRuleStatus");
		}
		return String.valueOf(result);
	}

	public Integer getRuleCount(String ruleStatus) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : CPPRulesService - getRuleCount");
		}

		Integer result = cppRulesDAO.getRuleCount(ruleStatus);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : CPPRulesService - getRuleCount");
		}
		return result;
	}
	
	public String updateRuleStatusWithFlag(List<Integer> cppIds,
			String lastUpdatedUserId, String ruleStatus) throws EDSException {

		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : CPPRulesService - updateRuleStatusWithFlag");
		}
		
		if(CommonConstants.YES.equals(ruleStatus)){
			String status = jobExecutionDAO.getJobRunningStatus();
			if(StringUtils.isNotBlank(status)&&!(CommonConstants.COMPLETED.equals(status) || CommonConstants.FAILED.equals(status) || CommonConstants.UNKNOWN.equals(status) || CommonConstants.STOPPED.equals(status))) {
				return "error";
			}
		}

		Integer result = cppRulesDAO.updateRuleStatusWithFlag(cppIds, lastUpdatedUserId, ruleStatus);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : CPPRulesService - updateRuleStatusWithFlag");
		}
		return String.valueOf(result);
	}
}
