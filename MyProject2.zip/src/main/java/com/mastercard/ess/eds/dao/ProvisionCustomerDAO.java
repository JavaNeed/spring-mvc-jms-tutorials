package com.mastercard.ess.eds.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.constant.CommonConstants;
import com.mastercard.ess.eds.model.EDSCustMaster;
import com.mastercard.ess.eds.request.ProvisionCustomerData;
import com.mastercard.ess.eds.request.ProvisionCustomerRequest;
import com.mastercard.ess.eds.request.SearchCriteria;
import com.mastercard.ess.eds.response.ProvisionCustomerResponse;
import com.mastercard.ess.eds.util.HibernateUtils;
import com.mastercard.ess.eds.util.SortingCriteria;

@Component
public class ProvisionCustomerDAO {

	private static final Logger logger = LoggerFactory.getLogger(ProvisionCustomerDAO.class);

	private static final String DELETE_ICA_DATA = "DELETE FROM com.mastercard.ess.eds.model.BillICALimit WHERE icaNum= :icaNum and billYear= :billYear";
	private static final String DELETE_EVENT_SUBSC_FOR_ICA = "DELETE FROM com.mastercard.ess.eds.model.EventSubscription WHERE ica = :icaNum";

	private static final String DEFAULT_NOTIFICATION_MAIL = "defaultNotficationEmail";
	private static final String END_POINT = "endPoint";
	private static final String BULK_ID = "bulkId";
	private static final String ICA_NUM = "icaNum";

	private static final String UPDATE_CUSTOMER_EVENT = "update com.mastercard.ess.eds.model.EDSCustMaster custMaster "
			+ " set custMaster.defaultNotficationEmail=:defaultNotficationEmail,  "
			+ " custMaster.endPoint=:endPoint, "
			+ " custMaster.bulkId=:bulkId, "
			+ " custMaster.lastUpdtUserId=:lastUpdatedUserId, "
			+ " custMaster.lastUpdtDate=:lastUpdatedDate "
			+ " where custMaster.icaNum=:icaNum";

	public ProvisionCustomerResponse getProvisionCustomerData(
			ProvisionCustomerRequest provisionCustReq) {
		ProvisionCustomerResponse provisionCustResp = new ProvisionCustomerResponse();
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : displayProvisionCustomer");
		}

		SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Criteria crt = session.createCriteria(EDSCustMaster.class);

		SearchCriteria searchCriteria = provisionCustReq.getSearchCriteria();
		setSearchCriteria(crt, searchCriteria);
		crt.add(Restrictions.eq(CommonConstants.IS_ACTIVE_SWITCH, CommonConstants.YES));
		crt.createAlias(CommonConstants.EDS_MEMBER_HIER, CommonConstants.MEMBER_HIER_ALIAS, CriteriaSpecification.LEFT_JOIN);

		setSortingCriteria(provisionCustReq, crt);
		List<EDSCustMaster> mstr = crt.list();
		List<ProvisionCustomerData> custDataList = new ArrayList<>();
		if(provisionCustReq.getChunk() == null){
			provisionCustReq.setChunk(CommonConstants.DEF_CHUNK_MIN_VAL);
		} 
		if(provisionCustReq.getChunkSize() == null){
			provisionCustReq.setChunkSize(CommonConstants.DEF_CHUNK_MAX_VAL);
		}

		int startLimit = (provisionCustReq.getChunk() - 1) * provisionCustReq.getChunkSize();
		int endLimit = provisionCustReq.getChunkSize() * provisionCustReq.getChunk();

		if(endLimit>mstr.size()){
			endLimit = mstr.size();
		}
		if(startLimit<endLimit){
			for(int i=startLimit; i<endLimit; i++){
				populateProvisionCustomerData(mstr, custDataList, i);
			}
		}
		provisionCustResp.setChunk(provisionCustReq.getChunk());
		provisionCustResp.setChunkSize(provisionCustReq.getChunkSize());
		provisionCustResp.setProvisionCustomerData(custDataList);
		provisionCustResp.setTotalCount(mstr.size());

		transaction.commit();
		session.close();
		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : displayProvisionCustomer");
		}

		return provisionCustResp;
	}

	private void setSearchCriteria(Criteria crt, SearchCriteria searchCriteria) {
		if(searchCriteria != null){
			if(null!=searchCriteria.getIca()){
				crt.add(Restrictions.eq(CommonConstants.ICA_NUM, searchCriteria.getIca()));
			}
			if(null!=searchCriteria.getBulkid()){
				crt.add(Restrictions.eq(CommonConstants.BULK_ID, searchCriteria.getBulkid()));
			}
			if(null!=searchCriteria.getEmailId()){
				crt.add(Restrictions.eq(CommonConstants.DEFAULT_NOTIFICATION_MAIL, searchCriteria.getEmailId()));
			}
			if(null!=searchCriteria.getEndPoint()){
				crt.add(Restrictions.eq(CommonConstants.END_POINT, searchCriteria.getEndPoint()).ignoreCase());
			}
			if(null!=searchCriteria.getOrgName()){
				crt.add(Restrictions.ilike(CommonConstants.CUST_NAME, CommonConstants.CONCATE + searchCriteria.getOrgName() + CommonConstants.CONCATE));
			}

		}

	}

	private void setSortingCriteria(ProvisionCustomerRequest provisionCustReq,
			Criteria crt) {
		SortingCriteria sc = provisionCustReq.getSort();
		if(sc != null){
			if(CommonConstants.SORT_ASCENDING.equalsIgnoreCase(sc.getSortOrder())){
				crt.addOrder(Order.asc(sc.getSortBy()).ignoreCase())	;
			} else if(CommonConstants.SORT_DESCENDING.equalsIgnoreCase(sc.getSortOrder())){
				crt.addOrder(Order.desc(sc.getSortBy()).ignoreCase());
			}
		}
	}

	private void populateProvisionCustomerData(List<EDSCustMaster> mstr,
			List<ProvisionCustomerData> custDataList, int i) {
		ProvisionCustomerData provisionCustData = new ProvisionCustomerData();
		provisionCustData.setEdsCustMasterId(mstr.get(i).getCustMstrId());
		provisionCustData.setIca(mstr.get(i).getIcaNum());
		provisionCustData.setBulkId(mstr.get(i).getBulkId());
		provisionCustData.setCreatedDate(mstr.get(i).getCreatedDate());
		provisionCustData.setDefaultNotficationEmail(mstr.get(i).getDefaultNotficationEmail());
		provisionCustData.setEndPoint(mstr.get(i).getEndPoint());
		provisionCustData.setRenewalDate(mstr.get(i).getRenewalDate());
		provisionCustData.setIsActiveSW(mstr.get(i).getIsActivSW());
		if(mstr.get(i).getEdsMemberHier() != null){
			provisionCustData.setIcaDescription(mstr.get(i).getEdsMemberHier().getAccessName());
		}
		custDataList.add(provisionCustData);
	}

	public ProvisionCustomerData saveProvisionCustomer(
			ProvisionCustomerData provisionCustomerData, HttpServletRequest request) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : saveProvisionCustomer");
		}
		SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
		Session session  = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		if(null!= provisionCustomerData){
			boolean isDuplicate = checkForDuplicate(provisionCustomerData, session);
			if(!isDuplicate)
			{
				EDSCustMaster eDSCustMaster = mapProvisionCustomerDataToEDSCustMaster(provisionCustomerData,request);
				session.save(eDSCustMaster);
			}
			else {
				provisionCustomerData.setDuplicate(true);
			}

		}		
		tr.commit();
		session.close();

		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : saveProvisionCustomer");
		}

		return provisionCustomerData;
	}

	public int editProvisionCustomer(ProvisionCustomerData provisionCustomerData, HttpServletRequest request) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : editProvisionCustomer");
		}
		SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
		Session session  = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		int updateStatus = 0;
		if(null != provisionCustomerData){
			Query query = session.createQuery(UPDATE_CUSTOMER_EVENT);
			query.setParameter(DEFAULT_NOTIFICATION_MAIL, provisionCustomerData.getDefaultNotficationEmail());
			query.setParameter(END_POINT, provisionCustomerData.getEndPoint());
			query.setParameter(BULK_ID, provisionCustomerData.getBulkId());
			query.setParameter(CommonConstants.LAST_UPDATED_USER_ID, request.getHeader("userId"));
			query.setParameter(CommonConstants.LAST_UPDATED_DATE, new Date());
			query.setParameter(ICA_NUM, provisionCustomerData.getIca());
			updateStatus = query.executeUpdate();
		}		
		tr.commit();
		session.close();

		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : editProvisionCustomer");
		}

		return updateStatus;
	}

	private boolean checkForDuplicate(ProvisionCustomerData provisionCustomerData, Session session) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : checkForDuplicate");
		}
		boolean isDuplicate = false;
		Criteria provisionCriteria = session.createCriteria(EDSCustMaster.class);
		provisionCriteria.add(Restrictions.eq(CommonConstants.ICA_NUM, provisionCustomerData.getIca()));
		provisionCriteria.add(Restrictions.eq(CommonConstants.IS_ACTIVE_SWITCH, CommonConstants.YES));

		List<EDSCustMaster> duplicateCustomer = provisionCriteria.list();

		if(duplicateCustomer!=null && !duplicateCustomer.isEmpty() )
		{
			logger.info("duplicateCustomer" + duplicateCustomer.size());
			isDuplicate = true;
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : checkForDuplicate");
		}

		return isDuplicate;
	}

	private EDSCustMaster mapProvisionCustomerDataToEDSCustMaster(ProvisionCustomerData provisionCustomerData, HttpServletRequest request) {
		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : mapProvisionCustomerDataToEDSCustMaster");
		}
		EDSCustMaster  eDSCustMaster= new EDSCustMaster();

		eDSCustMaster.setIcaNum(provisionCustomerData.getIca());
		eDSCustMaster.setCustName(provisionCustomerData.getIcaDescription());
		eDSCustMaster.setEndPoint(provisionCustomerData.getEndPoint());
		eDSCustMaster.setCustTypeCd(CommonConstants.CUSTOMER_TYPE_ISSUER);
		eDSCustMaster.setDefaultNotficationEmail(provisionCustomerData.getDefaultNotficationEmail());
		eDSCustMaster.setBulkId(String.valueOf(provisionCustomerData.getBulkId()));
		eDSCustMaster.setIsActivSW(CommonConstants.YES);
		eDSCustMaster.setIsSilentSW(CommonConstants.NO);
		eDSCustMaster.setCreatedDate(new Date());
		eDSCustMaster.setCreateUserId(request.getHeader("userId"));

		if (logger.isDebugEnabled()) {
			logger.debug("Exit In Method : mapProvisionCustomerDataToEDSCustMaster");
		}
		return eDSCustMaster;

	}

	/**
	 * Method will de-provision customers and will delete event subscription for inputed ICA.
	 * @param custIds
	 * @param userId
	 */
	public void deleteProvisionCustomer(List<Integer> custIds, String userId) {
		logger.info("Start method : deleteProvisionCustomer ");

		SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();

		for(Integer custId : custIds){
			Criteria crt = session.createCriteria(EDSCustMaster.class);
			crt.add(Restrictions.eq(CommonConstants.CUSTOMER_MASTER_ID, custId));
			List<EDSCustMaster> customerList = crt.list();
			if(CollectionUtils.isNotEmpty(customerList)){
				EDSCustMaster custmaster = customerList.get(0);
				custmaster.setIsActivSW(CommonConstants.NO);
				custmaster.setOptOutDt(new Date());
				custmaster.setLastUpdtUserId(userId);
				custmaster.setLastUpdtDate(new Date());
				session.update(custmaster);

				Query query = session.createQuery(DELETE_ICA_DATA);
				SimpleDateFormat sdf = new SimpleDateFormat(CommonConstants.YYYY);
				query.setParameter(CommonConstants.YEAR, sdf.format(new Date()));
				query.setParameter(CommonConstants.ICA_NUM, custmaster.getIcaNum());
				query.executeUpdate();
			
				logger.info("Going to delete event subscription for ICA = " +custmaster.getIcaNum() + " For custMstrId = " + custmaster.getCustMstrId() );
				
				Query deleteEventSubscQuery = session.createQuery(DELETE_EVENT_SUBSC_FOR_ICA);
				deleteEventSubscQuery.setParameter( ICA_NUM ,  custmaster.getIcaNum() );
				int result = deleteEventSubscQuery.executeUpdate();

				if (result > 0) {
					logger.info(" Deleted Event subscription for ica =  " + result + " ICA = " + custmaster.getIcaNum() );
				}				
			}
		}
		transaction.commit();
		session.close();
		logger.info("End method : deleteProvisionCustomer ");

	}
}
