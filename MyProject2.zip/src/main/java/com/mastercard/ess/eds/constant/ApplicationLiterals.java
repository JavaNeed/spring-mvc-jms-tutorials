package com.mastercard.ess.eds.constant;

public final class ApplicationLiterals {



    private ApplicationLiterals(){
		//Sonar gives issue.
	}
	
    //Service Description
    
    public static final String COUNTRY_LIST_SERVICE = "Country Service";
    public static final String COUNTRY_LIST_SERVICE_DESCRIPTION = "This service provides numeric and alphanumeric country codes";
	public static final String COUNTRY_LIST_DETAILS ="This service will provide list of countries with their codes";	
	
	public static final String CPP_RULES_SERVICE = "CPP Rule Service";
	public static final String CPP_RULES_SERVICE_DESCRIPTION = "This service will save, update and get cpp rule details";
	public static final String CPP_RULES_SAVE = "This service will save cpp rules";
	public static final String CPP_RULES_SEARCH = "This service will list all the CPP rules for given search criteria";
	public static final String CPP_RULES_UPDATE_STATUS = "This service will update the status of CPP rules";
	public static final String CPP_RULES_VIEW = "This service is use to view cpp rule to get confirmation from user to deactivate";
	public static final String CPP_RULES_COUNT = "This service is use to get the cpp rules count based on particular status";
	
    public static final String REFERENCE_SERVICE = "Reference Service";
    public static final String REFERENCE_SERVICE_DESCRIPTION = "This service will return static system data";
	public static final String REFERENCE_SERVICE_RESPONSE = "This method is used to return list of countries, vendors and icas";
	public static final String REFERENCE_SERVICE_UNSIGNEDICA = "This method is used to return list of Unsigned ICAs";
	
	public static final String EVENT_SERVICE = "Event Service";
	public static final String EVENT_SERVICE_DESCRIPTION = "This service provides event details";
	public static final String EVENT_SERVICE_LIST = "This method will get list of system events" ;
	
	public static final String EVENT_SUBS_SERVICE = "Event Subscription Service";
	public static final String EVENT_SUBS_SERVICE_DESCRIPTION = "This service saves and gets the event subscription details";
	public static final String EVENT_SUBS_SAVE  = "This service is used to save event subscriptions";
	public static final String EVENT_SUBS_DISPLAY = "This service gets list of event subscriptions";
	public static final String EVENT_SUBS_DELETE = "This service deletes event subscriptions";
	public static final String CUST_SERVICE = "Customer Service";
	public static final String CUST_SERVICE_DESCRIPTION = "This service gets and saves customer details";
	public static final String CUST_SERVICE_SAVE = "This service will save customer details";	
	public static final String CUST_SERVICE_DISPLAY = "This service will get list of provisioned customers" ;
	public static final String CUST_SERVICE_DELETE = "This service will delete on boarded customer";	
	public static final String CUST_SERVICE_EDIT = "This service will edit on-boarded customer";
	
	public static final String AUTH_SERVICE = "Authentication Service";
	public static final String AUTH_SERVICE_DESCRIPTION = "This service gets the user details from SAML";
	public static final String AUTH_SERVICE_USER = "This service gets the user details like name, id and roles from SAML";	
 
    //Header Constants
	public static final String HEADER = "Header";
	public static final String USER_ID = "userId";
    public static final String STUB_MODE = "stubMode"; 
    public static final String MCC_MOCK = "mccMock";
    public static final String CONTENT_TYPE_JSON =  "application/json";
    public static final String CONTENT_TYPE_MULTIPART =  "multipart/form-data";
    public static final String PRODUCTION =  "prod";
    public static final String DEVELOPMEMNT =  "dev";

    //Format
	public static final String START_DATE = "MMddyyyy";
	public static final String END_DATE = "MMddyyyy";
	
	//healthCheck
    public static final String HEALTHCHECK_PATH = "com.mastercard.risk.safe.healthcheck.*";
    public static final String HEALTHCHECK_URI = "healthcheck";
    
    public static final int VALUE_MIN_LENGTH = 6;
    public static final int CARD_NUM_LENGTH_11 = 11;
	public static final int CARD_NUM_LENGTH_14 = 14;
	public static final int PAN_MAX_LENGTH = 19;
    public static final int PAN_MIN_LENGTH = 16;
    public static final int VALID_ARN_LENGTH = 23;
    public static final int BRN_MAX_LENGTH = 9;
    public static final int ICA_MIN_LENGTH = 3;
    public static final int ICA_MAX_LENGTH = 7;
    public static final int DATE_VALID_LENGTH = 8;
    public static final int DATE_VALID_MONTH = 12;
    public static final int DATE_VALID_DAY = 31;
    public static final int VALID_START_NUMBER = 0;
    public static final int STRING_SUBSTRING_NUMBER = 2;
    public static final int STRING_SUBSTRING_END = 4;
    public static final String DESC_SORT_ORDER = "DESC";
    public static final String ASC_SORT_ORDER = "ASC";
    public static final String CLEARING_GLOBAL_COLLECTION_FLAG ="GCF_TRUE";
    public static final String RECURRING_PAYMENT_FLAG ="RP_TRUE";
    public static final Integer MINIMUM_CHUNK_VALUE = 1;
    
    public static final String VIEW_TYPES = "View Types";
    public static final String USER_VIEW_PREF = "UserViewPref";
    
   //Swagger Constants
    public static final String SWAGGER_URI = "swagger";
    public static final String SWAGGER_URI_API ="api-docs";

    //Roles
    
    public static final String EDS_RULE_ADMIN = "eds-rule-admin";
    public static final String EDS_CUST_ADMIN ="eds-cust-admin";   
    public static final String ROLE_EDS_RULE_ADMIN = "ROLE_EDS_RULE_ADMIN";
    public static final String ROLE_EDS_CUST_ADMIN ="ROLE_EDS_CUST_ADMIN";   
    
   
    //Status 
    public static final int QUEUED_STATUS = 1;
    public static final int ERROR_STATUS = 3;
    public static final int WIP_STATUS = 2;
    public static final int PROCESSED_STATUS = 4;
    public static final int PURGED_STATUS = 5;
   
    public static final String UNDERSCORE = "_";
    public static final String DOT = ".";

    
    public static final int DUPLICATE_DATA_ERROR = 2;
    public static final int DUPLICATE_SUCCESS = 1;
    public static final int RECORD_NOT_DUPLICATE = 0;
    public static final String INTERNAL_SERVER_ERROR = "Internal Server Error";
    public static final String SYSTEM_ACCOUNT = "system";

    public static final String EMPTY_STRING = "";
	public static final String CUSTOMER = "rule";
	public static final String EVENT = "event";
	public static final String REFERENCE = "reference";
	public static final String CPP = "cpp";
	public static final String GET_USER = "getUser";

 
    

}
