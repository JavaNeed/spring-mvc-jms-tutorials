package com.mastercard.ess.eds.controllers;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mastercard.ess.eds.constant.ApplicationLiterals;
import com.mastercard.ess.eds.constant.CommonConstants;
import com.mastercard.ess.eds.exceptions.EDSException;
import com.mastercard.ess.eds.model.CPPRules;
import com.mastercard.ess.eds.request.SearchRequest;
import com.mastercard.ess.eds.response.SearchResponse;
import com.mastercard.ess.eds.service.CPPRulesService;

/**
 * This class fetch the input parameters from consumer and pass this parameters to service layer. 
 * Whatever response getting from service layer send back to consumer.
 * In case of exception, ExceptionController take care of error code and error message
 * and send back to consumer.
 * 
 * @author e066879	
 * @since 22-02-2017
 */
@Api(value = ApplicationLiterals.CPP_RULES_SERVICE, description = ApplicationLiterals.CPP_RULES_SERVICE_DESCRIPTION)
@RestController
@Component 
public class CPPRulesServiceController {

	private static final Logger logger = LoggerFactory.getLogger(CPPRulesServiceController.class);


	@Autowired
	CPPRulesService cppRulesService;

	// for Junit

	public void setCPPRulesServiceController(CPPRulesService cPPRulesService) {
		this.cppRulesService = cPPRulesService;
	}

	/**
	 * This method is responsible for save and update rules. 
	 * This method pass the list of rule objects to service class method. 
	 * Which is used for store the data to database. 
	 *

	 * @param list  This is the request object.	
	 * @return ResponseEntity. 
	 */

	@PreAuthorize("hasRole(T(com.mastercard.ess.eds.constant.ApplicationLiterals).ROLE_EDS_RULE_ADMIN)")
	@ApiOperation(value = ApplicationLiterals.CPP_RULES_SAVE)
	@RequestMapping(value ="/eds/v1/cpp/rules", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity saveOrUpdateRules(@RequestBody List<CPPRules> list , HttpServletRequest request ) throws SQLException{

		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : saveOrUpdateRules");
		}

		List<CPPRules> resultList = cppRulesService.saveOrUpdateRules(list , request);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit From Method : saveOrUpdateRules");
		}
		return new ResponseEntity(resultList, HttpStatus.OK);
	}

	/**
	 * This method is responsible for fetch list of rules. 
	 * Which is used for fetch the data from database. 
	 *

	 * @param list  This is the request object.	
	 * @return list List of rules objects
	 */

	@PreAuthorize("hasRole(T(com.mastercard.ess.eds.constant.ApplicationLiterals).ROLE_EDS_RULE_ADMIN)")
	@ApiOperation(value = ApplicationLiterals.CPP_RULES_SEARCH)
	@RequestMapping(value ="/eds/v1/cpp/rules/search", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<SearchResponse> getRules(@RequestBody SearchRequest searchRequest) {		

		if (logger.isDebugEnabled()) {
			logger.debug("Enter From Method : getRules");
		}	

		SearchResponse response; 

		response = cppRulesService.getRules(searchRequest);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit From Method : getRules");
		}

		return new ResponseEntity<SearchResponse>(response, HttpStatus.OK);
	}

	/**
	 * @param cppIds - contains list of cppIds which has to be deactivated
	 * @param request - using this to get the user details
	 * @param ruleStatus - using this to get the value of status and updated it for the list of cppId's
	 * @return - return the count of deactivated rules
	 */
	@PreAuthorize("hasRole(T(com.mastercard.ess.eds.constant.ApplicationLiterals).ROLE_EDS_RULE_ADMIN)")
	@ApiOperation(value = ApplicationLiterals.CPP_RULES_UPDATE_STATUS)
	@RequestMapping(value ="/eds/v1/cpp/updateRuleStatus/{ruleStatus}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity updateRuleStatus(@PathVariable("ruleStatus") String ruleStatus, @RequestBody Map map, HttpServletRequest request) throws EDSException {		

		if (logger.isDebugEnabled()) {
			logger.debug("Enter From Method : updateRuleStatus");
		}	

		Map<String, String> resultMap = new HashMap<String, String>();

		String lastUpdatedUserId = request.getHeader(CommonConstants.USER_ID);

		String updatedStatus = null;
		List<Integer> cppIds = (List<Integer>) map.get(CommonConstants.CPP_IDS);
		String flag = (String) map.get(CommonConstants.IS_SELECT_ALL_CHECKED);

		if(CommonConstants.TRUE.equals(flag)){
			updatedStatus = cppRulesService.updateRuleStatusWithFlag(cppIds, lastUpdatedUserId, ruleStatus);
		} else {
			updatedStatus = cppRulesService.updateRuleStatus(cppIds, lastUpdatedUserId, ruleStatus);
		}

		if (logger.isDebugEnabled()) {
			logger.debug("Exit From Method : updateRuleStatus");
		}

		if(updatedStatus.equals(CommonConstants.CPP_JOB_RUNNING_ERROR)){
			resultMap.put((String) CommonConstants.CPP_JOB_RUNNING_ERROR, (String) CommonConstants.CPP_JOB_RUNNING_ERROR_MSG);
		}else{
			resultMap.put((String) CommonConstants.UPDATED_COUNT, updatedStatus);
		}

		return new ResponseEntity(resultMap, HttpStatus.OK);
	}

	@PreAuthorize("hasRole(T(com.mastercard.ess.eds.constant.ApplicationLiterals).ROLE_EDS_RULE_ADMIN)")
	@ApiOperation(value = ApplicationLiterals.CPP_RULES_COUNT)
	@RequestMapping(value ="/eds/v1/cpp/ruleCount/{ruleStatus}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity getRuleCount(@PathVariable("ruleStatus") String ruleStatus) {		

		if (logger.isDebugEnabled()) {
			logger.debug("Enter From Method : getRuleCount");
		}	

		Integer result = cppRulesService.getRuleCount(ruleStatus);

		Map<String, Integer> resultMap = new HashMap<String, Integer>();
		resultMap.put("totalCount", result);

		if (logger.isDebugEnabled()) {
			logger.debug("Exit From Method : getRuleCount");
		}

		return new ResponseEntity(resultMap, HttpStatus.OK);
	}


}
