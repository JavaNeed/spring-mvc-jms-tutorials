package com.mastercard.ess.eds;


import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;


public class ServletInitializer extends SpringBootServletInitializer {

	private static final Logger	log	= LoggerFactory.getLogger(ServletInitializer.class);

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(ServicesConfiguration.class);
	}

	@Override
	public void onStartup(ServletContext container) throws ServletException {
		if (log.isDebugEnabled()) {
			log.debug("Enter - onStartup");
		}
		
		String env = System.getProperty("spring.profiles.active");
		if ("".equals(env) || null == env) {
			env = "prod";
		}
		// Loading Configuration Data For EDSServices component
		AnnotationConfigWebApplicationContext context = new AnnotationConfigWebApplicationContext();
		context.setConfigLocation("com.mastercard.ess.eds");
		context.getEnvironment().setActiveProfiles(env);
		ServletRegistration.Dynamic registration = container.addServlet("dispatcher", new DispatcherServlet(context));
		registration.setLoadOnStartup(1);
		registration.addMapping("/*"); // required JBOSS EAP 6 / AS 7
		super.onStartup(container);
		
		if (log.isDebugEnabled()) {
			log.debug("Exit - onStartup");
		}
	}
	
}
