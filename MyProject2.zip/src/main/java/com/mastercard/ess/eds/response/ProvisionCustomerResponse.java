package com.mastercard.ess.eds.response;

import java.util.List;

import com.mastercard.ess.eds.request.ProvisionCustomerData;

public class ProvisionCustomerResponse {
	
	private Integer chunk;
	private Integer chunkSize;
	private Integer totalCount;
	List<ProvisionCustomerData> provisionCustomerData;
	public Integer getChunk() {
		return chunk;
	}
	public void setChunk(Integer chunk) {
		this.chunk = chunk;
	}
	public Integer getChunkSize() {
		return chunkSize;
	}
	public void setChunkSize(Integer chunkSize) {
		this.chunkSize = chunkSize;
	}
	public Integer getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}
	public List<ProvisionCustomerData> getProvisionCustomerData() {
		return provisionCustomerData;
	}
	public void setProvisionCustomerData(
			List<ProvisionCustomerData> provisionCustomerData) {
		this.provisionCustomerData = provisionCustomerData;
	}
	
	
	

}
