package com.mastercard.ess.eds.dao;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.constant.CommonConstants;
import com.mastercard.ess.eds.model.Event;
import com.mastercard.ess.eds.util.HibernateUtils;

/**
 * @author e069468
 *
 */
@Component
public class EventDAO {
	private static final Logger logger = LoggerFactory.getLogger(EventDAO.class);
	
	private static final String DISP_SW = "dispSW";
	private static final String FETCH_EVENT = "select eventId, eventType, eventName, eventDesc FROM com.mastercard.ess.eds.model.Event EVENT WHERE EVENT.dispSW= :dispSW";

	/**This method uses query to fetch all the records present in EDS_EVENT Table
	 * @return
	 * @throws SQLException
	 */
	public List<Event> getEvents() throws SQLException{

		if (logger.isDebugEnabled()) {
			logger.debug("Enter In Method : getEvents");
		}

		SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
		Session session = sessionFactory.openSession();
		List<Event> events = session.createQuery(FETCH_EVENT).setParameter(DISP_SW, CommonConstants.YES).list();

		if (logger.isDebugEnabled()) {
			logger.debug("Exit From  : getEvents");
		}
		return events;
	}
}
