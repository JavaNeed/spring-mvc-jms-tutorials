package com.mastercard.ess.eds;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Configuration
@EnableWebMvc
public class WebMvcConfigAdapter extends WebMvcConfigurerAdapter {
	   private static final Logger logger = LoggerFactory
	            .getLogger(WebMvcConfigAdapter.class);
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/").addResourceLocations("/index.html");
		registry.addResourceHandler("*.html",  "*.js", "*.css", "*.png", "*.jpg", "*.gif", "*.woff", "*.woff2", "*.ttf", "*.ico").addResourceLocations("dist/");
		
		registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources/");
		registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
		
		super.addResourceHandlers(registry);
	}
	public static Logger getLogger() {
		return logger;
	}
	
	@Bean(name = "multipartResolver")
	public CommonsMultipartResolver multipartResolver() {
	    logger.info("Loading the multipart resolver");
	    CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
	    return multipartResolver;
	}
}
