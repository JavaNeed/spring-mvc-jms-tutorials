package com.mastercard.ess.eds.request;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.mastercard.ess.eds.request.Request;
import com.mastercard.ess.eds.util.SortingCriteria;

public class SearchRequest extends Request implements Serializable {

	private static final long serialVersionUID = 1L;
	private HashMap<String, Object> ruleData ;
	private SortingCriteria sort;

	public SearchRequest() {
	}
	
	/**
	 * @param ruleData
	 */
	public SearchRequest(HashMap<String, Object> ruleData) {
		super();
		this.ruleData =  ruleData;
	}

	
	/**
	 * @return the ruleData
	 */
	public Map<String, Object> getruleData() {
		return ruleData;
	}


	/**
	 * @return the sort
	 */
	public SortingCriteria getSort() {
		return sort;
	}

	/**
	 * @param sort the sort to set
	 */
	public void setSort(SortingCriteria sort) {
		this.sort = sort;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SearchRequest [ruleData=" + ruleData + ", sort="
				+ sort + "]";
	}

	
	
}
