package com.mastercard.ess.eds.util;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.mastercard.ess.eds.constant.ApplicationLiterals;
import com.mastercard.ess.eds.constant.ErrorMessages;
import com.mastercard.ess.eds.exceptions.EDSException;
import com.mastercard.ess.eds.exceptions.EDSException.ExceptionType;
import com.mastercard.ess.eds.model.UserDTO;
import com.mastercard.ssi.security.UserIdentity;
import com.mastercard.ssi.security.exceptions.IdentityPropagationException;

@Component
public class UserIdentityUtil {

	private  final Logger logger = LoggerFactory.getLogger(UserIdentityUtil.class);
	
	 
	public UserDTO getUserFromSAML() throws EDSException{
		
		if (logger.isDebugEnabled()) {
			logger.debug("Enter From Method : getUserFromSAML");
		}
		
		UserDTO userDTO  = new UserDTO();
		String userId = null ;
		com.mastercard.ssi.security.UserIdentity userIdentity = null;

		try {        
			userIdentity = new com.mastercard.ssi.security.UserIdentity();
			userId = userIdentity.getUserID();		
			userDTO.setFirstName(userIdentity.getFirstName());			
			userDTO.setMiddleName( userIdentity.getMiddleName());
			userDTO.setLastName( userIdentity.getLastName());
			userDTO.setUserId(userId);
			userDTO.setMemberships(getMembership(userIdentity));
			userDTO.setEnviornment(System.getProperty("environment"));
		} catch (IdentityPropagationException e){
			logger.debug("SAML Parsing Error: " + e.getMessage());
			throw new EDSException(ErrorMessages.SAML_PARSE_ERROR, ExceptionType.AUTHORIZATION_EXCEPTION);
		}  
		
		if (logger.isDebugEnabled()) {
			logger.debug("Exit From Method : getUserFromSAML");
		}
		
		return userDTO ;
	}

	private Map<String, String> getMembership(UserIdentity userIdentity) {
		Map<String, String> membershipMap = new HashMap<String, String>();
		boolean showRule = false;
		boolean showCust = false;
		String[] memberships = null ;
		if(userIdentity!=null){
			memberships = userIdentity.getMembership() ;
		}
		if(memberships!=null && memberships.length > 0){
			for(String membership : memberships){        		   
				if(membership.contains(ApplicationLiterals.EDS_RULE_ADMIN)){
					showRule = true ; 
				} 
				if(membership.contains(ApplicationLiterals.EDS_CUST_ADMIN)){
					showCust = true;
				}
				if(showRule && showCust){
					break;
				}
			}
		}

		if(showRule){
			membershipMap.put(ApplicationLiterals.EDS_RULE_ADMIN, "true");
		}else{
			membershipMap.put(ApplicationLiterals.EDS_RULE_ADMIN, "false");
		}

		if(showCust){        	 
			membershipMap.put(ApplicationLiterals.EDS_CUST_ADMIN, "true"); 
		} else{
			membershipMap.put(ApplicationLiterals.EDS_CUST_ADMIN, "false");
		}
		return membershipMap;
	}
}
