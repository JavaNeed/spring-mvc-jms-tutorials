package com.mastercard.ess.eds.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity // entity should be created via "new" and not injected as spring bean
@Table(name = "EDS_CPP_SIM_DATA", schema = "EDS_OWNER")
public class CPPSimData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="SIM_DATA_ID",unique=true,nullable=false)
	private int simDataId;

	@Column(name = "CPP_RULE_ID")
	private BigDecimal edsCPPRuleId;

	@Column(name = "PAN_CNT_NUM")
	private String panCount;

	@Column(name = "JOB_INSTNCE_ID")
	private BigDecimal jobInstanceId;

	@Column(name = "SIM_SRC_ID")
	private BigDecimal edsSimSrcId;

	@Column(name = "CRTE_DT")
	private Date createDate;

	@Column(name = "CRTE_USER_ID")
	private String createUserId;
	
	@Column(name = "VAL_1")
	private String merchantName;

	public int getSimDataId() {
		return simDataId;
	}

	public void setSimDataId(int simDataId) {
		this.simDataId = simDataId;
	}

	public BigDecimal getEdsCPPRuleId() {
		return edsCPPRuleId;
	}

	public void setEdsCPPRuleId(BigDecimal edsCPPRuleId) {
		this.edsCPPRuleId = edsCPPRuleId;
	}

	public String getPanCount() {
		return panCount;
	}

	public void setPanCount(String panCount) {
		this.panCount = panCount;
	}

	public BigDecimal getJobInstanceId() {
		return jobInstanceId;
	}

	public void setJobInstanceId(BigDecimal jobInstanceId) {
		this.jobInstanceId = jobInstanceId;
	}

	public BigDecimal getEdsSimSrcId() {
		return edsSimSrcId;
	}

	public void setEdsSimSrcId(BigDecimal edsSimSrcId) {
		this.edsSimSrcId = edsSimSrcId;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}
	
	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
}
