package com.mastercard.ess.test.eds;

import static org.junit.Assert.*;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;

import com.mastercard.ess.eds.WebMvcConfigAdapter;

public class WebMvcConfigAdapterTest {
	WebMvcConfigAdapter webMvcConfigAdapter;
	ResourceHandlerRegistry registry;
	ApplicationContext appContext;
	private static final Logger logger = LoggerFactory
            .getLogger(WebMvcConfigAdapter.class);
	@Test
	public void test() {
		
		assertEquals(logger,webMvcConfigAdapter.getLogger());
	}
	
}
