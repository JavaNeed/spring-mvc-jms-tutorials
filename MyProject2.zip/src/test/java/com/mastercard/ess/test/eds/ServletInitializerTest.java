package com.mastercard.ess.test.eds;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Test;

import com.mastercard.ess.eds.ServletInitializer;


public class ServletInitializerTest {
	ServletInitializer servletInitializer;
	ServletContext container;
	private Logger logger = Logger.getLogger(ServletInitializer.class);
	
	@Test(expected = NullPointerException.class)
	public void test() throws ServletException {
		logger.setLevel(Level.DEBUG);
		servletInitializer = new ServletInitializer();
		servletInitializer.onStartup(container);
	}

}
