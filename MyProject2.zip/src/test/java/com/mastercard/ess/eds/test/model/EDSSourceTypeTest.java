package com.mastercard.ess.eds.test.model;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.mastercard.ess.eds.model.EDSSourceType;

public class EDSSourceTypeTest {
	
	@Test
	public void testEDSSourceType(){
		EDSSourceType source = new EDSSourceType();
		source.setIsVendor("test");
		source.setProviderName("test");
		source.setSrcTypeId(0);
		assertNotNull(source.getIsVendor());
		assertNotNull(source.getProviderName());
		assertNotNull(source.getSrcTypeId());
	}

}
