package com.mastercard.ess.eds.test.controllers;

import static org.junit.Assert.assertNotNull;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.controllers.EventServiceController;
import com.mastercard.ess.eds.dao.EventDAO;
import com.mastercard.ess.eds.model.Event;


public class EventServiceTest {
	EventDAO eventDAO;
	EventServiceController eventService;
	List<Event> eventList;
	Event event;
	
	@Before
	public void init() {
		eventList = new ArrayList<Event>();
		event = new Event();
		event.setEventName("test");
		event.setEventType("test");
		event.setEventId(1);
		eventList.add(event);
	}
	@Test
	public void testEventList() throws SQLException {
		eventDAO = EasyMock.createMock(EventDAO.class);
		EasyMock.expect(eventDAO.getEvents()).andReturn(eventList);
		EasyMock.replay(eventDAO);
		eventService = new EventServiceController();
		eventService.setEventService(eventDAO);
		assertNotNull(eventService.getEvents().getStatusCode());
	}

}
