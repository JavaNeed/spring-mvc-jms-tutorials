package com.mastercard.ess.eds.test.service;

import static org.junit.Assert.assertEquals;

import javax.servlet.http.HttpServletRequest;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.dao.ProvisionCustomerDAO;
import com.mastercard.ess.eds.request.ProvisionCustomerData;
import com.mastercard.ess.eds.request.ProvisionCustomerRequest;
import com.mastercard.ess.eds.response.ProvisionCustomerResponse;
import com.mastercard.ess.eds.service.CustomerHelper;

public class CustomerHelperTest {
	CustomerHelper customerHelper;
	ProvisionCustomerDAO   provisionCustomerDao;
	ProvisionCustomerData provisionCustomerData;
	ProvisionCustomerRequest provisionCustReq;
	ProvisionCustomerResponse provisionCustResp;
	HttpServletRequest request;
	
	@Before
	public void init() {
		provisionCustomerDao = EasyMock.createMock(ProvisionCustomerDAO.class);
		EasyMock.expect(provisionCustomerDao
				.saveProvisionCustomer(provisionCustomerData, request)).andReturn(provisionCustomerData);
		EasyMock.expect(provisionCustomerDao.getProvisionCustomerData(provisionCustReq)).andReturn(provisionCustResp);
		EasyMock.replay(provisionCustomerDao);
	}

	@Test
	public void test() {
		customerHelper = new CustomerHelper();
		customerHelper.setProvisionCustomerDao(provisionCustomerDao);
		assertEquals(provisionCustResp, customerHelper.getProvisionCustomerData(provisionCustReq));
		assertEquals(provisionCustomerData, customerHelper.saveProvisionCustomer(provisionCustomerData, request));
	}

}
