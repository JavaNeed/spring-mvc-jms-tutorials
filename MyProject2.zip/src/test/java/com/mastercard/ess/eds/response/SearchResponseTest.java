package com.mastercard.ess.eds.response;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;

import org.junit.Test;

import com.mastercard.ess.eds.response.EventSubscriptionResponse;
import com.mastercard.ess.eds.response.EventSubscriptionSearchResponse;

public class SearchResponseTest {
	
	@Test
	public void testSearchResponse(){
		EventSubscriptionSearchResponse sr = new EventSubscriptionSearchResponse();
		sr.setChunk(1);
		sr.setChunkSize(1);
		sr.setEventSubscriptionResponse(new ArrayList<EventSubscriptionResponse>());
		sr.setTotalCount(1);
		
		assertNotNull(sr.getChunk());
		assertNotNull(sr.getChunkSize());
		assertNotNull(sr.getEventSubscriptionResponse());
		assertNotNull(sr.getTotalCount());
	}

}
