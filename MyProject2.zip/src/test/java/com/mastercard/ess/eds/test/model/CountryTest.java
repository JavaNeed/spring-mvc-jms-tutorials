package com.mastercard.ess.eds.test.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.model.Country;

public class CountryTest {
	Country country;
	@Before
	public void setUp()
	{
		country = new Country();
		country.setCntryName("");
		country.setCntryCode("");
		country.setAlpha3Code("");
		country.setAlpha2Code("");
	}
	@Test
	public void test() {
		assertEquals("",country.getAlpha2Code());
		assertEquals("",country.getAlpha3Code());
		assertEquals("",country.getCntryCode());
		assertEquals("",country.getCntryName());
		
	}

}
