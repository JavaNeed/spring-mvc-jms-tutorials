package com.mastercard.ess.eds.test.service;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.dao.CPPRulesDAO;
import com.mastercard.ess.eds.model.CPPRules;
import com.mastercard.ess.eds.service.CPPRulesService;

public class CPPRulesServiceTest {
	CPPRulesDAO cppRulesDAO;
	CPPRulesService cPPRulesService;
	List<CPPRules> cppRulesList;
	CPPRules cPPRules;
	HttpServletRequest request;

	
	@Before
	public void init() {
		cppRulesList = new ArrayList<CPPRules>();
		cPPRules = new CPPRules();
		cPPRules.setIssuerCntryClause("clause");
		cPPRules.setIssuerCntryValue("issuerCntry");
		cPPRules.setLocalTxnAmountClause("localTxnAmountClause");
		cPPRules.setLocalTxnAmountVal(BigDecimal.valueOf(123));
		cPPRules.setLocationIdClause("locationIdClause");
		cPPRules.setLocationIdValue(BigDecimal.valueOf(456));
		cPPRules.setRuleId(123);
		cPPRules.setTimeUnit("timeUnit");
		cPPRules.setTimeValue(BigDecimal.valueOf(789));
		cppRulesList.add(cPPRules);
		
	}
	@Test
	public void testGetRules() throws Exception {
		
		cppRulesDAO = EasyMock.createMock(CPPRulesDAO.class);
			//EasyMock.expect(cppRulesDAO.getRules()).andReturn(cppRulesList);
			EasyMock.replay(cppRulesDAO);
			cPPRulesService = new CPPRulesService();
			cPPRulesService.setCPPRulesService(cppRulesDAO);
		//	assertEquals(cppRulesList, cPPRulesService.getRules());
	}
	
	@Test
	public void tesSaveOrUpdateRules() throws Exception {
		cppRulesDAO = EasyMock.createMock(CPPRulesDAO.class);
			EasyMock.expect(cppRulesDAO.saveOrUpdateRules(cppRulesList, request)).andReturn(cppRulesList);
			EasyMock.replay(cppRulesDAO);
			cPPRulesService = new CPPRulesService();
			cPPRulesService.setCPPRulesService(cppRulesDAO);
			assertEquals(cppRulesList,cPPRulesService.saveOrUpdateRules(cppRulesList, request));
	}
}
