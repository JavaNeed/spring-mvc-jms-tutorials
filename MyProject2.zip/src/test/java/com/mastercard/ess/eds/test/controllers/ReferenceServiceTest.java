package com.mastercard.ess.eds.test.controllers;

import static org.junit.Assert.*;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.controllers.ReferenceServiceController;
import com.mastercard.ess.eds.exceptions.EDSException;
import com.mastercard.ess.eds.response.ReferenceResponse;
import com.mastercard.ess.eds.request.ICAData;
import com.mastercard.ess.eds.service.ResourceHelper;

public class ReferenceServiceTest {
	ReferenceServiceController referenceService;
	ResourceHelper resourceService;
	ReferenceResponse referenceResponse;
	ICAData iCAData;

	
	@Before
	public void init() {
		resourceService = EasyMock.createMock(ResourceHelper.class);
		EasyMock.expect(resourceService.getResource("icas")).andReturn(referenceResponse);
		EasyMock.expect(resourceService.getUnsignedIca("ica")).andReturn(iCAData);
		EasyMock.replay(resourceService);
	}
	@Test
	public void testReferenceService() throws EDSException {
		referenceService = new ReferenceServiceController();
		referenceService.setResourceService(resourceService);
		assertNotNull(referenceService.getResource("icas"));
		assertNotNull(referenceService.getUnsignedIca("ica"));
	}

}
