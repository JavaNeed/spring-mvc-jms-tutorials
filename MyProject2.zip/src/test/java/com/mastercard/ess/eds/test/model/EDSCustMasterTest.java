package com.mastercard.ess.eds.test.model;

import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.Test;

import com.mastercard.ess.eds.model.EDSCustMaster;
import com.mastercard.ess.eds.model.EDSMemberHier;

public class EDSCustMasterTest {
	
	@Test
	public void testEDSCustMaster(){
		EDSCustMaster custMaster = new EDSCustMaster();
		custMaster.setCustMstrId(0);
		custMaster.setIcaNum(0);
		custMaster.setBulkId("1");
		custMaster.setCreatedDate(new Date());
		custMaster.setCustName("test");
		custMaster.setCustTypeCd("test");
		custMaster.setDefaultNotficationEmail("test");
		custMaster.setEdsMemberHier(new EDSMemberHier());
		custMaster.setEndPoint("test");
		custMaster.setIsActivSW("Y");
		custMaster.setIsSilentSW("Y");
		custMaster.setLastUpdtDate(new Date());
		custMaster.setLastUpdtUserId("test");
		custMaster.setRenewalDate(new Date());
		assertNotNull(custMaster.getBulkId());
		assertNotNull(custMaster.getCustMstrId());
		assertNotNull(custMaster.getCreatedDate());
		assertNotNull(custMaster.getCustName());
		assertNotNull(custMaster.getCustTypeCd());
		assertNotNull(custMaster.getDefaultNotficationEmail());
		assertNotNull(custMaster.getEdsMemberHier());
		assertNotNull(custMaster.getIcaNum());
		assertNotNull(custMaster.getEndPoint());
		assertNotNull(custMaster.getIsActivSW());
		assertNotNull(custMaster.getIsSilentSW());
		assertNotNull(custMaster.getLastUpdtDate());
		assertNotNull(custMaster.getLastUpdtUserId());
		assertNotNull(custMaster.getRenewalDate());
	}
}
