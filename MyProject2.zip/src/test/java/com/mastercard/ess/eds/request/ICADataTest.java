package com.mastercard.ess.eds.request;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class ICADataTest {
	
	@Test
	public void test(){
		ICAData ica = new ICAData();
		ica.setIcaDescription("test");
		ica.setIcaNum(1);
		ica.setOnboarded(true);
		ica.setValid(true);
		assertNotNull(ica.getIcaDescription());
		assertNotNull(ica.getIcaNum());
		assertNotNull(ica.isOnboarded());
		assertNotNull(ica.isValid());
	}

}
