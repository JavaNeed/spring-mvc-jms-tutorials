package com.mastercard.ess.eds.test.model;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.Date;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.mastercard.ess.eds.model.CPPRules;

public class CPPRulesTest {

	CPPRules cPPRules;
	@Before
	public void setUp()
	{
		BigDecimal sample = new BigDecimal(0);
		Integer sample1 = new Integer(0);
		cPPRules = new CPPRules();
		cPPRules.setIssuerCntryClause("");
		cPPRules.setIssuerCntryValue("");
		cPPRules.setLocalTxnAmountClause("");
		cPPRules.setLocationIdClause("");
		cPPRules.setLocationIdValue(sample);
		cPPRules.setRuleId(sample1);
		cPPRules.setTimeUnit("");
		cPPRules.setTimeValue(sample);
		cPPRules.setLocalTxnAmountVal(sample);
		cPPRules.setActiveSW("");
		cPPRules.setCreateUserId("");
		cPPRules.setFirstRunSW("");
		cPPRules.setIsDuplicate("");
		cPPRules.setLastUpdatedUserId("");
		cPPRules.setCreateDate(new Date(0L));
		cPPRules.setLastUpdatedDate(new Date(0L));
		
	}
	
	@Test
	public void test() {
		assertEquals("",cPPRules.getIssuerCntryClause());
		assertEquals("",cPPRules.getIssuerCntryValue());
		assertEquals("",cPPRules.getLocalTxnAmountClause());
		assertEquals("",cPPRules.getLocationIdClause());
		assertEquals(new BigDecimal(0),cPPRules.getLocationIdValue());
		assertEquals(0,cPPRules.getRuleId());
		assertEquals(new BigDecimal(0),cPPRules.getTimeValue());
		assertEquals(new BigDecimal(0),cPPRules.getLocalTxnAmountVal());
		assertEquals("",cPPRules.getTimeUnit());
		assertEquals("",cPPRules.getActiveSW());
		assertEquals("",cPPRules.getCreateUserId());
		assertEquals("",cPPRules.getLastUpdatedUserId());
		assertEquals("",cPPRules.getFirstRunSW());
		assertEquals("",cPPRules.getIsDuplicate());
		assertEquals(new Date(0L),cPPRules.getCreateDate());
		assertEquals(new Date(0L),cPPRules.getLastUpdatedDate());
		cPPRules.toString();
	}

}
