package com.mastercard.ess.eds.test.model;

import static org.junit.Assert.*;

import org.junit.Test;

import com.mastercard.ess.eds.request.RequestHeader;

public class RequestHeaderTest {
	RequestHeader requestHeader;
	
	
	@Test
	public void testStubConditionF() {
		requestHeader = new RequestHeader("", "F");
		assertEquals("",requestHeader.getContentType());
		assertEquals("F",requestHeader.getStubMode());
		assertEquals(Boolean.TRUE,requestHeader.isStubbed());
		assertEquals("F",requestHeader.getStubCondition());
	}

	@Test
	public void testStubConditionS() {
		requestHeader = new RequestHeader("", "S");
		assertEquals("",requestHeader.getContentType());
		assertEquals("S",requestHeader.getStubMode());
		assertEquals(Boolean.TRUE,requestHeader.isStubbed());
		assertEquals("S",requestHeader.getStubCondition());
	}
	
	@Test
	public void testNullStub() {
		requestHeader = new RequestHeader("", null);
		assertEquals("",requestHeader.getContentType());
		assertEquals(null,requestHeader.getStubMode());
		assertEquals(Boolean.FALSE,requestHeader.isStubbed());
		assertEquals("S",requestHeader.getStubCondition());
	}

	@Test
	public void testtoString() {
		requestHeader = new RequestHeader();
		requestHeader = new RequestHeader("", null);
		assertEquals("RequestHeader [contentType=" + "" + ", stubMode=" + null + "]",requestHeader.toString());
		
	}
}
