package com.mastercard.ess.eds.response;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.mastercard.ess.eds.request.ProvisionCustomerData;

public class ProvisionCustomerResponseTest {
	
	@Test
	public void testProvisionCustomerResponse(){
		ProvisionCustomerResponse resp = new ProvisionCustomerResponse();
		resp.setChunk(1);
		resp.setChunkSize(5);
		List<ProvisionCustomerData> pcdList = new ArrayList<ProvisionCustomerData>();
		resp.setProvisionCustomerData(pcdList);
		resp.setTotalCount(10);
		assertNotNull(resp.getChunk());
		assertNotNull(resp.getChunkSize());
		assertNotNull(resp.getProvisionCustomerData());
		assertNotNull(resp.getTotalCount());
	}

}
