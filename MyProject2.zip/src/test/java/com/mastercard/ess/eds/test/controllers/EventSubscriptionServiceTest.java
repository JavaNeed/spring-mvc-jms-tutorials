package com.mastercard.ess.eds.test.controllers;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.controllers.EventSubscriptionServiceController;
import com.mastercard.ess.eds.dao.EventSubscriptionDAO;
import com.mastercard.ess.eds.exceptions.EDSException;
import com.mastercard.ess.eds.model.EventSubscription;
import com.mastercard.ess.eds.request.EventSubscriptionRequest;
import com.mastercard.ess.eds.request.EventSubscriptions;
import com.mastercard.ess.eds.response.EventSubscriptionSearchResponse;

public class EventSubscriptionServiceTest {

	EventSubscriptionServiceController eventSubscriptionService;
	EventSubscriptionDAO eventSubscriptionDAO;
	EventSubscriptions evntSubs;
	EventSubscriptionRequest request;
	EventSubscription eventSubscription;
	EventSubscriptionSearchResponse eventSubscriptionSearchResponse;
	List<Integer> list;
	HttpServletRequest httpRequest;
	
	@Before
	public void init() {
		list = new ArrayList<Integer>();
		list.add(1);
		eventSubscriptionDAO = EasyMock.createMock(EventSubscriptionDAO.class);
		EasyMock.expect(eventSubscriptionDAO.saveOrUpdateEventSubscription(evntSubs, httpRequest)).andReturn(new ArrayList<EventSubscription>());
		EasyMock.expect(eventSubscriptionDAO.searchEventSubscription(request)).andReturn(eventSubscriptionSearchResponse);
		eventSubscriptionDAO.deleteEventSubscription(list);
		EasyMock.expectLastCall();
		EasyMock.replay(eventSubscriptionDAO);
	}
	@Test
	public void test() throws EDSException {
		eventSubscriptionService = new EventSubscriptionServiceController();
		eventSubscriptionService.setEventSubscriptionService(eventSubscriptionDAO);
		assertNotNull(eventSubscriptionService.saveOrUpdateEventSubscription(evntSubs, httpRequest));
		assertNotNull(eventSubscriptionService.displayEvents(request));
        assertNotNull(eventSubscriptionService.deleteEventSubscription(list));
		
	}

}
