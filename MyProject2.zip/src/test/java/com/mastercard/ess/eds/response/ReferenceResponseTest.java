package com.mastercard.ess.eds.response;

import static org.junit.Assert.assertNotNull;

import java.util.HashMap;

import org.junit.Test;

import com.mastercard.ess.eds.response.ReferenceResponse;

public class ReferenceResponseTest {
	
	@Test
	public void testReferenceResponse(){
		ReferenceResponse rr = new ReferenceResponse();
		rr.setReferences(new HashMap<String, String>());
		rr.setReferenceType("test");
		
		assertNotNull(rr.getReferences());
		assertNotNull(rr.getReferenceType());
	}

}
