package com.mastercard.ess.eds.response;

import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.Test;

import com.mastercard.ess.eds.response.EventSubscriptionResponse;

public class EventSubscriptionResponseTest {
	
	@Test
	public void testEvntSubsResp(){
		EventSubscriptionResponse esr = new EventSubscriptionResponse();
		esr.setCreatedDate(new Date());
		esr.setEmailId("test");
		esr.setEventId("test");
		esr.setEventName("test");
		esr.setEventSubscriptionId("test");
		esr.setEventType("test");
		esr.setIca("test");
		esr.setVendorName("test");
		
		assertNotNull(esr.getCreatedDate());
		assertNotNull(esr.getEmailId());
		assertNotNull(esr.getEventId());
		assertNotNull(esr.getEventName());
		assertNotNull(esr.getEventSubscriptionId());
		assertNotNull(esr.getEventType());
		assertNotNull(esr.getIca());
		assertNotNull(esr.getVendorName());
	}

}
