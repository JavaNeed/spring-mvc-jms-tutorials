package com.mastercard.ess.eds.test.model;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.mastercard.ess.eds.model.EDSMemberHier;

public class EDSMemberHierTest {
	
	@Test
	public void testMembHier(){
		EDSMemberHier mHier = new EDSMemberHier();
		mHier.setAccessName("test");
		mHier.setIcaCode(0);
		mHier.setParentIcaId(0);
		assertNotNull(mHier.getAccessName());
		assertNotNull(mHier.getIcaCode());
		assertNotNull(mHier.getParentIcaId());
	}

}
