package com.mastercard.ess.eds.test.controllers;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.mastercard.ess.eds.controllers.BaseController;
import com.mastercard.ess.eds.exceptions.EDSException;

public class BaseControllerTest {
	BaseController baseController;
	List<Integer> list = new ArrayList<Integer>();
	
	@Test(expected = EDSException.class)
	public void test() throws EDSException {
		baseController = new BaseController();
		ReflectionTestUtils.invokeMethod(baseController, "validateEndpoint", "");
		ReflectionTestUtils.invokeMethod(baseController, "validateICA", "");
		ReflectionTestUtils.invokeMethod(baseController, "validateResource", "");
		baseController.validateList(list);
	}

}
