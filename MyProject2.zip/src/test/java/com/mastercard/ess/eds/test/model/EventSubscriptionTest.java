package com.mastercard.ess.eds.test.model;

import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.Test;

import com.mastercard.ess.eds.model.EDSSourceType;
import com.mastercard.ess.eds.model.Event;
import com.mastercard.ess.eds.model.EventSubscription;

public class EventSubscriptionTest {
	
	@Test
	public void testEventSubscription(){
		EventSubscription es = new EventSubscription();
		es.setCreateDate(new Date());
		es.setCreateUserId("test");
		es.setEdsSourceTypeId(0);
		es.setEmailId("test");
		es.setEnabledSW("test");
		es.setEventId(1);
		es.setEventName("test");
		es.setEventSubsId(1);
		es.setIca(1);
		es.setLstUpdtdt(new Date());
		es.setLstUpdtUserId("test");
		es.setOrgName("test");
		es.setEvent(new Event());
		es.setEdsSourceType(new EDSSourceType());
		
		assertNotNull(es.getCreateDate());
		assertNotNull(es.getCreateUserId());
		assertNotNull(es.getEdsSourceTypeId());
		assertNotNull(es.getEmailId());
		assertNotNull(es.getEnabledSW());
		assertNotNull(es.getEventId());
		assertNotNull(es.getEventName());
		assertNotNull(es.getEventSubsId());
		assertNotNull(es.getIca());
		assertNotNull(es.getLstUpdtdt());
		assertNotNull(es.getLstUpdtUserId());
		assertNotNull(es.getOrgName());
		assertNotNull(es.getEvent());
		assertNotNull(es.getEdsSourceType());
	}

}
