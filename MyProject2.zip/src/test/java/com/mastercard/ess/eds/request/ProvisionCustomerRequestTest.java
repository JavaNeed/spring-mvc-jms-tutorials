package com.mastercard.ess.eds.request;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.mastercard.ess.eds.util.SortingCriteria;

public class ProvisionCustomerRequestTest {

	@Test
	public void testProvisonCustomerRequest(){
		ProvisionCustomerRequest req = new ProvisionCustomerRequest();
		req.setChunk(1);
		req.setChunkSize(5);
		req.setEventCriteria(new EventCriteria());
		req.setSort(new SortingCriteria());
		assertNotNull(req.getChunk());
		assertNotNull(req.getChunkSize());
		assertNotNull(req.getEventCriteria());
		assertNotNull(req.getSort());
	}
}
