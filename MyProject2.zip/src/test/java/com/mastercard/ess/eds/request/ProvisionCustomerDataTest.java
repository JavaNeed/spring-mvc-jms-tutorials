package com.mastercard.ess.eds.request;

import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.Test;

public class ProvisionCustomerDataTest {
	
	@Test
	public void testProvisionCustomerData(){
		ProvisionCustomerData data = new ProvisionCustomerData();
		data.setBulkId("1");
		data.setCreatedDate(new Date());
		data.setDefaultNotficationEmail("test");
		data.setDuplicate(true);
		data.setEdsCustMasterId(1);
		data.setEndPoint("test");
		data.setIca(1);
		data.setIcaDescription("test");
		data.setIsActiveSW("test");
		data.setRenewalDate(new Date());
		assertNotNull(data.getBulkId());
		assertNotNull(data.getCreatedDate());
		assertNotNull(data.getDefaultNotficationEmail());
		assertNotNull(data.getEdsCustMasterId());
		assertNotNull(data.getEndPoint());
		assertNotNull(data.getIca());
		assertNotNull(data.getIcaDescription());
		assertNotNull(data.getIsActiveSW());
		assertNotNull(data.getRenewalDate());
	}

}
