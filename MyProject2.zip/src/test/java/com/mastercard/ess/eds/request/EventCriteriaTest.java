package com.mastercard.ess.eds.request;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.mastercard.ess.eds.request.EventCriteria;

public class EventCriteriaTest {
	
	@Test
	public void testEventCriteria(){
		EventCriteria ec = new EventCriteria();
		ec.setEmailId(null);
		ec.setEventId(null);
		ec.setIca(null);
		ec.setVendorName("test");
		assertEquals(null, ec.getEmailId());
		assertEquals(null, ec.getEventId());
		assertEquals(null, ec.getIca());
		assertNotNull(ec.getVendorName());
		
	}

}
