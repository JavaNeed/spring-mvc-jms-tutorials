package com.mastercard.ess.eds.test.exceptions;

import static org.junit.Assert.*;

import org.easymock.EasyMock;
import org.junit.Test;

import com.mastercard.ess.eds.constant.ErrorMessages;
import com.mastercard.ess.eds.exceptions.EDSException;
import com.mastercard.ess.eds.exceptions.EDSException.ExceptionType;

public class EDSExceptionTest {
	EDSException eDSException;
	@Test
	public void testExceptionType() {
		
		eDSException = new EDSException(new Exception() , ErrorMessages.HEADER_VALIDATION, ExceptionType.VALIDATION_EXCEPTION);
		eDSException.getExceptionType();
		assertEquals(ExceptionType.VALIDATION_EXCEPTION, eDSException.getExceptionType());
	}
	
	@Test
	public void testErrorCode() {
		
		eDSException = new EDSException(ErrorMessages.HEADER_VALIDATION, ExceptionType.VALIDATION_EXCEPTION);
		eDSException.getErrorCode();
		assertEquals("FLT0001", eDSException.getErrorCode());
	}

	@Test
	public void testExceptionTypeOne() {
		
		eDSException = new EDSException(new Exception() , ErrorMessages.HEADER_VALIDATION, ExceptionType.BUSINESS_EXCEPTION);
		eDSException.getExceptionType();
		assertEquals(ExceptionType.BUSINESS_EXCEPTION, eDSException.getExceptionType());
	}
	
	@Test
	public void testExceptionTypeTwo() {
		
		eDSException = new EDSException(new Exception() , ErrorMessages.HEADER_VALIDATION, ExceptionType.AUTHORIZATION_EXCEPTION);
		eDSException.getExceptionType();
		assertEquals(ExceptionType.AUTHORIZATION_EXCEPTION, eDSException.getExceptionType());
	}
}
