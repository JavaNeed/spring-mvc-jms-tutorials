package com.mastercard.ess.eds.test.service;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;






import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.mastercard.ess.eds.dao.CountryListDAO;
import com.mastercard.ess.eds.model.Country;
import com.mastercard.ess.eds.service.CountryListService;

public class CountryListServiceTest {
	CountryListDAO cntryListDAO;
	CountryListService countryListService;
	List<Country> countryList;
	Country country;
	
	@Before
	public void init() {
		countryList = new ArrayList<Country>();
		country = new Country();
		country.setAlpha2Code("alpha2Code");
		country.setAlpha3Code("alpha3Code");
		country.setCntryCode("cntryCode");
		country.setCntryName("INDIA");
		countryList.add(country);
	}
	@Test
	public void testCountryList() {
		cntryListDAO = EasyMock.createMock(CountryListDAO.class);
		EasyMock.expect(cntryListDAO.getCountryList()).andReturn(countryList);
		EasyMock.replay(cntryListDAO);
		countryListService = new CountryListService();
		countryListService.CountryListDAO(cntryListDAO);
		assertEquals(countryList,countryListService.getCountryList());
	}
	
	@Test
	public void testCountryDao() {
		cntryListDAO = EasyMock.createMock(CountryListDAO.class);
		EasyMock.expect(cntryListDAO.getCountryList()).andReturn(countryList);
		EasyMock.replay(cntryListDAO);
		countryListService = new CountryListService();
		countryListService.CountryListDAO(cntryListDAO);
		countryListService.CountryListDAO(cntryListDAO);
	}
	
	@Test
	public void testCountryListService() {
		cntryListDAO = EasyMock.createMock(CountryListDAO.class);
		EasyMock.expect(cntryListDAO.getCountryList()).andReturn(countryList);
		EasyMock.replay(cntryListDAO);
		countryListService = new CountryListService();
		countryListService.setCountryListService(cntryListDAO);
		
	}
}
