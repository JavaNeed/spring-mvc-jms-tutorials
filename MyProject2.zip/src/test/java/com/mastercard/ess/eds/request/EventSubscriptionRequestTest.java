package com.mastercard.ess.eds.request;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.mastercard.ess.eds.request.EventCriteria;
import com.mastercard.ess.eds.request.EventSubscriptionRequest;
import com.mastercard.ess.eds.util.SortingCriteria;

public class EventSubscriptionRequestTest {
	
	@Test
	public void testEventSubsTest(){
		EventSubscriptionRequest esr = new EventSubscriptionRequest();
		esr.setChunk(1);
		esr.setChunkSize(1);
		esr.setEventCriteria(new EventCriteria());
		esr.setSort(new SortingCriteria());
		
		assertNotNull(esr.getChunk());
		assertNotNull(esr.getChunkSize());
		assertNotNull(esr.getEventCriteria());
		assertNotNull(esr.getSort());
	}

}
