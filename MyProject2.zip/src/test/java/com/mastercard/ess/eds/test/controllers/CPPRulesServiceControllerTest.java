package com.mastercard.ess.eds.test.controllers;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.web.bind.annotation.RequestBody;

import com.mastercard.ess.eds.controllers.CPPRulesServiceController;
import com.mastercard.ess.eds.dao.CPPRulesDAO;
import com.mastercard.ess.eds.dao.CountryListDAO;
import com.mastercard.ess.eds.model.CPPRules;
import com.mastercard.ess.eds.service.CPPRulesService;
import com.mastercard.ess.eds.service.CountryListService;

public class CPPRulesServiceControllerTest {
	CPPRulesServiceController cPPRulesServiceController;
	CPPRulesDAO cppRulesDAO;
	CPPRulesService cPPRulesService;
	List<CPPRules> cppRulesList;
	HttpServletRequest request;
	CPPRules cPPRules;
	
	@Before
	public void init() throws Exception {
		cppRulesList = new ArrayList<CPPRules>();
		cPPRules = new CPPRules();
		cPPRules.setIssuerCntryClause("clause");
		cPPRules.setIssuerCntryValue("issuerCntry");
		cPPRules.setLocalTxnAmountClause("localTxnAmountClause");
		cPPRules.setLocalTxnAmountVal(BigDecimal.valueOf(123));
		cPPRules.setLocationIdClause("locationIdClause");
		cPPRules.setLocationIdValue(BigDecimal.valueOf(456));
		cPPRules.setRuleId(123);
		cPPRules.setTimeUnit("timeUnit");
		cPPRules.setTimeValue(BigDecimal.valueOf(789));
		cppRulesList.add(cPPRules);
		cppRulesDAO = EasyMock.createMock(CPPRulesDAO.class);
	//	EasyMock.expect(cppRulesDAO.getRules()).andReturn(cppRulesList);
		EasyMock.expect(cppRulesDAO.saveOrUpdateRules(cppRulesList, request)).andReturn(cppRulesList);
		EasyMock.replay(cppRulesDAO);
		cPPRulesService = new CPPRulesService();
		cPPRulesService.setCPPRulesService(cppRulesDAO);
		
	}
	
	@Test
	public void testSaveOrUpdate() throws Exception {
		cPPRulesServiceController = new CPPRulesServiceController();
		cPPRulesServiceController.setCPPRulesServiceController(cPPRulesService);
		cPPRulesServiceController.saveOrUpdateRules(cppRulesList, request);
	}
	
	@Test
	public void testgetRules() throws Exception {
		cPPRulesServiceController = new CPPRulesServiceController();
		cPPRulesServiceController.setCPPRulesServiceController(cPPRulesService);
		//cPPRulesServiceController.getRules();
	}

}
