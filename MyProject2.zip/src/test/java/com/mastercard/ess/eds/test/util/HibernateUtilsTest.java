package com.mastercard.ess.eds.test.util;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.junit.Before;
import org.junit.Test;




import com.mastercard.ess.eds.util.HibernateUtils;

public class HibernateUtilsTest {
	
	private Logger logger = Logger.getLogger(HibernateUtils.class);
	
@Before
public void init() {
	logger.setLevel(Level.DEBUG);
}
	@Test
	public void test() {
		HibernateUtils.getSessionFactory();
	}

}
