package com.mastercard.ess.eds.test.service;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.dao.CountryListDAO;
import com.mastercard.ess.eds.dao.ICAListDAO;
import com.mastercard.ess.eds.dao.VendorListDAO;
import com.mastercard.ess.eds.model.Country;
import com.mastercard.ess.eds.request.ICAData;
import com.mastercard.ess.eds.response.ReferenceResponse;
import com.mastercard.ess.eds.service.ResourceHelper;

public class ResourceHelperTest {
	ResourceHelper resourceHelper;
	VendorListDAO vendorListDAO;
	ICAListDAO icaListDAO;
	CountryListDAO countryListDAO;
	ReferenceResponse referenceResponse;
	ICAData iCAData;
	Country country;
	List<Country> countryList;
	
	@Before
	public void init() {
		country = new Country();
		country.setAlpha2Code("alpha2Code");
		country.setAlpha3Code("alpha3Code");
		country.setCntryCode("cntryCode");
		country.setCntryName("INDIA");
		countryList = new ArrayList<Country>();
		countryList.add(country);
		icaListDAO = EasyMock.createMock(ICAListDAO.class);
		vendorListDAO = EasyMock.createMock(VendorListDAO.class);
		countryListDAO = EasyMock.createMock(CountryListDAO.class);
		EasyMock.expect(vendorListDAO.getVendorList("vendors")).andReturn(referenceResponse);
		EasyMock.replay(vendorListDAO);
		EasyMock.expect(countryListDAO.getCountryList()).andReturn(countryList);
		EasyMock.replay(countryListDAO);
		EasyMock.expect(icaListDAO.getUnsignedICAList("unSignedIca", "ica")).andReturn(iCAData);
		EasyMock.expect(icaListDAO.getSignedICAList("icas")).andReturn(referenceResponse);
		EasyMock.replay(icaListDAO);
	}
	
	@Test
	public void testGetUnsignedIca() {
		resourceHelper = new ResourceHelper();
		resourceHelper.setDao(icaListDAO, vendorListDAO, countryListDAO);
		resourceHelper.getUnsignedIca("ica");
	}

	@Test
	public void testgetCountryResource() {
		resourceHelper = new ResourceHelper();
		resourceHelper.setDao(icaListDAO, vendorListDAO, countryListDAO);
		resourceHelper.getResource("country");
		resourceHelper.getResource("vendors");
		resourceHelper.getResource("icas");
		resourceHelper.getResource("ica");
	}
}
