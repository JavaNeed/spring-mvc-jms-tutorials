package com.mastercard.ess.eds.test.model;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.mastercard.ess.eds.model.Event;

public class EventTest {
	
	@Test
	public void testEvent(){
		Event e = new Event();
		e.setEventId(0);
		e.setEventName("test");
		e.setEventType("test");
		assertNotNull(e.getEventId());
		assertNotNull(e.getEventType());
		assertNotNull(e.getEventName());
	}

}
