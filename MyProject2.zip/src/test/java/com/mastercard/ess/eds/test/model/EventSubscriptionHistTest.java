package com.mastercard.ess.eds.test.model;

import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.Test;

import com.mastercard.ess.eds.model.EventSubscriptionHist;

public class EventSubscriptionHistTest {
	
	@Test
	public void testEventSubscriptionHist(){
		EventSubscriptionHist hist = new EventSubscriptionHist();
		hist.setCreateDate(new Date());
		hist.setCreateUserId("test");
		hist.setEdsSourceTypeId(1);
		hist.setEmailId("test");
		hist.setEnabledSW("Y");
		hist.setEventId(1);
		hist.setEventSubsId(1);
		hist.setEvntSubsHistId(1);
		hist.setIca(1);
		hist.setLstUpdtdt(new Date());
		hist.setLstUpdtUserId("test");
		hist.setOrgName("test");
		assertNotNull(hist.getCreateDate());
		assertNotNull(hist.getCreateUserId());
		assertNotNull(hist.getEdsSourceTypeId());
		assertNotNull(hist.getEmailId());
		assertNotNull(hist.getEnabledSW());
		assertNotNull(hist.getEventId());
		assertNotNull(hist.getEventSubsId());
		assertNotNull(hist.getEvntSubsHistId());
		assertNotNull(hist.getIca());
		assertNotNull(hist.getLstUpdtdt());
		assertNotNull(hist.getLstUpdtUserId());
		assertNotNull(hist.getOrgName());
	}

}
