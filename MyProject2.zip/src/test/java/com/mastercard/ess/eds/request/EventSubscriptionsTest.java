package com.mastercard.ess.eds.request;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.mastercard.ess.eds.request.EventSubscriptions;

public class EventSubscriptionsTest {
	
	@Test
	public void testEvntSubs(){
		EventSubscriptions es = new EventSubscriptions();
		es.setEmailId(null);
		es.setEventId(1);
		es.setIcas(null);
		es.setVendorId(1);
		
		assertEquals(null, es.getEmailId());
		assertNotNull(es.getEventId());
		assertNotNull(es.getVendorId());
		assertEquals(null, es.getIcas());
	}

}
