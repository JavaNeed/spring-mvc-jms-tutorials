package com.mastercard.ess.eds.test.controllers;

import static org.junit.Assert.*;

import javax.servlet.http.HttpServletRequest;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.mastercard.ess.eds.controllers.CustomerServiceController;
import com.mastercard.ess.eds.exceptions.EDSException;
import com.mastercard.ess.eds.service.CustomerHelper;
import com.mastercard.ess.eds.request.ProvisionCustomerData;
import com.mastercard.ess.eds.request.ProvisionCustomerRequest;
import com.mastercard.ess.eds.response.ProvisionCustomerResponse;

public class CustomerServiceTest {
	
	CustomerServiceController customerService;
	ProvisionCustomerData provisionCustomerData;
	CustomerHelper customerHelper;
	ProvisionCustomerRequest provisionCustomerRequest;
	ProvisionCustomerResponse provisionCustomerResponse;
	HttpServletRequest request;

	
	@Before
	public void init() {
		provisionCustomerData = new ProvisionCustomerData();
		provisionCustomerData.setEndPoint("EndPoint");
		provisionCustomerRequest= new ProvisionCustomerRequest();
		provisionCustomerRequest.setChunk(1);
		customerHelper = EasyMock.createMock(CustomerHelper.class);
		EasyMock.expect(customerHelper.saveProvisionCustomer(provisionCustomerData, request)).andReturn(provisionCustomerData);
		EasyMock.expect(customerHelper.getProvisionCustomerData(provisionCustomerRequest)).andReturn(provisionCustomerResponse);
		EasyMock.replay(customerHelper);
	}
	
	@Test
	public void testSaveProvisionCustomer() throws EDSException {
		customerService = new CustomerServiceController();
		customerService.setCustomerHelper(customerHelper);
		assertNotNull(customerService.saveProvisionCustomer(provisionCustomerData, request));	
		
	}

	@Test
	public void testDisplayProvisionCustomer() throws EDSException {
		customerService = new CustomerServiceController();
		customerService.setCustomerHelper(customerHelper);
		assertNotNull(customerService.displayProvisionCustomer(provisionCustomerRequest));
	}
}
